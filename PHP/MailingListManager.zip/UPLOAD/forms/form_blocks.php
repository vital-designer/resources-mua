<?php
function showsection($id_section = "")
{
				global $smarty;
				global $dbconn;
				global $config;
				global $admin_nl_gentemplates;
				$file_name = isset($_SERVER['PHP_SELF']) ? basename($_SERVER['PHP_SELF']) : "form_blocks.php";
				$form = new form($dbconn, $config);
				$sections = $form->getsections();
				if ($id_section == "" && isset($sections[0]))
				{
								$id_section = $sections[0]['id'];
				}
				$new_section_link = $file_name . "?sel=add_new_section";
				$del_section_link = $file_name . "?sel=del_section&id_sec=";
				$smarty->assign("new_section_link", $new_section_link);
				$smarty->assign("del_section_link", $del_section_link);
				$smarty->assign("count", count($sections));
				$smarty->assign("sections", $sections);
				$smarty->assign("id_section", $id_section);
				$smarty->display("{$admin_nl_gentemplates}/forms_form_blocks.tpl");
				exit();
}
function addnewsection()
{
				global $dbconn;
				global $config;
				$form = new form($dbconn, $config);
				$data['name'] = $_POST['new_sec_name'];
				$new_id = $form->addnewsection($data);
				showsection($new_id);
}
function delsection($id_section)
{
				global $dbconn;
				global $config;
				$form = new form($dbconn, $config);
				$form->delsection($id_section);
				showsection();
}
include ("../include/config.php");
include_once ("../common.php");
include ("../include/class.form.php");
$section = "forms";
$right_name = "view";
check_right($section, $right_name);
$sel = $_GET['sel'] ? $_GET['sel'] : $_POST['sel'];
$smarty->assign("razdel", "Forms");
$smarty->assign("description", "Manage Subscription Form Fields");
$smarty->assign("hint", "Here you can manage the fields of the subscription from. The fields can be added, removed or modified.");
switch ($sel)
{
				case "add_new_section":
								addnewsection();
								break;
				case "del_section":
								delsection($_REQUEST['id_sec']);
								break;
				default:
								$id_section = isset($_REQUEST['id_section']) ? $_REQUEST['id_section']:
								"";
								showsection($id_section);
								break;
}
?>
