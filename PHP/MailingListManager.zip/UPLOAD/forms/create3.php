<?php
error_reporting(E_ALL);
include ("../common.php");
include ("../include/forms_function.php");
if (isset($_POST['FormName']))
{
				if (0 < $_REQUEST['id'])
				{
								$form = getformcontent($_REQUEST['id']);
				}
				else
				{
								$res = $dbconn->execute("select * from settings");
								$form = $res->getrowassoc(false);
								$form['confirmation_url'] = "http&#58;//";
								$form['thankyou_url'] = "http&#58;//";
								if ($_POST['FormType'] == "unsub")
								{
												$form['confirmation_subject'] = "Unsubscription confirmation";
												$form['confirmation_email'] = "Hi, Please click on the link below to confirm your unsubscription: &lt;a href=&quot;%CONFIRMLINK%&quot;&gt;Confitm E-mail&lt;/a&gt;";
												$form['confirmation_text'] = "<html><title>Unsubscription Confirmation</title></head><body><font face=Verdana size=2>Please check your email to confirm your unsubscription...</font></body></html>";
												$form['thankyou_subject'] = "We feel sorry you unsubscribe.";
												$form['thankyou_email'] = "Hi, Your unsubscription is now completed. It's a shame to see you go!";
												$form['thankyou_text'] = "<html><title>Unsubscription Confirmed</title></head><body><font face=Verdana size=2>You have been successfully removed from our mailing list.</font></body></html>";
								}
								else
								{
												$form['confirmation_subject'] = "Subscription confirmation";
												$form['confirmation_email'] = "Hi, Please click on the link below to confirm your subscription: &lt;a href=&quot;%CONFIRMLINK%&quot;&gt;Confirm E-mail&lt;/a&gt;";
												$form['confirmation_text'] = "<html><title>Subscription Confirmation</title></head><body><font face=Verdana size=2>Please check your email to confirm your subscription...</font></body></html>";
												$form['thankyou_subject'] = "Thank you for subscription.";
												$form['thankyou_email'] = "Hi, Your subscription is now completed.";
												$form['thankyou_text'] = "<html><title>Subscription Confirmed</title></head><body><font face=Verdana size=2>You have been successfully added to our mailing list.</font></body></html>";
								}
				}
				$smarty->assign("form", $form);
				$smarty->assign("name", $_POST['FormName']);
				$smarty->assign("Lists", $_POST['Lists']);
				$smarty->assign("RequireConfirm", $_POST['RequireConfirm']);
				$smarty->assign("SendThankyou", $_POST['SendThankyou']);
				$smarty->assign("FormType", $_POST['FormType']);
				$smarty->assign("captcha", $_POST['captcha']);
				$smarty->assign("razdel", "Forms");
				$smarty->assign("description", "New Form Creating: Step 3");
				$smarty->assign("hint", "Here you determine an image a user will see during subscription or unsubscription process.");
				$smarty->display("{$admin_nl_gentemplates}/forms_create_form3.tpl");
}
else
{
				$smarty->assign("razdel", "Forms");
				$smarty->assign("description", "New Form Creating: Step 1");
				$smarty->assign("hint", "Please enter name of the form and choose its type.");
				$smarty->display("{$admin_nl_gentemplates}/forms_create_form1.tpl");
}
?>
