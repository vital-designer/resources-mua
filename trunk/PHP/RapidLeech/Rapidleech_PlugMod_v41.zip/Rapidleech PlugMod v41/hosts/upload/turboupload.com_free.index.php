<?php
$upload_services[]="turboupload.com_free";
$max_file_size["turboupload.com_free"]=100;
$page_upload["turboupload.com_free"] = "turboupload.com_free.php";  
?>