<?
//phpFormBuilder Version 1.5 by Baris Kayar (barishkayar@yahoo.com)
//2002(cl)  The FormBuilder Group http://pfb.sourceforge.net

setcookie("BaRTPFBuser","",0);
setcookie("BaRTPFBpass","",0);
setcookie("BaRTPFBserver","",0);
header("location: index.php");
?>