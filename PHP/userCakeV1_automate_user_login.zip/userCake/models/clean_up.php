<?php
/*
	Copyright UserCake
	http://usercake.com
	
	Developed by: Adam Davis
*/

   if (!empty($db))
   {
      $db->sql_close();
   }
?>