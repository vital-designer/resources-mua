<?php
include ("../common.php");
include ("../include/administrators_function.php");
$section = "admins";
$error = "";
$res = $dbconn->execute("select * from groups");
while (!$res->EOF)
{
				$row = $res->getrowassoc(false);
				$groups_values[] = $row['group_id'];
				$groups_output[] = $row['name'];
				$res->movenext();
}
$smarty->assign("groups_values", $groups_values);
$smarty->assign("groups_output", $groups_output);
$smarty->assign("error", "");
if (isset($_GET['id']))
{
				if (!isset($_POST['action']) || $_POST['action'] != "change")
				{
								if ($_GET['id'] == 0)
								{
												$right_name = "create";
												check_right($section, $right_name);
												$smarty->assign("razdel", "Administrators");
												$smarty->assign("description", "New Administrator");
												$smarty->assign("hint", "Complete the form and click \"Save\" button to create a new administrator.");
												$content = getblankcontent();
								}
								else
								{
												$right_name = "view_item";
												check_right($section, $right_name);
												$smarty->assign("razdel", "Administrators");
												$smarty->assign("description", "Administrator Editing");
												$smarty->assign("hint", "Edit the values in the fields of this administrator.");
												$content = getadmincontent($_GET['id']);
								}
								$smarty->assign("rel", $content);
								$smarty->display("{$admin_nl_gentemplates}/administrators_change_admin.tpl");
				}
				else
				{
								if ($_GET['id'] == 0 || $_GET['id'] == "0")
								{
												$right_name = "create";
												check_right($section, $right_name);
												if (isset($_POST['action']) && $_POST['action'] == "change")
												{
																if (trim($_POST['login']) == "" || trim($_POST['password']) == "" || trim($_POST['name']) == "")
																{
																				$error = "Error: name, login and password should not consist only of spaces.";
																}
																else
																				if ($_POST['password'] != $_POST['password'])
																				{
																								$error = "Error: passwords not equal.";
																				}
																$res = $dbconn->execute("SELECT * FROM settings");
																$settings = $res->getrowassoc(false);
																$res = $dbconn->execute("SELECT * FROM administrator WHERE login='" . $_POST['login'] . "'");
																$count_such = $res->rowcount();
																if ($settings['admin_login'] == $_POST['login'] || 0 < $count_such)
																{
																				$error = "Such Login is in use already. Please enter another one.";
																}
																if ($error != "")
																{
																				$smarty->assign("error", $error);
																				$smarty->assign("razdel", "Administrators");
																				$smarty->assign("description", "Administrator Editing");
																				$smarty->assign("hint", "Edit the values in the fields of this administrator.");
																				$content = $_POST;
																				$smarty->assign("rel", $content);
																				$smarty->display("{$admin_nl_gentemplates}/administrators_change_admin.tpl");
																				exit();
																}
																else
																{
																				addadmin();
																}
												}
								}
								else
								{
												$right_name = "edit";
												check_right($section, $right_name);
												if (trim($_POST['login']) == "" || trim($_POST['password']) == "" || trim($_POST['name']) == "")
												{
																$error = "Error: name, login and password should not consist only of spaces.";
												}
												else
																if ($_POST['password'] != $_POST['password'])
																{
																				$error = "Error: passwords not equal.";
																}
																else
																				if ($_POST['password'] != $_POST['password'])
																				{
																								$error = "Error: passwords not equal.";
																				}
												$res = $dbconn->execute("SELECT * FROM settings");
												$settings = $res->getrowassoc(false);
												$res = $dbconn->execute("SELECT * FROM administrator WHERE login='" . $_POST['login'] . "' and admin_id<>'" . $_GET['id'] . "'");
												$count_such = $res->rowcount();
												if ($settings['admin_login'] == $_POST['login'] || 0 < $count_such)
												{
																$error = "Such Login is in use already. Please enter another one.";
												}
												if ($error != "")
												{
																$smarty->assign("error", $error);
																$smarty->assign("razdel", "Administrators");
																$smarty->assign("description", "Administrator Editing");
																$smarty->assign("hint", "Please edit the values in the fields of this administrator.");
																$content = getadmincontent($_GET['id']);
																$smarty->assign("rel", $content);
																$smarty->display("{$admin_nl_gentemplates}/administrators_change_admin.tpl");
																exit();
												}
												else
												{
																updadmin();
												}
								}
								header("Location: admins.php");
				}
}
else
{
				header("Location: admins.php");
}
?>