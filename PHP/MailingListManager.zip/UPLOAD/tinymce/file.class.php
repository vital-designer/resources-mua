<?php
class file
{
				public $__name = "";
				public $__extension = "";
				public $__dir = "";
				public $__v_path = "";
				public $__path = "";
				public $__mime_type = "";
				public $__size = 0;
				public $__save_path = "";
				public $__helps = null;
				public $__errors = null;
				public $__manage_types = array(0 => "image");
				public $__extensions = array(0 => "jpeg", 1 => "jpg", 2 => "pjpeg", 3 => "gif", 4 => "bmp", 5 => "tiff", 6 => "png");
				public $__image_type = array(0 => "image/jpeg", 1 => "image/pjpeg", 2 => "image/gif", 3 => "image/bmp", 4 => "image/tiff", 5 => "image/png", 6 => "image/x-png", 7 => "image/vnd.ms-modi");
				public function File($dir = null, $v_path = null)
				{
								if (!is_null($dir))
								{
												$this->__dir = $dir;
								}
								if (!is_null($v_path))
								{
												$this->__v_path = $v_path;
								}
				}
				public function GetList()
				{
								if (is_dir($this->__dir))
								{
												if ($dh = opendir($this->__dir))
												{
																$f_arr = array();
																$i = 0;
																while (($file = readdir($dh)) !== false)
																{
																				if ($file != "." && $file != ".." && 0 < substr_count($file, "."))
																				{
																								$type = strtolower(array_pop(explode(".", basename($this->__dir . $file))));
																								if (in_array($type, $this->__extensions))
																								{
																												$f_arr[$i]['name'] = basename($file);
																												$f_arr[$i]['path'] = $this->__dir;
																												$f_arr[$i]['v_path'] = $this->__v_path;
																												$f_arr[$i]['code'] = htmlspecialchars("<img src = \"" . $f_arr[$i]['v_path'] . $f_arr[$i]['name'] . "\">");
																												$f_arr[$i]['link'] = htmlspecialchars("<a href = \"" . $f_arr[$i]['v_path'] . $f_arr[$i]['name'] . "\">" . $f_arr[$i]['name'] . "</a>");
																												$size_array = getimagesize($this->__dir . $file);
																												$f_arr[$i]['width'] = $size_array[0];
																												$f_arr[$i]['heigth'] = $size_array[1];
																												++$i;
																								}
																				}
																}
																closedir($dh);
																return $f_arr;
												}
												$this->__errors[] = "can_not_open_dir";
												return false;
								}
								$this->__errors[] = "something_with_config";
								return false;
				}
				public function Upload($file)
				{
								$type = strtolower(array_pop(explode(".", $file['name'])));
								$mime_type = strtolower($file['type']);
								$name = array_shift(explode(".", $file['name']));
								if (in_array($mime_type, $this->__image_type) && in_array($type, $this->__extensions))
								{
												if (!move_uploaded_file($file['tmp_name'], $this->__dir . $name . "." . $type))
												{
																$this->__errors[] = "can_not_upload";
																return false;
												} else
												{
																return true;
												}
								}
								$this->__errors[] = "wrong_file_type";
								return false;
				}
				public function Delete($name)
				{
								if (!unlink($this->__dir . $name))
								{
												$this->__errors[] = "can_not_delete";
												return false;
								} else
								{
												return true;
								}
				}
				public function isError()
				{
								return !empty($this->__errors) ? true : false;
				}
				public function getLastError()
				{
								return !empty($this->__errors) ? $this->__errors[count($this->__errors) - 1] : null;
				}
				public function getErrorCount()
				{
								return !empty($this->__errors) ? count($this->__errors) : 0;
				}
}
?>
