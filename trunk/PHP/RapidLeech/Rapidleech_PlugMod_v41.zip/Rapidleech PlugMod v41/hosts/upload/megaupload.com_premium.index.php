<?php
$upload_services[]="megaupload.com_premium";
$max_file_size["megaupload.com_premium"]=1000;
$page_upload["megaupload.com_premium"] = "megaupload.com_premium.php";  
?>