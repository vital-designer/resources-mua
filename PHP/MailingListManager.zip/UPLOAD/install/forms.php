<?php
function template_top($hint)
{
				echo "                        <html>\r\n                        <head>\r\n                        <title> PG Newsletter Site Installation  [iAG] Nulled 2008</title>\r\n                        <meta http-equiv=\"Content-Language\" content=\"ru\">\r\n                        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1251\">\r\n                        </head>\r\n\r\n                        ";
				echo "<s";
				echo "tyle>\r\n\t\t\t\t\t\tinput, select, div, textarea {\r\n\t\t\t\t\t\t\tfont: 11px tahoma, verdana, arial;\r\n\t\t\t\t\t\t}\r\n\t\t\t\t\t\tinput.text, select {\r\n\t\t\t\t\t\t\twidth: 100%;\r\n\t\t\t\t\t\t}\r\n\t\t\t\t\t\tfieldset {\r\n\t\t\t\t\t\t\tmargin-bottom: 10px;\r\n\t\t\t\t\t\t}\r\n\t\t\t\t\t\tbody{\r\n\t\t\t\t\t\t\toverflow: auto;\r\n\t\t\t\t\t\t}\r\n\t\t\t\t\t\ttable, tr, td p {\r\n                                font-size: 12px;\r\n                                color: #000000;\r\n                   ";
				echo "             font-family: Verdana, Tahoma, sans-serif;\r\n\t\t\t\t\t\t\t\tcursor: default;\r\n\t\t\t\t\t\t} \r\n                        .hint{\r\n                                background-color: #FFCC00;\r\n                                border: solid 1px #999966;\r\n                                font-size: 11px;\r\n                                color: #660033;\r\n                                font-family: Verdana, Tah";
				echo "oma, sans-serif;\r\n                                text-align: center;\r\n                        }\r\n                        .main{\r\n                                background-color: #FFFFEE;\r\n                                border: solid 1px #DDDDDD;\r\n                                font-size: 11px;\r\n                                color: #660033;\r\n                                font-family: Verdan";
				echo "a, Tahoma, sans-serif;\r\n                                text-align: center;\r\n                        }\r\n                        .error_area{\r\n                                background-color: #FFFFFF;\r\n                                border: solid 1px #DDDDDD;\r\n                                padding: 5px;\r\n                                font-size: 11px;\r\n                                color: #F";
				echo "F6600;\r\n                                font-family: Verdana, Tahoma, sans-serif;\r\n                                text-align: left;\r\n                        }\r\n                        .table_fonts{\r\n                                border-bottom: solid 1px #DDDDDD;\r\n                                padding: 2px;\r\n                                font-size: 11px;\r\n                                colo";
				echo "r: #660033;\r\n                                font-family: Verdana, Tahoma, sans-serif;\r\n                        }\r\n                        .sub_table_fonts{\r\n                                padding: 0px;\r\n                                padding-left: 20px;\r\n                                font-size: 11px;\r\n                                color: #664254;\r\n                                font-family";
				echo ": Verdana, Tahoma, sans-serif;\r\n                        }\r\n                        .button {\r\n                                font-family: Verdana, Tahoma, sans-serif;\r\n                                font-size: 11px;\r\n                                border: solid 1px;\r\n                                color:#660033;\r\n                                background-color:#DDDDDD\r\n                       ";
				echo " }\r\n                        .form_fields {\r\n                                font-family: Verdana, Tahoma, sans-serif;\r\n                                font-size: 11px;\r\n                                color:#660033;\r\n                                text-align: right;\r\n                        }\r\n                        .form_input {\r\n                                font-family: Verdana, Tahoma, san";
				echo "s-serif;\r\n                                font-size: 11px;\r\n                                color:#660033;\r\n                                border: solid 1px #DDDDDD;\r\n                                width: 200px;\r\n                        }\r\n                        h4{\r\n                                font-family: Verdana, Tahoma, sans-serif;\r\n                                font-size: 11px;\r\n    ";
				echo "                            font-weight: bold;\r\n                                color: #FF9966;\r\n                                text-align: left;\r\n                                padding-left: 20px;\r\n                        }\r\n                        </style>\r\n\r\n                        <body>\r\n                        <table width=100% cellspacing=0 cellpadding=5>\r\n                        <tr>\r\n      ";
				echo "                          <td align=center>\r\n                                        <table class=hint width=100%>\r\n                                                <tr><td>";
				echo $hint;
				echo "</td></tr>\r\n                                        </table>\r\n                                </td>\r\n                        </tr>\r\n                        <tr>\r\n                                <td>\r\n        ";
}
function template_bottom()
{
				echo "                        </td>\r\n                </tr>\r\n                </table>\r\n                </body>\r\n                </html>\r\n        ";
}
function template_lisence_page($str, $next_step)
{
				global $install;
				$form = "License Agreement Page";
				template_top($form);
				echo "\t\t<table class=\"main\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\">\r\n\t\t<tr>\r\n\t\t\t<td align=\"center\">\r\n\t\t\t\t<table width=\"400\" cellpadding=\"5\" cellspacing=\"0\" style=\"margin: 20px; border: 1px solid #000000\" align=\"center\">\r\n\t\t        <tr>\r\n\t\t        \t<td align=\"center\">\r\n\t\t        \t<textarea readonly cols=\"90\" rows=\"40\">";
				echo $str;
				echo "</textarea>\r\n\t\t        \t</td>\r\n\t\t\t\t</tr>\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td>\r\n\t\t\t\t\t<table cellpadding=\"0\" cellspacing=\"0\">\r\n\t\t\t\t\t\t<tr>\r\n\t\t\t\t\t\t\t<td align=\"left\" width=\"15\"><input type=\"checkbox\" onclick=\"CheckLicense();\" value=\"1\" id=\"check_box\"></td>\r\n\t\t\t\t\t\t\t<td width=\"100%\" align=\"left\">I accept the terms of the license agreement</td>\r\n\t\t\t\t\t\t</tr>\r\n\t\t\t\t\t</table>\r\n\t\t\t\t\t</td>\r\n\t\t\t\t</tr>\r\n\t\t\t\t<tr>\r\n\t\t\t\t\t<td align=\"left\"><input type=";
				echo "\"button\" onclick=\"javascript: location.href='./index.php?sel=1'\" value=\"next>>\" class=button disabled id=\"sub_but\"></td>\r\n\t\t\t\t</tr>\r\n\t\t        </table>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\r\n                ";
				echo "<s";
				echo "cript type=\"text/javascript\">\r\n                function CheckLicense(val){\r\n                \tif (document.getElementById('check_box').checked == true ){\r\n                \t\tdocument.getElementById('sub_but').disabled = false;\r\n                \t} else {\r\n                \t\tdocument.getElementById('sub_but').disabled = true;\r\n                \t}\r\n\t\t\treturn;\r\n                }\r\n                </script>\r";
				echo "\n\r\n        ";
				template_bottom();
}
function template_first_page($str, $next_step)
{
				global $install;
				$form = "Step 1: Your Server Environment";
				template_top($form);
				echo "        \r\n                <table class=main width=100%>\r\n                        <tr height=300>\r\n                        <td align=center>\r\n    \t\t\t\t\t\t\t\t<div align=left style=\"width: 600;\">In this step, the Newsletter installer will determine if your system meets the requirements for the server environment. To use Newsletter system you must have PHP with MySQL support, and write-permissions on certain";
				echo " files.<br><br>\r\n\t\t\t\t\t\t\t\t\t";
				if ($next_step)
				{
								echo "\t\t\t\t\t\t\t\t\tCongratulations! You may continue the installation. Click 'next' button to continue. &nbsp; \r\n\t\t\t\t\t\t\t\t\t<input type=\"button\" onclick=\"javascript: location.href='./index.php?sel=2'\" value=\"next>>\" class=button>\r\n\t\t\t\t\t\t\t\t\t";
				} else
				{
								echo "\t\t\t\t\t\t\t\t\tThe installer has detected some problems with your server environment, which will not allow Newsletter to operate correctly.<br /><br />Please correct these issues and then refresh the page to re-check your environment.\r\n\t\t\t\t\t\t\t\t\t";
				}
				echo "\t\t\t\t\t\t\t\t<br><br>\r\n\t\t\t\t\t\t\t\t</div>\r\n                            <table>\r\n                                        <tr>\r\n\t\t\t\t\t\t\t\t\t\t\t<td align=center>\r\n\t\t\t\t\t\t\t\t\t\t\t<div style=\"width: 500;\" class=error_area>\r\n\t\t\t\t\t\t\t\t\t\t\t\t<table width=\"100%\">\r\n\t\t\t\t\t\t\t\t\t\t\t\t";
				echo $str;
				echo "\t\t\t\t\t\t\t\t\t\t\t\t</table>\r\n                                                <br><br>\r\n\t\t\t\t\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t\t\t\t\t</td>\r\n\t\t\t\t\t\t\t\t\t\t</tr>\r\n                                </table>\r\n                        </td>\r\n                        </tr>\r\n                </table>\r\n        \r\n        ";
				template_bottom();
}
function permission_str($str, $good, $sub = 0)
{
				$ret_str = "<tr>\n";
				if ($sub == 1)
				{
								$ret_str .= "\t<td class=\"sub_table_fonts\">" . $str . "</td>\n";
				} else
				{
								$ret_str .= "\t<td class=\"table_fonts\">" . $str . "</td>\n";
				}
				if ($good == 1)
				{
								$s = "<font color=\"#339900\">+</font>";
				} else
				{
								$s = "<font color=\"#FF0000\">-</font>";
				}
				if ($sub == 1)
				{
								$ret_str .= "\t<td align=center width=60 style=\"font-size:  16px;\"><b>" . $s . "</b></td>\n";
				} else
				{
								$ret_str .= "\t<td class=\"table_fonts\" align=center width=60 style=\"font-size:  18px;\"><b>" . $s . "</b></td>\n";
				}
				$ret_str .= "</tr>\n";
				return $ret_str;
}
function blank_str()
{
				$ret_str = "<tr>\n";
				$ret_str .= "\t<td class=\"table_fonts\" colspan=2 style=\"font-size: 2px\">&nbsp;</td>\n";
				$ret_str .= "</tr>\n";
				return $ret_str;
}
function template_database_server_form($err = "", $data = "")
{
				global $install;
				$form = "Step 2: Database & Server Configuration";
				template_top($form);
				$doc_root = $_SERVER['DOCUMENT_ROOT'];
				$data['site_path'] = $install['install_path'];
				if ($doc_root)
				{
								$data['site_root'] = substr($install['install_path'], strlen($doc_root));
				}
				switch ($install['system'])
				{
								case "unix":
												if (substr($data['site_path'], -1) == "/")
												{
																$data['site_path'] = substr($data['site_path'], 0, -1);
												}
												if (!(substr($data['site_root'], -1) == "/"))
												{
																break;
												}
												$data['site_root'] = substr($data['site_root'], 0, -1);
												break;
								case "win":
												if (substr($data['site_path'], -1) == "/")
												{
																$data['site_path'] = substr($data['site_path'], 0, -1);
												}
												if (!(substr($data['site_root'], -1) == "/"))
												{
																break;
												}
												$data['site_root'] = substr($data['site_root'], 0, -1);
				}
				echo "        \r\n                <table class=main width=100%>\r\n                        <tr height=300>\r\n                        <td align=center>\r\n\t\t\t\t\t\t\t\t<div align=left style=\"width: 600;\">The Newsletter installer needs some information about your database to finish the installation. If you do not know this information, then please contact your website host or administrator. Please note that this is proba";
				echo "bly NOT the same as your FTP login information!\r\n\t\t\t\t\t\t\t\t<br><br>\r\n\t\t\t\t\t\t\t\t</div>\r\n                                <form action=\"index.php\" method=post>\r\n                                <table>\r\n                                        <tr>\r\n\t\t\t\t\t\t\t\t\t\t<td align=center>\r\n\t\t\t\t\t\t\t\t\t\t<div style=\"width: 500; \" class=error_area>\r\n                                                ";
				if ($err)
				{
								echo "\t\t\t\t\t\t\t\t\t\t\t\t<table width=\"100%\">\r\n                                                <tr>\r\n                                                        <td class=error_area>";
								echo $err;
								echo "</td>\r\n                                                </tr>\r\n                                                </table>";
				}
				echo "                                                <input type=hidden name=sel value=3>\r\n                                                <h4>Database Info</h4>\r\n                                                <table width=\"100%\">\r\n                                                <tr>\r\n                                                        <td width=\"40%\" class=form_fields>db host: </td>\r\n                   ";
				echo "                                     <td width=\"60%\"><input type=text name=\"dbhost\" value=\"";
				echo $data['dbhost'] ? $data['dbhost'] : "localhost";
				echo "\" class=form_input></td>\r\n                                                </tr>\r\n                                                <tr>\r\n                                                        <td width=\"40%\" class=form_fields>db name: </td>\r\n                                                        <td width=\"60%\"><input type=text name=\"dbname\" value=\"";
				echo $data['dbname'] ? $data['dbname'] : "newsletter";
				echo "\" class=form_input></td>\r\n                                                </tr>\r\n                                                <tr>\r\n                                                        <td width=\"40%\" class=form_fields>db user: </td>\r\n                                                        <td width=\"60%\"><input type=text name=\"dbuser\" value=\"";
				echo $data['dbuser'] ? $data['dbuser'] : "root";
				echo "\" class=form_input></td>\r\n                                                </tr>\r\n                                                <tr>\r\n                                                        <td width=\"40%\" class=form_fields>db password: </td>\r\n                                                        <td width=\"60%\"><input type=text name=\"dbpass\" value=\"";
				echo $data['dbpass'];
				echo "\" class=form_input></td>\r\n                                                </tr>\r\n                                                </table>\r\n                                                <h4>Server Info</h4>\r\n                                                <table width=\"100%\">\r\n                                                <tr>\r\n                                                        <td width=\"40%\" cla";
				echo "ss=form_fields>Server Name: </td>\r\n                                                        <td width=\"60%\"><input type=text name=\"server\" value=\"";
				echo $data['server'] ? $data['server'] : "http://" . $_SERVER['SERVER_NAME'];
				echo "\" class=form_input></td>\r\n                                                </tr>\r\n                                                <tr>\r\n                                                        <td width=\"40%\" class=form_fields>Site Root: </td>\r\n                                                        <td width=\"60%\"><input type=text name=\"site_root\" value=\"";
				echo $data['site_root'];
				echo "\" class=form_input></td>\r\n                                                </tr>\r\n                                                <tr>\r\n                                                        <td width=\"40%\" class=form_fields>Site Path: </td>\r\n                                                        <td width=\"60%\"><input type=text name=\"site_path\" value=\"";
				echo $data['site_path'];
				echo "\" class=form_input></td>\r\n                                                </tr>\r\n                                                </table>\r\n\r\n                                        </div></td></tr>\r\n                                        <tr><td align=right><br><input type=submit name=\"next\" value=\"next>>\" class=button></td></tr>\r\n                                </table>\r\n                                </form";
				echo ">\r\n                        </td>\r\n                        </tr>\r\n                </table>\r\n        \r\n        ";
				template_bottom();
}
function template_db_restore($top_comment, $location)
{
				global $install;
				template_top($top_comment);
				echo "\t\t<table class=main width=100%>\r\n\t\t<tr height=300>\r\n\t\t\t<td align=center>\r\n\t\t\t\t<br><br>\r\n\r\n\t\t<div align=\"center\">\r\n\t\t<TABLE WIDTH=500 BORDER=0 CELLSPACING=0 CELLPADDING=0>\r\n\t\t<TR> \r\n\t\t\t<TD VALIGN=TOP STYLE=\"border: 1px solid #919B9C;\">\r\n\t\t\t<TABLE WIDTH=100% HEIGHT=100% BORDER=0 CELLSPACING=1 CELLPADDING=0>\r\n\t\t\t\t<TR> \r\n\t\t\t\t<FORM NAME=skb METHOD=POST ACTION=\"{\$form.action}\">\r\n\t\t\t\t<TD class=\"main_content_text\" VAL";
				echo "IGN=TOP BGCOLOR=#F4F3EE STYLE=\"FILTER: progid:DXImageTransform.Microsoft.Gradient(gradientType=0,startColorStr=#FCFBFE,endColorStr=#F4F3EE); padding: 8px 8px;\"> \r\n\t\t\t\t\t<FIELDSET>\r\n\t\t\t\t\t<LEGEND  class=\"main_content_text\">Creating Database&nbsp;</LEGEND>\r\n\t\t\t\t\t<TABLE WIDTH=100% BORDER=0 CELLSPACING=0 CELLPADDING=2>\r\n\t\t\t\t\t<TR><TD class=\"main_content_text\" COLSPAN=2><DIV ID=logarea STYLE=\"width: 100%; height";
				echo ": 140px; border: 1px solid #7F9DB9; padding: 3px; overflow: auto;\"></DIV></TD></TR>\r\n\t\t\t\t\t<TR><TD class=\"main_content_text\" WIDTH=31%>Table Status:</TD><TD WIDTH=69%><TABLE WIDTH=100% BORDER=1 CELLPADDING=0 CELLSPACING=0>\r\n\t\t\t\t\t<TR><TD  class=\"main_content_text\" BGCOLOR=#FFFFFF><TABLE WIDTH=1 BORDER=0 CELLPADDING=0 CELLSPACING=0 BGCOLOR=#5555CC ID=st_tab \r\n\t\t\t\t\tSTYLE=\"FILTER: progid:DXImageTransform.Microsof";
				echo "t.Gradient(gradientType=0,startColorStr=#B7CEF2,endColorStr=#0045B5);\r\n\t\t\t\t\tborder-right: 1px solid #AAAAAA\"><TR><TD HEIGHT=12></TD></TR></TABLE></TD></TR></TABLE></TD></TR>\r\n\t\t\t\t\t<TR><TD  class=\"main_content_text\">DB Status:</TD><TD><TABLE WIDTH=100% BORDER=1 CELLSPACING=0 CELLPADDING=0>\r\n\t\t\t\t\t<TR><TD BGCOLOR=#FFFFFF  class=\"main_content_text\"><TABLE WIDTH=1 BORDER=0 CELLPADDING=0 CELLSPACING=0 BGCOLOR=#00AA00 ID=";
				echo "so_tab\r\n\t\t\t\t\tSTYLE=\"FILTER: progid:DXImageTransform.Microsoft.Gradient(gradientType=0,startColorStr=#CCFFCC,endColorStr=#00AA00);\r\n\t\t\t\t\tborder-right: 1px solid #AAAAAA\"><TR><TD HEIGHT=12></TD></TR></TABLE></TD>\r\n\t\t\t\t\t</TR></TABLE></TD></TR></TABLE>\r\n\t\t\t\t\t</FIELDSET>\r\n\t\t\t\t\t";
				echo "<S";
				echo "CRIPT>\r\n\t\t\t\t\tvar WidthLocked = false;\r\n\t\t\t\t\tfunction s(st, so){\r\n\t\t\t\t\t\tdocument.getElementById('st_tab').width = st ? st + '%' : '1';\r\n\t\t\t\t\t\tdocument.getElementById('so_tab').width = so ? so + '%' : '1';\r\n\t\t\t\t\t}\r\n\t\t\t\t\tfunction l(str, color){\r\n\t\t\t\t\t\tswitch(color){\r\n\t\t\t\t\t\t\tcase 2: color = 'navy'; break;\r\n\t\t\t\t\t\t\tcase 3: color = 'red'; break;\r\n\t\t\t\t\t\t\tdefault: color = 'black';\r\n\t\t\t\t\t\t}\r\n\t\t\t\t\t\twith(docu";
				echo "ment.getElementById('logarea')){\r\n\t\t\t\t\t\t\tif (!WidthLocked){\r\n\t\t\t\t\t\t\t\tstyle.width = clientWidth;\r\n\t\t\t\t\t\t\t\tWidthLocked = true;\r\n\t\t\t\t\t\t\t}\r\n\t\t\t\t\t\t\tstr = '<FONT COLOR=' + color + '>' + str + '</FONT>';\r\n\t\t\t\t\t\t\tinnerHTML += innerHTML ? \"<BR>\\n\" + str : str;\r\n\t\t\t\t\t\t\tscrollTop += 14;\r\n\t\t\t\t\t\t}\r\n\t\t\t\t\t}\r\n\t\t\t\t\t</SCRIPT>\r\n\t\t\t\t\t<TABLE WIDTH=100% BORDER=0 CELLSPACING=0 CELLPADDING=2>\r\n\t\t\t\t\t<TR>\r\n\t\t\t\t\t<TD class=\"main_co";
				echo "ntent_text\" STYLE='color: #CECECE' ID=timer></TD>\r\n\t\t\t\t\t<TD ALIGN=RIGHT >\r\n\t\t\t\t\t</TD>\r\n\t\t\t\t\t</TR>\r\n\t\t\t\t\t</TABLE>\r\n\t\t\t\t</TD>\r\n\t\t\t\t</FORM>\r\n\t\t\t\t</TR>\r\n\t\t\t</TABLE>\r\n\t\t\t</TD>\r\n\t\t</TR>\r\n\t\t</TABLE>\r\n</div>\r\n<div width=\"600\"><br><br><INPUT ID=back TYPE=button VALUE='";
				echo "<";
				echo "<Back' DISABLED onClick=\"window.close();opener.focus();\" class=button> <INPUT ID=next TYPE=button VALUE='Next>>' DISABLED onClick=\"javascript: location.href='";
				echo $location;
				echo "'\" class=button></div>\r\n\t\t\t</td>\r\n\t\t</tr>\r\n\t\t</table>\r\n\r\n";
				template_bottom();
}
function template_misc_parametrs_form($err = "", $data = "")
{
				global $install;
				$form = "Step 3: Site Settings";
				template_top($form);
				echo "                <table class=main width=100%>\r\n                        <tr height=300>\r\n                        <td align=center>\r\n                                <form action=\"index.php\" method=post>\r\n                                <table>\r\n                                        <tr><td align=center><div style=\"width: 500; \" class=error_area>\r\n                                                ";
				if ($err)
				{
								echo "<table width=\"100%\">\r\n                                                <tr>\r\n                                                        <td class=error_area>";
								echo $err;
								echo "</td>\r\n                                                </tr>\r\n                                                </table>";
				}
				echo "                                                <input type=hidden name=sel value=5>\r\n                                                <h4>Administrator Info</h4>\r\n                                                <table width=\"100%\">\r\n                                                <tr>\r\n                                                        <td width=\"40%\" class=form_fields>company name: </td>\r\n         ";
				echo "                                               <td width=\"60%\"><input type=text name=\"company_name\" value=\"";
				echo $data['company_name'];
				echo "\" class=form_input></td>\r\n                                                </tr>\r\n                                                <tr>\r\n                                                        <td width=\"40%\" class=form_fields>administrator login: </td>\r\n                                                        <td width=\"60%\"><input type=text name=\"admin_login\" value=\"";
				echo $data['admin_login'];
				echo "\" class=form_input></td>\r\n                                                </tr>\r\n                                                <tr>\r\n                                                        <td width=\"40%\" class=form_fields>password: </td>\r\n                                                        <td width=\"60%\"><input type=password name=\"admin_pass\" value=\"";
				echo $data['admin_pass'];
				echo "\" class=form_input></td>\r\n                                                </tr>\r\n                                                <tr>\r\n                                                        <td width=\"40%\" class=form_fields>re-password: </td>\r\n                                                        <td width=\"60%\"><input type=password name=\"admin_repass\" value=\"";
				echo $data['admin_repass'];
				echo "\" class=form_input></td>\r\n                                                </tr>\r\n                                                <tr>\r\n                                                        <td width=\"40%\" class=form_fields>admin email: </td>\r\n                                                        <td width=\"60%\"><input type=text name=\"admin_email\" value=\"";
				echo $data['admin_email'];
				echo "\" class=form_input></td>\r\n                                                </tr>\r\n                                                </table><br>\r\n\r\n                                        </div></td></tr>\r\n                                        <tr><td align=right><input type=submit name=\"next\" value=\"next>>\" class=button></td></tr>\r\n                                </table>\r\n                                </form";
				echo ">\r\n                        </td>\r\n                        </tr>\r\n                </table>\r\n        ";
				template_bottom();
}
function template_last_page()
{
				global $install;
				$form = "Welcome to the PG Newsletter Site Installation Program!";
				template_top($form);
				echo "        \r\n                <table class=main width=100%>\r\n                        <tr height=300>\r\n                        <td align=center>\r\n                                <table>\r\n                                        <tr><td align=center><div style=\"width: 500;\" class=error_area>\r\n                                                PG Newsletter is successfully installed!<br><br>\r\n                        ";
				echo "                        Don't forget to setup the following crontab files to have all the functions work correctly:<br>\r\n\t\t\t\t\t\t\t\t\t\t\t\t/newsletters/cron_send.php - dispatch on schedule <br>\r\n                                                /newsletters/cron_send_hour.php - dispatch based on a set per hour quote <br>\r\n                                                /newsletters/cron_send_period.php - dis";
				echo "patch on a recurring basis <br>\r\n                                                /users/cron_del_user.php - automatic removal of bounced emails <br>\r\n                                        </div></td></tr>\r\n                                        <tr><td align=right><input type=submit name=\"next\" value=\"next>>\" class=button onclick=\"javascript: location.href='../index.php'\"></td></tr>\r\n                    ";
				echo "            </table>\r\n                        </td>\r\n                        </tr>\r\n                </table>\r\n        \r\n        ";
				template_bottom();
}
?>