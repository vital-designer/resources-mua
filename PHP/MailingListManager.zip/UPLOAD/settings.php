<?php
function text_process($s)
{
				return addslashes(trim($s));
}
include ("common.php");
$section = "settings";
$right_name = "view";
check_right($section, $right_name);
foreach ($GLOBALS['_POST'] as $key => $val)
{
				$GLOBALS['_POST'][$key] = text_process($val);
}
if (isset($_POST['action']) && $_POST['action'] == "change")
{
				$right_name = "edit";
				check_right($section, $right_name);
				$res = $dbconn->execute("SELECT * FROM administrator WHERE login='" . $_POST['admin_login'] . "'");
				if ($_POST['admin_password'] != $_POST['admin_password2'])
				{
								$error = "Administrator's password and Confirm password not equal";
				}
				else
								if (0 < $res->rowcount())
								{
												$error = "Such Login is in use already. Please enter another one.";
								}
				if ($error == "")
				{
								if (intval($_POST['auto']) != 1)
								{
												$GLOBALS['_POST']['auto_del'] = 0;
								}
								$rs = $dbconn->execute("update settings set admin_login='" . addslashes($_POST['admin_login']) . "', admin_password='" . addslashes($_POST['admin_password']) . "', timeout='" . $_POST['timeout'] . "', test_email='" . $_POST['test_email'] . "', smtp_quota='" . $_POST['smtp_quota'] . "', send_period='" . $_POST['send_period'] . "', from_name='" . $_POST['from_name'] . "', from_email='" . $_POST['from_email'] . "', is_tips='" . $_POST['is_tips'] . "', auto_delete='" . $_POST['auto_del'] . "'");
								$GLOBALS['_SESSION']['is_tips'] = $_POST['is_tips'];
				}
				else
				{
								$smarty->assign("error", $error);
								$smarty->assign("description", "Settings");
								$smarty->assign("hint", "Here you may set access parameters to system, SMTP-server and some additional options.");
								$smarty->assign("row", $_POST);
								$smarty->display("{$admin_nl_gentemplates}/settings.tpl");
								exit();
				}
}
$rs = $dbconn->execute("select * from settings");
$row = $rs->getrowassoc(false);
$smarty->assign("auto_del_values", array(1, 2, 3, 4, 5, 6, 7));
$smarty->assign("auto_del_output", array(1, 2, 3, 4, 5, 6, 7));
if ($row['auto_delete'] == 0)
{
				$smarty->assign("auto_del_select", 3);
}
else
{
				$smarty->assign("auto_del_select", $row['auto_delete']);
}
$smarty->assign("razdel", "Settings");
$smarty->assign("description", "General Settings");
$smarty->assign("hint", "Here you may set access parameters to system, SMTP-server and some additional options.");
$smarty->assign("row", $row);
$smarty->display("{$admin_nl_gentemplates}/settings.tpl");
?>