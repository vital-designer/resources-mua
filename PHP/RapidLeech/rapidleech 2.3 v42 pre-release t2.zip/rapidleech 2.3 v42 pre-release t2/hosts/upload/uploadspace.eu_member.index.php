<?php
$upload_services[]="uploadspace.eu_member";
$max_file_size["uploadspace.eu_member"]=500;
$page_upload["uploadspace.eu_member"] = "uploadspace.eu_member.php";  
?>