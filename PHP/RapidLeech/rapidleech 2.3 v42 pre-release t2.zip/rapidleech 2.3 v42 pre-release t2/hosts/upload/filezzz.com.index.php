<?php
$upload_services[]="filezzz.com";
$max_file_size["filezzz.com"]=false;
$page_upload["filezzz.com"] = "filezzz.com.php";
?>