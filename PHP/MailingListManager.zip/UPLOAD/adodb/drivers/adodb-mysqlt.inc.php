<?php
include_once (ADODB_DIR . "/drivers/adodb-mysql.inc.php");
class adodb_mysqlt extends adodb_mysql
{
				var $databaseType = "mysqlt";
				function begintrans()
				{
								$this->execute("SET AUTOCOMMIT=0");
								$this->execute("BEGIN");
								return true;
				}
				function committrans()
				{
								$this->execute("COMMIT");
								$this->execute("SET AUTOCOMMIT=1");
								return true;
				}
				function rollbacktrans()
				{
								$this->execute("ROLLBACK");
								$this->execute("SET AUTOCOMMIT=1");
								return true;
				}
}
class adorecordset_mysqlt extends adorecordset_mysql
{
				var $databaseType = "mysqlt";
				function adorecordset_mysqlt($queryID)
				{
								return $this->adorecordset_mysql($queryID);
				}
}
?>