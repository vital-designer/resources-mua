<?php
$upload_services[]="ugotfile.com_member";
$max_file_size["ugotfile.com_member"]=200;
$page_upload["ugotfile.com_member"] = "ugotfile.com_member.php";
?>