<?php
include ("../common.php");
include ("../include/users_function.php");
if (isset($_GET['id']))
{
				$smarty->assign("razdel", "Subscriber");
				$smarty->assign("description", "View subscriber's details");
				$smarty->assign("users", getusers($_GET['id']));
				$smarty->display("{$admin_nl_gentemplates}/users_profile.tpl");
}
?>