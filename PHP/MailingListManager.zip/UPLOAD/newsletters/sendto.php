<?php
include ("../common.php");
include ("../include/newsletters_function.php");
ini_set("max_execution_time", 100);
ini_set("display_errors", "0");
error_reporting(E_ALL);
$us = sendreleaseundelivered((integer)$_GET['id'], addslashes($_GET['date']), (integer)$_GET['l']);
echo "<script>window.opener.location.href='index.php';</script>";
?>