<?
//phpFormBuilder Version 1.5 by Baris Kayar (barishkayar@yahoo.com)
//2002(cl)  The FormBuilder Group http://pfb.sourceforge.net

require("config.inc.php");
require("connectdb.inc.php");
require("style.inc.php");
echo "<body background=\"images/bkg.gif\">";
//.......................Gerekli Datalar  Olu�turuluyor ......................
$postvars=array();
//$postvalues=array(); //iptal ettim :))
$postlistvars=array();
//$postlistvalues=array(); //iptal ettim :))
//$postoptvars=array(); //iptal ettim :))
$postoptvalues=array();
if ($act=="olustur")
{
	foreach ($HTTP_POST_VARS as $anahtar=>$deger ) 
		{
		//echo "<b>$anahtar = $deger <br>\n";// ne gelmi� bi g�relim
		if (
			($anahtar!="chklist" && $anahtar!="chkinsert" &&
			 $anahtar!="chkupdate" && $anahtar!="chkdelete") &&
			($deger=="on" || $deger=="off")
		   )
			{
			if (substr($anahtar,0,5)=="PFBf_")
				{
				array_push ($postvars,str_replace("PFBf_","",$anahtar));
				//array_push ($postvalues,$deger); //iptal ettim :))
				}
			if (substr($anahtar,0,5)=="PFBl_")
				{
				array_push ($postlistvars,str_replace("PFBl_","",$anahtar));
				//array_push ($postlistvalues,$deger); //iptal ettim :))
				}
			//echo "<b>$anahtar = $deger <br>\n";// ne gelmi� bi g�relim
			}
		if (substr($anahtar,0,5)=="PFBo_")
			{
			//array_push ($postoptvars,str_replace("PFBo_","",$anahtar)); //iptal ettim :))
			$newkey=str_replace("PFBo_","PFBf_",$anahtar);
			if ($$newkey=="on")	array_push ($postoptvalues,$deger);
			}
		}
//.......................Gerekli Datalar  Olu�turuluyor ......................
mysql_close();
if ($chkinsert || $chkupdate) include("buildform.php");
include("builder.inc.php");
}//if
//for ($i=0;$i<sizeof($postoptvalues);$i++) echo $postoptvalues[$i]."<br>"; // ne gelmi� bi g�relim
?>
