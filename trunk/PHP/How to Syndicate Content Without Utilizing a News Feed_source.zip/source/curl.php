<?php
$ch = curl_init("http://net.tutsplus.com/");
$html = curl_exec($ch);

print "$html";
?>