<?php
ini_set("max_execution_time", 0);
ini_set("display_errors", "0");
error_reporting(E_ALL);
include ("../include/config.php");
include ("../adodb/adodb.inc.php");
include ("../include/common_functions.php");
include ("../include/users_function.php");
$dbconn = &adonewconnection($config['dbtype']);
global $ADODB_FETCH_MODE;
if ($config['dbtype'] == "ado_mssql")
{
				if ($config['useoledb'] == 1)
				{
								$connectString = "SERVER=" . $config['dbhost'] . ";DATABASE=" . $config['dbname'] . ";";
								$dbh = $dbconn->pconnect($connectString, $config['dbuname'], $config['dbpass'], "SQLOLEDB");
				}
				else
				{
								$connectString = "PROVIDER=MSDASQL;DRIVER={SQL Server};SERVER=" . $config['dbhost'] . ";DATABASE=" . $config['dbname'] . ";id_user=" . $config['dbuname'] . ";PWD=" . $config['dbpass'] . ";";
								$dbh = $dbconn->pconnect($connectString, "", "", "");
				}
}
else
{
				$connectString = $config['dbtype'] . ":" . $config['dbuname'] . ":" . $config['dbpass'] . "@" . $config['dbhost'] . "/" . $config['dbname'];
				$dbh = $dbconn->pconnect($config['dbhost'], $config['dbuname'], $config['dbpass'], $config['dbname']);
}
$ADODB_FETCH_MODE = ADODB_FETCH_NUM;
if ($dbh === false)
{
				error_log("connect string: {$connectString}");
				error_log("error: " . $dbconn->errormsg());
}
$rs1 = $dbconn->execute("select auto_delete from settings");
if (intval($rs1->fields[0]) != 0)
{
				$rs = $dbconn->execute("select distinct(client_id) from clients_releases");
				while (!$rs->EOF)
				{
								$res_sent = $dbconn->execute("SELECT count(client_id), UNIX_TIMESTAMP(date_format(max(date),'%Y-%m-%d')) FROM clients_releases WHERE client_id=" . $rs->fields[0] . " and is_sent=1");
								$res_notsent = $dbconn->execute("SELECT count(client_id), UNIX_TIMESTAMP(date_format(max(date),'%Y-%m-%d')) FROM clients_releases WHERE client_id=" . $rs->fields[0] . " and is_sent=2");
								if (intval($rs1->fields[0]) <= intval($res_notsent->fields[0]))
								{
												if (is_null($res_sent->fields[1]))
												{
																$res_sent->fields[1] = 0;
												}
												if (is_null($res_notsent->fields[1]))
												{
																$res_notsent->fields[1] = 0;
												}
												if (intval($res_sent->fields[1]) < intval($res_notsent->fields[1]))
												{
																deluser($rs->fields[0]);
												}
								}
								$rs->movenext();
				}
}
?>