<?php
include ("../common.php");
include ("../include/users_function.php");
ini_set("max_execution_time", 0);
$section = "subscribers";
$right_name = "export";
check_right($section, $right_name);
$rs = $dbconn->execute("select * from settings");
$settings = $rs->getrowassoc(false);
if (isset($_POST['action']) || $_POST['action'] == "export")
{
				$err = "";
				$count_errors = 0;
				$end = strstr($_POST['FileName'], ".");
				$file_name = str_replace($end, "", $_POST['FileName']) . ".csv";
				$fp = fopen($config['site_path'] . "/files/" . $file_name, "w+");
				if (!$fp)
				{
								$err1 = "bad_file";
								$is_err = true;
				}
				++$count_errors;
				if (sizeof($_POST['list']) < 1)
				{
								$err2 = "list_empty";
								$is_err = true;
				}
				++$count_errors;
				if ($is_err)
				{
								$i = 1;
								for (; $i <= $count_errors; ++$i)
								{
												$tmp = "err" . $i;
												$$tmp = !isset($tmp) ? "no" : $$tmp;
												$err .= "err" . $i . "=" . $$tmp . "&";
								}
								$err .= "count_errors=" . $count_errors;
								echo "<script>this.location.href = 'export_csv.php?" . $err . "'</script>";
								exit();
				}
				$c = 0;
				$delimiter = trim($_POST['Delimiter']) != "" ? trim($_POST['Delimiter']) : ";";
				if (isset($_POST['ExportHeaders']))
				{
								fwrite($fp, "Date {$delimiter} First Name {$delimiter} Last Name {$delimiter} Company {$delimiter} Email {$delimiter} Comment {$delimiter} \n");
				}
				$lists = array();
				$l = 0;
				foreach ($GLOBALS['_POST']['list'] as $list_id)
				{
								$lists[] = "cl.list_id='" . $list_id . "'";
								$res = $dbconn->execute("select name from list where id='" . $list_id . "'");
								$list_array[$l] = stripslashes($res->fields[0]);
								++$l;
				}
				$rl = join($lists, " OR ");
				$res = $dbconn->execute("select distinct cl.client_id, s.* from clients_lists cl, snd_users s where cl.client_id=s.id and ({$rl})");
				while (!$res->EOF)
				{
								$row = $res->getrowassoc(false);
								$comment = str_replace($delimiter, " ", $row['comment']);
								fwrite($fp, $row['date'] . $delimiter . $row['firstname'] . $delimiter . $row['secondname'] . $delimiter . $row['company'] . $delimiter . $row['email1'] . $delimiter . $comment . $delimiter . " \n");
								++$c;
								$res->movenext();
				}
				fclose($fp);
				$lists = "<ul>";
				foreach ($list_array as $k => $v)
				{
								$lists .= "<li>" . $v . "</li>";
				}
				$lists .= "</ul>";
				$email = trim($_POST['NotifyEmail']);
				if ($email != "")
				{
								$message = "File: <a href='" . $config['server'] . "/files/" . $file_name . "'>{$file_name}</a> <br> Mailing lists: <br> {$lists} Amount users: {$c}";
								$headers = "From: " . $settings['from_name'] . " <" . $settings['from_email'] . ">";
								$headers .= "X-Mailer: PHP/" . phpversion() . "";
								$headers .= "X-Priority: 0";
								$headers .= "MIME-Version: 1.0";
								$headers .= "Content-type: text/html; charset=iso-8951-1";
								$is_send = mail($email, "Export to cvs file complete", $message, $headers) ? true : false;
				}
				$smarty->assign("path_send", $config['server'] . "/files/");
				$smarty->assign("web_path", $config['server']);
				$smarty->assign("count", $c);
				$smarty->assign("lists", $lists);
				$smarty->assign("is_send", $is_send);
				$smarty->assign("email", $email);
				$smarty->assign("file_name", $file_name);
				$smarty->assign("razdel", "Subscribers");
				$smarty->assign("description", "The data export is finished");
				$smarty->assign("hint", "After you browse the csv file with saved subscribers, we would recommend you delete this file from the server for security reasons. To do this click the link \"Delete file\".");
				$GLOBALS['_SESSION']['is_del'] = 1;
				$smarty->display("{$admin_nl_gentemplates}/users_export_csv_end.tpl");
				exit();
}
$smarty->assign("lists", getlistsfilled());
$msg = "";
if (isset($_GET['count_errors']))
{
				$i = 1;
				for (; $i <= $_GET['count_errors']; ++$i)
				{
								$tmp = "err" . $i;
								if ($_GET[$tmp] == "list_empty")
								{
												$msg .= "Error: Please, choose list for subscribers.<br>";
								}
								if ($_GET[$tmp] == "bad_file")
								{
												$msg .= "Error: Can't open file.<br>";
								}
				}
}
$smarty->assign("razdel", "Subscribers");
$smarty->assign("description", "Export Subscribers to CSV file");
$smarty->assign("hint", "You can export information about your subscribers to CSV file (Data separated with a certain sign). You may need it to transfer the data to another program or for additional saving. The following fields will be exported: \"First Name\", \"Last Name\", \"Email\", \"Company\", \"Comment\". Complete the form and click \"Save\".");
$smarty->assign("admin_email", $settings['from_email']);
$smarty->assign("msg", $msg);
$smarty->display("{$admin_nl_gentemplates}/users_export_csv.tpl");
?>