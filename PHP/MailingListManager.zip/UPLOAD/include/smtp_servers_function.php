<?php
function getservers($orderby = "", $server_page = 0)
{
				global $dbconn;
				global $smarty;
				global $config;
				if (isset($_GET['p']) && 0 < $_GET['p'])
				{
								$p = $_GET['p'];
				} else
				{
								$p = 0;
				}
				$end = $_SESSION['is_desc'] && !$_GET['is_nav'] || !$_SESSION['is_desc'] && $_GET['is_nav'] ? " desc " : "";
				if ($orderby)
				{
								$is_nav = isset($_GET['is_nav']) ? $_GET['is_nav'] : false;
								if (!$is_nav && $orderby == $_SESSION['order'])
								{
												if ($_SESSION['is_desc'])
												{
																$GLOBALS['_SESSION']['is_desc'] = false;
																$end = " desc ";
												} else
												{
																$GLOBALS['_SESSION']['is_desc'] = true;
																$end = "";
												}
								}
								$sql .= " order by " . $orderby . $end;
				} else
				{
								$sql .= " order by name";
				}
				$smarty->assign("end", trim($end));
				$res = $dbconn->execute("select count(id_smtp_server) from smtp_server");
				$amount = $res->fields[0];
				$smarty->assign("navigation", create_navigation($amount, $server_page, "server_page={$server_page}&order=" . $_GET['order'] . "&is_nav=true", "index.php", $p, "server_page"));
				get_smarty_array_list("server_page", $config['server_page']);
				$per_page = $config['server_page'][$server_page];
				$res = $dbconn->pageexecute("select * from smtp_server " . $sql, $per_page, $p + 1);
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$row = $res->getrowassoc();
								$releases[$c]['id'] = $row['ID_SMTP_SERVER'];
								$releases[$c]['name'] = stripslashes($row['NAME']);
								$releases[$c]['host'] = $row['HOST'];
								$releases[$c]['login'] = $row['LOGIN'] != "" ? "Yes" : "No";
								$releases[$c]['password'] = $row['PASSWORD'];
								$releases[$c]['order_num'] = $row['ORDER_NUM'];
								++$c;
								$res->movenext();
				}
				$smarty->assign("amount", $amount);
				return $releases;
}
function delserver($id)
{
				global $dbconn;
				$res = $dbconn->execute("delete from smtp_server where id_smtp_server='" . $id . "'");
}
function addserver()
{
				global $dbconn;
				$name = str_prepare($_POST['Name']);
				$host = str_prepare($_POST['Host']);
				$login = str_prepare($_POST['Login']);
				$password = str_prepare($_POST['Password']);
				$order_num = $_POST['OrderNum'];
				$res = $dbconn->execute("insert into smtp_server (name,host,login,password,order_num) values ('" . $name . "', '" . $host . "', '" . $login . "', '" . $password . "', '" . $order_num . "')");
				$rid = $dbconn->_insertid();
				return $rid;
}
function updserver()
{
				global $dbconn;
				$name = str_prepare($_POST['Name']);
				$host = str_prepare($_POST['Host']);
				$login = str_prepare($_POST['Login']);
				$password = str_prepare($_POST['Password']);
				$order_num = $_POST['OrderNum'];
				$id = $_GET['id'];
				$res = $dbconn->execute("update smtp_server set name='" . $name . "', host='" . $host . "', login='" . $login . "', password='" . $password . "', order_num='" . $order_num . "' where id_smtp_server='" . $id . "'");
}
function getcontent()
{
				global $dbconn;
				$id = $_GET['id'];
				$res = $dbconn->execute("select * from smtp_server where id_smtp_server='" . $id . "'");
				$releases = array();
				$row = $res->getrowassoc();
				$releases['id'] = $row['ID_SMTP_SERVER'];
				$releases['name'] = stripslashes($row['NAME']);
				$releases['host'] = $row['HOST'];
				$releases['login'] = $row['LOGIN'];
				$releases['password'] = $row['PASSWORD'];
				$releases['order_num'] = $row['ORDER_NUM'];
				return $releases;
}
function getblankcontent()
{
				$releases = array();
				$releases['id'] = 0;
				$releases['name'] = "";
				$releases['host'] = "";
				$releases['login'] = "";
				$releases['password'] = "";
				$releases['order_num'] = "";
				return $releases;
}
?>
