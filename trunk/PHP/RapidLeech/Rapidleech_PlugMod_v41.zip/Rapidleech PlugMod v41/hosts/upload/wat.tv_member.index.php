<?php
$upload_services[]="wat.tv";
$max_file_size["wat.tv"]=200;
$page_upload["wat.tv"] = "wat.tv_member.php";
?>