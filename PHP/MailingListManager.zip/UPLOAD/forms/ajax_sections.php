<?php
function getsectionattrs($id_section)
{
				global $dbconn;
				global $config;
				global $smarty;
				global $admin_nl_gentemplates;
				$form = new form($dbconn, $config);
				$attrs = $form->getsectionattributes($id_section, $total_count);
				$smarty->assign("attrs", $attrs);
				$smarty->assign("total_count", $total_count);
				$smarty->assign("id_section", $id_section);
				header("Content-Type: text/plain; charset=utf-8");
				$smarty->display("{$admin_nl_gentemplates}/ajax_sec_attrs.tpl");
}
function getattributeform($act, $id_section, $id_attr)
{
				global $dbconn;
				global $config;
				global $smarty;
				global $admin_nl_gentemplates;
				$form = new form($dbconn, $config);
				$regs = $form->getregexps();
				if ($act == "new")
				{
								$save_link = "ajax_sections.php?sel=add_attr&id_sec=" . $id_section;
				} else
				{
								$attr = $form->getsectionattribute($id_attr);
								$type = $form->getcontroltype($control_type);
								$save_link = "ajax_sections.php?sel=update_attr&id_attr=" . $id_attr . "&id_sec=" . $id_section;
								if ($attr['control_type'] == "select")
								{
												$max_ref = 0;
												foreach ($attr['setup']['values'] as $index => $option)
												{
																$s_data[] = implode("&", $option);
																if ($max_ref < $option['id'])
																{
																				$max_ref = $option['id'];
																}
												}
												$s_data = implode(";", $s_data);
												$s_data .= ";";
												$smarty->assign("max_ref", $max_ref);
												$smarty->assign("s_data", $s_data);
												$ds = $form->getalldatasources();
												$smarty->assign("ds", $ds);
								}
								$smarty->assign("attr", $attr);
								$smarty->assign("type_text", $type);
				}
				$id_attr = isset($id_attr) ? $id_attr : "null";
				$smarty->assign("id_attr", $id_attr);
				$smarty->assign("act", $act);
				$smarty->assign("save_link", $save_link);
				$smarty->assign("regs", $regs);
				$smarty->assign("header", $lang['forms']);
				$smarty->assign("button", $lang['button']);
				header("Content-Type: text/plain; charset=utf-8");
				if ($act != "new")
				{
								$smarty->assign("type", $attr['control_type']);
								$attr_form_content = $smarty->fetch("{$admin_nl_gentemplates}/attr_props_form.tpl");
								$smarty->assign("attr_form_content", $attr_form_content);
				}
				$smarty->display("{$admin_nl_gentemplates}/attr_edit_form.tpl");
}
function getattributepropertiesform($control_type, $id_attr)
{
				global $dbconn;
				global $config;
				global $smarty;
				global $admin_nl_gentemplates;
				$form = new form($dbconn, $config);
				$regs = $form->getregexps();
				$type = $form->getcontroltype($control_type);
				if (0 < $id_attr)
				{
								$attr = $form->getsectionattribute($id_attr);
								if ($attr['control_type'] == $control_type)
								{
												$smarty->assign("attr", $attr);
								}
				}
				if ($control_type == "select")
				{
								$ds = $form->getalldatasources();
								$smarty->assign("ds", $ds);
				}
				$smarty->assign("type", $control_type);
				$smarty->assign("type_text", $type);
				$smarty->assign("regs", $regs);
				$smarty->assign("header", $lang['forms']);
				$smarty->assign("button", $lang['button']);
				header("Content-Type: text/plain; charset=utf-8");
				$smarty->display("{$admin_nl_gentemplates}/attr_props_form.tpl");
}
function addattribute($id_section)
{
				global $dbconn;
				global $config;
				global $smarty;
				global $admin_nl_gentemplates;
				$attr_data['field_name'] = $_REQUEST['field_name'];
				$attr_data['mandatory'] = isset($_REQUEST['mandatory']) ? "Y" : "N";
				$attr_data['control_type'] = $_REQUEST['control_type'];
				$attr_setup = array();
				switch ($_REQUEST['control_type'])
				{
								case "checkbox":
												$attr_setup['def_value'] = isset($_REQUEST['def_value']) ? 1:
												0;
												break;
								case "text":
												$attr_setup['def_value'] = $_REQUEST['def_value'];
												$attr_setup['max_len'] = $_REQUEST['max_len'];
												$attr_setup['reg_exp'] = $_REQUEST['reg_exp'];
												break;
								case "select":
												$attr_setup = array();
												$i = 0;
												$temp = explode(";", $_REQUEST['s_data']);
												foreach ($temp as $element)
												{
																if ($element == "")
																{
																} else
																{
																				$temp_elem = explode("&", $element);
																				$attr_setup['values'][$i]['id'] = $temp_elem[0];
																				$attr_setup['values'][$i]['name'] = $temp_elem[1];
																				++$i;
																}
												}
												$attr_setup['select_type'] = $_REQUEST['select_type'];
												if ($attr_setup['select_type'] == "listbox")
												{
																$attr_setup['vsize'] = $_REQUEST['vsize'];
																$attr_setup['is_mult'] = isset($_REQUEST['is_mult']) ? 1 : 0;
												}
												$attr_setup['datasource'] = $_REQUEST['datasource'];
												break;
								case "textarea":
												$attr_setup['def_value'] = $_REQUEST['def_value'];
												$attr_setup['reg_exp'] = $_REQUEST['reg_exp'];
												break;
								case "date":
												$attr_setup['min_age'] = $_REQUEST['min_age'];
												$attr_setup['max_age'] = $_REQUEST['max_age'];
				}
				$attr_data['setup'] = $attr_setup;
				$form = new form($dbconn, $config);
				$form->addsectionattribute($id_section, $attr_data);
				header("location: form_blocks.php?id_section=" . $id_section);
}
function updateattribute($id_attr, $id_section)
{
				global $dbconn;
				global $config;
				global $smarty;
				global $lang;
				$attr_data['field_name'] = $_REQUEST['field_name'];
				$attr_data['mandatory'] = isset($_REQUEST['mandatory']) ? "Y" : "N";
				$attr_data['control_type'] = $_REQUEST['control_type'];
				$attr_setup = array();
				switch ($_REQUEST['control_type'])
				{
								case "checkbox":
												$attr_setup['def_value'] = isset($_REQUEST['def_value']) ? 1:
												0;
												break;
								case "text":
												$attr_setup['def_value'] = $_REQUEST['def_value'];
												$attr_setup['max_len'] = $_REQUEST['max_len'];
												$attr_setup['reg_exp'] = $_REQUEST['reg_exp'];
												break;
								case "select":
												$attr_setup = array();
												$i = 0;
												$temp = explode(";", $_REQUEST['s_data']);
												foreach ($temp as $element)
												{
																if ($element == "")
																{
																} else
																{
																				$temp_elem = explode("&", $element);
																				$attr_setup['values'][$i]['id'] = $temp_elem[0];
																				$attr_setup['values'][$i]['name'] = $temp_elem[1];
																				++$i;
																}
												}
												$attr_setup['select_type'] = $_REQUEST['select_type'];
												if ($attr_setup['select_type'] == "listbox")
												{
																$attr_setup['vsize'] = intval($_REQUEST['vsize']);
																$attr_setup['is_mult'] = isset($_REQUEST['is_mult']) ? 1 : 0;
												}
												$attr_setup['datasource'] = $_REQUEST['datasource'];
												break;
								case "textarea":
												$attr_setup['def_value'] = $_REQUEST['def_value'];
												$attr_setup['reg_exp'] = $_REQUEST['reg_exp'];
												break;
								case "date":
												$attr_setup['min_age'] = $_REQUEST['min_age'];
												$attr_setup['max_age'] = $_REQUEST['max_age'];
				}
				$attr_data['setup'] = $attr_setup;
				$form = new form($dbconn, $config);
				$form->updatesectionattribute($id_attr, $attr_data);
				header("location: form_blocks.php?id_section=" . $id_section);
}
include ("../include/config.php");
include ("../include/class.form.php");
include_once ("../common.php");
header("Content-type: text/html; charset=" . $charset);
$smarty->assign("template_root", $config['admin_theme_path']);
@$sel = $_REQUEST['sel'];
header("Content-Type: text/plain; charset=utf-8");
switch ($sel)
{
				case "get_section_attrs":
								$id_section = $_REQUEST['id_section'];
								getsectionattrs($id_section);
								break;
				case "get_attr_form":
								$act = $_REQUEST['act'];
								$id_section = $_REQUEST['id_sec'];
								$id_attr = $_REQUEST['id_attr'];
								getattributeform($act, $id_section, $id_attr);
								break;
				case "get_attr_props_form":
								$control_type = $_REQUEST['control_type'];
								$id_attr = isset($_REQUEST['id_attr']) ? $_REQUEST['id_attr']:
								0;
								getattributepropertiesform($control_type, $id_attr);
								break;
				case "add_attr":
								$id_section = $_REQUEST['id_sec'];
								addattribute($id_section);
								break;
				case "update_attr":
								$id_attr = $_REQUEST['id_attr'];
								$id_section = $_REQUEST['id_sec'];
								updateattribute($id_attr, $id_section);
								break;
				case "del_section_attr":
								$id_attr = $_REQUEST['id_attr'];
								$form = new form($dbconn, $config);
								$form->delsectionattribute($id_attr);
}
header("Content-Type: text/plain; charset=utf-8");
?>
