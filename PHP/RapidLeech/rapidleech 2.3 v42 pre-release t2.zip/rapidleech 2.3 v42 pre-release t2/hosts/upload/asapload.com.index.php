<?php
$upload_services[]="asapload.com";
$max_file_size["asapload.com"]=1024;
$page_upload["asapload.com"] = "asapload.com.php";
?>