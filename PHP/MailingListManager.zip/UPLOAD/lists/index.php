<?php
include ("../common.php");
include ("../include/lists_function.php");
$section = "lists";
$right_name = "view";
check_right($section, $right_name);
if (isset($_POST['del']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				foreach ($GLOBALS['_POST']['del'] as $val)
				{
								dellist((integer)$val);
				}
}
if (isset($_GET['clear_id']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				$res = $dbconn->execute("DELETE FROM clients_lists WHERE list_id='" . (integer)$_GET['clear_id'] . "'");
}
if (isset($_GET['erase_id']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				$res = $dbconn->execute("SELECT * FROM clients_lists WHERE list_id='" . (integer)$_GET['erase_id'] . "'");
				while (!$res->EOF)
				{
								$c = $dbconn->execute("DELETE FROM snd_users WHERE id='" . $res->fields[0] . "'");
								$res->movenext();
				}
				$res = $dbconn->execute("DELETE FROM list WHERE id='" . (integer)$_GET['erase_id'] . "'");
}
if (isset($_GET['did']) && !empty($_GET['did']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				dellist((integer)$_GET['did']);
}
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "date";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
} else
{
				$order = "";
}
$list_page = isset($_REQUEST['list_page']) ? $_REQUEST['list_page'] : 0;
$smarty->assign("razdel", "Mailing Lists");
$smarty->assign("description", "Manage Lists");
$smarty->assign("hint", "You can view a list of users subscribed to a certain mailing list (users number is shown in the brackets). To delete users from this list click \"Clear\" button. As a result, all the subscribers of the list will be unsubscribed");
$GLOBALS['_SESSION']['return_url'] = "index.php";
$smarty->assign("order", $order);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("list_page", $list_page);
$smarty->assign("rel", getlists($order, $list_page));
$smarty->display("{$admin_nl_gentemplates}/lists_lists_list.tpl");
?>
