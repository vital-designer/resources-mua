<?php 
$upload_services[]="uploaded.to";
$max_file_size["uploaded.to"]=250;
$page_upload["uploaded.to"] = "uploaded.to.php";  
?>