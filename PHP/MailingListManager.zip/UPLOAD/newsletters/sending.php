<?php
include ("../common.php");
include ("../include/newsletters_function.php");
ini_set("max_execution_time", 100);
ini_set("display_errors", "0");
error_reporting(E_ALL);
$us = sendrelease((integer)$_GET['id'], $_SESSION['list'], $_REQUEST['is_test'], false, (integer)$_GET['match_list'], $_GET['match_status']);
?>