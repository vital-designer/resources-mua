<?php 
$upload_services[] = "rapidshare.com_premium";
$max_file_size["rapidshare.com_premium"] = 200;
$page_upload["rapidshare.com_premium"] = "rapidshare.com_premium.php";  
?>