<?php
// Heading
$_['heading_title']    = 'BizRate';

// Text 
$_['text_payment']     = 'Product Feeds';
$_['text_success']     = 'Success: You have modified BizRate feed!';
$_['text_development'] = '<span style="color: red;">In Development</span>';
?>