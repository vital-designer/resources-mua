<?php
$upload_services[]="ifolder.ru";
$max_file_size["ifolder.ru"]=100;
$page_upload["ifolder.ru"] = "ifolder.ru.php";  
?>