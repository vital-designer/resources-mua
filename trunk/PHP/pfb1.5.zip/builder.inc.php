<?
//phpFormBuilder Version 1.5 by Baris Kayar (barishkayar@yahoo.com)
//2002(cl)  The FormBuilder Group http://pfb.sourceforge.net

$fmformfields="";
$fmformsetvalues="";
$fminsertbas="";
$fminsertson="";
$fmaction="";
$fmform="";
$fmupdate="";
$fmselectfields="\$unique,";
$fmfieldcaptions=	
"\t\t<td bgcolor=\\\"#66ccff\\\">".
"<a href=\\\"\$dosya.php?order=\$unique&sort=desc&start=\$start&Hc=\$Hc&filtre=\$filtre\\\">&lt;&lt;</a>".
"<b>&nbsp;\$unique&nbsp;</b>".
"<a href=\\\"\$dosya.php?order=\$unique&sort=asc&start=\$start&Hc=\$Hc&filtre=\$filtre\\\">&gt;&gt;</a>".
"</td>\n";

for ($i=0;$i<sizeof($postlistvars);$i++) 
{
if ($i==sizeof($postlistvars)-1)
	$fmselectfields.=$postlistvars[$i];
	else
	$fmselectfields.=$postlistvars[$i].",";
$fmfieldcaptions.=	
"\t\t<td bgcolor=\\\"#66ccff\\\">".
"<a href=\\\"\$dosya.php?order=$postlistvars[$i]&sort=desc&start=\$start&Hc=\$Hc&filtre=\$filtre\\\">&lt;&lt;</a>".
"<b>&nbsp;".$postlistvars[$i]."&nbsp;</b>".
"<a href=\\\"\$dosya.php?order=$postlistvars[$i]&sort=asc&start=\$start&Hc=\$Hc&filtre=\$filtre\\\">&gt;&gt;</a>".
"</td>\n";
}
for ($i=0;$i<sizeof($postvars);$i++) 
{
//echo $postvars[$i]."&nbsp;&nbsp;".$postvalues[$i]."<br>"; // ne gelmi� bi g�relim
$fmformfields.="\$".$postvars[$i]."=addslashes(\$".$postvars[$i].");\n";
$fmformsetvalues.="\$".$postvars[$i]."=mysql_result(\$qselect,0,\"".$postvars[$i]."\");\n";
if ($i==sizeof($postvars)-1)
	{
	$fminsertbas.=$postvars[$i];
	$fminsertson.="'\$".$postvars[$i]."'";
	$fmupdate.=$postvars[$i]."='\$".$postvars[$i]."'";
	}
	else
	{
	$fminsertbas.=$postvars[$i].",";
	$fminsertson.="'\$".$postvars[$i]."',";
	$fmupdate.=$postvars[$i]."='\$".$postvars[$i]."',";
	}
}
$fmdosyaadi="style.inc.php";
$fmdosyagostergesi = fopen ($fmdosyaadi, "r");
$fmstyle=fread($fmdosyagostergesi,filesize($fmdosyaadi));
fclose($fmdosyagostergesi);
$fmstyle=str_replace("\$PFBg_Title","$table powered by phpFormBuilder",$fmstyle);
$fmdosyaadi="about.inc.php";
$fmdosyagostergesi = fopen ($fmdosyaadi, "r");
$fmabout=fread($fmdosyagostergesi,filesize($fmdosyaadi));
fclose($fmdosyagostergesi);
$fmgiris="<?
\$server=\"$server\";
\$user=\"$users[$hostindex]\";
\$pass=\"$passes[$hostindex]\";
\$database=\"$database\";
\$table=\"$table\";
mysql_connect(\$server,\$user,\$pass);
mysql_select_db(\$database);
\$actnow=\"ekle\";
\$dosya=\"$dosya\";
\$unique=\"$unique\";
\$silinecek=\$\$unique;
if (!\$order) \$order=\$unique;
if (!\$sort) \$sort=\"asc\";";
if  ($chkupdate || $chkdelete || $chklist)
$fmgiris.=
"if (!\$start) \$start=\"0\";
if (!\$Hc) \$Hc=$HavingCount;
if (\$Sayfa) \$start=\$Sayfa*\$Hc;
\$rowColors=Array(\"$PFBg_rowColors[0]\",\"$PFBg_rowColors[1]\");\n";
$fmaction="";
if ($chkupdate || $chkinsert)
$fmaction.=
"if (\$act==\"ekle\")
{\n".$fmformfields.
"\$q=\"insert into \$table (".$fminsertbas.") values (".$fminsertson.")\";\n".
"\$qinsert=mysql_query(\$q);
}\n";
if ($chkdelete)
$fmaction.=
"if (\$act==\"sil\")
{
\$q=\"delete from \$table where \$unique='\$silinecek'\";
\$qdelete=mysql_query(\$q);
}\n";
if ($chkupdate)
$fmaction.=
"if (\$act==\"upd\")
{\n".$fmformfields.
"\$q=\"update \$table set ".$fmupdate." where \$unique='\$silinecek'\";
\$qupdate=mysql_query(\$q);
}";
$fmaction.="\n?>\n";
$fmhtml=$fmstyle."<body marginheight=0 marginwidth=0 topmargin=0 leftmargin=0>\n";
if ($chkupdate || $chkinsert) $fmhtml.="$PFB_js";
$fmhtml.=
"<script>
function uleynsubmitedilirmi2() {
with (document.limit)
{
if (Hc.value==\"\") 
				{
				alert (\"$Limit_Caption $ErrorMsg_1\");
				Hc.focus();
				return false;
				}
if (isNaN (Hc.value)) 
				{
				alert (\"$Limit_Caption $ErrorMsg_2\");
				Hc.focus();
				return false;
				}
}
}
function uleynsubmitedilirmi3() {
with (document.page)
{
if (Sayfa.value==\"\") 
				{
				alert (\"$Page_Caption $ErrorMsg_1\");
				Sayfa.focus();
				return false;
				}
if (isNaN (Sayfa.value)) 
				{
				alert (\"$Page_Caption $ErrorMsg_2\");
				Sayfa.focus();
				return false;
				}
}
}
</script>\n";
$fmhtml.="<table width=\"100%\" border=1><tr><td width=\"100%\" align=\"center\" valign=\"top\">";
$fmhtml.=	"<table width=\"600\">\n<tr><td width=\"590\" height=\"30\" valign=\"middle\" bgcolor=\"#CFCFCF\">\n".
			"<b>$DbList_Caption :</b> <? echo \$database;?> | <b>$Table_Caption :</b> <? echo \$table;?>\n</td></tr>\n".
			"</table><br>\n";
if ($chkupdate || $chkinsert) $fmhtml.="<a href=\"<? echo \"\$dosya.php?start=\$start&order=\$order&sort=\$sort&Hc=\$Hc&filtre=\$filtre\";?>\"><b>$NewRecord_Caption</b></a>\n";
$fmhtml.="<?\n";
if  ($chkupdate || $chkdelete || $chklist)
$fmhtml.=	"\$filtre=str_replace(\"\\\\\",\"\",\$filtre);\n".
			"if (\$filtre) \$where=\"where \$filtre\"; else \$where=\"\";\n".
			"\$q=\"select $fmselectfields from \$table \$where order by \$order \$sort limit \$start,\".(\$Hc+1);\n".
			"\$qselect=mysql_query(\$q);\n".
			"\$listRc=mysql_numrows(\$qselect);\n".
			"if (\$listRc>\$Hc) \$listRowc=\$Hc; else \$listRowc=\$listRc;\n".
			"echo \"<table border=1>\";\n".
			"echo \t\"<tr>\n$fmfieldcaptions\t\t</tr>\";\n".
			"\$i=0;\n".
			"while(\$i<\$listRowc)\n".
			"{\n".
				"echo \"<tr>\";\n".
				"\$j=0;\n".
				"while (\$j<mysql_num_fields(\$qselect))\n".
				"\t {\n".
				"\t echo \"<td bgcolor=\\\"\".\$rowColors[\$i%2].\"\\\">\";\n".
				"\t echo mysql_result(\$qselect,\$i,\$j);\n".
				"\t echo \"</td>\";\n".
				"\t \$j++;\n".
				"\t }\n";
if ($chkdelete)
$fmhtml.="echo \"<td bgcolor=\\\"\".\$rowColors[\$i%2].\"\\\"><a href=\\\"\$dosya.php?act=sil&\$unique=\".mysql_result(\$qselect,\$i,\"\$unique\").\"&order=\$order&sort=\$sort&start=\$start&Hc=\$Hc&filtre=\$filtre\\\"><b>$Delete_Caption</b></a></td>\";\n";
if ($chkupdate)
$fmhtml.="echo \"<td bgcolor=\\\"\".\$rowColors[\$i%2].\"\\\"><a href=\\\"\$dosya.php?act=deg&\$unique=\".mysql_result(\$qselect,\$i,\"\$unique\").\"&order=\$order&sort=\$sort&start=\$start&Hc=\$Hc&filtre=\$filtre\\\"><b>$Update_Caption</b></a></td>\";\n";
if  ($chkupdate || $chkdelete || $chklist)
$fmhtml.="echo \"</tr>\";\n\$i++;\n}\necho \"</table>\";\n";
if  ($chkupdate || $chkdelete || $chklist)
$fmform.=
"if (\$start>=\$Hc) 
	\$prevlink=	\"<a href=\\\"\$dosya.php?start=\".
				(\$start-\$Hc).
				\"&Hc=\$Hc&order=\$order&sort=\$sort&filtre=\$filtre\\\">\".
				\"<b>previous page &lt;&lt;</b></a>&nbsp;&nbsp;\";
	else 
	\$prevlink=	\"$PrevPage_Caption &lt;&lt;&nbsp;&nbsp;\";

if (\$listRc>\$Hc)
	\$nextlink=	\"&nbsp;&nbsp;<a href=\\\"\$dosya.php?start=\".(\$start+\$Hc).
				\"&Hc=\$Hc&order=\$order&sort=\$sort&filtre=\$filtre\\\">\".
				\"<b>&gt;&gt; next page</b></a>\";
	else 
	\$nextlink=	\"&nbsp;&nbsp;&gt;&gt;$NextPage_Caption\";
echo \"<table><tr>\";
echo \"<td align=center valign=middle>\$prevlink</td>\";
echo \"<td align=center valign=middle>\$nextlink</td>\";\n";
$fmform.="echo 	\"</tr><tr><td align=center valign=middle>\";\n";
$fmform.=
"echo\n\"<form method=post name=limit action=\\\"\$dosya.php?order=\$order&sort=\$sort&start=\$start&filtre=\$filtre\\\"\n".
"onsubmit=\\\"return uleynsubmitedilirmi2();\\\">\n".
"$Limit_Caption:<input type=text name=Hc maxlength=3 size=5 value=\\\"\$Hc\\\">\n".
"<input type=submit value=$Go_Caption>\n".
"</form></td><td align=center>\";\n".
"echo\n\"<form method=post name=page action=\\\"\$dosya.php?order=\$order&sort=\$sort&start=\$start&Hc=\$Hc&filtre=\$filtre\\\"\n".
"onsubmit=\\\"return uleynsubmitedilirmi3();\\\">\n".
"$Page_Caption:<input type=text name=Sayfa maxlength=3 size=5 value=\\\"\$Sayfa\\\">\n".
"<input type=submit value=$Go_Caption>\n".
"</form></td></tr>\";\n".
"echo \n\"<tr><td align=center colspan=2>\".\n\"<form method=post name=filtre action=\\\"\$dosya.php?order=\$order&sort=\$sort&start=\$start&Hc=\$Hc\\\">\n".
"$Filter_Caption:<input type=text name=filtre maxlength=255 size=30 value=\\\"\$filtre\\\">\n".
"<input type=submit value=$Go_Caption><br>\n $Example_Caption: id>'3' and title like '%x%'\n".
"</form></td></tr>\";\n";
$fmform.="echo \"</table>\";\n";
if ($chkupdate)
$fmform.=
"if (\$act==\"deg\")\n".
"{\n".
"\$q=\"select * from \$table where \$unique='\$silinecek'\";\n".
"\$qselect=mysql_query(\$q);\n".
"\$actnow=\"upd\";\n".$fmformsetvalues.
"}\n";
$fmform.="?>\n<hr width=\"600\">\n";
if ($chkupdate || $chkinsert)
$fmform.=
"<form name=\"<? echo \$table;?>\" action=\"<? echo \"\$dosya.php?act=\$actnow&\$unique=\$silinecek&order=\$order&sort=\$sort&start=\$start&Hc=\$Hc&filtre=\$filtre\";?>\" method=\"post\"  onsubmit=\"return uleynsubmitedilirmi();\">".
"\n<table>".$fmformsetedits."\n".
"<tr><td colspan=2 align=\"center\"><input type=\"Submit\" value=\"$OkayButon_Caption\" name=\"submit\">&nbsp;&nbsp;<input type=\"reset\" name=\"reset\" value=\"$CancelButon_Caption\"></td></tr>
</table></form>\n";
$fmform.="</td></tr><tr><td align=center>powered by <a href=\"http://pfb.sourceforge.net/\" target=\"_blank\" class=\"linkler\">phpFormBuilder</a></td></tr></table>\n";
$fmform.="<? mysql_close();?>\n";
$fmend="</body></html>";
$fmdosyaadi="out/$dosya.php";
$fmdosyagostergesi = fopen ($fmdosyaadi, "w");
fwrite($fmdosyagostergesi,$fmgiris);
fwrite($fmdosyagostergesi,$fmaction);
fwrite($fmdosyagostergesi,$fmhtml);
fwrite($fmdosyagostergesi,$fmform);
//fwrite($fmdosyagostergesi,$fmabout); //iptal ettim :))
fwrite($fmdosyagostergesi,$fmend);
fclose($fmdosyagostergesi);
//header("location:$fmdosyaadi");  //iptal ettim :))
echo "<h4>$Complete_Caption!</h4>";
echo "<script>window.open(\"$fmdosyaadi\");</script>";
?>
