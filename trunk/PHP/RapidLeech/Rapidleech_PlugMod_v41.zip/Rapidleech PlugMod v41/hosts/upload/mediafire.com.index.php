<?
$upload_services[]="mediafire.com";
$max_file_size["mediafire.com"]=100;
$page_upload["mediafire.com"] = "mediafire.com.php";
?>