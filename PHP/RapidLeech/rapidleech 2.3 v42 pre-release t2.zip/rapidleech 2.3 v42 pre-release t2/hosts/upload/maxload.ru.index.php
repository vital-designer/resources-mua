<?php
$upload_services[]="maxload.ru";
$max_file_size["maxload.ru"]=2000;
$page_upload["maxload.ru"] = "maxload.ru.php";  
?>