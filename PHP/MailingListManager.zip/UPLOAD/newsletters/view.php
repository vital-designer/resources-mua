<?php
include ("../common.php");
include ("../include/newsletters_function.php");
$section = "newsletters";
$right_name = "view_item";
check_right($section, $right_name);
$content = getcontent((integer)$_GET['id']);
$content['body'] = html_entity_decode(html_entity_decode($content['body']));
$smarty->assign("content", $content['body']);
$smarty->display("{$admin_nl_gentemplates}/newsletters_newsletter_view.tpl");
?>