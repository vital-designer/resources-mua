<?php
$upload_services[]="oron.com_member";
$max_file_size["oron.com_member"]=400;
$page_upload["oron.com_member"] = "oron.com_member.php";  
?>