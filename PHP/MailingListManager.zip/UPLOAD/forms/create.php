<?php
include ("../common.php");
include ("../include/forms_function.php");
$section = "forms";
if (isset($_POST['FormName']))
{
				$right_name = "create";
				check_right($section, $right_name);
				$GLOBALS['_POST']['captcha'] = $_POST['captcha'] == "on" ? 1 : 0;
				if (!isset($_REQUEST['id']) || trim($_REQUEST['id']) == "")
				{
								$res = $dbconn->execute("insert into form\r\n\t\t(\tname,\r\n\t\t\ttype,\r\n\t\t\tconfirmation,\r\n\t\t\tthankyou,\r\n\t\t\tconfirmation_text,\r\n\t\t\tthankyou_text,\r\n\t\t\tconfirmation_url,\r\n\t\t\tthankyou_url,\r\n\t\t\tconfirmation_email,\r\n\t\t\tthankyou_email,\r\n\t\t\tdate,\r\n\t\t\tfrom_name,\r\n\t\t\tfrom_email,\r\n\t\t\tthankyou_subject,\r\n\t\t\tconfirmation_subject,\r\n\t\t\tcaptcha\r\n\t\t) values\r\n\t\t('" . str_prepare($_POST['FormName']) . "',\r\n\t\t '" . str_prepare($_POST['FormType']) . "',\r\n\t\t '" . str_prepare($_POST['RequireConfirm']) . "',\r\n\t\t '" . str_prepare($_POST['SendThankyou']) . "',\r\n\t\t '" . str_prepare($_POST['Responses']['ConfirmPage']) . "',\r\n\t\t '" . str_prepare($_POST['Responses']['ThanksPage']) . "',\r\n\t\t '" . str_prepare($_POST['Responses']['ConfirmURL']) . "',\r\n\t\t '" . str_prepare($_POST['Responses']['ThanksURL']) . "',\r\n\t\t '" . str_prepare($_POST['Responses']['ConfirmEmail']) . "',\r\n\t\t '" . str_prepare($_POST['Responses']['ThanksEmail']) .
												"',\r\n\t\t NOW(),\r\n\t\t '" . str_prepare($_POST['Responses']['FromName']) . "',\r\n\t\t '" . str_prepare($_POST['Responses']['FromEmail']) . "',\r\n\t\t '" . str_prepare($_POST['Responses']['ThanksSubject']) . "',\r\n\t\t '" . str_prepare($_POST['Responses']['ConfirmSubject']) . "',\r\n\t\t '" . $_POST['captcha'] . "'\r\n\t\t )");
								$fid = $dbconn->_insertid();
								foreach ($GLOBALS['_POST']['Lists'] as $list)
								{
												$res = $dbconn->execute("insert into forms_lists (form_id,list_id) values ('" . $fid . "','" . $list . "')");
								}
								$smarty->assign("id", $fid);
								$smarty->assign("razdel", "Forms");
								$smarty->assign("description", "Report");
								$smarty->assign("hint", "New form create");
								$smarty->display("{$admin_nl_gentemplates}/forms_create_form.tpl");
				} else
				{
								$right_name = "edit";
								check_right($section, $right_name);
								$res = $dbconn->execute("UPDATE form SET\r\n\t\t\tname = '" . str_prepare($_POST['FormName']) . "',\r\n\t\t\ttype = '" . str_prepare($_POST['FormType']) . "',\r\n\t\t\tconfirmation = '" . str_prepare($_POST['RequireConfirm']) . "',\r\n\t\t\tthankyou = '" . str_prepare($_POST['SendThankyou']) . "',\r\n\t\t\tconfirmation_text = '" . str_prepare($_POST['Responses']['ConfirmPage']) . "',\r\n\t\t\tthankyou_text = '" . str_prepare($_POST['Responses']['ThanksPage']) . "',\r\n\t\t\tconfirmation_url = '" . str_prepare($_POST['Responses']['ConfirmURL']) . "',\r\n\t\t\tthankyou_url = '" . str_prepare($_POST['Responses']['ThanksURL']) . "',\r\n\t\t\tconfirmation_email = '" . str_prepare($_POST['Responses']['ConfirmEmail']) . "',\r\n\t\t\tthankyou_email = '" . str_prepare($_POST['Responses']['ThanksEmail']) . "',\r\n\t\t\tfrom_name = '" . str_prepare($_POST['Responses']['FromName']) . "',\r\n\t\t\tfrom_email = '" . str_prepare($_POST['Responses']['FromEmail']) . "',\r\n\t\t\tthankyou_subject = '" .
												str_prepare($_POST['Responses']['ThanksSubject']) . "',\r\n\t\t\tconfirmation_subject = '" . str_prepare($_POST['Responses']['ConfirmSubject']) . "',\r\n\t\t\tcaptcha = '" . $_POST['captcha'] . "'\r\n\t\t\tWHERE id='" . $_REQUEST['id'] . "'");
								$res = $dbconn->execute("DELETE FROM forms_lists WHERE form_id='" . $_REQUEST['id'] . "'");
								foreach ($GLOBALS['_POST']['Lists'] as $list)
								{
												$res = $dbconn->execute("insert into forms_lists (form_id,list_id) values ('" . $_REQUEST['id'] . "','" . $list . "')");
								}
								header("Location: index.php");
				}
} else
{
				$right_name = "create";
				check_right($section, $right_name);
				if (isset($_GET['lid']) && !empty($_GET['lid']))
				{
								$form['type'] = "sub";
								$smarty->assign("form", $form);
								$smarty->assign("lid", $_GET['lid']);
				}
				$smarty->assign("razdel", "Forms");
				$smarty->assign("description", "New Form Creating: Step 1");
				$smarty->assign("hint", "Indicate Form Name and choose its Type.");
				$smarty->display("{$admin_nl_gentemplates}/forms_create_form1.tpl");
}
?>
