// UK lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Run spell checking',
iespell_download : "ieSpell not detected. Click OK to go to download page."
});

