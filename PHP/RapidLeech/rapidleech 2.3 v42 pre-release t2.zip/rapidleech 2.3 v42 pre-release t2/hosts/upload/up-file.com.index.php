<?php 
$upload_services[]="up-file.com";
$max_file_size["up-file.com"]=1200;
$page_upload["up-file.com"] = "up-file.com.php";  
?>