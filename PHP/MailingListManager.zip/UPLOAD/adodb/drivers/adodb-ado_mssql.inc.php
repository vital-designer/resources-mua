<?php
if (!defined("_ADODB_ADO_LAYER"))
{
				include (ADODB_DIR . "/drivers/adodb-ado.inc.php");
}
class adodb_ado_mssql extends adodb_ado
{
				var $databaseType = "ado_mssql";
				var $hasTop = true;
}
class adorecordset_ado_mssql extends adorecordset_ado
{
				var $databaseType = "ado_mssql";
				function adorecordset_ado_mssql(&$id)
				{
								return $this->adorecordset_ado($id);
				}
				function recordcount()
				{
								return sizeof($this->getarray());
				}
				function rowcount()
				{
								return $this->recordcount();
				}
}
?>