<?php
define("_ADODB_ODBC_LAYER", 1);
class adodb_odbc extends adoconnection
{
				var $databaseType = "odbc";
				var $fmtDate = "'Y-m-d'";
				var $fmtTimeStamp = "'Y-m-d, h:i:sA'";
				var $replaceQuote = "''";
				var $dataProvider = "odbc";
				var $hasAffectedRows = true;
				var $binmode = ODBC_BINMODE_RETURN;
				var $_bindInputArray = false;
				var $_haserrorfunctions = false;
				var $curmode = SQL_CUR_USE_DRIVER;
				var $_genSeqSQL = "create table %s (id integer)";
				function adodb_odbc()
				{
								$this->_haserrorfunctions = 0 <= strnatcmp(PHP_VERSION, "4.0.5");
				}
				function errormsg()
				{
								if ($this->_haserrorfunctions)
								{
												if (empty($this->_connectionID))
												{
																return odbc_errormsg();
												}
												return odbc_errormsg($this->_connectionID);
								} else
								{
												return adoconnection::errormsg();
								}
				}
				function genid($seq = "adodbseq", $start = 1)
				{
								$MAXLOOPS = 100;
								while (0 <= --$MAXLOOPS)
								{
												$num = $this->getone("select id from {$seq}");
												if ($num === false)
												{
																$this->execute(sprintf($this->_genSeqSQL, $seq));
																$start -= 1;
																$num = "0";
																$ok = $this->execute("insert into {$seq} values({$start})");
																if (!$ok)
																{
																				return false;
																}
												}
												$this->execute("update {$seq} set id=id+1 where id={$num}");
												if ($this->affected_rows() == 1)
												{
																$num += 1;
																$this->genID = $num;
																return $num;
												}
								}
								if ($fn = $this->raiseErrorFn)
								{
												$fn($this->databaseType, "GENID", -32000, "Unable to generate unique id after {$MAXLOOP} attempts", $seq, $num);
								}
								return false;
				}
				function errorno()
				{
								if ($this->_haserrorfunctions)
								{
												if (empty($this->_connectionID))
												{
																$e = @odbc_error();
												} else
												{
																$e = @odbc_error($this->_connectionID);
												}
												if (strlen($e) <= 2)
												{
																return 0;
												}
												return $e;
								} else
								{
												return adoconnection::errorno();
								}
				}
				function _connect($argDSN, $argUsername, $argPassword, $argDatabasename)
				{
								global $php_errormsg;
								$php_errormsg = "";
								$this->_connectionID = odbc_connect($argDSN, $argUsername, $argPassword, $this->curmode);
								$this->_errorMsg = $php_errormsg;
								return $this->_connectionID != false;
				}
				function _pconnect($argDSN, $argUsername, $argPassword, $argDatabasename)
				{
								global $php_errormsg;
								$php_errormsg = "";
								$this->_connectionID = odbc_pconnect($argDSN, $argUsername, $argPassword, $this->curmode);
								$this->_errorMsg = $php_errormsg;
								return $this->_connectionID != false;
				}
				function begintrans()
				{
								return odbc_autocommit($this->_connectionID, false);
				}
				function committrans()
				{
								$ret = odbc_commit($this->_connectionID);
								odbc_autocommit($this->_connectionID, true);
								return $ret;
				}
				function rollbacktrans()
				{
								$ret = odbc_rollback($this->_connectionID);
								odbc_autocommit($this->_connectionID, true);
								return $ret;
				}
				function &metatables()
				{
								$qid = odbc_tables($this->_connectionID);
								$rs = new adorecordset_odbc($qid);
								$arr = &$rs->getarray();
								$rs->close();
								$arr2 = array();
								$i = 0;
								for (; $i < sizeof($arr); ++$i)
								{
												if ($arr[$i][2])
												{
																$arr2[] = $arr[$i][2];
												}
								}
								return $arr2;
				}
				function odbctypes($t)
				{
								switch ((integer)$t)
								{
												case 1:
												case 12:
												case 0:
																return "C";
												case - 1:
																return "X";
												case - 4:
																return "B";
												case 91:
												case 11:
																return "D";
												case 92:
												case 93:
												case 9:
																return "T";
												case 4:
												case 5:
												case - 6:
																return "I";
												case - 11:
																return "R";
												case - 7:
																return "L";
												default:
																return "N";
								}
				}
				function &metacolumns($table)
				{
								$table = strtoupper($table);
								$qid = odbc_columns($this->_connectionID);
								$rs = new adorecordset_odbc($qid);
								if (!$rs)
								{
												return false;
								}
								$retarr = array();
								while (!$rs->EOF)
								{
												if (strtoupper($rs->fields[2]) == $table)
												{
																$fld = new adofieldobject();
																$fld->name = $rs->fields[3];
																$fld->type = $this->odbctypes($rs->fields[4]);
																$fld->max_length = $rs->fields[7];
																$retarr[strtoupper($fld->name)] = $fld;
												} else
												{
																if (0 < sizeof($retarr))
																{
																				break;
																}
												}
												$rs->movenext();
								}
								$rs->close();
								return $retarr;
				}
				function prepare($sql)
				{
								if (!$this->_bindInputArray)
								{
												return $sql;
								}
								$stmt = odbc_prepare($this->_connectionID, $sql);
								if (!$stmt)
								{
												return $sql;
								}
								return array($sql, $stmt, false);
				}
				function _query($sql, $inputarr = false)
				{
								global $php_errormsg;
								$php_errormsg = "";
								$this->_error = "";
								if ($inputarr)
								{
												if (is_array($sql))
												{
																$stmtid = $sql[1];
												} else
												{
																$stmtid = odbc_prepare($this->_connectionID, $sql);
												}
												if ($stmtid == false)
												{
																$this->_errorMsg = $php_errormsg;
																return false;
												}
												if (!odbc_execute($stmtid, $inputarr))
												{
																@odbc_free_result($stmtid);
																return false;
												}
								} else
												if (is_array($sql))
												{
																$stmtid = $sql[1];
																if (!odbc_execute($stmtid))
																{
																				@odbc_free_result($stmtid);
																				return false;
																}
												} else
												{
																$stmtid = odbc_exec($this->_connectionID, $sql);
												}
												if ($stmtid)
												{
																odbc_binmode($stmtid, $this->binmode);
																odbc_longreadlen($stmtid, $this->maxblobsize);
												}
								$this->_errorMsg = $php_errormsg;
								return $stmtid;
				}
				function updateblob($table, $column, $val, $where, $blobtype = "BLOB")
				{
								return $this->execute("UPDATE {$table} SET {$column}=? WHERE {$where}", array($val)) != false;
				}
				function _close()
				{
								$ret = @odbc_close($this->_connectionID);
								$this->_connectionID = false;
								return $ret;
				}
				function _affectedrows()
				{
								return odbc_num_rows($this->_queryID);
				}
}
class adorecordset_odbc extends adorecordset
{
				var $bind = false;
				var $databaseType = "odbc";
				var $dataProvider = "odbc";
				function adorecordset_odbc($id)
				{
								global $ADODB_FETCH_MODE;
								$this->fetchMode = $ADODB_FETCH_MODE;
								return $this->adorecordset($id);
				}
				function &fetchfield($fieldOffset = -1)
				{
								$off = $fieldOffset + 1;
								$o = new adofieldobject();
								$o->name = @odbc_field_name($this->_queryID, $off);
								$o->type = @odbc_field_type($this->_queryID, $off);
								$o->max_length = @odbc_field_len($this->_queryID, $off);
								return $o;
				}
				function fields($colname)
				{
								if ($this->fetchMode == ADODB_FETCH_ASSOC)
								{
												return $this->fields[$colname];
								}
								if (!$this->bind)
								{
												$this->bind = array();
												$i = 0;
												for (; $i < $this->_numOfFields; ++$i)
												{
																$o = $this->fetchfield($i);
																$this->bind[strtoupper($o->name)] = $i;
												}
								}
								return $this->fields[$this->bind[strtoupper($colname)]];
				}
				function _initrs()
				{
								$this->_numOfRows = @odbc_num_rows($this->_queryID);
								$this->_numOfFields = @odbc_num_fields($this->_queryID);
				}
				function _seek($row)
				{
								return false;
				}
				function movenext()
				{
								if ($this->_numOfRows != 0 && !$this->EOF)
								{
												++$this->_currentRow;
												$row = 0;
												if (odbc_fetch_into($this->_queryID, $row, $this->fields))
												{
																if ($this->fetchMode == ADODB_FETCH_ASSOC)
																{
																				$this->fields = $this->getrowassoc(false);
																}
																return true;
												}
								}
								$this->EOF = true;
								return false;
				}
				function _fetch()
				{
								$row = 0;
								$rez = odbc_fetch_into($this->_queryID, $row, $this->fields);
								if ($rez && $this->fetchMode == ADODB_FETCH_ASSOC)
								{
												$this->fields = $this->getrowassoc(false);
								}
								return $rez;
				}
				function _close()
				{
								return odbc_free_result($this->_queryID);
				}
}
?>