<?php
include ("common.php");
if (!isset($_GET['cl']) || empty($_GET['cl']))
{
				$link = "http://www.google.com";
				header("Location: " . $link);
				exit();
}
if (!preg_match("/http/i", $_GET['cl']))
{
				$link = "http://" . urldecode($_GET['cl']);
}
else
{
				$link = urldecode($_GET['cl']);
}
if (isset($_GET['cu']) && !empty($_GET['cu']) && isset($_GET['cr']) && !empty($_GET['cr']))
{
				$rs = $dbconn->execute("select * from click_counter where client_id='" . $_GET['cu'] . "' and release_id='" . $_GET['cr'] . "' and url='" . addslashes($link) . "' and time > (NOW() - Interval " . $config['interval_between_click'] . " minute)");
				if (!$rs->rowcount())
				{
								$rs = $dbconn->execute("insert into click_counter (client_id,release_id,url,time) values ('" . $_GET['cu'] . "','" . $_GET['cr'] . "','" . addslashes($link) . "',NOW())");
				}
}
header("Location: " . $link);
?>