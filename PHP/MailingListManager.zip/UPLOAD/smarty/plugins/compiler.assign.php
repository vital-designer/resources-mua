<?php
function smarty_compiler_assign($tag_attrs, &$compiler)
{
				$_params = $compiler->_parse_attrs($tag_attrs);
				if (!isset($_params['var']))
				{
								$compiler->_syntax_error("assign: missing 'var' parameter", E_USER_WARNING);
				} else
								if (!isset($_params['value']))
								{
												$compiler->_syntax_error("assign: missing 'value' parameter", E_USER_WARNING);
								} else
								{
												return "\$this->assign({$_params['var']}, {$_params['value']});";
								}
}
?>