<?php
$upload_services[]="files.ge";
$max_file_size["files.ge"]=2000;
$page_upload["files.ge"] = "files.ge.php";
?>