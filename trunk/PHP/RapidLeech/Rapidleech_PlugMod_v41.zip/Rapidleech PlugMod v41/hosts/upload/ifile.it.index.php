<?php
$upload_services[]="ifile.it";
$max_file_size["ifile.it"]=100;
$page_upload["ifile.it"] = "ifile.it.php";  
?>