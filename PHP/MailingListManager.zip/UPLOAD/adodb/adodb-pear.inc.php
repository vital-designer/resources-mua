<?php
define("ADODB_PEAR", dirname(__file__));
require_once ("PEAR.php");
require_once (ADODB_PEAR . "/adodb-errorpear.inc.php");
require_once (ADODB_PEAR . "/adodb.inc.php");
if (!defined("DB_OK"))
{
				define("DB_OK", 1);
				define("DB_ERROR", -1);
				define("DB_FETCHMODE_DEFAULT", 0);
				define("DB_FETCHMODE_ORDERED", 1);
				define("DB_FETCHMODE_ASSOC", 2);
				define("DB_GETMODE_ORDERED", DB_FETCHMODE_ORDERED);
				define("DB_GETMODE_ASSOC", DB_FETCHMODE_ASSOC);
				define("DB_TABLEINFO_ORDER", 1);
				define("DB_TABLEINFO_ORDERTABLE", 2);
				define("DB_TABLEINFO_FULL", 3);
}
class db
{
				function &factory($type)
				{
								@include_once ("adodb-{$type}.inc.php");
								$classname = "DB_{$type}";
								if (!class_exists($classname))
								{
												return pear::raiseerror(null, DB_ERROR_NOT_FOUND, null, null, null, "DB_Error", true);
								}
								@$obj = &new $classname();
								return $obj;
				}
				function &connect($dsn, $options = false)
				{
								if (is_array($dsn))
								{
												$dsninfo = $dsn;
								} else
								{
												$dsninfo = db::parsedsn($dsn);
								}
								switch ($dsninfo['phptype'])
								{
												case "pgsql":
																$type = "postgres7";
																break;
												default:
																$type = $dsninfo['phptype'];
																break;
								}
								if (is_array($options) && isset($options['debug']) && 2 <= $options['debug'])
								{
												@include_once ("adodb-{$type}.inc.php");
								} else
								{
												@include_once ("adodb-{$type}.inc.php");
								}
								@$obj = &newadoconnection($type);
								if (!is_object($obj))
								{
												return new pear_error("Unknown Database Driver: " . $dsninfo['phptype'], -1);
								}
								if (is_array($options))
								{
												$persist = !empty($options['persistent']);
								} else
								{
												$persist = true;
								}
								if ($persist)
								{
												$ok = $obj->pconnect($dsninfo['hostspec'], $dsninfo['username'], $dsninfo['password'], $dsninfo['database']);
								} else
								{
												$ok = $obj->connect($dsninfo['hostspec'], $dsninfo['username'], $dsninfo['password'], $dsninfo['database']);
								}
								if (!$ok)
								{
												return adodb_pear_error();
								}
								return $obj;
				}
				function apiversion()
				{
								return 2;
				}
				function iserror($value)
				{
								return is_object($value) && (get_class($value) == "db_error" || is_subclass_of($value, "db_error"));
				}
				function iswarning($value)
				{
								return is_object($value) && (get_class($value) == "db_warning" || is_subclass_of($value, "db_warning"));
				}
				function parsedsn($dsn)
				{
								if (is_array($dsn))
								{
												return $dsn;
								}
								$parsed = array("phptype" => false, "dbsyntax" => false, "protocol" => false, "hostspec" => false, "database" => false, "username" => false, "password" => false);
								if (($pos = strpos($dsn, "://")) !== false)
								{
												$str = substr($dsn, 0, $pos);
												$dsn = substr($dsn, $pos + 3);
								} else
								{
												$str = $dsn;
												$dsn = null;
								}
								if (preg_match("|^(.+?)\\((.*?)\\)\$|", $str, $arr))
								{
												$parsed['phptype'] = $arr[1];
												$parsed['dbsyntax'] = empty($arr[2]) ? $arr[1] : $arr[2];
								} else
								{
												$parsed['phptype'] = $str;
												$parsed['dbsyntax'] = $str;
								}
								if (empty($dsn))
								{
												return $parsed;
								}
								if (($at = strpos($dsn, "@")) !== false)
								{
												$str = substr($dsn, 0, $at);
												$dsn = substr($dsn, $at + 1);
												if (($pos = strpos($str, ":")) !== false)
												{
																$parsed['username'] = urldecode(substr($str, 0, $pos));
																$parsed['password'] = urldecode(substr($str, $pos + 1));
												} else
												{
																$parsed['username'] = urldecode($str);
												}
								}
								if (($pos = strpos($dsn, "/")) !== false)
								{
												$str = substr($dsn, 0, $pos);
												$dsn = substr($dsn, $pos + 1);
								} else
								{
												$str = $dsn;
												$dsn = null;
								}
								if (($pos = strpos($str, "+")) !== false)
								{
												$parsed['protocol'] = substr($str, 0, $pos);
												$parsed['hostspec'] = urldecode(substr($str, $pos + 1));
								} else
								{
												$parsed['hostspec'] = urldecode($str);
								}
								if (!empty($dsn))
								{
												$parsed['database'] = $dsn;
								}
								return $parsed;
				}
				function assertextension($name)
				{
								if (!extension_loaded($name))
								{
												$dlext = substr(PHP_OS, 0, 3) == "WIN" ? ".dll" : ".so";
												@dl($name . $dlext);
								}
								if (!extension_loaded($name))
								{
												return false;
								}
								return true;
				}
}
?>