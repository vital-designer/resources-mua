<?php
$upload_services[]="azsharing.com_member";
$max_file_size["azsharing.com_member"]=200;
$page_upload["azsharing.com_member"] = "azsharing.com_member.php";  
?>