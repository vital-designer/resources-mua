<?php

class Publisher {
    public $name;
    public $location; // This will hold a Location object
}