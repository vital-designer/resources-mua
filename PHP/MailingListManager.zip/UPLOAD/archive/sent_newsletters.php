<?php
include ("../common.php");
include ("../include/archive_function.php");
$section = "statistic";
$right_name = "view_sent";
check_right($section, $right_name);
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "date";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
} else
{
				$order = "";
}
$archive_page = isset($_REQUEST['archive_page']) ? $_REQUEST['archive_page'] : 0;
$smarty->assign("razdel", "Statistics");
$smarty->assign("description", "Sent Newslettres");
$smarty->assign("hint", "Sent newsletters and number of recepients are listed here. With the help of \"View\" button you may find out who received newsletters");
$smarty->assign("order", $order);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("archive_page", $archive_page);
$smarty->assign("rel", getreleasesinfo($order, $archive_page));
$smarty->display("{$admin_nl_gentemplates}/archive_sent_newsletter_statistics.tpl");
?>