<?php
$upload_services[]="uploadground.com";
$max_file_size["uploadground.com"]=1024;
$page_upload["uploadground.com"] = "uploadground.com.php";
?>