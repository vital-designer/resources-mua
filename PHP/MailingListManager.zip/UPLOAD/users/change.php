<?php
ini_set("display_errors", "0");
error_reporting(1);
include ("../common.php");
include ("../include/users_function.php");
include ("../include/class.form.php");
$section = "subscribers";
$msg = "";
$smarty->assign("config", $config);
if (isset($_GET['id']))
{
				get_smarty_array_list("status_subscribe", $config['status_subscribe']);
				if ((!isset($_POST['action']) || $_POST['action'] != "change") && (!isset($_GET['action']) || $_GET['action'] != "change"))
				{
								$form_class = new form($dbconn, $config);
								$user_attrs = array();
								$count = 0;
								$attrs = $form_class->getallattributes($count);
								$regs = $form_class->getregexps();
								foreach ($attrs as $index => $field)
								{
												if ($field['id'] == FIELD_COMPANY)
												{
																unset($attrs[$index]);
												}
												else
																if (isset($field['setup']['reg_exp']))
																{
																				$id_reg = $attrs[$index]['setup']['reg_exp'];
																				$attrs[$index]['setup']['reg_exp'] = $regs[$id_reg]['reg_exp'];
																}
								}
								if (count($_POST) == 0)
								{
												foreach ($attrs as $index => $attr)
												{
																$temp = $form_class->getuserattribute($_GET['id'], $attr['id'], false);
																if ($temp === false)
																{
																}
																else
																{
																				$user_attrs[$attr['id']] = $temp;
																}
												}
								}
								else
								{
												$user_attrs = $_POST;
								}
								if (intval($_GET['id'] != 0))
								{
												$smarty->assign("user_data", $user_attrs);
								}
								$smarty->assign("fields", $attrs);
								if ($_GET['id'] == 0)
								{
												$right_name = "create";
												check_right($section, $right_name);
												$smarty->assign("razdel", "Subscribers");
												$smarty->assign("description", "New Subscriber Creation");
												$smarty->assign("hint", "Complete the form, mark necessary mailing lists and click \"Submit\" button.");
												$content = getblankcontent();
								}
								else
								{
												$right_name = "view_item";
												check_right($section, $right_name);
												$content = getusers($_GET['id']);
												$smarty->assign("razdel", "Subscribers");
												$smarty->assign("description", "Subscriber Editing");
												$smarty->assign("hint", "Here you can change user�s data: First Name, Last Name, Email, Company, Comment. You can also change user�s subscription status for every existing mailing list.");
								}
								$smarty->assign("status_subscribe", $config['status_subscribe_val']['subscribe']);
								$smarty->assign("users", $content);
								$smarty->assign("lists", getlists());
								$smarty->display("{$admin_nl_gentemplates}/users_change_user.tpl");
				}
				else
				{
								$form_class = new form($dbconn, $config);
								$attrs = array();
								$data = $_POST;
								foreach ($data as $key => $value)
								{
												$arr = array();
												if (preg_match("/^attr_(\\d*)/", $key, $arr) == 0)
												{
												}
												else
												{
																$id_attr = $arr[1];
																$sec_attrs[$id_attr] = $form_class->getsectionattribute($id_attr);
																unset($data[$key]);
																if (is_array($value) && $sec_attrs[$id_attr]['control_type'] == "select")
																{
																				$temp = array();
																				foreach ($value as $i => $v)
																				{
																								$temp[$v] = $v;
																				}
																				$data[$id_attr] = $temp;
																}
																else
																{
																				$data[$id_attr] = $value;
																}
																$attrs[$id_attr] = $value;
												}
								}
								$form_fields = $form_class->getallattributes();
								foreach ($form_fields as $form_field)
								{
												if ($form_field['control_type'] == "checkbox")
												{
																$keys = array_keys($attrs);
																if (!in_array($form_field['id'], $keys))
																{
																				$attrs[$form_field['id']] = 0;
																}
																$sec_attrs[$form_field['id']] = $form_class->getsectionattribute($form_field['id']);
												}
								}
								$regs = $form_class->getregexps();
								foreach ($sec_attrs as $index => $field)
								{
												if (isset($field['setup']['reg_exp']))
												{
																$id_reg = $sec_attrs[$index]['setup']['reg_exp'];
																$sec_attrs[$index]['setup']['reg_exp'] = $regs[$id_reg]['reg_exp'];
												}
								}
								$err = "";
								$valid = true;
								foreach ($attrs as $id_attr => $value)
								{
												if ($sec_attrs[$id_attr]['mandatory'] == "Y" && ($value == "" || !isset($value)))
												{
																$valid = false;
																$err .= "<br>" . $sec_attrs[$id_attr]['field_name'];
												}
												if (isset($sec_attrs[$id_attr]['setup']['reg_exp']))
												{
																$pattern = $sec_attrs[$id_attr]['setup']['reg_exp'];
																if (preg_match($pattern, $value) == 0)
																{
																				$valid = false;
																				$err .= "<br>" . $sec_attrs[$id_attr]['field_name'];
																}
												}
								}
								if ($_GET['id'] == 0 || $_GET['id'] == "0")
								{
												$id_user = 0;
												if (isset($_POST) && !isset($_GET['action']))
												{
																$msg = adduser($_POST, $id_user);
												}
												else
												{
																$msg = adduser($_GET, $id_user);
												}
								}
								else
								{
												$id_user = intval($_GET['id']);
												$right_name = "edit";
												check_right($section, $right_name);
												upduser($_GET['id'], $_POST);
								}
								$form_class->saveuserattributes($id_user, $attrs);
								$GLOBALS['_SESSION']['message'] = $msg;
								header("Location: index.php");
				}
}
else
{
				header("Location: index.php");
}
?>