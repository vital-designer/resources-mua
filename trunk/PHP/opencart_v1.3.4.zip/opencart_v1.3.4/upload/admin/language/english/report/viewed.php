<?php
// Heading
$_['heading_title']  = 'Products Viewed Report';

// Column
$_['column_name']    = 'Product Name';
$_['column_model']   = 'Model';
$_['column_viewed']  = 'Viewed';
$_['column_percent'] = 'Percent';
?>
