<?php
$upload_services[]="sharedzilla.com";
$max_file_size["sharedzilla.com"]=2048;
$page_upload["sharedzilla.com"] = "sharedzilla.com.php";  
?>