﻿using System.Web.UI.WebControls;
using Telerik.Cms.Web.UI;
using Telerik.Cms.Web.UI.Backend;
using Telerik.Web;

namespace Samples.Books.WebControls
{
    /// <summary>
    /// Custom control which is used for command panel
    /// </summary>
    public class BooksCommandPanel : ViewModeControl<BooksControlPanel>, ICommandPanel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BooksCommandPanel"/> class.
        /// </summary>
        /// <param name="ctrlPnl">The CTRL PNL.</param>
        public BooksCommandPanel(IControlPanel ctrlPnl)
        {
            this.ctrlPnl = ctrlPnl;
        }

        /// <summary>
        /// Gets or sets the path to a custom layout template for the control.
        /// </summary>
        /// <remarks>
        /// We are overriding this property only to add attribute to it. The attribute will be used in future
        /// for the template mapping / exporting tool.
        /// </remarks>
        [WebSysTemplate(BooksCommandPanel.BooksCommandPanelTemplateName,
            "BooksCommandPanelTemplateName_Template_Desc", "/Books/", false, "2000-01-25")]
        public override string LayoutTemplatePath
        {
            get
            {
                return base.LayoutTemplatePath;
            }
            set
            {
                base.LayoutTemplatePath = value;
            }
        }

        /// <summary>
        /// Gets the name of the embedded layout template. If the control uses layout template this
        /// property must be overridden to provide the path (key) to an embedded resource file.
        /// </summary>
        /// <value>Name of the resource with embedded template</value>
        protected override string LayoutTemplateName
        {
            get
            {
                return BooksCommandPanel.BooksCommandPanelTemplateName;
            }
        }

        #region Control references

        /// <summary>
        /// Gets all books.
        /// </summary>
        /// <value>All books.</value>
        protected virtual HyperLink AllBooks
        {
            get { return base.Container.GetControl<HyperLink>("allBooks", true); }
        }

        /// <summary>
        /// Gets the sales.
        /// </summary>
        /// <value>The sales.</value>
        protected virtual HyperLink Sales
        {
            get { return base.Container.GetControl<HyperLink>("sales", true); }
        }

        #endregion

        /// <summary>
        /// Initializes all controls instantiated in the layout container. This method is called at appropriate time for setting initial values and subscribing for events of layout controls.
        /// </summary>
        /// <param name="viewContainer">The control that will host the current view.</param>
        protected override void InitializeControls(System.Web.UI.Control viewContainer)
        {
            base.InitializeControls(viewContainer);

            this.AllBooks.NavigateUrl = CreateRootViewCommand(typeof (BooksControlPanel), typeof (BooksListView));
            this.Sales.NavigateUrl = CreateRootViewCommand(typeof (BooksControlPanel), typeof (BooksSalesView));
        }

        /// <summary>
        /// Refreshes the command panel information.
        /// </summary>
        /// <requirements>
        ///             This method could be used to refresh the command panel information. For example
        ///             when there is some change in the ControlPanel which reflects on the information of the
        ///             CommandPanel.
        ///             </requirements>
        /// <example>
        ///                 You can refer to <see cref="T:Telerik.Web.ICommandPanel">ICommandPanel</see> interface for more
        ///                 complicated example implementing the whole
        ///                 <see cref="T:Telerik.Web.ICommandPanel">ICommandPanel</see> interface.
        /// </example>
        public void Refresh()
        {
            this.ChildControlsCreated = false;
        }

        /// <summary>
        /// Reference to the control panel tied to the command panel instance.
        /// </summary>
        /// <remarks>
        ///             This property is used for communication between the command panel and its control
        ///             panel.
        /// </remarks>
        /// <example>
        ///                 You can refer to <see cref="T:Telerik.Web.ICommandPanel">ICommandPanel</see> interface for more
        ///                 complicated example implementing the whole
        ///                 <see cref="T:Telerik.Web.ICommandPanel">ICommandPanel</see> interface.
        /// </example>
        public IControlPanel ControlPanel
        {
            get { return this.ctrlPnl; }
        }

        private IControlPanel ctrlPnl;

        private const string BooksCommandPanelTemplateName =
            "Samples.Books.Resources.ControlTemplates.Backend.BooksCommandPanel.ascx";
    }
}
