<?php
$upload_services[]="upfordown.com_member";
$max_file_size["upfordown.com_member"]=200;
$page_upload["upfordown.com_member"] = "upfordown.com_member.php";
?>