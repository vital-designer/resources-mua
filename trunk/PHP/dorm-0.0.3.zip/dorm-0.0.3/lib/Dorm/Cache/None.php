<?php
/**
 * This file is part of Dorm and is subject to the GNU Affero General
 * Public License Version 3 (AGPLv3). You should have received a copy
 * of the GNU Affero General Public License along with Dorm. If not,
 * see <http://www.gnu.org/licenses/>.
 *
 * @category Dorm
 * @package Dorm_Cache
 * @copyright Copyright (c) 2008-2009 Olivier Lalonde <olalonde@gmail.com>
 */

/**
 * This class doesn't cache anything. It will return false on every fetch/save.
 *
 */
class Dorm_Cache_None extends Dorm_Cache_Abstract {
    /**
     * @param string $key
     * @return boolean false
     */
    public function fetch($key) {return false;}

    /**
     * @param string $key
     * @param mixed $var
     * @param int $time_to_last Seconds.
     */
    public function store($key, $var, $time_to_last = 0) {return false;}

    /**
     * @param string $key
     */
    public function delete($key) {return false;}

    /**
     * @return boolean
     */
    public function flush() {return false;}
}