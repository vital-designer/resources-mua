<?php
include ("common.php");
if (!isset($_GET['e']) || empty($_GET['e']) || !isset($_GET['f']) || empty($_GET['f']))
{
				exit("Error: Please, enter all values");
}
$rs = $dbconn->execute("select id,email1 from snd_users where md5(email1)='" . $_GET['e'] . "'");
if (!$rs->rowcount())
{
				exit("Error: Unknown email");
}
$uid = $rs->fields[0];
$email = $rs->fields[1];
$rs2 = $dbconn->execute("select type from form where id='" . $_GET['f'] . "'");
if (!$rs2->rowcount())
{
				exit("Error: Unknown form ID");
}
$type = $rs2->fields[0];
$rs = $dbconn->execute("select list_id from forms_lists where form_id='" . $_GET['f'] . "'");
if ($type == "sub")
{
				while (!$rs->EOF)
				{
								$rs2 = $dbconn->execute("update clients_lists set status_subscribe='" . $config['status_subscribe_val']['subscribe'] . "', date_status=now() where list_id='" . $rs->fields[0] . "' and client_id='" . $uid . "'");
								$rs->movenext();
				}
}
else
{
				while (!$rs->EOF)
				{
								$rs2 = $dbconn->execute("update clients_lists set status_subscribe='" . $config['status_subscribe_val']['unsubscribe'] . "', date_status=now() where list_id='" . $rs->fields[0] . "' and client_id='" . $uid . "'");
								$rs->movenext();
				}
}
$res = $dbconn->execute("select * from settings");
$settings = $res->getrowassoc(false);
$rs2 = $dbconn->execute("select * from form where id='" . $_GET['f'] . "'");
$row = $rs2->getrowassoc(false);
if ($row['thankyou'] == 1)
{
				emailtext($email, $row['thankyou_subject'], stripslashes($row['thankyou_email']), $settings['from_name'], $settings['from_email']);
				if (!empty($row['thankyou_url']) && $row['thankyou_url'] !== "http://")
				{
								header("Location: " . $row['thankyou_url']);
								exit();
				}
				else
				{
								exit(stripslashes($row['thankyou_text']));
				}
}
$smarty->display("{$admin_nl_gentemplates}/confirmed.tpl");
?>
