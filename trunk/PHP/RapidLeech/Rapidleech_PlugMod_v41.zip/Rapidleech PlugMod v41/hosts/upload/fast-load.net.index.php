<?php
$upload_services[]="fast-load.net";
$max_file_size["fast-load.net"]=250;
$page_upload["fast-load.net"] = "fast-load.net.php";  
?>