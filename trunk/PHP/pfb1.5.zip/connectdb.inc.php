<?
//phpFormBuilder Version 1.5 by Baris Kayar (barishkayar@yahoo.com)
//2002(cl)  The FormBuilder Group http://pfb.sourceforge.net

$hostindex=0;
$server=$servers[$hostindex];
$connection=@mysql_connect($servers[$hostindex],$users[$hostindex],$passes[$hostindex]) or header("location: logoff.php");
?>