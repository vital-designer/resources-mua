<?
//phpFormBuilder Version 1.5 by Baris Kayar (barishkayar@yahoo.com)
//2002(cl)  The FormBuilder Group http://pfb.sourceforge.net

echo 
"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">
<html>
<head>
<meta http-equiv=\"content-language\" content=\"TR\">
<meta http-equiv=\"content-type\" content=\"text/html; charset=windows-1254\">
<meta http-equiv=\"content-type\" content=\"text/html; charset=iso-8859-9\">
	<title>$PFBg_Title</title>";
?>
<style>
BODY,TD {
	font-family: Verdana, Arial, Geneva;
	font-size: 9pt;
	color : #000000;
}

A {
	font-family: "Tahoma", Arial;
	font-size: 9pt;
	font-weight: normal;
	text-decoration : none;
}

A:HOVER {
	font-family: "Tahoma", Arial;
	font-size: 9pt;
	font-weight: normal;
	text-decoration : underline;
}
A:VISITED {
	font-family: "Tahoma", Arial;
	font-size: 9pt;
	font-weight: normal;
	text-decoration : none;
}
.about {
           	font-size: 8pt;
			color: #000000;
			text-decoration : none;
		  }

A.linkler {
           	font-size: 8pt;
			color: #000000;
			font-weight: normal;
			text-decoration : none;
		  }

A.linkler:VISITED {
           	font-size: 8pt;
			color: #000000;
			font-weight: normal;
			text-decoration : none;
			}

A.linkler:HOVER {
           	font-size: 8pt;
			color: #000000;
			font-weight: normal;
			text-decoration : none;
			background: #809DAA;
			}
</style>
</head>