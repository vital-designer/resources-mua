﻿using Telerik.Cms.Web.UI.Backend;
using Telerik;

namespace Samples.Books.WebControls
{
    /// <summary>
    /// Control panel for the books module
    /// </summary>
    public class BooksControlPanel : ControlPanel<BooksControlPanel>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BooksControlPanel"/> class.
        /// </summary>
        /// <remarks>
        /// We are passing false to base constructor indicating that we do not want automatic
        /// command generation, since this feature is not working properly in the beta release
        /// </remarks>
        public BooksControlPanel() : base(false)
        {
            
        }

        /// <summary>
        /// We are overriding the CreateViews and defining the child views of this control.
        /// </summary>
        protected override void CreateViews()
        {
            // adding view which will display list of views - this is also the default view
            AddView<BooksListView>();
            // adding view which is used for adding new books
            AddView<BookInsertView>();
            // adding view which is used for editing existing books
            AddView<BookEditView>();
            // adding view which is used for previewing a book
            AddView<BookPreviewView>();
            // adding view which is used for viewing the sales report
            AddView<BooksSalesView>();
        }

        /// <summary>
        /// Creates the custom command panels.
        /// </summary>
        /// <param name="viewMode">The view mode.</param>
        /// <param name="list">The list.</param>
        protected override void CreateCustomCommandPanels(string viewMode, System.Collections.Generic.List<Telerik.Web.ICommandPanel> list)
        {
            list.Add(new BooksCommandPanel(this));
        }

    }
}
