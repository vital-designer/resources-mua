<?php 
$upload_services[] = "easy-share.com_member";
$max_file_size["easy-share.com_member"] = 100;
$page_upload["easy-share.com_member"] = "easy-share.com_member.php";
?>