﻿using System;
using Samples.Books.Resources;
using Telerik.Web;

namespace Samples.Books
{
    /// <summary>
    /// This is a template attribute class which needs to exist in each module that uses embedded templates. This class
    /// will probably not be required in the next version.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    internal class WebSysTemplate : EmbeddedTemplateAttribute
    {
        public WebSysTemplate(string resourceName, string description
            , string defaultExtPaht, bool isFrontEnd, string lastModified)
            : base(resourceName, description, defaultExtPaht, isFrontEnd, lastModified)
        {
        }

        public override string Description
        {
            get
            {
                return Messages.ResourceManager.GetString(base.Description);
            }
        }

        public override object TypeId
        {
            get
            {
                return typeof(EmbeddedTemplateAttribute);
            }
        }
    }
}