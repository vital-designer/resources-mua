<?php
function mergelist($merge)
{
				global $dbconn;
				global $smarty;
				global $config;
				$mas_user = array();
				$i = 0;
				for (; $i < count($merge['sel']); ++$i)
				{
								$mas_user_1 = getusersformerge($merge['sel'][$i]);
								$mas_user = array_unique(array_merge($mas_user, $mas_user_1));
				}
				$name = str_prepare($merge['name']);
				$owner_email = str_prepare($merge['owner_email']);
				$notify_add = isset($merge['notify_add']) ? 1 : 0;
				$notify_unsub = isset($merge['notify_unsub']) ? 1 : 0;
				$res = $dbconn->execute("insert into list (name,owner_name,owner_email,date,release_sub_id,release_unsub_id, notify_add, notify_unsub) \r\n  \t  values ('" . $name . "','" . $owner_name . "','" . $owner_email . "',NOW(), \r\n\t  '" . $merge['newsletter_subscribe_id'] . "','" . $merge['newsletter_unsubscribe_id'] . "', \r\n\t  '" . $notify_add . "', '" . $notify_unsub . "')");
				$rid = $dbconn->insert_id();
				$i = 0;
				for (; $i < count($mas_user); ++$i)
				{
								$res = $dbconn->execute("insert into clients_lists (client_id,list_id,status_subscribe,date_status) values ('" . $mas_user[$i] . "','" . $rid . "',1,NOW())");
				}
}
function getlists($orderby = "", $list_page = 0)
{
				global $dbconn;
				global $smarty;
				global $config;
				if (isset($_GET['p']) && 0 < $_GET['p'])
				{
								$p = $_GET['p'];
				} else
				{
								$p = 0;
				}
				$end = $_SESSION['is_desc'] && !$_GET['is_nav'] || !$_SESSION['is_desc'] && $_GET['is_nav'] ? " desc " : "";
				if ($orderby)
				{
								$is_nav = isset($_GET['is_nav']) ? $_GET['is_nav'] : false;
								if (!$is_nav && $orderby == $_SESSION['order'])
								{
												if ($_SESSION['is_desc'])
												{
																$GLOBALS['_SESSION']['is_desc'] = false;
																$end = " desc ";
												} else
												{
																$GLOBALS['_SESSION']['is_desc'] = true;
																$end = "";
												}
								}
								$sql .= " order by " . $orderby . $end;
				} else
				{
								$sql .= " order by name";
				}
				$smarty->assign("end", trim($end));
				$res = $dbconn->execute("select count(id) from list");
				$amount = $res->fields[0];
				$smarty->assign("navigation", create_navigation($amount, $list_page, "list_page={$list_page}&order=" . $_GET['order'] . "&is_nav=true", "index.php", $p, "list_page"));
				get_smarty_array_list("list_page", $config['list_page']);
				$per_page = $config['list_page'][$list_page];
				$res = $dbconn->pageexecute("select id, name, date,owner_name,owner_email from list " . $sql, $per_page, $p + 1);
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$releases[$c]['id'] = $res->fields[0];
								$releases[$c]['name'] = stripslashes($res->fields[1]);
								$releases[$c]['date'] = $res->fields[2];
								$releases[$c]['owner_name'] = $res->fields[3];
								$releases[$c]['owner_email'] = $res->fields[4];
								$res2 = $dbconn->execute("select count(*) from clients_lists where list_id='" . $res->fields[0] . "' and status_subscribe<>'" . $config['status_subscribe_val']['unsubscribe'] . "'");
								$releases[$c]['count'] = $res2->fields[0];
								++$c;
								$res->movenext();
				}
				$smarty->assign("amount", $amount);
				return $releases;
}
function getusersformerge($a = "")
{
				global $dbconn;
				$res = $dbconn->execute("select client_id from clients_lists where list_id='" . $a . "' and status_subscribe=1 order by client_id");
				$users = array();
				$c = 0;
				while (!$res->EOF)
				{
								$users[$c] = $res->fields[0];
								++$c;
								$res->movenext();
				}
				return $users;
}
function getusers($a = "", $orderby = "")
{
				global $dbconn;
				if ($a)
				{
								$sql = " where id='" . $a . "' and uns_date IS NULL ";
				} else
				{
								$sql = " where uns_date IS NULL ";
				}
				if ($orderby)
				{
								$sql .= " order by " . $orderby;
				} else
				{
								$sql .= " order by id";
				}
				$res = $dbconn->execute("select id,date,firstname,secondname,company,email1,comment from snd_users " . $sql);
				$users = array();
				$c = 0;
				while (!$res->EOF)
				{
								$users[$c] = $res->getrowassoc();
								++$c;
								$res->movenext();
				}
				return $users;
}
function dellist($id)
{
				global $dbconn;
				$res = $dbconn->query("delete from list where id='" . $id . "'");
				$res = $dbconn->query("delete from clients_lists where list_id='" . $id . "'");
}
function addlist()
{
				global $dbconn;
				$name = str_prepare($_POST['name']);
				$owner_name = str_prepare($_POST['owner_name']);
				$owner_email = str_prepare($_POST['owner_email']);
				$notify_add = isset($_POST['notify_add']) ? 1 : 0;
				$notify_unsub = isset($_POST['notify_unsub']) ? 1 : 0;
				$res = $dbconn->execute("insert into list (name,owner_name,owner_email,date,release_sub_id,\r\n\t  release_unsub_id, notify_add, notify_unsub) \r\n  \t  values ('" . $name . "','" . $owner_name . "','" . $owner_email . "',NOW(), \r\n\t  '" . $_POST['newsletter_subscribe_id'] . "','" . $_POST['newsletter_unsubscribe_id'] . "', \r\n\t  '" . $notify_add . "', '" . $notify_unsub . "')");
				$rid = $dbconn->_insertid();
				return $rid;
}
function sendrelease($rid, $usersArray)
{
				global $dbconn;
				$res = $dbconn->execute("select id,body,subject from creleases where id='" . $rid . "'");
				$userInfo = array();
				if ($res->rowcount())
				{
								$body = nl2br(stripslashes($res->fields[2]));
								$subject = stripslashes($res->fields[3]);
								$headers = "From: Manager <manager@domain.tld>\r\n";
								$headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
								$headers .= "X-Priority: 1\r\n";
								$headers .= "MIME-Version: 1.0\r\n";
								$headers .= "Content-type: text/html; charset=windows-1251\r\n";
								foreach ($usersArray as $u)
								{
												$body = "";
												$email = "";
												$body = nl2br(stripslashes($res->fields[2]));
												$subject = stripslashes($res->fields[3]);
												$res2 = $dbconn->execute("select id,firstname,secondname,email1 from snd_users where id='" . $u . "'");
												$userInfo[] = $res2->fields[1] . " " . $res2->fields[2];
												$email = !empty($res2->fields[3]) ? $res2->fields[3] : $res2->fields[4];
												$body = preg_replace("/\\[name\\]/i", $res2->fields[1] . " " . $res2->fields[2], $body);
												$body = preg_replace("/\\[unsubscribe\\]/i", "http://www.domain.tld/u.php?c=" . md5($res2->fields[3]), $body);
												$body = preg_replace("/\\[(http:.*?)\\]/i", "http://www.domain.tld/r.php?c=" . $res2->fields[0] . "&r=" . $rid . "&l=\\1", $body);
												$body = "<table width=\"100%\"><tr><td><font size=2 face=\"Verdana\">" . $body . "</font>\n</td></tr>\n";
												$body = $body . "\n</table>";
												mail($email, $subject, $body, $headers);
												$res3 = $dbconn->execute("insert into clients_releases (client_id,release_id) values ('" . $res2->fields[0] . "','" . $rid . "')");
								}
				}
				return $userInfo;
}
function updlist()
{
				global $dbconn;
				$id = $_GET['id'];
				$name = str_prepare($_POST['name']);
				$owner_name = str_prepare($_POST['owner_name']);
				$owner_email = str_prepare($_POST['owner_email']);
				$notify_add = isset($_POST['notify_add']) ? 1 : 0;
				$notify_unsub = isset($_POST['notify_unsub']) ? 1 : 0;
				$res = $dbconn->execute("update list set name='" . addslashes($name) . "', \r\n  \t\t\t\t\t\towner_name='" . addslashes($owner_name) . "', \r\n\t\t\t\t\t\towner_email='" . addslashes($owner_email) . "',\r\n\t\t\t\t\t\tdate=NOW(),\r\n\t\t\t\t\t\trelease_sub_id='" . $_POST['newsletter_subscribe_id'] . "',\r\n\t\t\t\t\t\trelease_unsub_id='" . $_POST['newsletter_unsubscribe_id'] . "',\r\n\t\t\t\t\t\tnotify_add='" . $notify_add . "',\r\n\t\t\t\t\t\tnotify_unsub='" . $notify_unsub . "'\r\n\t\t\t\t\t\twhere id='" . $id . "'");
}
function getcontent($id)
{
				global $dbconn;
				$res = $dbconn->execute("select id,name,owner_name,owner_email, release_sub_id, release_unsub_id, \r\n  notify_add, notify_unsub from list where id='" . $id . "'");
				$releases = array();
				$releases['id'] = $res->fields[0];
				$releases['name'] = stripslashes($res->fields[1]);
				$releases['owner_name'] = stripslashes($res->fields[2]);
				$releases['owner_email'] = stripslashes($res->fields[3]);
				$releases['release_sub_id'] = $res->fields[4];
				$releases['release_unsub_id'] = $res->fields[5];
				$releases['notify_add'] = $res->fields[6];
				$releases['notify_unsub'] = $res->fields[7];
				return $releases;
}
function getblankcontent()
{
				$releases = array();
				$releases['id'] = 0;
				$releases['name'] = "";
				$releases['owner_name'] = "";
				$releases['owner_email'] = "";
				$releases['release_sub_id'] = -2;
				$releases['release_unsub_id'] = -2;
				return $releases;
}
?>
