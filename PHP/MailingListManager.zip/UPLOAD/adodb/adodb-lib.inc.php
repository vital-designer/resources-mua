<?php
function _adodb_totalpages(&$rs)
{
				if ($rs->rowsPerPage)
				{
								$rows = ($rs->recordcount() + $rs->rowsPerPage - 1) / $rs->rowsPerPage;
								if ($rows < 0)
								{
												return - 1;
								} else
								{
												return $rows;
								}
				} else
				{
								return - 1;
				}
}
function _adodb_getmenu(&$zthis, $name, $defstr = "", $blank1stItem = true, $multiple = false, $size = 0, $selectAttr = "", $compareFields0 = true)
{
				$hasvalue = false;
				if ($multiple || is_array($defstr))
				{
								if ($size == 0)
								{
												$size = 5;
								}
								$attr = " multiple size={$size}";
								if (!strpos($name, "[]"))
								{
												$name .= "[]";
								}
				} else
								if ($size)
								{
												$attr = " size={$size}";
								} else
								{
												$attr = "";
								}
								$s = "<select name=\"{$name}\"{$attr} {$selectAttr}>";
				if ($blank1stItem)
				{
								$s .= "\n<option></option>";
				}
				if (1 < $zthis->fieldcount())
				{
								$hasvalue = true;
				} else
				{
								$compareFields0 = true;
				}
				while (!$zthis->EOF)
				{
								$zval = trim($zthis->fields[0]);
								$selected = trim($zthis->fields[$compareFields0 ? 0 : 1]);
								if ($blank1stItem && $zval == "")
								{
												$zthis->movenext();
								} else
								{
												if ($hasvalue)
												{
																$value = "value=\"" . htmlspecialchars(trim($zthis->fields[1])) . "\"";
												}
												if (is_array($defstr))
												{
																if (in_array($selected, $defstr))
																{
																				$s .= "<option selected {$value}>" . htmlspecialchars($zval) . "</option>";
																} else
																{
																				$s .= "\n<option " . $value . ">" . htmlspecialchars($zval) . "</option>";
																}
												} else
																if (strcasecmp($selected, $defstr) == 0)
																{
																				$s .= "<option selected {$value}>" . htmlspecialchars($zval) . "</option>";
																} else
																{
																				$s .= "\n<option " . $value . ">" . htmlspecialchars($zval) . "</option>";
																}
																$zthis->movenext();
								}
				}
				return $s . "\n</select>\n";
}
function &_adodb_pageexecute(&$zthis, $sql, $nrows, $page, $inputarr = false, $arg3 = false, $secs2cache = 0)
{
				$atfirstpage = false;
				$atlastpage = false;
				if (!isset($page) || $page <= 1)
				{
								$page = 1;
								$atfirstpage = true;
				}
				if ($nrows <= 0)
				{
								$nrows = 10;
				}
				$pagecounter = $page + 1;
				$pagecounteroffset = $pagecounter * $nrows - $nrows;
				if (0 < $secs2cache)
				{
								$rstest = &$zthis->cacheselectlimit($secs2cache, $sql, $nrows, $pagecounteroffset, $inputarr, $arg3);
				} else
				{
								$rstest = &$zthis->selectlimit($sql, $nrows, $pagecounteroffset, $inputarr, $arg3, $secs2cache);
				}
				if ($rstest)
				{
								while ($rstest && $rstest->EOF && 0 < $pagecounter)
								{
												$atlastpage = true;
												--$pagecounter;
												$pagecounteroffset = $nrows * ($pagecounter - 1);
												$rstest->close();
												if (0 < $secs2cache)
												{
																$rstest = &$zthis->cacheselectlimit($secs2cache, $sql, $nrows, $pagecounteroffset, $inputarr, $arg3);
												} else
												{
																$rstest = &$zthis->selectlimit($sql, $nrows, $pagecounteroffset, $inputarr, $arg3, $secs2cache);
												}
								}
								if ($rstest)
								{
												$rstest->close();
								}
				}
				if ($atlastpage)
				{
								$page = $pagecounter;
								if ($page == 1)
								{
												$atfirstpage = true;
								}
				}
				$offset = $nrows * ($page - 1);
				if (0 < $secs2cache)
				{
								$rsreturn = &$zthis->cacheselectlimit($secs2cache, $sql, $nrows, $offset, $inputarr, $arg3);
				} else
				{
								$rsreturn = &$zthis->selectlimit($sql, $nrows, $offset, $inputarr, $arg3, $secs2cache);
				}
				if ($rsreturn)
				{
								$rsreturn->rowsPerPage = $nrows;
								$rsreturn->absolutepage($page);
								$rsreturn->atfirstpage($atfirstpage);
								$rsreturn->atlastpage($atlastpage);
				}
				return $rsreturn;
}
function _adodb_getupdatesql(&$zthis, &$rs, $arrFields, $forceUpdate = false, $magicq = false)
{
				if (!$rs)
				{
								printf(ADODB_BAD_RS, "GetUpdateSQL");
								return false;
				}
				$fieldUpdatedCount = 0;
				eregi("FROM " . ADODB_TABLE_REGEX, $rs->sql, $tableName);
				eregi("WHERE ([]0-9a-z=' \\(\\)\\[\t\r\n_-]*)", $rs->sql, $whereClause);
				$updateSQL = "UPDATE " . $tableName[1] . " SET ";
				$i = 0;
				$max = $rs->fieldcount();
				for (; $i < $max; ++$i)
				{
								$field = $rs->fetchfield($i);
								if (!isset($arrFields[$field->name]) && !($forceUpdate || strcmp($rs->fields[$i], $arrFields[$field->name])))
								{
												++$fieldUpdatedCount;
												$mt = $rs->metatype($field->type);
												if (substr($zthis->databaseType, 0, 8) == "postgres" && $mt == "L")
												{
																$mt = "C";
												}
												switch ($mt)
												{
																case "C":
																case "X":
																				$updateSQL .= $field->name . " = " . $zthis->qstr($arrFields[$field->name], $magicq) . ", ";
																				break;
																case "D":
																				$updateSQL .= $field->name . " = " . $zthis->dbdate($arrFields[$field->name]) . ", ";
																				break;
																case "T":
																				$updateSQL .= $field->name . " = " . $zthis->dbtimestamp($arrFields[$field->name]) . ", ";
																				break;
																default:
																				$updateSQL .= $field->name . " = " . (double)$arrFields[$field->name] . ", ";
																				break;
												}
								}
				}
				if (0 < $fieldUpdatedCount || $forceUpdate)
				{
								$updateSQL = substr($updateSQL, 0, -2);
								if ($whereClause[1])
								{
												$updateSQL .= " WHERE " . $whereClause[1];
								}
								return $updateSQL;
				} else
				{
								return false;
				}
}
function _adodb_getinsertsql(&$zthis, &$rs, $arrFields, $magicq = false)
{
				$values = "";
				$fields = "";
				if (!$rs)
				{
								printf(ADODB_BAD_RS, "GetInsertSQL");
								return false;
				}
				$fieldInsertedCount = 0;
				eregi("FROM " . ADODB_TABLE_REGEX, $rs->sql, $tableName);
				$i = 0;
				$max = $rs->fieldcount();
				for (; $i < $max; ++$i)
				{
								$field = $rs->fetchfield($i);
								if (isset($arrFields[$field->name]))
								{
												++$fieldInsertedCount;
												$fields .= $field->name . ", ";
												$mt = $rs->metatype($field->type);
												if (substr($zthis->databaseType, 0, 8) == "postgres" && $mt == "L")
												{
																$mt = "C";
												}
												switch ($mt)
												{
																case "C":
																case "X":
																				$values .= $zthis->qstr($arrFields[$field->name], $magicq) . ", ";
																				break;
																case "D":
																				$values .= $zthis->dbdate($arrFields[$field->name]) . ", ";
																				break;
																case "T":
																				$values .= $zthis->dbtimestamp($arrFields[$field->name]) . ", ";
																				break;
																default:
																				$values .= (double)$arrFields[$field->name] . ", ";
																				break;
												}
								}
				}
				if (0 < $fieldInsertedCount)
				{
								$fields = substr($fields, 0, -2);
								$values = substr($values, 0, -2);
								$insertSQL = "INSERT INTO " . $tableName[1] . " ( {$fields} ) VALUES ( {$values} )";
								return $insertSQL;
				} else
				{
								return false;
				}
}
?>
