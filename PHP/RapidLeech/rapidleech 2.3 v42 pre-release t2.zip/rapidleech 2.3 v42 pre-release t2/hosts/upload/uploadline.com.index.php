<?php
$upload_services[]="uploadline.com";
$max_file_size["uploadline.com"]=1024;
$page_upload["uploadline.com"] = "uploadline.com.php";  
?>