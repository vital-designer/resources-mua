<?php
$upload_services[]="multi-load.com";
$max_file_size["multi-load.com"]=1000;
$page_upload["multi-load.com"] = "multi-load.com.php";  
?>