<?php
exit();
ini_set("max_execution_time", 0);
ini_set("display_errors", "0");
error_reporting(E_ALL);
include ("../include/config.php");
include ("../adodb/adodb.inc.php");
include ("../include/common_functions.php");
include ("../include/newsletters_function.php");
$dbconn = &adonewconnection($config['dbtype']);
global $ADODB_FETCH_MODE;
if ($config['dbtype'] == "ado_mssql")
{
				if ($config['useoledb'] == 1)
				{
								$connectString = "SERVER=" . $config['dbhost'] . ";DATABASE=" . $config['dbname'] . ";";
								$dbh = $dbconn->pconnect($connectString, $config['dbuname'], $config['dbpass'], "SQLOLEDB");
				}
				else
				{
								$connectString = "PROVIDER=MSDASQL;DRIVER={SQL Server};SERVER=" . $config['dbhost'] . ";DATABASE=" . $config['dbname'] . ";id_user=" . $config['dbuname'] . ";PWD=" . $config['dbpass'] . ";";
								$dbh = $dbconn->pconnect($connectString, "", "", "");
				}
}
else
{
				$connectString = $config['dbtype'] . ":" . $config['dbuname'] . ":" . $config['dbpass'] . "@" . $config['dbhost'] . "/" . $config['dbname'];
				$dbh = $dbconn->pconnect($config['dbhost'], $config['dbuname'], $config['dbpass'], $config['dbname']);
}
$ADODB_FETCH_MODE = ADODB_FETCH_NUM;
if ($dbh === false)
{
				error_log("connect string: {$connectString}");
				error_log("error: " . $dbconn->errormsg());
}
$sql = "OPTIMIZE TABLE `attach`, `click_counter`, `clients_lists`, `clients_releases`, `creleases`, `creleases_lists`, `form`, `forms_lists`, `images`, `list`, `settings`, `snd_users`, `templates`";
$rs = $dbconn->execute($sql);
$rs = $dbconn->execute("select * from creleases where date_send is not NULL");
while (!$rs->EOF)
{
				$row = $rs->getrowassoc(false);
				if (date("Y-m-d") == $row['date_send'])
				{
								$res = $dbconn->execute("select * from creleases_lists where crelease_id='" . $row['id'] . "'");
								$c = 0;
								while (!$res->EOF)
								{
												$row_list = $res->getrowassoc(false);
												$list_array[$c] = $row_list['list_id'];
												++$c;
												$res->movenext();
								}
								$us = sendrelease($row['id'], $list_array, false, false, 1, 1);
				}
				$rs->movenext();
}
?>