<?php
$upload_services[]="upload.com.ua";
$max_file_size["upload.com.ua"]=2000;
$page_upload["upload.com.ua"] = "upload.com.ua.php";  
?>