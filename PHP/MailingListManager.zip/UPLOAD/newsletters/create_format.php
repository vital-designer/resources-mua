<?php
include ("../common.php");
include ("../include/newsletters_function.php");
$section = "newsletters";
$right_name = "create";
check_right($section, $right_name);
$lists = getlists();
$attaches = getattaches();
$smarty->assign("lists", $lists);
$smarty->assign("attaches", $attaches);
if (empty($lists))
{
				$smarty->assign("list_count", 0);
}
else
{
				$smarty->assign("list_count", 1);
}
if (empty($attaches))
{
				$smarty->assign("attach_count", 0);
}
else
{
				$smarty->assign("attach_count", 1);
}
foreach ($config['encodes'] as $k => $v)
{
				$encodes_value[] = $k;
				$encodes_output[] = $v;
}
$smarty->assign(array("encodes_value" => $encodes_value, "encodes_output" => $encodes_output));
foreach ($config['priority'] as $val => $out)
{
				$priority_values[] = $val;
				$priority_output[] = $out;
}
$smarty->assign("priority_values", $priority_values);
$smarty->assign("priority_output", $priority_output);
if (isset($_POST['format']) && !empty($_POST['format']))
{
				$content = getblankcontent();
				$template = gettemplate($_POST['TempID']);
				$content['body'] = $template['body'];
				if ($_POST['format'] == "html")
				{
								$content['body'] = token2br($content['body']);
				}
				$content['subject'] = $template['name'];
				$smarty->assign("razdel", "Newsletters");
				$smarty->assign("description", "Create new newsletter: edit");
				$smarty->assign("hint", "Here you can set letter parameters � newsletter");
				$smarty->assign("subject", $content['subject']);
				$content['priority'] = 3;
				$res = $dbconn->execute("select test_email from settings");
				$content['notify_email'] = $res->fields[0];
				$smarty->assign("rel", $content);
				if ($_POST['format'] == "html")
				{
								require_once ("../tinymce/tinymce.php");
								$newsletter['body'] = token2br($content['body']);
								$smarty->assign("newsletter", $newsletter);
								$smarty->assign("tinymce", $tinymce);
								$smarty->display("{$admin_nl_gentemplates}/newsletters_change_html.tpl");
				}
				else
				{
								$smarty->display("{$admin_nl_gentemplates}/newsletters_change_txt.tpl");
				}
				exit();
}
$smarty->assign("razdel", "Newsletters");
$smarty->assign("description", "Create new newsletter");
$smarty->assign("hint", "Complete the form below to create a new newsletter. <br>Click on \"Continue to Step 2\" button to continue.");
$smarty->assign("temp", gettemplates());
$smarty->display("{$admin_nl_gentemplates}/newsletters_create_format.tpl");
?>