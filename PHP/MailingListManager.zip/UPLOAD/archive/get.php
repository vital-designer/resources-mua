<?php
include ("../common.php");
include ("../include/archive_function.php");
if (isset($_GET['id']) && !empty($_GET['id']))
{
				if (isset($_GET['a']))
				{
								$a = $_GET['a'];
				} else
				{
								$a = "a.id";
				}
				$smarty->assign("razdel", "Statistics");
				$smarty->assign("description", "Message Recepients");
				$smarty->assign("hint", "View recepients");
				$smarty->assign("rel", getrelease($_GET['id']));
				$smarty->assign("cl", getclientsinfo($_GET['id'], $a, $_GET['date'], $_GET['status']));
				$smarty->assign("date", $_GET['date']);
				$smarty->display("{$admin_nl_gentemplates}/archive_get.tpl");
}
?>