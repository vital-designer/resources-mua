<?php 
$upload_services[] = "flyupload.com";
$max_file_size["flyupload.com"] = 2000;
$page_upload["flyupload.com"] = "flyupload.com.php";
?>