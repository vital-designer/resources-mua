System Requirements:
   Windows NT Server / Windows 2000 Server (Min. Requirements for either O.S.)
   SMTP Service Started on Server
   Microsoft Internet Information Server (IIS 4.0/5.0)
   Browser: 
      Either IE or Netscape

Installation:
   Place mailSend.htm and mailSend.asp in the wwwroot directory or within a directory
   that you can point a virtual directory to.

Running program:
   Point URL to the mailSend.htm page.  Enter in valid addresses, subject, and body
   then click submit.  SMTP should be started and this page is submitted to mailSend.asp
   that does all the work.

Note: This is a simple application to be a proof of concept and includes no error handling.
CDO, IIS, and ASP are trademarks of Microsoft Corp.


   