<?php
include ("../common.php");
include ("../include/template_function.php");
$section = "templates";
$right_name = "view";
check_right($section, $right_name);
if (isset($_POST['del']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				foreach ($GLOBALS['_POST']['del'] as $val)
				{
								delrelease($val);
				}
}
if (isset($_GET['did']) && !empty($_GET['did']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				delrelease($_GET['did']);
}
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "date";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
}
else
{
				$order = "";
}
if (isset($_REQUEST['template_page']))
{
				$template_page = $_REQUEST['template_page'];
}
else
{
				$template_page = 0;
}
$smarty->assign("razdel", "Templates");
$smarty->assign("description", "Manage Templates");
$smarty->assign("hint", "Here you can view a list of templates used for newsletter creation. Templates can be either of text format (contain plain text) or html one, that is contain html-tags, allowing to format text. It�s convenient to use templates if your newsletters have repeated elements (design, text). Once creating one template you can use it to make many newsletters.");
$smarty->assign("order", $order);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("template_page", $template_page);
$smarty->assign("rel", getreleases($order, $template_page));
$smarty->display("{$admin_nl_gentemplates}/template_templates_list.tpl");
?>