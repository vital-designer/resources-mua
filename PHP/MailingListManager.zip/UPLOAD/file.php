<?php
include ("tinymce/file.class.php");
include ("common.php");
$class_file = new file($config['site_path'] . "/pictures/", $config['server'] . "/pictures/");
if (isset($_REQUEST['action']) && !empty($_REQUEST['action']))
{
				$action = $_REQUEST['action'];
}
if (isset($_REQUEST['file']) && !empty($_REQUEST['file']))
{
				$file = $_REQUEST['file'];
}
switch ($action)
{
				case "del":
								if (!$file)
								{
												break;
								}
								$class_file->delete($file);
								break;
				case "upl":
								if (!$_FILES['userfile'])
								{
												break;
								}
								$class_file->upload($_FILES['userfile']);
								break;
				default:
								break;
}
$list = $class_file->getlist();
if ($class_file->isError)
{
				exit($class_file->getlasterror);
}
$smarty->assign("razdel", "Newsletter Edition");
$smarty->assign("description", "File Management");
$smarty->assign("viewfile", 1);
$smarty->assign("list", $list);
$smarty->assign("errors" . $class_file->__errors);
$smarty->display("{$admin_nl_gentemplates}/file.tpl");
?>
