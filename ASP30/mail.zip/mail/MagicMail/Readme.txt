 _   __   _   _____   _____   _____    _____       ___   _      
| | |  \ | | |  _  \ | ____| |  _  \  |  _  \     /   | | |     
| | |   \| | | | | | | |__   | |_| |  | |_| |    / /| | | |     
| | | |\   | | | | | |  __|  |  _  /  |  ___/   / / | | | |     
| | | | \  | | |_| | | |___  | | \ \  | |      / /  | | | |___  
|_| |_|  \_| |_____/ |_____| |_|  \_\ |_|     /_/   |_| |_____| 

MagicMail v1.0
==================

By       : Inderpal Singh
	   -------------
E-mail	 : inderpal0@hotmail.com
	   -----------------------	
Web Page : http://connect.to/lanserver
           ----------------------------

			MagicMail is an simple anonymous mailer. You can use it to send email without logging into an account. It uses the Winsock control in VB. So you need Mswinsck.ocx to be in your system directory. I have included the source code for it. It uses SMTP relaying to send the message to any e-mail address from any email address. I am also including lists of SMTP servers. If you manually edit the server list, each entry should be in the format "servername","port". 

Disclaimer of Warranty:
===========================

			I have made MagicMail for informational purposes only, I will not responsible for the wrong use (if any) of it.

* You MAY NOT sell this software or it's source code.
* You MAY USE this code in any way you find useful.

Contact:
==========

This is the first version I am releasing, so I know there will be a lot of bugs. Feel free to write to me at inderpal0@hotmail.com for bug reports and suggestions.

You can contact me at:
==========================

Inderpal Singh
Room no 305-E, New Boys Hostel,
Army Institute of Technology,
Dighi Hills, Pune (India) - 411015

inderpal0@hotmail.com

Or visit the website:
			http://connect.to/lanserver

The Latest Version
-------------------
Details of the latest version can be found on the MagicMail web page at
http://connect.to/lanserver

Features to be added future versions:
--------------------------------------
* Support Attachments
* And Several New Features

-------------------------------------------------------------------------------------------------
				Thanks! For Using My Software.
-------------------------------------------------------------------------------------------------
