<?php
include ("../common.php");
include ("../include/administrators_function.php");
$section = "admins";
$right_name = "view";
check_right($section, $right_name);
if (isset($_POST['del']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				foreach ($GLOBALS['_POST']['del'] as $val)
				{
								deladmin($val);
				}
}
if (isset($_GET['did']) && !empty($_GET['did']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				deladmin($_GET['did']);
}
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "name";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
}
else
{
				$order = "";
}
$admin_page = isset($_REQUEST['admin_page']) ? $_REQUEST['admin_page'] : 0;
$smarty->assign("razdel", "Administrators");
$smarty->assign("description", "Manage Administrators");
$smarty->assign("hint", "Here is a list of administrators who have system access permissions. Person responsible for performing some part of functions (for example: user subscribing controlling) but still having limited access to other system sections can act as admin.");
$GLOBALS['_SESSION']['return_url'] = "admins.php";
$smarty->assign("order", $order);
$smarty->assign("rel", $rel);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("admin_page", $admin_page);
$smarty->assign("rel", getadmins($order, $admin_page));
$smarty->display("{$admin_nl_gentemplates}/administrators_admins.tpl");
?>