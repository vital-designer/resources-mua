<?php 
$upload_services[] = "ziddu.com_member";
$max_file_size["ziddu.com_member"] = 200;
$page_upload["ziddu.com_member"] = "ziddu.com_member.php";  
?>