<?php
include ("../common.php");
include ("../include/attaches_function.php");
if (isset($_POST['del']))
{
				foreach ($GLOBALS['_POST']['del'] as $val)
				{
								delattach((integer)$val);
				}
}
if (isset($_GET['did']) && !empty($_GET['did']))
{
				delattach((integer)$_GET['did']);
}
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "file_name";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
} else
{
				$order = "";
}
$attach_page = isset($_REQUEST['attach_page']) ? $_REQUEST['attach_page'] : 0;
$smarty->assign("razdel", "Attachments");
$smarty->assign("description", "Manage Attachments");
$smarty->assign("hint", "List of uploaded files on the server. You can attach these files to sent newsletters. General depository for attached files lets you attach one and the same file for different newsletters without additonal uploades.");
$GLOBALS['_SESSION']['return_url'] = "index.php";
$smarty->assign("order", $order);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("attach_page", $attach_page);
$smarty->assign("rel", getattach($order, $attach_page));
$smarty->display("{$admin_nl_gentemplates}/attaches_attaches.tpl");
?>
