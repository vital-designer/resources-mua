<?php
$upload_services[]="azsharing.com";
$max_file_size["azsharing.com"]=100;
$page_upload["azsharing.com"] = "azsharing.com.php";  
?>