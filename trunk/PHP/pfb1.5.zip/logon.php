<?
//phpFormBuilder Version 1.5 by Baris Kayar (barishkayar@yahoo.com)
//2002(cl)  The FormBuilder Group http://pfb.sourceforge.net

$PFBg_Title="PHPFB Logon";
include("langen.inc.php");
echo 
"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">
<html>
<head>
<meta http-equiv=\"content-language\" content=\"TR\">
<meta http-equiv=\"content-type\" content=\"text/html; charset=windows-1254\">
<meta http-equiv=\"content-type\" content=\"text/html; charset=iso-8859-9\">
	<title>$PFBg_Title</title>";
require("style.inc.php");
echo 
"<body>
<table width=\"100%\" height=\"60%\"><tr><td align=\"center\" valign=\"middle\">
<table cellpadding=\"2\" cellspacing=\"0\" border=\"0\">
<tr><td bgcolor=\"#000000\" align=center>
<table cellpadding=\"2\" cellspacing=\"0\" border=\"0\">
<tr><td bgcolor=\"#9999cc\" align=center>
<form action=\"index.php\" method=\"post\">
<table>
<tr><td>$Username_Caption</td><td><input type=\"text\" name=\"username\" value=\"root\" size=10></td></tr>
<tr><td>$Password_Caption</td><td><input type=\"password\" name=\"password\" size=10></td></tr>
<tr><td>$MysqlServer_Caption</td><td><input type=\"text\" name=\"dbserver\" value=\"localhost\" size=10></td></tr>
<tr><td colspan=2 align=\"center\"><input type=\"Submit\" name=\"logon\" value=\"logon\"></td></tr>
</table>
</form></td></tr></table></td></tr></table>
</td></tr></table>";
include("about.inc.php");
echo "</body></html>";
?>