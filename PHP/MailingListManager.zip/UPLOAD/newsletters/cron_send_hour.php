<?php
exit();
ini_set("max_execution_time", 0);
include ("../include/config.php");
include ("../adodb/adodb.inc.php");
include ("../include/common_functions.php");
include ("../include/newsletters_function.php");
$dbconn = &adonewconnection($config['dbtype']);
global $ADODB_FETCH_MODE;
if ($config['dbtype'] == "ado_mssql")
{
				if ($config['useoledb'] == 1)
				{
								$connectString = "SERVER=" . $config['dbhost'] . ";DATABASE=" . $config['dbname'] . ";";
								$dbh = $dbconn->pconnect($connectString, $config['dbuname'], $config['dbpass'], "SQLOLEDB");
				}
				else
				{
								$connectString = "PROVIDER=MSDASQL;DRIVER={SQL Server};SERVER=" . $config['dbhost'] . ";DATABASE=" . $config['dbname'] . ";id_user=" . $config['dbuname'] . ";PWD=" . $config['dbpass'] . ";";
								$dbh = $dbconn->pconnect($connectString, "", "", "");
				}
}
else
{
				$connectString = $config['dbtype'] . ":" . $config['dbuname'] . ":" . $config['dbpass'] . "@" . $config['dbhost'] . "/" . $config['dbname'];
				$dbh = $dbconn->pconnect($config['dbhost'], $config['dbuname'], $config['dbpass'], $config['dbname']);
}
$ADODB_FETCH_MODE = ADODB_FETCH_NUM;
if ($dbh === false)
{
				error_log("connect string: {$connectString}");
				error_log("error: " . $dbconn->errormsg());
}
$rs_settings = $dbconn->execute("select * from settings");
$settings = $rs_settings->getrowassoc(false);
$rs = $dbconn->execute("select * from clients_releases where is_sent='0' and date <= now()");
$quota = 0;
while (!$rs->EOF && ($quota < $settings['smtp_quota'] && 0 < $settings['smtp_quota'] || $settings['smtp_quota'] == 0))
{
				$row = $rs->getrowassoc(false);
				$res = $dbconn->execute("select * from creleases_lists where crelease_id='" . $row['release_id'] . "'");
				sendreleasetouser($row['release_id'], $row['client_id'], $row['list_id']);
				++$quota;
				$rs->movenext();
}
$rs = $dbconn->execute("select * from creleases where is_sent='2'");
while (!$rs->EOF)
{
				$res = $dbconn->execute("select count(*) from clients_releases where is_sent='0' and release_id = '" . $rs->fields['0'] . "'");
				if ($res->fields[0] == 0)
				{
								$res = $dbconn->execute("update creleases set is_sent='1' where id='" . $rs->fields['0'] . "'");
								$rel = getcontent($rs->fields['0']);
								if ($rel['notify_end'])
								{
												$message = "Complete sending newsletter from " . $config['server'] . "<br>\r\n\t\t\t<strong>Subject: </strong>" . $rel['subject'] . "<br>\r\n\t\t\t<strong>Priority: </strong>" . $config['priority'][$rel['priority']] . "<br>\r\n\t\t\t<strong>Attach file(s):</strong> ";
												$rs_attach = $dbconn->execute("select * from release_attach ra, attach a where ra.release_id='" . $rs->fields['0'] . "' and ra.attach_id=a.id");
												while (!$rs_attach->EOF)
												{
																$row = $rs_attach->getrowassoc(false);
																$attach[] = $row['file_name'];
																$mail->addattachment($config['files_path'] . "/" . $row['file_name']);
																$rs_attach->movenext();
												}
												if (is_array($attach))
												{
																foreach ($attach as $file_name)
																{
																				$message .= $file_name . " (" . file_size($config['files_path'] . "/" . $file_name) . ")&nbsp;&nbsp;";
																				++$t;
																}
												}
												if ($t == 0)
												{
																$message .= "No";
												}
												emailtext($res->fields[8], "Notification: complete sending newsletter", $message, $settings['from_name'], $settings['from_email']);
								}
				}
				$rs->movenext();
}
?>