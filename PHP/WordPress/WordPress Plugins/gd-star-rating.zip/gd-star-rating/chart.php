<?php

    require_once("./config.php");
    $wpconfig = get_wpload_path();
    require($wpconfig);

    global $gdsr;

?>