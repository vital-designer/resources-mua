<?php
include ("../common.php");
include ("../include/archive_function.php");
$section = "statistic";
$right_name = "view";
check_right($section, $right_name);
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "date";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
}
else
{
				$order = "";
}
$archive_page = isset($_REQUEST['archive_page']) ? $_REQUEST['archive_page'] : 0;
$res = $dbconn->execute("SELECT COUNT(id) FROM snd_users");
$total['users'] = $res->fields[0];
$res = $dbconn->execute("SELECT DISTINCT client_id FROM clients_lists WHERE status_subscribe ='" . $config['status_subscribe_val']['subscribe'] . "'");
$total['subscribed'] = $res->rowcount();
$res = $dbconn->execute("SELECT DISTINCT client_id FROM clients_lists WHERE status_subscribe ='" . $config['status_subscribe_val']['unsubscribe'] . "'");
$total['unsubscribed'] = $res->rowcount();
$res = $dbconn->execute("SELECT DISTINCT client_id FROM clients_lists WHERE status_subscribe ='" . $config['status_subscribe_val']['unconf_sub'] . "'");
$total['unconfirm_subscribe'] = $res->rowcount();
$res = $dbconn->execute("SELECT DISTINCT client_id FROM clients_lists WHERE status_subscribe ='" . $config['status_subscribe_val']['unconf_unsub'] . "'");
$total['unconfirm_unsubscribe'] = $res->rowcount();
$res = $dbconn->execute("SELECT count(id) FROM list");
$total['lists'] = $res->fields[0];
$res = $dbconn->execute("select distinct list_id from clients_lists where status_subscribe<>'" . $config['status_subscribe_val']['unsubscribe'] . "'");
$total['sub_lists'] = $res->rowcount();
$total['unsub_lists'] = $total['lists'] - $total['sub_lists'];
$res = $dbconn->execute("select count(id) from creleases");
$total['newsletters'] = $res->fields[0];
$res = $dbconn->execute("select count(id) from creleases where is_sent='1' or is_sent='3'");
$total['sent_newsletters'] = $res->fields[0];
$res = $dbconn->execute("select count(id) from creleases where is_sent='0'");
$total['not_sent_newsletters'] = $res->fields[0];
$res = $dbconn->execute("select count(id) from creleases where is_sent='2'");
$total['in_process'] = $res->fields[0];
$c = 0;
$res = $dbconn->execute("select * from list order by name");
while (!$res->EOF)
{
				$row = $res->getrowassoc();
				$rel[$c]['list_name'] = $row['NAME'];
				$rs1 = $dbconn->execute("select distinct client_id from clients_lists where status_subscribe='" . $config['status_subscribe_val']['subscribe'] . "' and list_id='" . $row['ID'] . "'");
				$rel[$c]['subscribe'] = $rs1->rowcount();
				$rs1 = $dbconn->execute("select distinct client_id from clients_lists where status_subscribe='" . $config['status_subscribe_val']['unsubscribe'] . "' and list_id='" . $row['ID'] . "'");
				$rel[$c]['unsubscribe'] = $rs1->rowcount();
				$rs1 = $dbconn->execute("select distinct client_id from clients_lists where status_subscribe='" . $config['status_subscribe_val']['unconf_sub'] . "' and list_id='" . $row['ID'] . "'");
				$rel[$c]['unconfirm_subscribe'] = $rs1->rowcount();
				$rs1 = $dbconn->execute("select distinct client_id from clients_lists where status_subscribe='" . $config['status_subscribe_val']['unconf_unsub'] . "' and list_id='" . $row['ID'] . "'");
				$rel[$c]['unconfirm_unsubscribe'] = $rs1->rowcount();
				$rs1 = $dbconn->execute("select max(date_status) from clients_lists where status_subscribe='" . $config['status_subscribe_val']['subscribe'] . "' and list_id='" . $row['ID'] . "'");
				$rel[$c]['last_subscribe'] = $rs1->fields[0];
				$rs1 = $dbconn->execute("select max(date_status) from clients_lists where status_subscribe='" . $config['status_subscribe_val']['unsubscribe'] . "' and list_id='" . $row['ID'] . "'");
				$rel[$c]['last_unsubscribe'] = $rs1->fields[0];
				$rs1 = $dbconn->execute("select distinct cl.crelease_id from creleases_lists cl, creleases c where cl.list_id='" . $row['ID'] . "' and c.id=cl.crelease_id and c.is_sent='1'");
				$rel[$c]['sent_newsletters'] = $rs1->rowcount();
				$rs1 = $dbconn->execute("select distinct cl.crelease_id from creleases_lists cl, creleases c where cl.list_id='" . $row['ID'] . "' and c.id=cl.crelease_id and c.is_sent='0'");
				$rel[$c]['not_sent_newsletters'] = $rs1->rowcount();
				$rs1 = $dbconn->execute("select distinct cl.crelease_id from creleases_lists cl, creleases c where cl.list_id='" . $row['ID'] . "' and c.id=cl.crelease_id and c.is_sent='2'");
				$rel[$c]['in_process'] = $rs1->rowcount();
				++$c;
				$res->movenext();
}
$smarty->assign("razdel", "Statistics");
$smarty->assign("description", "General Statistics");
$smarty->assign("hint", "Here you may find basic figures on subscribers, newsletters and mailing lists. Use this information to estimate your work performed. To simplify calculations let's consider that a user is subscribed to a list if his status to this list has the value different from \"Unsubscribe\"");
$GLOBALS['_SESSION']['return_url'] = "index.php";
$smarty->assign("rel", $rel);
$smarty->assign("total", $total);
$smarty->assign("order", $order);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("archive_page", $archive_page);
$smarty->display("{$admin_nl_gentemplates}/archive_general_statistics.tpl");
?>