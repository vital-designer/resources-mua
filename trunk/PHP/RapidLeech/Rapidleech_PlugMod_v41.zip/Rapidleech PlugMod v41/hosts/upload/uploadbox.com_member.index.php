<?php
$upload_services[]="uploadbox.com_member";
$max_file_size["uploadbox.com_member"]=2000;
$page_upload["uploadbox.com_member"] = "uploadbox.com_member.php";  
?>