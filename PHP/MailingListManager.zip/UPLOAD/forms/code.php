<?php
include ("../common.php");
include ("../include/forms_function.php");
include ("../include/class.form.php");
$smarty->assign("razdel", "Forms");
$smarty->assign("description", "HTML Form");
$smarty->assign("hint", "HTML-code of the form to place at your site");
$res = $dbconn->execute("SELECT * FROM form WHERE id='" . (integer)$_GET['id'] . "'");
$row = $res->getrowassoc(false);
$form_html = $row['type'] == "sub" ? generateform($row) : generateunsubscribeform($row);
$smarty->assign("code", htmlspecialchars($form_html));
$smarty->display("{$admin_nl_gentemplates}/forms_form_code.tpl");
?>
