<?php
include ("../common.php");
include ("../include/newsletters_function.php");
$section = "newsletters";
$right_name = "view";
check_right($section, $right_name);
if (isset($_POST['del']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				foreach ($GLOBALS['_POST']['del'] as $val)
				{
								delreleasearhive($val);
				}
}
if (isset($_GET['did']) && !empty($_GET['did']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				delreleasearhive($_GET['did']);
}
if (isset($_REQUEST['newsletter_page']))
{
				$newsletter_page = $_REQUEST['newsletter_page'];
}
else
{
				$newsletter_page = 0;
}
$smarty->assign("razdel", "Newsletters");
$smarty->assign("description", "Newsletters Archive");
$smarty->assign("hint", "This is the section where you can keep your sent newsletters  archive. To add a newsletter to this section, go to �Manage newsletters� section, choose the newsletter and click the�Add to archive� button. \nYou can make newsletters from archive available on your website. Just insert the link to it on your site page. Clicking it, site visitor will be able to view the newsletter right from the website.");
$GLOBALS['_SESSION']['return_url'] = "archive.php";
$smarty->assign("rel", getreleasesarhive($order, $newsletter_page));
$smarty->assign("newsletter_page", $newsletter_page);
$smarty->display("{$admin_nl_gentemplates}/newsletters_archive.tpl");
?>