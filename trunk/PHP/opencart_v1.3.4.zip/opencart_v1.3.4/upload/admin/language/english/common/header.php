<?php
// Text
$_['text_heading'] = 'Administration';
$_['text_user']    = 'You are logged in as <b>%s</b>';
$_['text_logout']  = 'Logout';
?>