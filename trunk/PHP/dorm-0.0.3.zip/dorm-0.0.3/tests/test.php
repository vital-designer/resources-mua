<?php
require('bootstrap.php');

$dorm = new Dorm('config.xml');

include('footer.php');