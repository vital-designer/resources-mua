<?php
function step_lisence()
{
				global $install;
				global $errors;
				include ("license.php");
				$ret_str = $license;
				$next_step = true;
				template_lisence_page($ret_str, $next_step);
				exit();
}
function step_1()
{
				global $install;
				global $errors;
				$ret_str = "";
				$next_step = true;
				$write_good = true;
				$good = "4.1.2" <= phpversion() ? 1 : 0;
				$ret_str .= permission_str("PHP version >= 4.1.2: ", $good);
				$next_step = $next_step && $good;
				$good = function_exists("mysql_connect") ? 1 : 0;
				$ret_str .= permission_str("MySQL support exists: ", $good);
				$next_step = $next_step && $good;
				foreach ($install['permission_files'] as $num => $file)
				{
								$good = iswriteable($install['install_path'] . "/" . $file, 511);
								$sub_ret_str .= permission_str($file . " is writable: ", $good, 1);
								$write_good = $write_good && $good;
				}
				$ret_str .= permission_str(" Check file permissions: ", $write_good) . $sub_ret_str;
				$next_step = $next_step && $write_good;
				clearstatcache();
				$next_step = $next_step && $good;
				template_first_page($ret_str, $next_step);
				exit();
}
function step_2()
{
				global $install;
				global $errors;
				template_database_server_form();
}
function database_server_install()
{
				global $install;
				global $errors;
				$data['dbhost'] = $_POST['dbhost'];
				$data['dbname'] = $_POST['dbname'];
				$data['dbuser'] = $_POST['dbuser'];
				$data['dbpass'] = $_POST['dbpass'];
				$data['dblang'] = $_POST['dblang'];
				$data['server'] = $_POST['server'];
				$data['site_root'] = $_POST['site_root'];
				$data['site_path'] = $_POST['site_path'];
				if (!strlen($data['dbhost']))
				{
								template_database_server_form($errors['not_valid_field'] . " dbhost", $data);
								insertlogdata($errors['not_valid_field'] . " dbhost");
				}
				else
								if (!strlen($data['dbname']))
								{
												template_database_server_form($errors['not_valid_field'] . " dbname", $data);
												insertlogdata($errors['not_valid_field'] . " dbname");
								}
								else
								{
												if (!strlen($data['dbuser']))
												{
																template_database_server_form($errors['not_valid_field'] . " dbuser", $data);
																insertlogdata($errors['not_valid_field'] . " dbuser");
												}
												else
												{
																if ($data['site_root'])
																{
																				$pos = strpos($data['site_path'], $data['site_root']);
																				if ($pos === false)
																				{
																								template_database_server_form($errors['not_valid_site_root'], $data);
																								insertlogdata($errors['not_valid_site_root']);
																								return;
																				}
																}
																$data['site_root'] = str_replace("/", "/", stripslashes($_POST['site_root']));
																$link = mysql_connect($data['dbhost'], $data['dbuser'], $data['dbpass']);
																if (!$link)
																{
																				template_database_server_form($errors['cant_connect_to_host'] . "(" . mysql_error() . ")", $data);
																				insertlogdata($errors['cant_connect_to_host'] . "(" . mysql_error() . ")");
																}
																else
																				if (!mysql_select_db($data['dbname']))
																				{
																								template_database_server_form($errors['cant_select_db'] . "(" . mysql_error() . ")", $data);
																								insertlogdata($errors['cant_select_db'] . "(" . mysql_error() . ")");
																				}
																				else
																				{
																								$db_file = dirname(__file__) . "/bases/newsletter.sql";
																								if (!file_exists($db_file))
																								{
																												template_database_server_form($errors['not_valid_base_file'], $data);
																												insertlogdata($errors['not_valid_base_file']);
																								}
																								else
																								{
																												$db_content = implode("\n", file($db_file));
																												$db_content = str_replace("[image_path]", $data['server'] . $data['site_root'], $db_content);
																												$db_content = str_replace("[homepage]", $data['server'], $db_content);
																												$db_file_temp = dirname(__file__) . "/bases/newsletter_tmp.sql";
																												$fp = fopen($db_file_temp, "w");
																												if ($fp)
																												{
																																fwrite($fp, $db_content);
																																fclose($fp);
																												}
																												$is_safe_mode = ini_get("safe_mode") == "1" ? 1 : 0;
																												if (!$is_safe_mode)
																												{
																																set_time_limit(600);
																												}
																												template_db_restore("Step 2: Database & Server Configuration : Creating DB", "./index.php?sel=4");
																												$restore_obj = new baserestore();
																												$timer = array_sum(explode(" ", microtime()));
																												ob_implicit_flush();
																												$err = $restore_obj->restore($data['dbhost'], $data['dbuser'], $data['dbpass'], $data['dbname'], $db_file_temp);
																												print "<SCRIPT>document.getElementById('timer').innerHTML = '" . round(array_sum(explode(" ", microtime())) - $timer, 4) . " sec.'</SCRIPT>";
																												if ($err != 0)
																												{
																																print "<SCRIPT>document.getElementById('back').disabled = 0;</SCRIPT>";
																												}
																												else
																												{
																																$string = implode("", file("./config_dist"));
																																$string = str_replace("[server]", $data['server'], $string);
																																$string = str_replace("[site_root]", $data['site_root'], $string);
																																$string = str_replace("[site_path]", str_replace($data['site_root'], "", $data['site_path']), $string);
																																$string = str_replace("[db_host]", $data['dbhost'], $string);
																																$string = str_replace("[db_user]", $data['dbuser'], $string);
																																$string = str_replace("[db_pass]", $data['dbpass'], $string);
																																$string = str_replace("[db_name]", $data['dbname'], $string);
																																$config_path = "../include/config.php";
																																$fp = fopen($config_path, "w");
																																if ($fp)
																																{
																																				fputs($fp, $string);
																																				fclose($fp);
																																}
																																print "<SCRIPT>document.getElementById('next').disabled = 0;</SCRIPT>";
																												}
																												return;
																								}
																				}
												}
								}
}
function step_3()
{
				global $install;
				global $errors;
				template_misc_parametrs_form();
}
function settings_install()
{
				global $install;
				global $errors;
				global $config;
				$data['company_name'] = $_POST['company_name'];
				$data['admin_login'] = $_POST['admin_login'];
				$data['admin_pass'] = $_POST['admin_pass'];
				$data['admin_repass'] = $_POST['admin_repass'];
				$data['admin_email'] = $_POST['admin_email'];
				$data1['company_name'] = $data['company_name'];
				$data1['admin_login'] = $data['admin_login'];
				$data1['admin_pass'] = $data['admin_pass'];
				$data1['admin_repass'] = $data['admin_repass'];
				$data1['admin_email'] = $data['admin_email'];
				if (!strlen($data['company_name']))
				{
								template_misc_parametrs_form($errors['empty_company_name'], $data);
								insertlogdata($errors['empty_company_name']);
				}
				else
								if ($err = loginfilter($data['admin_login']))
								{
												template_misc_parametrs_form($err, $data);
												insertlogdata($err);
								}
								else
												if ($err = emailfilter($data['admin_email']))
												{
																template_misc_parametrs_form($err, $data);
																insertlogdata($err);
												}
												else
																if (!strlen($data['admin_email']))
																{
																				template_misc_parametrs_form($errors['email_bad'], $data);
																				insertlogdata($errors['email_bad']);
																}
																else
																				if ($err = passwfilter($data['admin_pass']))
																				{
																								template_misc_parametrs_form($err, $data);
																								insertlogdata($err);
																				}
																				else
																								if ($data['admin_pass'] != $data['admin_repass'])
																								{
																												template_misc_parametrs_form($errors['pass_eq_repass'], $data);
																												insertlogdata($errors['pass_eq_repass']);
																								}
																								else
																												if ($data['admin_pass'] == $data['admin_login'])
																												{
																																template_misc_parametrs_form($errors['pass_eq_log'], $data);
																																insertlogdata($errors['pass_eq_log']);
																												}
																												else
																												{
																																$db_admin_file = dirname(__file__) . "/bases/newsletter_update_admin.sql";
																																if (!file_exists($db_admin_file))
																																{
																																				template_database_server_form($errors['not_valid_base_file'], $data);
																																				insertlogdata($errors['not_valid_base_file'] . " " . $db_file);
																																}
																																else
																																{
																																				include ("../include/config.php");
																																				$db_content = implode("\n", file($db_admin_file));
																																				$db_content = str_replace("[admin_email]", $data1['admin_email'], $db_content);
																																				$db_content = str_replace("[company_name]", $data1['company_name'], $db_content);
																																				$db_content = str_replace("[admin_login]", $data1['admin_login'], $db_content);
																																				$db_content = str_replace("[admin_passw]", $data1['admin_pass'], $db_content);
																																				$smtp_host = ini_get("SMTP") ? ini_get("SMTP") : "localhost";
																																				$db_content = str_replace("[smtp_host]", $smtp_host, $db_content);
																																				$db_file_temp = dirname(__file__) . "/bases/newsletter_tmp.sql";
																																				$fp = fopen($db_file_temp, "w");
																																				if ($fp)
																																				{
																																								fwrite($fp, $db_content);
																																								fclose($fp);
																																				}
																																				$is_safe_mode = ini_get("safe_mode") == "1" ? 1 : 0;
																																				if (!$is_safe_mode)
																																				{
																																								set_time_limit(600);
																																				}
																																				template_db_restore("Step 3: Site Settings : Updating DB", "./index.php?sel=6");
																																				$restore_obj = new baserestore();
																																				$timer = array_sum(explode(" ", microtime()));
																																				ob_implicit_flush();
																																				$err = $restore_obj->restore($config['dbhost'], $config['dbuname'], $config['dbpass'], $config['dbname'], $db_file_temp);
																																				print "<SCRIPT>document.getElementById('timer').innerHTML = '" . round(array_sum(explode(" ", microtime())) - $timer, 4) . " sec.'</SCRIPT>";
																																				if ($err != 0)
																																				{
																																								print "<SCRIPT>document.getElementById('back').disabled = 0;</SCRIPT>";
																																				}
																																				else
																																				{
																																								print "<SCRIPT>document.getElementById('next').disabled = 0;</SCRIPT>";
																																				}
																																				return;
																																}
																												}
}
function loginfilter($str)
{
				global $errors;
				$err = "";
				if (strlen($str) < 5 || 20 < strlen($str))
				{
								$err = $errors['login_length'];
				}
				if (!eregi("^[0-9a-z_\\sA-Z]*\$", $str))
				{
								$err = $errors['login_cont'];
				}
				return $err;
}
function emailfilter($str)
{
				global $errors;
				$err = "";
				if (0 < strlen($str) && !eregi("^.+@.+\\..+\$", $str))
				{
								$err = $errors['email_bad'];
				}
				return $err;
}
function passwfilter($str)
{
				global $errors;
				$err = "";
				if (strlen($str) < 6 || 20 < strlen($str))
				{
								$err = $errors['pass_length'];
				}
				if (!eregi("^[0-9a-z_]*\$", $str))
				{
								$err = $errors['pass_cont'];
				}
				return $err;
}
function insertlogdata($err = "")
{
				global $install;
				$file_path = "./install_log.txt";
				if (!$err)
				{
								$fp = fopen($file_path, "a+");
								if ($fp)
								{
												fclose($fp);
								}
				}
				else
				{
								$err = br2n($err);
								$err = explode("\n", $err);
								$string = "";
								$i = 0;
								for (; $i < count($err); ++$i)
								{
												$string .= date("d-m-y H:i:s") . " " . $err[$i] . "\n";
								}
								$fp = fopen($file_path, "a+");
								if ($fp)
								{
												fputs($fp, $string);
												fclose($fp);
								}
								return;
				}
}
function n2br($str)
{
				return eregi_replace("\n", "<br>", $str);
}
function br2n($str)
{
				return eregi_replace("<br>", "\n", $str);
}
function iswriteable($file, $mode)
{
				@chmod($file, $mode);
				$good = is_writable($file) ? 1 : 0;
				return $good;
}
ini_set("display_errors", "0");
error_reporting(E_ALL);
ini_set("max_execution_time", 1000);
include ("./initial.php");
include ("./forms.php");
include ("./errors.php");
include ("../include/class.restore.php");
$sel = $_GET['sel'] ? $_GET['sel'] : $_POST['sel'];
switch ($sel)
{
				case "1":
								step_1();
								break;
				case "2":
								step_2();
								break;
				case "3":
								database_server_install();
								break;
				case "4":
								step_3();
								break;
				case "5":
								settings_install();
								break;
				case "6":
								template_last_page();
								break;
				default:
								step_lisence();
								break;
}
?>