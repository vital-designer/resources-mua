<?php 
$upload_services[]="supernovatube.com";
$max_file_size["supernovatube.com"]=512;
$page_upload["supernovatube.com"] = "supernovatube.com.php";  
?>