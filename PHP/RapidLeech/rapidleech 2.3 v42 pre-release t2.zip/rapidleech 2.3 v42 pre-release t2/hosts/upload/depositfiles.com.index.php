<?php 
$upload_services[] = "depositfiles.com";
$max_file_size["depositfiles.com"] = 2000;
$page_upload["depositfiles.com"] = "depositfiles.com.php";  
?>