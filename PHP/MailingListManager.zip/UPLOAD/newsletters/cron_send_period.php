<?php
exit();
ini_set("max_execution_time", 0);
include ("../include/config.php");
include ("../adodb/adodb.inc.php");
include ("../include/common_functions.php");
include ("../include/newsletters_function.php");
$dbconn = &adonewconnection($config['dbtype']);
global $ADODB_FETCH_MODE;
if ($config['dbtype'] == "ado_mssql")
{
				if ($config['useoledb'] == 1)
				{
								$connectString = "SERVER=" . $config['dbhost'] . ";DATABASE=" . $config['dbname'] . ";";
								$dbh = $dbconn->pconnect($connectString, $config['dbuname'], $config['dbpass'], "SQLOLEDB");
				}
				else
				{
								$connectString = "PROVIDER=MSDASQL;DRIVER={SQL Server};SERVER=" . $config['dbhost'] . ";DATABASE=" . $config['dbname'] . ";id_user=" . $config['dbuname'] . ";PWD=" . $config['dbpass'] . ";";
								$dbh = $dbconn->pconnect($connectString, "", "", "");
				}
}
else
{
				$connectString = $config['dbtype'] . ":" . $config['dbuname'] . ":" . $config['dbpass'] . "@" . $config['dbhost'] . "/" . $config['dbname'];
				$dbh = $dbconn->pconnect($config['dbhost'], $config['dbuname'], $config['dbpass'], $config['dbname']);
}
$ADODB_FETCH_MODE = ADODB_FETCH_NUM;
if ($dbh === false)
{
				error_log("connect string: {$connectString}");
				error_log("error: " . $dbconn->errormsg());
}
$sql = "OPTIMIZE TABLE `attach`, `click_counter`, `clients_lists`, `clients_releases`, `creleases`, `creleases_lists`, `form`, `forms_lists`, `images`, `list`, `settings`, `snd_users`, `templates`";
$rs = $dbconn->execute($sql);
$rs = $dbconn->execute("select * from creleases where date_send is not NULL");
while (!$rs->EOF)
{
				$row = $rs->getrowassoc(false);
				$inter = explode(" ", $row['repeat']);
				switch ($inter[1])
				{
								case "day":
												$strsql = "select (date_send + INTERVAL " . intval($inter[0]) . " DAY) as inter from creleases where id=" . $row['id'];
												break;
								case "week":
												$s = 7 * intval($inter[0]);
												$strsql = "select (date_send + INTERVAL " . $s . " DAY) as inter from creleases where id=" . $row['id'];
												break;
								case "month":
												$strsql = "select (date_send + INTERVAL " . intval($inter[0]) . " MONTH) as inter from creleases where id=" . $row['id'];
												break;
								case "year":
												$strsql = "select (date_send + INTERVAL " . intval($inter[0]) . " YEAR) as inter from creleases where id=" . $row['id'];
				}
				$rs = $dbconn->execute($strsql);
				$date_send = strtotime($rs->fields[0]);
				if (date("Y-m-d") == $date_send)
				{
								$res = $dbconn->execute("select * from creleases_lists where crelease_id='" . $row['id'] . "'");
								$c = 0;
								while (!$res->EOF)
								{
												$row_list = $res->getrowassoc(false);
												$list_array[$c] = $row_list['list_id'];
												++$c;
												$res->movenext();
								}
								$us = sendrelease($row['id'], $list_array);
				}
				$rs->movenext();
}
?>