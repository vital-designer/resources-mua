<?php
include ("../common.php");
include ("../include/users_function.php");
ini_set("max_execution_time", 0);
$section = "subscribers";
$right_name = "import";
check_right($section, $right_name);
$msg_user = "";
if (isset($_POST['action']) || $_POST['action'] == "import")
{
				$err = "";
				$count_errors = 0;
				$fp = @fopen($_FILES['csv_file']['tmp_name'], "r");
				if (!$fp)
				{
								$err1 = "bad_file";
								$is_err = true;
				}
				++$count_errors;
				if (sizeof($_POST['list']) < 1)
				{
								$err2 = "list_empty";
								$is_err = true;
				}
				++$count_errors;
				if ($is_err)
				{
								$i = 1;
								for (; $i <= $count_errors; ++$i)
								{
												$tmp = "err" . $i;
												$$tmp = !isset($tmp) ? "no" : $$tmp;
												$err .= "err" . $i . "=" . $$tmp . "&";
								}
								$err .= "count_errors=" . $count_errors;
								echo "<script>this.location.href = 'import_csv.php?" . $err . "'</script>";
								exit();
				}
				if (!($data = @fgetcsv($fp, 1000, $_POST['delimiter'])) || !is_array($data))
				{
								$err = "err1=bad_file&count_errors=1";
								echo "<script>this.location.href = 'import_csv.php?" . $err . "'</script>";
								exit();
				}
				foreach ($data as $key => $value)
				{
								$value = strtolower(trim($value));
								if ($value == "name" || $value == "first name" || $value == "firstname" || $value == "first_name")
								{
												$arr['name'] = $key;
								}
								if ($value == "surname" || $value == "last name" || $value == "lastname" || $value == "last_name")
								{
												$arr['surname'] = $key;
								}
								if ($value == "company")
								{
												$arr['company'] = $key;
								}
								if ($value == "email" || $value == "e-mail" || $value == "e_mail" || $value == "mail")
								{
												$arr['email'] = $key;
								}
				}
				$row = 0;
				while ($data = fgetcsv($fp, 1000, ";"))
				{
								$email = trim($data[$arr['email']]);
								if (check_email($email))
								{
												$subscriber[$row]['firstname'] = trim($data[$arr['name']]);
												$subscriber[$row]['secondname'] = trim($data[$arr['surname']]);
												$subscriber[$row]['company'] = trim($data[$arr['company']]);
												$subscriber[$row]['email1'] = $email;
												$subscriber[$row]['comment'] = trim($_POST['comment']);
												$subscriber[$row]['list'] = $_POST['list'];
												$subscriber[$row]['status'] = 1;
												$msg_user .= adduser($subscriber[$row]);
												++$row;
												print str_repeat(" ", 4096);
												flush();
								}
				}
				$msg_user .= "<br>" . $row . " subscribers are imported.<br>";
				$GLOBALS['_SESSION']['message'] = $msg_user;
				fclose($fp);
				echo "<script> window.location='index.php'; </script>";
				exit();
}
$smarty->assign("lists", getlists());
$msg = "";
if (0 < sizeof($_GET))
{
				$i = 1;
				for (; $i <= $_GET['count_errors']; ++$i)
				{
								$tmp = "err" . $i;
								if ($_GET[$tmp] == "list_empty")
								{
												$msg .= "Error: Please, choose list for subscribers.<br>";
								}
								if ($_GET[$tmp] == "bad_file")
								{
												$msg .= "Error: Can't open file.<br>";
								}
				}
}
$smarty->assign("razdel", "Subscribers");
$smarty->assign("description", "Import Subscribers from CSV file");
$smarty->assign("hint", "Choose csv file with saved information on subscribers. Columns titles can be the following: Name (variant First Name, first_name), Last Name (variant Surname, last_name, lastname), Company, Email (variant e-mail). Case free. Choose mailing lists of those in the list. If no delivery list is created, please, create it first.");
$smarty->assign("msg", $msg);
$smarty->display("{$admin_nl_gentemplates}/users_import_csv.tpl");
?>