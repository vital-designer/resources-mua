<?php
class form
{
				var $dbconn;
				var $config;
				var $ds;
				function form($dbconn, $config)
				{
								$this->dbconn = $dbconn;
								$this->config = $config;
								$this->ds[0]['name'] = "Mailing Lists";
								$this->ds[0]['table'] = "list";
								$this->ds[0]['col_id'] = "id";
								$this->ds[0]['col_name'] = "name";
				}
				function getalldatasources()
				{
								return $this->ds;
				}
				function getdatasourcevalues($ds_id)
				{
								$datasource = $this->ds[$ds_id];
								$strSQL = "SELECT " . $datasource['col_id'] . ", " . $datasource['col_name'] . " FROM " . $datasource['table'];
								$rs = $this->dbconn->execute($strSQL);
								$values = array();
								$i = 0;
								while (!$rs->EOF)
								{
												$values[$i]['id'] = $rs->fields[0];
												$values[$i]['name'] = $rs->fields[1];
												$rs->movenext();
												++$i;
								}
								return $values;
				}
				function getformattributes($id_form)
				{
								$strSQL = "SELECT b.id_block, b.id_attribute, b.attr_order FROM " . FORMS_TABLE . " b\n\t\t\t\t\tWHERE b.id_block=" . $id_form . " AND ISNULL(b.id_attribute)=0 ORDER BY attr_order";
								$rs = $this->dbconn->execute($strSQL);
								$attrs = array();
								$i = 0;
								while (!$rs->EOF)
								{
												$row = $rs->getrowassoc(false);
												$attrs[$i]['id_block'] = $row['id_block'];
												$attrs[$i]['attr_order'] = $row['attr_order'];
												$attr_temp = $this->getsectionattribute($row['id_attribute']);
												$attrs[$i] = array_merge($attrs[$i], $attr_temp);
												++$i;
												$rs->movenext();
								}
								return $attrs;
				}
				function updateform($id_form, $attrs)
				{
								$strSQL = "DELETE FROM " . FORMS_TABLE . " WHERE id_block=" . $id_form;
								$this->dbconn->execute($strSQL);
								foreach ($attrs as $order => $id_attr)
								{
												$strSQL = "INSERT INTO " . FORMS_TABLE . "(id_block, id_attribute, attr_order) VALUES(" . $id_form . ", " . $id_attr . ", " . $order . ")";
												$this->dbconn->execute($strSQL);
								}
				}
				function deleteform($id_form)
				{
								$strSQL = "DELETE FROM " . FORMS_TABLE . " WHERE id_block=" . $id_form;
								$this->dbconn->execute($strSQL);
				}
				function getsection($id_section)
				{
								$strSQL = "SELECT id, name, is_const FROM " . SECTIONS_TABLE . " WHERE id=" . $id_section;
								$rs = $this->dbconn->execute($strSQL);
								$section = array();
								$row = $rs->getrowassoc(false);
								$section['id'] = $row['id'];
								$section['name'] = $row['name'];
								$section['is_const'] = $row['is_const'];
								return $section;
				}
				function getsections()
				{
								$strSQL = "SELECT id FROM " . SECTIONS_TABLE . " ORDER BY id";
								$rs = $this->dbconn->execute($strSQL);
								$sections = array();
								$i = 0;
								while (!$rs->EOF)
								{
												$sections[$i] = $this->getsection($rs->fields[0]);
												++$i;
												$rs->movenext();
								}
								return $sections;
				}
				function getsectionattribute($id_attr)
				{
								$strSQL = "SELECT a.id, a.name, a.id_section, a.mandatory, a.control_type, a.control_setup, a.is_const FROM " . SECTION_ATTRS_TABLE . " a\n\t\t\t\tWHERE a.id=" . $id_attr;
								$rs = $this->dbconn->execute($strSQL);
								$attr = array();
								$row = $rs->getrowassoc(false);
								$attr['id'] = $row['id'];
								$attr['id_section'] = $row['id_section'];
								$attr['mandatory'] = $row['mandatory'];
								$attr['control_type'] = $row['control_type'];
								$attr['is_const'] = $row['is_const'];
								$attr['setup'] = unserialize(stripslashes($row['control_setup']));
								$attr['field_name'] = $row['name'];
								$attr['type_text'] = $this->getcontroltype($row['control_type']);
								switch ($attr['control_type'])
								{
												case "text":
												case "textarea":
																$strSQL = "SELECT name FROM " . REFERENCE_SPR . " WHERE table_key=" . VALUES_KEY . " AND id_reference=" . $attr['id'];
																$rs = $this->dbconn->execute($strSQL);
																$attr['setup']['def_value'] = $rs->fields[0];
																break;
												case "select":
																if ($attr['setup']['datasource'] == -1 || !isset($attr['setup']['datasource']))
																{
																				$strSQL = "SELECT id, id_reference as id_ref, name FROM " . REFERENCE_SPR . " WHERE table_key=" . ($attr['id'] + 1) . " ORDER BY id";
																				$rs = $this->dbconn->execute($strSQL);
																				$i = 0;
																				while (!$rs->EOF)
																				{
																								$row = $rs->getrowassoc(false);
																								$attr['setup']['values'][$i]['id'] = $row['id_ref'];
																								$attr['setup']['values'][$i]['name'] = stripslashes($row['name']);
																								++$i;
																								$rs->movenext();
																				}
																} else
																{
																				$ds_id = $attr['setup']['datasource'];
																				$attr['setup']['values'] = $this->getdatasourcevalues($ds_id);
																}
								}
								return $attr;
				}
				function getcontroltype($control_type)
				{
								switch ($control_type)
								{
												case "checkbox":
																$type = "Checkbox";
																break;
												case "text":
																$type = "Text";
																break;
												case "select":
																$type = "Select";
																break;
												case "textarea":
																$type = "Textarea";
																break;
												case "date":
																$type = "Date";
								}
								return $type;
				}
				function getsectionattributes($id_section, &$total_count, $id_form = "")
				{
								$filter_str = "";
								if ($id_form != "")
								{
												$form_attrs = $this->getformattributes($id_form);
												if (0 < count($form_attrs))
												{
																$filter_str = " AND ( ";
																$len = count($form_attrs);
																$i = 0;
																for (; $i < $len; ++$i)
																{
																				$filter_str .= "a.id!=" . $form_attrs[$i]['id'];
																				if ($i != $len - 1)
																				{
																								$filter_str .= " AND ";
																				}
																}
																$filter_str .= ")";
												}
								}
								$strSQL = "SELECT COUNT(*) as count FROM " . SECTION_ATTRS_TABLE . " a\n\t\t\t\tWHERE a.id_section=" . $id_section;
								$rs = $this->dbconn->execute($strSQL);
								$total_count = $rs->fields[0];
								$strSQL = "SELECT a.id FROM " . SECTION_ATTRS_TABLE . " a\n\t\t\t\tWHERE a.id_section=" . $id_section . $filter_str;
								$rs = $this->dbconn->execute($strSQL);
								$attrs = array();
								$i = 0;
								while (!$rs->EOF)
								{
												$row = $rs->getrowassoc(false);
												$attrs[$i] = $this->getsectionattribute($row['id']);
												++$i;
												$rs->movenext();
								}
								return $attrs;
				}
				function getallattributes(&$total_count, $filter_str = "", $order_by = "")
				{
								$strSQL = "";
								if ($filter_str != "")
								{
												$filter_str = " WHERE " . $filter_str;
								}
								if ($order_by == "")
								{
												$order_by = "ORDER BY a.id";
								}
								$strSQL = "SELECT COUNT(*) as count FROM " . SECTION_ATTRS_TABLE . " a " . $filter_str . $order_by;
								$rs = $this->dbconn->execute($strSQL);
								$total_count = $rs->fields[0];
								$strSQL = "SELECT a.id FROM " . SECTION_ATTRS_TABLE . " a " . $filter_str . $order_by;
								$rs = $this->dbconn->execute($strSQL);
								$attrs = array();
								$i = 0;
								while (!$rs->EOF)
								{
												$row = $rs->getrowassoc(false);
												$attrs[$i] = $this->getsectionattribute($row['id']);
												++$i;
												$rs->movenext();
								}
								return $attrs;
				}
				function addnewsection($section_data)
				{
								$new_sec_id = 0;
								$strSQL = "INSERT INTO " . SECTIONS_TABLE . "(name) VALUES('" . addslashes($section_data['name']) . "')";
								$this->dbconn->execute($strSQL);
								$new_sec_id = $this->dbconn->insert_id();
								return $new_sec_id;
				}
				function delsection($id_section)
				{
								if ($this->checkifsectionisconst($id_section))
								{
												return false;
								}
								$total_count = 0;
								$attrs = $this->getsectionattributes($id_section, $total_count);
								foreach ($attrs as $attr)
								{
												$this->delsectionattribute($attr['id']);
								}
								$strSQL = "DELETE FROM " . SECTIONS_TABLE . " WHERE id=" . $id_section;
								$this->dbconn->execute($strSQL);
								return true;
				}
				function addsectionattribute($id_section, $attr_data)
				{
								$strSQL = "INSERT INTO " . SECTION_ATTRS_TABLE . "(name, id_section, mandatory, control_type) VALUES('" . addslashes($attr_data['field_name']) . "', " . $id_section . ", '" . $attr_data['mandatory'] . "', '" . $attr_data['control_type'] . "')";
								$this->dbconn->execute($strSQL);
								$new_id = $this->dbconn->insert_id();
								switch ($attr_data['control_type'])
								{
												case "text":
												case "textarea":
																$def_value = $attr_data['setup']['def_value'];
																$strSQL = "INSERT INTO " . REFERENCE_SPR . "(table_key, id_reference, name) VALUES(" . VALUES_KEY . ", " . $new_id . ", '" . addslashes($def_value) . "')";
																$this->dbconn->execute($strSQL);
																$attr_data['setup']['def_value'] = $new_id;
																break;
												case "select":
																if ($attr_data['setup']['datasource'] == -1)
																{
																				$values = $attr_data['setup']['values'];
																				$temp = array();
																				foreach ($values as $value)
																				{
																								$strSQL = "INSERT INTO " . REFERENCE_SPR . "(table_key, id_reference, name) VALUES(" . ($new_id + 1) . ", " . $value['id'] . ", '" . addslashes($value['name']) . "')";
																								$this->dbconn->execute($strSQL);
																				}
																}
																unset($values['values']);
								}
								$strSQL = "UPDATE " . SECTION_ATTRS_TABLE . " SET control_setup='" . addslashes(serialize($attr_data['setup'])) . "' WHERE id=" . $new_id;
								$this->dbconn->execute($strSQL);
								return $new_id;
				}
				function updatesectionattribute($id_attr, $attr_data)
				{
								$strSQL = "SELECT control_type FROM " . SECTION_ATTRS_TABLE . " WHERE id=" . $id_attr;
								$rs = $this->dbconn->execute($strSQL);
								$last_type = $rs->fields[0];
								$strSQL = "UPDATE " . SECTION_ATTRS_TABLE . " SET name='" . addslashes($attr_data['field_name']) . "', mandatory='" . $attr_data['mandatory'] . "', control_type='" . $attr_data['control_type'] . "' WHERE id=" . $id_attr;
								$this->dbconn->execute($strSQL);
								switch ($attr_data['control_type'])
								{
												case "text":
												case "textarea":
																$def_value = $attr_data['setup']['def_value'];
																if ($last_type == "select")
																{
																				$strSQL = "DELETE FROM " . REFERENCE_SPR . " WHERE table_key=" . ($id_attr + 1);
																				$this->dbconn->execute($strSQL);
																				$strSQL = "INSERT INTO " . REFERENCE_SPR . "(table_key, id_reference, name) VALUES(" . VALUES_KEY . ", " . $id_attr . ", '" . addslashes($def_value) . "')";
																} else
																{
																				$strSQL = "UPDATE " . REFERENCE_SPR . " SET name='" . addslashes($def_value) . "' WHERE table_key=" . VALUES_KEY . " AND id_reference=" . $id_attr;
																}
																$this->dbconn->execute($strSQL);
																break;
												case "select":
																if ($last_type != "select")
																{
																				$strSQL = "DELETE FROM " . REFERENCE_SPR . " WHERE table_key=" . VALUES_KEY . " AND id_reference=" . $id_attr;
																				$this->dbconn->execute($strSQL);
																} else
																{
																				$strSQL = "DELETE FROM " . REFERENCE_SPR . " WHERE table_key=" . ($id_attr + 1);
																				$this->dbconn->execute($strSQL);
																}
																if ($attr_data['setup']['datasource'] == -1)
																{
																				$values = $attr_data['setup']['values'];
																				$temp = array();
																				foreach ($values as $value)
																				{
																								$strSQL = "INSERT INTO " . REFERENCE_SPR . "(table_key, id_reference, name) VALUES(" . ($id_attr + 1) . ", " . $value['id'] . ", '" . addslashes($value['name']) . "')";
																								$this->dbconn->execute($strSQL);
																				}
																}
																unset($values['values']);
								}
								$strSQL = "UPDATE " . SECTION_ATTRS_TABLE . " SET control_setup='" . addslashes(serialize($attr_data['setup'])) . "' WHERE id=" . $id_attr;
								$this->dbconn->execute($strSQL);
								return true;
				}
				function delsectionattribute($id_attr)
				{
								if ($this->checkifattrisconst($id_attr))
								{
												return false;
								}
								$attr_data = $this->getsectionattribute($id_attr);
								switch ($attr_data['control_type'])
								{
												case "text":
												case "textarea":
																$strSQL = "DELETE FROM " . REFERENCE_SPR . " WHERE table_key=" . VALUES_KEY . " AND id_reference=" . $id_attr;
																break;
												case "select":
																$strSQL = "DELETE FROM " . REFERENCE_SPR . " WHERE table_key=" . ($id_attr + 1);
								}
								$this->dbconn->execute($strSQL);
								$strSQL = "DELETE FROM " . SECTION_ATTRS_TABLE . " WHERE id=" . $id_attr;
								$this->dbconn->execute($strSQL);
								$strSQL = "DELETE FROM " . FORMS_TABLE . " WHERE id_attribute=" . $id_attr;
								$this->dbconn->execute($strSQL);
								return true;
				}
				function getregexps()
				{
								$strSQL = "SELECT id, name, reg_exp FROM " . REG_EXPS_TABLE;
								$rs = $this->dbconn->execute($strSQL);
								$regs = array();
								$i = 0;
								while (!$rs->EOF)
								{
												$row = $rs->getrowassoc(false);
												$id_reg = $row['id'];
												$regs[$id_reg]['id'] = $row['id'];
												$regs[$id_reg]['name'] = $row['name'];
												$regs[$id_reg]['reg_exp'] = $row['reg_exp'];
												++$i;
												$rs->movenext();
								}
								return $regs;
				}
				function addnewregexp($regexp_data)
				{
								$strSQL = "INSERT INTO " . REG_EXPS_TABLE . "(name, reg_exp) VALUES('" . addslashes($regexp_data['name']) . "', '" . addslashes($regexp_data['reg_exp']) . "')";
								$this->dbconn->execute($strSQL);
								$new_id = $this->dbconn->insert_id();
								return $new_id;
				}
				function delregexp($regexp_id)
				{
								$strSQL = "DELETE FROM " . REG_EXPS_TABLE . " WHERE id=" . $regexp_id;
								$this->dbconn->execute($strSQL);
				}
				function updateregexps($regs)
				{
								foreach ($regs as $reg_exp)
								{
												$strSQL = "UPDATE " . REG_EXPS_TABLE . " SET reg_exp='" . addslashes($reg_exp['reg_exp']) . "' WHERE id=" . $reg_exp['id'];
												$this->dbconn->execute($strSQL);
								}
				}
				function checkifsectionisconst($id_section)
				{
								$strSQL = "SELECT is_const FROM " . SECTIONS_TABLE . " WHERE id=" . $id_section;
								$rs = $this->dbconn->execute($strSQL);
								$is_const = $rs->fields[0] == "Y" ? true : false;
								return $is_const;
				}
				function checkifattrisconst($id_attr)
				{
								$strSQL = "SELECT is_const FROM " . SECTION_ATTRS_TABLE . " WHERE id=" . $id_attr;
								$rs = $this->dbconn->execute($strSQL);
								$is_const = $rs->fields[0] == "Y" ? true : false;
								return $is_const;
				}
				function getusersectiondata($id_user, $id_section, $convert_to_str = false)
				{
								$strSQL = "SELECT a.id, b.value FROM " . SECTION_ATTRS_TABLE . " a\n\t\t\tLEFT JOIN " . USER_ATTR_TABLE . " b ON a.id=b.id_attr\n\t\t\tWHERE a.id_section=" . $id_section . " AND b.id_user=" . $id_user;
								$rs = $this->dbconn->execute($strSQL);
								$user_attrs = array();
								while (!$rs->EOF)
								{
												$row = $rs->getrowassoc(false);
												$id_attr = $row['id'];
												$user_attrs[$id_attr]['id_attr'] = $row['id'];
												$user_attrs[$id_attr]['value'] = $this->getuserattribute($id_user, $id_attr, $convert_to_str);
												$rs->movenext();
								}
								return $user_attrs;
				}
				function getuserattribute($id_user, $id_attr, $convert_to_str = false)
				{
								$strSQL = "SELECT a.id, a.control_type, a.control_setup, b.value FROM " . SECTION_ATTRS_TABLE . " a\n\t\t\tLEFT JOIN " . USER_ATTR_TABLE . " b ON a.id=b.id_attr\n\t\t\tWHERE a.id=" . $id_attr . " AND b.id_user=" . $id_user;
								$rs = $this->dbconn->execute($strSQL);
								if ($rs->rowcount() == 0)
								{
												return false;
								}
								$user_attr = array();
								$row = $rs->getrowassoc(false);
								$setup = unserialize($row['control_setup']);
								switch ($row['control_type'])
								{
												case "checkbox":
												case "text":
												case "textarea":
																$temp = $row['value'];
																break;
												case "select":
																if (strpos($row['value'], ","))
																{
																				$temp = explode(",", $row['value']);
																}
																if (!is_array($temp))
																{
																				$temp = array();
																				$temp[0] = $row['value'];
																}
																if (!is_array($temp))
																{
																				break;
																}
																foreach ($temp as $index => $id_ref)
																{
																				if ($convert_to_str)
																				{
																								if ($setup['datasource'] == -1)
																								{
																												$strSQL = "SELECT name FROM " . REFERENCE_SPR . " WHERE table_key=" . ($id_attr + 1) . " AND id_reference=" . $id_ref;
																								} else
																								{
																												$datasource = $this->ds[$setup['datasource']];
																												$strSQL = "SELECT " . $datasource['col_name'] . " as name FROM " . $datasource['table'] . " WHERE " . $datasource['col_id'] . "=" . $id_ref;
																								}
																								$rs = $this->dbconn->execute($strSQL);
																								$res[$id_ref] = $rs->fields[0];
																				} else
																				{
																								$res[$id_ref] = $id_ref;
																				}
																}
																if ($convert_to_str)
																{
																				$res = implode(", ", $res);
																}
																$temp = $res;
																break;
												case "date":
																$temp = unserialize($row['value']);
																if (!$convert_to_str)
																{
																				break;
																}
																$temp = $temp['month'] . "-" . $temp['day'] . "-" . $temp['year'];
								}
								$value = $temp;
								return $value;
				}
				function getalluserdata($id_user, $convert_to_str = false)
				{
								$strSQL = "SELECT id_attr FROM " . USER_ATTR_TABLE . " WHERE id_user=" . $id_user;
								$rs = $this->dbconn->execute($strSQL);
								while (!$rs->EOF)
								{
												$row = $rs->getrowassoc(false);
												$id_attr = $row['id_attr'];
												$user_attrs[$id_attr]['id_attr'] = $id_attr;
												$user_attrs[$id_attr]['value'] = $this->getuserattribute($id_user, $id_attr, $convert_to_str);
												$rs->movenext();
								}
								return $user_attrs;
				}
				function saveuserattribute($id_user, $id_attr, $new_value)
				{
								$attr = $this->getsectionattribute($id_attr);
								$exist = false;
								$strSQL = "SELECT value FROM " . USER_ATTR_TABLE . " WHERE id_user=" . $id_user . " AND id_attr=" . $id_attr;
								$rs = $this->dbconn->execute($strSQL);
								if (0 < $rs->rowcount())
								{
												$exist = true;
								}
								switch ($attr['control_type'])
								{
												case "checkbox":
												case "text":
												case "textarea":
																if ($exist)
																{
																				$strSQL = "UPDATE " . USER_ATTR_TABLE . " SET value='" . addslashes($new_value) . "' WHERE id_user=" . $id_user . " AND id_attr=" . $id_attr;
																} else
																{
																				$strSQL = "INSERT INTO " . USER_ATTR_TABLE . "(id_user, id_attr, value) VALUES(" . $id_user . ", " . $id_attr . ", '" . addslashes($new_value) . "')";
																}
																break;
												case "select":
																if (is_array($new_value))
																{
																				$new_value = implode(",", $new_value);
																}
																if ($exist)
																{
																				$strSQL = "UPDATE " . USER_ATTR_TABLE . " SET value='" . addslashes($new_value) . "' WHERE id_user=" . $id_user . " AND id_attr=" . $id_attr;
																} else
																{
																				$strSQL = "INSERT INTO " . USER_ATTR_TABLE . "(id_user, id_attr, value) VALUES(" . $id_user . ", " . $id_attr . ", '" . addslashes($new_value) . "')";
																}
																break;
												case "date":
																$str_arr = serialize($new_value);
																if ($exist)
																{
																				$strSQL = "UPDATE " . USER_ATTR_TABLE . " SET value='" . addslashes($str_arr) . "' WHERE id_user=" . $id_user . " AND id_attr=" . $id_attr;
																} else
																{
																				$strSQL = "INSERT INTO " . USER_ATTR_TABLE . "(id_user, id_attr, value) VALUES(" . $id_user . ", " . $id_attr . ", '" . addslashes($str_arr) . "')";
																}
								}
								$this->dbconn->execute($strSQL);
				}
				function saveuserattributes($id_user, $attrs)
				{
								foreach ($attrs as $id_attr => $value)
								{
												$this->saveuserattribute($id_user, $id_attr, $value);
								}
								return "";
				}
				function deluserattributes($id_user)
				{
								$strSQL = "DELETE FROM " . USER_ATTR_TABLE . " WHERE id_user=" . $id_user;
								$this->dbconn->execute($strSQL);
				}
				function attrsearch($id_attr, $value, $id_user = "")
				{
								$strSQL = "SELECT a.id_user FROM " . USER_ATTR_TABLE . " a WHERE a.id_attr=" . $id_attr . " AND a.value='" . $value . "'";
								if ($id_user != "")
								{
												$strSQL .= " AND a.id_user=" . $id_user;
								}
								$rs = $this->dbconn->execute($strSQL);
								if ($rs->rowcount() == 0)
								{
												return false;
								}
								$users = array();
								$i = 0;
								while (!$rs->EOF)
								{
												$users[] = $rs->fields[0];
												$rs->movenext();
								}
								return $users;
				}
				function todate($id_user, $id_date_attr)
				{
								$value = $this->getuserattribute($id_user);
								$date = $value['year'] . "-" . $value['month'] . "-" . $value['day'];
								return $date;
				}
}
define("FIELD_COMPANY", 1);
define("FIELD_MAILLIST", 2);
define("VALUES_KEY", 1);
?>
