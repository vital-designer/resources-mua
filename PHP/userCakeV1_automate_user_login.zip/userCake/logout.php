<?php
/*
	Copyright UserCake
	http://usercake.com
	
	Developed by: Adam Davis
*/
	include("models/config.php");
	
	//Log the user out
	if(isUserLoggedIn()) userLogOut();

	include("models/clean_up.php");

	header('Location:'.$websiteUrl);
	die;
?>


