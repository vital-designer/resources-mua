<?php
include ("../common.php");
include ("../include/newsletters_function.php");
$section = "newsletters";
$right_name = "view";
check_right($section, $right_name);
if (isset($_POST['action']) && $_POST['action'] == "schedule")
{
				if (!preg_match("|([0-9]{4})[-/\\.]?([0-9]{1,2})[-/\\.]?([0-9]{1,2})|", $_POST['date_send']))
				{
								$date_send = "";
				}
				else
				{
								$date_send = $_POST['date_send'];
				}
				if (isset($_POST['repeat']) && intval($_POST['repeat']) == 1)
				{
								$int = intval($_POST['int']);
								$interval = stripslashes(trim($_POST['interval']));
								$res = $dbconn->execute("update creleases set repeat='" . $int . " " . $interval . "' where id='" . $_POST['Newsletter'] . "'");
				}
				$res = $dbconn->execute("update creleases set date_send='" . $date_send . "', date_last_send=NULL where id='" . $_POST['Newsletter'] . "'");
}
else
				if (isset($_POST['del']))
				{
								foreach ($GLOBALS['_POST']['del'] as $val)
								{
												delrelease($val);
								}
				}
if (isset($_GET['did']) && !empty($_GET['did']))
{
				delrelease($_GET['did']);
}
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "subject";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
}
else
{
				$order = "";
}
if (isset($_REQUEST['newsletter_page']))
{
				$newsletter_page = $_REQUEST['newsletter_page'];
}
else
{
				$newsletter_page = 0;
}
$res = $dbconn->execute("select id, subject, date, format from creleases where date_send is NULL and is_sent='0'");
while (!$res->EOF)
{
				$values[] = stripslashes($res->fields[0]);
				$output[] = stripslashes($res->fields[1]) . " (" . $res->fields[3] . " - " . $res->fields[2] . ")";
				$res->movenext();
}
$smarty->assign(array("newsletters_values" => $values, "newsletters_output" => $output));
$values = array();
$output = array();
$res = $dbconn->execute("select id, subject, date, format from creleases where is_sent='1'");
while (!$res->EOF)
{
				$values[] = stripslashes($res->fields[0]);
				$output[] = stripslashes($res->fields[1]) . " (" . $res->fields[3] . " - " . $res->fields[2] . ")";
				$res->movenext();
}
$smarty->assign(array("newsletters_sent_values" => $values, "newsletters_sent_output" => $output));
$GLOBALS['_SESSION']['return_url'] = "schedule.php";
$int = array(1, 2, 3, 4, 5, 6);
$interval = array("day", "week ", "month ", "year");
$smarty->assign("int", $int);
$smarty->assign("interval", $interval);
$smarty->assign("display", "none");
$smarty->assign("razdel", "Newsletters");
$smarty->assign("description", "Monitoring of deliver letter schedule ");
$smarty->assign("hint", "A list of the letters delivered according to a certain schedule is reflected here. You can add new letters to the schedule, remove existing ones and manage letters as shown in the field \"Manage Newsletters\".");
$smarty->assign("order", $order);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("rel", getreleasesschedule($order, $newsletter_page));
$smarty->assign("newsletter_page", $newsletter_page);
$smarty->display("{$admin_nl_gentemplates}/newsletters_schedule.tpl");
?>