<?php
$upload_services[]="megashares.com";
$max_file_size["megashares.com"]=1500;
$page_upload["megashares.com"] = "megashares.com.php";

$megashares_login=""; // <- �����/Login
$megashares_pass=""; // <- ������/Password
?>