UPDATE settings set admin_login='[admin_login]', admin_password='[admin_passw]', from_name='[company_name]', from_email='[admin_email]', test_email='[admin_email]';
UPDATE smtp_server set host='[smtp_host]';
