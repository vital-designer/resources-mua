<?php
function getgroups($orderby = "", $group_page = 0)
{
				global $dbconn;
				global $smarty;
				global $config;
				if (isset($_GET['p']) && 0 < $_GET['p'])
				{
								$p = $_GET['p'];
				} else
				{
								$p = 0;
				}
				$end = $_SESSION['is_desc'] && !$_GET['is_nav'] || !$_SESSION['is_desc'] && $_GET['is_nav'] ? " desc " : "";
				if ($orderby)
				{
								$is_nav = isset($_GET['is_nav']) ? $_GET['is_nav'] : false;
								if (!$is_nav && $orderby == $_SESSION['order'])
								{
												if ($_SESSION['is_desc'])
												{
																$GLOBALS['_SESSION']['is_desc'] = false;
																$end = " desc ";
												} else
												{
																$GLOBALS['_SESSION']['is_desc'] = true;
																$end = "";
												}
								}
								$sql .= " order by " . $orderby . $end;
				} else
				{
								$sql .= " order by name";
				}
				$smarty->assign("end", trim($end));
				$res = $dbconn->execute("select count(group_id) from groups");
				$amount = $res->fields[0];
				$smarty->assign("navigation", create_navigation($amount, $group_page, "group_page={$group_page}&order=" . $_GET['order'] . "&is_nav=true", "index.php", $p, "group_page"));
				get_smarty_array_list("group_page", $config['group_page']);
				$per_page = $config['group_page'][$group_page];
				$res = $dbconn->pageexecute("select * from groups " . $sql, $per_page, $p + 1);
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$releases[$c]['id'] = $res->fields[0];
								$releases[$c]['name'] = stripslashes($res->fields[1]);
								$res2 = $dbconn->execute("select count(*) from administrator where group_id='" . $res->fields[0] . "'");
								$releases[$c]['count'] = $res2->fields[0];
								++$c;
								$res->movenext();
				}
				$smarty->assign("amount", $amount);
				return $releases;
}
function delgroup($id)
{
				global $dbconn;
				$res = $dbconn->execute("update administrator set group_id='0' where group_id='" . $id . "'");
				$res = $dbconn->execute("delete from groups where group_id='" . $id . "'");
				$res = $dbconn->execute("delete from group_right where group_id='" . $id . "'");
}
function addgroup()
{
				global $dbconn;
				$name = str_prepare($_POST['name']);
				$description = str_prepare($_POST['description']);
				$res = $dbconn->execute("insert into groups (name, description) values ('" . $name . "', '" . $description . "')");
				$gid = $dbconn->_insertid();
				foreach ($GLOBALS['_POST']['Right'] as $section => $right)
				{
								foreach ($right as $r => $val)
								{
												if (0 < $val)
												{
																$res = $dbconn->execute("insert into group_right (group_id, section_id, right_id) \r\n\t\t\tvalues ('" . $gid . "', '" . $section . "','" . $r . "')");
												}
								}
				}
				return $gid;
}
function updgroup()
{
				global $dbconn;
				$id = $_GET['id'];
				$name = str_prepare($_POST['name']);
				$description = str_prepare($_POST['description']);
				$res = $dbconn->execute("update groups set \r\n  \t\t\t\t\t\tname='" . $name . "', \r\n\t\t\t\t\t\tdescription='" . $description . "'\r\n\t\t\t\t\t\twhere group_id='" . $id . "'");
				$res = $dbconn->execute("delete from group_right where group_id='" . $id . "'");
				foreach ($GLOBALS['_POST']['Right'] as $section => $right)
				{
								foreach ($right as $r => $val)
								{
												if (0 < $val)
												{
																$res = $dbconn->execute("insert into group_right (group_id, section_id, right_id) \r\n\t\t\tvalues ('" . $id . "', '" . $section . "','" . $r . "')");
												}
								}
				}
}
function getcontent($id)
{
				global $dbconn;
				$res = $dbconn->execute("select * from groups where group_id='" . $id . "'");
				$releases = array();
				$releases['id'] = $res->fields[0];
				$releases['name'] = stripslashes($res->fields[1]);
				$releases['description'] = stripslashes($res->fields[2]);
				$res = $dbconn->execute("select * from group_right where group_id='" . $id . "'");
				$i = 0;
				while (!$res->EOF)
				{
								$row = $res->getrowassoc(false);
								$releases[$i]['section'] = intval($row['section_id']);
								$releases[$i]['right'] = $row['right_id'];
								++$i;
								$res->movenext();
				}
				return $releases;
}
function getblankcontent()
{
				$releases = array(-1);
				return $releases;
}
function getadmins($orderby = "", $admin_page = 0)
{
				global $dbconn;
				global $smarty;
				global $config;
				if (isset($_GET['p']) && 0 < $_GET['p'])
				{
								$p = $_GET['p'];
				} else
				{
								$p = 0;
				}
				$end = $_SESSION['is_desc'] && !$_GET['is_nav'] || !$_SESSION['is_desc'] && $_GET['is_nav'] ? " desc " : "";
				if ($orderby)
				{
								$is_nav = isset($_GET['is_nav']) ? $_GET['is_nav'] : false;
								if (!$is_nav && $orderby == $_SESSION['order'])
								{
												if ($_SESSION['is_desc'])
												{
																$GLOBALS['_SESSION']['is_desc'] = false;
																$end = " desc ";
												} else
												{
																$GLOBALS['_SESSION']['is_desc'] = true;
																$end = "";
												}
								}
								$sql .= " order by " . $orderby . $end;
				} else
				{
								$sql .= " order by name";
				}
				$smarty->assign("end", trim($end));
				$res = $dbconn->execute("select count(admin_id) from administrator");
				$amount = $res->fields[0];
				$smarty->assign("navigation", create_navigation($amount, $admin_page, "admin_page={$admin_page}&order=" . $_GET['order'] . "&is_nav=true", "index.php", $p, "admin_page"));
				get_smarty_array_list("admin_page", $config['admin_page']);
				$per_page = $config['admin_page'][$admin_page];
				$res = $dbconn->pageexecute("select a.*, g.name as group_name from administrator a LEFT JOIN groups g ON a.group_id=g.group_id " . $sql, $per_page, $p + 1);
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$row = $res->getrowassoc(false);
								$releases[$c]['id'] = $row['admin_id'];
								$releases[$c]['group'] = stripslashes($row['group_name']);
								$releases[$c]['group_id'] = $row['group_id'];
								$releases[$c]['name'] = stripslashes($row['name']);
								$releases[$c]['date'] = $row['date'];
								$releases[$c]['date_last'] = $row['date_last'];
								$releases[$c]['status'] = $row['status'] ? "Active" : "Inactive";
								$releases[$c]['status_id'] = intval($row['status']);
								++$c;
								$res->movenext();
				}
				$smarty->assign("amount", $amount);
				return $releases;
}
function addadmin()
{
				global $dbconn;
				$name = str_prepare($_POST['name']);
				$login = str_prepare($_POST['login']);
				$password = str_prepare($_POST['password']);
				$res = $dbconn->execute("insert into administrator (group_id, name,  date_last, status, date, login, password) \r\n  \tvalues ('" . $_POST['group'] . "', '" . $name . "', NULL, '" . $_POST['status'] . "',NOW(), '" . $login . "','" . $password . "')");
				$aid = $dbconn->_insertid();
				return $aid;
}
function updadmin()
{
				global $dbconn;
				$id = $_GET['id'];
				$name = str_prepare($_POST['name']);
				$login = str_prepare($_POST['login']);
				$password = str_prepare($_POST['password']);
				$res = $dbconn->execute("update administrator set \r\n  \t\t\t\t\t\tgroup_id='" . $_POST['group'] . "',\r\n\t\t\t\t\t\tname='" . $name . "', \r\n\t\t\t\t\t\tstatus='" . $_POST['status'] . "',\r\n\t\t\t\t\t\tlogin = '" . $login . "',\r\n\t\t\t\t\t\tpassword = '" . $password . "'\t\t\t\t\t\t \r\n\t\t\t\t\t\twhere admin_id='" . $id . "'");
}
function getadmincontent($id)
{
				global $dbconn;
				$releases = array();
				$res = $dbconn->execute("select * from administrator where admin_id='" . $id . "'");
				$row = $res->getrowassoc(false);
				$releases['id'] = $row['admin_id'];
				$releases['name'] = stripslashes($row['name']);
				$releases['group_id'] = $row['group_id'];
				$releases['status'] = $row['status'];
				$releases['login'] = $row['login'];
				$releases['password'] = $row['password'];
				return $releases;
}
function deladmin($id)
{
				global $dbconn;
				$res = $dbconn->execute("delete from administrator where admin_id='" . $id . "'");
}
?>
