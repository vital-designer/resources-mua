Rapidleech v42 pre-release [t2]

This is the second trial (t2) of a testing release of Rapidleech v42. If we need to, we might release another updated pre-release (t3) and so on, until we reach a stable enough revision which can be released officially.

If you downloaded this file you can test it out and please report back on the forum (http://www.rapidleech.com/index.php) and the bugtracker (http://bugs.rapidleech.com) so we can clean up any errors before the official release of v42.

There is no log for this Pre-Release at this stage - please see SVN logs for update infos - http://rapidleech.googlecode.com