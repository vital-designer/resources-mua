<?php
class simplexmlparser
{
				var $root;
				var $parser;
				var $data;
				var $vals;
				var $index;
				var $charset = "ISO-8859-1";
				function simplexmlparser($fileName = "", $data = "", $charset = "")
				{
								if ($data == "")
								{
												if (!file_exists($fileName))
												{
																$this->_raiseerror("Can't open file " . $fileName);
												}
												$this->data = implode("", file($fileName));
								} else
								{
												$this->data = $data;
								}
								$this->data = eregi_replace(">[[:space:]]+<", "><", $this->data);
								$this->charset = $charset != "" ? $charset : $this->charset;
								$this->_parsefile();
				}
				function getroot()
				{
								return $this->root;
				}
				function _parsefile()
				{
								$this->parser = xml_parser_create($this->charset);
								xml_parser_set_option($this->parser, XML_OPTION_TARGET_ENCODING, $this->charset);
								xml_parser_set_option($this->parser, XML_OPTION_SKIP_WHITE, 1);
								xml_parser_set_option($this->parser, XML_OPTION_CASE_FOLDING, 0);
								if (!xml_parse_into_struct($this->parser, $this->data, $this->vals, $this->index))
								{
												$this->_raiseerror("Error while parsing XML File: " . xml_error_string(xml_get_error_code($this->parser)) . " at line " . xml_get_current_line_number($this->parser));
								}
								xml_parser_free($this->parser);
								$this->_buildroot(0);
				}
				function _buildroot()
				{
								$i = 0;
								$this->root = new xmlnode($this->vals[$i]['tag'], isset($this->vals[$i]['attributes']) ? $this->vals[$i]['attributes'] : null, $this->_getchildren($this->vals, $i), isset($this->vals[$i]['value']) ? $this->vals[$i]['value'] : null);
				}
				function _getchildren($vals, &$i)
				{
								$children = array();
								while (++$i < sizeof($vals))
								{
												switch ($vals[$i]['type'])
												{
																case "cdata":
																				array_push($children, $vals[$i]['value']);
																				break;
																case "complete":
																				array_push($children, new xmlnode($vals[$i]['tag'], isset($vals[$i]['attributes']) ? $vals[$i]['attributes'] : null, null, isset($vals[$i]['value']) ? $vals[$i]['value'] : null));
																				break;
																case "open":
																				array_push($children, new xmlnode($vals[$i]['tag'], isset($vals[$i]['attributes']) ? $vals[$i]['attributes'] : null, $this->_getchildren($vals, $i), isset($vals[$i]['value']) ? $vals[$i]['value'] : null));
																				break;
																case "close":
																				return $children;
												}
								}
				}
				function _raiseerror($errorMsg)
				{
								trigger_error($errorMsg, E_USER_ERROR);
				}
}
class xmlnode
{
				var $tag;
				var $attrs;
				var $children;
				var $childrenCount;
				var $value;
				function xmlnode($nodeTag, $nodeAttrs, $nodeChildren = null, $nodeValue = null)
				{
								$this->tag = $nodeTag;
								$this->attrs = $nodeAttrs;
								$this->children = $nodeChildren;
								$this->childrenCount = is_array($nodeChildren) ? count($nodeChildren) : 0;
								$this->value = $nodeValue;
				}
				function haschildren()
				{
								return 0 < $this->childrenCount;
				}
				function getchildrencount()
				{
								return $this->childrenCount;
				}
				function &getchildren($index)
				{
								return isset($this->children[$index]) ? $this->children[$index] : false;
				}
				function getchildrentagsarray()
				{
								if (!$this->children)
								{
												return false;
								} else
								{
												$childrenArr = array();
												foreach ($this->children as $children)
												{
																$childrenArr[$children->tag] = $children;
												}
												return $childrenArr;
								}
				}
}
?>
