<?php
$upload_services[] = "badongo.com_FreeUser";
$max_file_size["badongo.com_FreeUser"] = 1000;
$page_upload["badongo.com_FreeUser"] = "badongo.com_FreeUser.php";  
?>