﻿using Telerik.Cms.Web.UI;

namespace Samples.Books.WebControls
{
    /// <summary>
    /// Represents a book edit view
    /// </summary>
    public class BookEditView : ViewModeControl<BooksControlPanel>
    {
        // not implemented
    }
}
