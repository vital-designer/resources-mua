<?php
$upload_services[]="storage.to";
$max_file_size["storage.to"]=1024;
$page_upload["storage.to"] = "storage.to.php";  
?>