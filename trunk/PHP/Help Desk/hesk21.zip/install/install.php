<?php
/*******************************************************************************
*  Title: Help Desk Software HESK
*  Version: 2.1 from 7th August 2009
*  Author: Klemen Stirn
*  Website: http://www.hesk.com
********************************************************************************
*  COPYRIGHT AND TRADEMARK NOTICE
*  Copyright 2005-2009 Klemen Stirn. All Rights Reserved.
*  HESK is a trademark of Klemen Stirn.

*  The HESK may be used and modified free of charge by anyone
*  AS LONG AS COPYRIGHT NOTICES AND ALL THE COMMENTS REMAIN INTACT.
*  By using this code you agree to indemnify Klemen Stirn from any
*  liability that might arise from it's use.

*  Selling the code for this program, in part or full, without prior
*  written consent is expressly forbidden.

*  Using this code, in part or full, to create derivate work,
*  new scripts or products is expressly forbidden. Obtain permission
*  before redistributing this software over the Internet or in
*  any other medium. In all cases copyright and header must remain intact.
*  This Copyright is in full effect in any country that has International
*  Trade Agreements with the United States of America or
*  with the European Union.

*  Removing any of the copyright notices without purchasing a license
*  is expressly forbidden. To remove HESK copyright notice you must purchase
*  a license for this script. For more information on how to obtain
*  a license please visit the page below:
*  https://www.hesk.com/buy.php
*******************************************************************************/

define('IN_SCRIPT',1);
define('INSTALL',1);
define('HESK_NEW_VERSION','2.1');
define('HESK_PATH','../');

/* Get all the required files and functions */
require(HESK_PATH . 'hesk_settings.inc.php');
$hesk_settings['debug_mode'] = 1;
$hesk_settings['language']='English';
$hesk_settings['languages']=array('English' => array('folder'=>'en'));
require(HESK_PATH . 'inc/common.inc.php');
require(HESK_PATH . 'inc/database.inc.php');
hesk_session_start();

/* Check for license agreement */
if (empty($_SESSION['license_agree']))
{
    $agree = !empty($_GET['agree']) ? hesk_input($_GET['agree']) : '';
    if ($agree == 'YES')
    {
        $_SESSION['license_agree']=1;
        $_SESSION['step']=1;
    }
    else
    {
        $_SESSION['step']=0;
    }
}

if (!isset($_SESSION['step']))
{
    $_SESSION['step']=0;
}

/* Test database connection */
if (isset($_POST['dbtest']))
{
    $db_success = 1;
    $hesk_settings['db_host']=hesk_Input($_POST['host']);
    $hesk_settings['db_name']=hesk_Input($_POST['name']);
    $hesk_settings['db_user']=hesk_Input($_POST['user']);
    $hesk_settings['db_pass']=hesk_Input($_POST['pass']);
    $hesk_settings['db_pfix']=hesk_Input($_POST['pfix']);

    /* Connect to database */
    $hesk_db_link = @mysql_connect($hesk_settings['db_host'],$hesk_settings['db_user'], $hesk_settings['db_pass']) or $db_success=0;

    /* Select database works ok? */
    if ($db_success == 1 && !mysql_select_db($hesk_settings['db_name'], $hesk_db_link))
    {
    	/* Try to create the database */
		if (function_exists('mysql_create_db') && mysql_create_db($hesk_settings['db_name'], $hesk_db_link))
        {
        	if (mysql_select_db($hesk_settings['db_name'], $hesk_db_link))
            {
				$db_success = 1;
            }
            else
            {
				$db_success = 2;
            }
        }
        else
        {
        	$db_success = 2;
        }
    }

    if ($db_success == 2)
    {
        hesk_iDatabase(2);
        exit();
    }
    elseif ($db_success == 1)
    {
        /* Check if these MySQL tables already exist, stop if they do */
        $tables_exist=0;
        $sql='SHOW TABLES FROM `'.$hesk_settings['db_name'].'`';
        $result = hesk_dbQuery($sql);

		$hesk_tables = array(
			$hesk_settings['db_pfix'].'attachments',
			$hesk_settings['db_pfix'].'categories',
			$hesk_settings['db_pfix'].'kb_articles',
            $hesk_settings['db_pfix'].'kb_attachments',
			$hesk_settings['db_pfix'].'kb_categories',
			$hesk_settings['db_pfix'].'notes',
			$hesk_settings['db_pfix'].'replies',
			$hesk_settings['db_pfix'].'std_replies',
			$hesk_settings['db_pfix'].'tickets',
			$hesk_settings['db_pfix'].'users'
        );

        while ($row=mysql_fetch_array($result, MYSQL_NUM))
        {
            if (in_array($row[0],$hesk_tables))
            {
                $tables_exist = 1;
                break;
            }
        }
        mysql_free_result($result);

        if ($tables_exist)
        {
            $_SESSION['step']=0;
            $_SESSION['license_agree']=0;
            hesk_iFinish(1);
        }

        /* All ok, save settings and install the tables */
        hesk_iSaveSettings();
        hesk_iTables();

        /* Close database conenction and move to the next step */
        mysql_close($hesk_db_link);
        $_SESSION['step']=3;
    }
    else
    {
        hesk_iDatabase(1);
        exit();
    }

}


switch ($_SESSION['step'])
{
	case 1:
	   hesk_iCheckSetup();
	   break;
	case 2:
	   hesk_iDatabase();
	   break;
	case 3:
	   hesk_iFinish();
	   break;
	default:
	   hesk_iStart();
}

function hesk_iFinish($problem=0) {
    global $hesk_settings;
    hesk_iHeader();
?>

<table border="0" width="100%">
<tr>
<td>INSTALLATION STEPS:<br />
<font color="#008000">1. License agreement</font> -&gt; <font color="#008000">2. Check setup</font> -&gt; <font color="#008000">3. Database settings</font> -&gt; <b>4. Setup database tables</b></td>
</tr>
</table>

	<br />

    <div align="center">
	<table border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="7" height="7"><img src="../img/roundcornerslt.jpg" width="7" height="7" alt="" /></td>
		<td class="roundcornerstop"></td>
		<td><img src="../img/roundcornersrt.jpg" width="7" height="7" alt="" /></td>
	</tr>
	<tr>
		<td class="roundcornersleft">&nbsp;</td>
		<td>

<h3>Setup database tables</h3>

<table>
<tr>
<td>-&gt; Testing database connection...</td>
<td><font color="#008000"><b>SUCCESS</b></td>
</tr>
<tr>
<td>-&gt; Installing database tables...</td>

<?php
if ($problem==1)
{
?>

    <td><font color="#FF0000"><b>ERROR: Database tables already exist!</b></td>
    </tr>
    </table>

    <p style="color:#FF0000;">Hesk database tables with <?php echo $hesk_settings['db_pfix']; ?> prefix already exist in this database. If you are trying
    to upgrade from a previous version please run the installation program again and select
    <b>Update existing install</b> from the installation page. If you are trying to
    install a new copy of Hesk in the same database make sure you change
    table prefix to a unique one.</p>

    <p align="center"><a href="index.php">Click here to continue</a></p>

<?php
}
else
{
?>

    <td><font color="#008000"><b>SUCCESS</b></font></td>
    </tr>
    </table>

    <p>Congratulations, you have successfully completed Hesk database setup!</p>

    <p style="color:#FF0000"><b>Next steps:</b></p>

    <ol>
    <li><font color="#FF0000"><b>IMPORTANT:</b></font> Before doing anything else <b>delete</b> the <b>install</b> folder from your server!
    You can leave this browser window open.<br />&nbsp;</li>
    <li>Setup your help desk from the Administration panel. Login using the default
    username and password:<br /><br />
    Username: <b>Administrator</b><br />
    Password: <b>admin</b><br /><br />

		<form action="<?php echo HESK_PATH; ?>admin/index.php" method="post">
        <input type="hidden" name="a" value="do_login" />
        <input type="hidden" name="remember_user" value="JUSTUSER" />
        <input type="hidden" name="user" value="Administrator" />
        <input type="hidden" name="pass" value="admin" />
		<input type="hidden" name="goto" value="admin_settings.php" />
		<input type="submit" value="Click here to login automatically" class="orangebutton" onmouseover="hesk_btn(this,'orangebuttonover');" onmouseout="hesk_btn(this,'orangebutton');" /></p>
		</form>

    </li>
    </ol>

    <p>&nbsp;</p>

    <p align="center">For further instructions please see the readme.htm file!</p>

<?php
} // End else
?>

		</td>
		<td class="roundcornersright">&nbsp;</td>
	</tr>
	<tr>
		<td><img src="../img/roundcornerslb.jpg" width="7" height="7" alt="" /></td>
		<td class="roundcornersbottom"></td>
		<td width="7" height="7"><img src="../img/roundcornersrb.jpg" width="7" height="7" alt="" /></td>
	</tr>
	</table>
    </div>

<?php
    hesk_iFooter();
    exit();
} // End hesk_iFinish()


function hesk_iTables() {
	global $hesk_settings;
/* This function setups all required MySQL tables */
$sql="CREATE TABLE `".hesk_dbEscape($hesk_settings['db_pfix'])."attachments` (
  `att_id` mediumint(8) unsigned NOT NULL auto_increment,
  `ticket_id` varchar(10) NOT NULL default '',
  `saved_name` varchar(255) NOT NULL default '',
  `real_name` varchar(255) NOT NULL default '',
  `size` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`att_id`),
  KEY `ticket_id` (`ticket_id`)
) ENGINE=MyISAM";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

$sql="CREATE TABLE `".hesk_dbEscape($hesk_settings['db_pfix'])."categories` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(60) NOT NULL default '',
  `cat_order` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

$sql="INSERT INTO `".hesk_dbEscape($hesk_settings['db_pfix'])."categories` VALUES (1, 'Default', 10)";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

$sql="CREATE TABLE `".hesk_dbEscape($hesk_settings['db_pfix'])."kb_articles` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `catid` smallint(5) unsigned NOT NULL,
  `dt` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `author` smallint(5) unsigned NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `rating` float NOT NULL default '0',
  `votes` mediumint(8) unsigned NOT NULL default '0',
  `views` mediumint(8) unsigned NOT NULL default '0',
  `type` enum('0','1','2') NOT NULL default '0',
  `html` enum('0','1') NOT NULL default '0' default '0',
  `art_order` smallint(5) unsigned NOT NULL default '0',
  `history` text NOT NULL,
  `attachments` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`),
  KEY `type` (`type`),
  FULLTEXT KEY `subject` (`subject`,`content`)
) ENGINE=MyISAM";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

$sql="CREATE TABLE `".hesk_dbEscape($hesk_settings['db_pfix'])."kb_attachments` (
  `att_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `saved_name` varchar(255) NOT NULL default '',
  `real_name` varchar(255) NOT NULL default '',
  `size` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY (`att_id`)
) ENGINE=MyISAM";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

$sql="CREATE TABLE `".hesk_dbEscape($hesk_settings['db_pfix'])."kb_categories` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `parent` smallint(5) unsigned NOT NULL,
  `articles` smallint(5) unsigned NOT NULL,
  `cat_order` smallint(5) unsigned NOT NULL,
  `type` enum('0','1') NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

$sql="INSERT INTO `".hesk_dbEscape($hesk_settings['db_pfix'])."kb_categories` VALUES (1, 'Knowledgebase', 0, 0, 10, '0')";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

$sql="CREATE TABLE `".hesk_dbEscape($hesk_settings['db_pfix'])."notes` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `ticket` mediumint(8) unsigned NOT NULL,
  `who` smallint(5) unsigned NOT NULL,
  `dt` datetime NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `ticketid` (`ticket`)
) ENGINE=MyISAM";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

$sql="CREATE TABLE `".hesk_dbEscape($hesk_settings['db_pfix'])."replies` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `replyto` varchar(10) NOT NULL default '',
  `name` varchar(50) NOT NULL default '',
  `message` text NOT NULL,
  `dt` datetime default NULL,
  `attachments` text,
  `staffid` smallint(5) unsigned NOT NULL default '0',
  `rating` enum('1','5') default NULL,
  PRIMARY KEY  (`id`),
  KEY `replyto` (`replyto`)
) ENGINE=MyISAM";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

$sql="CREATE TABLE `".hesk_dbEscape($hesk_settings['db_pfix'])."std_replies` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `message` text NOT NULL,
  `reply_order` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

$sql="CREATE TABLE `".hesk_dbEscape($hesk_settings['db_pfix'])."tickets` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `trackid` varchar(10) NOT NULL default '',
  `name` varchar(50) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `category` smallint(5) unsigned NOT NULL default '1',
  `priority` enum('1','2','3') NOT NULL default '3',
  `subject` varchar(70) NOT NULL default '',
  `message` text NOT NULL,
  `dt` datetime NOT NULL default '0000-00-00 00:00:00',
  `lastchange` datetime NOT NULL default '0000-00-00 00:00:00',
  `ip` varchar(20) NOT NULL default '',
  `status` enum('0','1','2','3') default '1',
  `lastreplier` enum('0','1') NOT NULL default '0',
  `archive` enum('0','1') NOT NULL default '0',
  `attachments` text,
  `custom1` text NOT NULL,
  `custom2` text NOT NULL,
  `custom3` text NOT NULL,
  `custom4` text NOT NULL,
  `custom5` text NOT NULL,
  `custom6` text NOT NULL,
  `custom7` text NOT NULL,
  `custom8` text NOT NULL,
  `custom9` text NOT NULL,
  `custom10` text NOT NULL,
  `custom11` text NOT NULL,
  `custom12` text NOT NULL,
  `custom13` text NOT NULL,
  `custom14` text NOT NULL,
  `custom15` text NOT NULL,
  `custom16` text NOT NULL,
  `custom17` text NOT NULL,
  `custom18` text NOT NULL,
  `custom19` text NOT NULL,
  `custom20` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `trackid` (`trackid`),
  KEY `archive` (`archive`),
  KEY `categories` (`category`),
  KEY `statuses` (`status`)
) ENGINE=MyISAM";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

$sql="CREATE TABLE `".hesk_dbEscape($hesk_settings['db_pfix'])."users` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `user` varchar(20) NOT NULL default '',
  `pass` char(40) NOT NULL,
  `isadmin` enum('0','1') NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `signature` varchar(255) NOT NULL default '',
  `categories` varchar(255) NOT NULL default '',
  `afterreply` enum( '0', '1', '2' ) NOT NULL default '0',
  `notify` enum('0','1') NOT NULL default '1',
  `heskprivileges` varchar(255) NOT NULL default '',
  `ratingneg` mediumint(8) unsigned NOT NULL default '0',
  `ratingpos` mediumint(8) unsigned NOT NULL default '0',
  `rating` float NOT NULL default '0',
  `replies` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

$sql="INSERT INTO `".hesk_dbEscape($hesk_settings['db_pfix'])."users` VALUES (1, 'Administrator', '499d74967b28a841c98bb4baaabaad699ff3c079', '1', 'Your name', 'you@yourwebsite.com', 'Best regards,\r\n\r\nYour name\r\nYour website\r\nhttp://www.yourwebsite.com', '', '0', '1', '', 0, 0, 0, 0);";
$result = hesk_dbQuery($sql) or hesk_error("Couldn't execute SQL: $sql. Please make sure you delete any old installations of Hesk before installing this version!");

} // End hesk_iTables()


function hesk_iSaveSettings() {
    global $hesk_settings, $hesklang;

	$spam_question = hesk_generate_SPAM_question();

    $path = substr($_SERVER["SCRIPT_FILENAME"],0,-11);
	$path = rtrim($path,'\/');
    $path = substr($path,0,-7);
    $path = rtrim($path,'\/');

$settings_file_content='<?php
/* Settings file for Hesk '.HESK_NEW_VERSION.' */
/*** Please read the README.HTML file for more information on these settings ***/

/* General settings */
$hesk_settings[\'site_title\']=\'My Web site\';
$hesk_settings[\'site_url\']=\'http://www.domain.com/\';
$hesk_settings[\'support_mail\']=\'support@domain.com\';
$hesk_settings[\'webmaster_mail\']=\'support@domain.com\';
$hesk_settings[\'noreply_mail\']=\'support@domain.com\';

/* Language settings */
$hesk_settings[\'can_sel_lang\']=0;
$hesk_settings[\'language\']=\'English\';
$hesk_settings[\'languages\']=array(
\'English\' => array(\'folder\'=>\'en\')
);

/* Help desk settings */
$hesk_settings[\'hesk_url\']=\'http://www.domain.com/hesk\';
$hesk_settings[\'hesk_title\']=\'My Help Desk\';
$hesk_settings[\'server_path\']=\''.$path.'\';
$hesk_settings[\'max_listings\']=10;
$hesk_settings[\'print_font_size\']=12;
$hesk_settings[\'debug_mode\']=0;
$hesk_settings[\'secimg_use\']=' . $_SESSION['set_captcha'] . ';
$hesk_settings[\'secimg_sum\']=\'RXJULAMMPT\';
$hesk_settings[\'question_use\']=' . $_SESSION['use_spamq'] . ';
$hesk_settings[\'question_ask\']=\'' . addslashes($spam_question[0]) . '\';
$hesk_settings[\'question_ans\']=\'' . addslashes($spam_question[1]) . '\';
$hesk_settings[\'list_users\']=0;
$hesk_settings[\'autologin\']=1;
$hesk_settings[\'autoclose\']=5;
$hesk_settings[\'custopen\']=1;
$hesk_settings[\'rating\']=1;
$hesk_settings[\'diff_hours\']=0;
$hesk_settings[\'diff_minutes\']=0;
$hesk_settings[\'daylight\']=0;
$hesk_settings[\'timeformat\']=\'Y-m-d H:i:s\';
$hesk_settings[\'alink\']=1;

/* Knowledgebase settings */
$hesk_settings[\'kb_enable\']=1;
$hesk_settings[\'kb_search\']=1;
$hesk_settings[\'kb_search_limit\']=10;
$hesk_settings[\'kb_recommendanswers\']=1;
$hesk_settings[\'kb_rating\']=1;
$hesk_settings[\'kb_substrart\']=200;
$hesk_settings[\'kb_cols\']=2;
$hesk_settings[\'kb_numshow\']=2;
$hesk_settings[\'kb_popart\']=6;
$hesk_settings[\'kb_latest\']=6;
$hesk_settings[\'kb_index_popart\']=3;
$hesk_settings[\'kb_index_latest\']=3;

/* Database settings */
$hesk_settings[\'db_host\']=\'' . $hesk_settings['db_host'] . '\';
$hesk_settings[\'db_name\']=\'' . $hesk_settings['db_name'] . '\';
$hesk_settings[\'db_user\']=\'' . $hesk_settings['db_user'] . '\';
$hesk_settings[\'db_pass\']=\'' . $hesk_settings['db_pass'] . '\';
$hesk_settings[\'db_pfix\']=\'' . $hesk_settings['db_pfix'] . '\';

/* File attachments */
$hesk_settings[\'attachments\']=array (
    \'use\' =>  ' . $_SESSION['set_attachments'] . ',
    \'max_number\'  =>  2,
    \'max_size\'    =>  1024, // kb
    \'allowed_types\'   =>  array(\'.gif\',\'.jpg\',\'.png\',\'.zip\',\'.rar\',\'.csv\',\'.doc\',\'.docx\',\'.txt\',\'.pdf\')
);

/* Custom fields */
$hesk_settings[\'custom_fields\']=array (
\'custom1\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 1\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom2\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 2\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom3\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 3\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom4\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 4\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom5\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 5\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom6\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 6\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom7\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 7\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom8\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 8\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom9\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 9\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom10\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 10\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom11\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 11\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom12\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 12\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom13\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 13\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom14\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 14\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom15\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 15\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom16\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 16\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom17\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 17\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom18\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 18\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom19\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 19\',\'maxlen\'=>255,\'value\'=>\'\'),
\'custom20\'=>array(\'use\'=>0,\'place\'=>0,\'type\'=>\'text\',\'req\'=>0,\'name\'=>\'Custom field 20\',\'maxlen\'=>255,\'value\'=>\'\')
);

#############################
#     DO NOT EDIT BELOW     #
#############################
$hesk_settings[\'hesk_version\']=\''.HESK_NEW_VERSION.'\';
if ($hesk_settings[\'debug_mode\'])
{
    error_reporting(E_ALL ^ E_NOTICE);
}
else
{
    ini_set(\'display_errors\', 0);
    ini_set(\'log_errors\', 1);
}
if (!defined(\'IN_SCRIPT\')) {die(\'Invalid attempt!\');}
?' . '>';

$fp=fopen(HESK_PATH . 'hesk_settings.inc.php','w') or hesk_error($hesklang['err_openset']);
fputs($fp,$settings_file_content);
fclose($fp);

return true;
} // End hesk_iSaveSettings()


function hesk_iDatabase($problem=0) {
    global $hesk_settings, $hesk_db_link;
    hesk_iHeader();
?>

<table border="0" width="100%">
<tr>
<td>INSTALLATION STEPS:<br />
<font color="#008000">1. License agreement</font> -&gt; <font color="#008000">2. Check setup</font> -&gt; <b>3. Database settings</b> -&gt; 4. Setup database tables</td>
</tr>
</table>

	<br />

    <div align="center">
	<table border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="7" height="7"><img src="../img/roundcornerslt.jpg" width="7" height="7" alt="" /></td>
		<td class="roundcornerstop"></td>
		<td><img src="../img/roundcornersrt.jpg" width="7" height="7" alt="" /></td>
	</tr>
	<tr>
		<td class="roundcornersleft">&nbsp;</td>
		<td>

<h3>Database settings</h3>

<div align="center">
<table border="0" width="750" cellspacing="1" cellpadding="5" class="white">
<tr>
<td>
<p><b>Hesk will not work unless the information below is correct and database connection
test is successful. For correct database information contact your hosting company,
I cannot help you find this information!</b></p>

<?php
if ($problem==1)
{
    echo '<p style="color:#FF0000;"><b>Database connection failed!</b><br />Double-check all the information below. If not sure contact your hosting company for the correct information!<br /><br />MySQL said: '.mysql_error().'</p>';
}
elseif ($problem==2)
{
    echo '<p style="color:#FF0000;"><b>Database connection failed!</b><br />Double-check <b>database name</b> and make sure the user has access to the database. If not sure contact your hosting company for the correct information!<br /><br />MySQL said: '.mysql_error().'</p>';
}
?>

<form action="install.php" method="post">
<table>
<tr>
<td>Database Host:</td>
<td><input type="text" name="host" value="<?php echo $hesk_settings['db_host']; ?>" size="40" /></td>
</tr>
<tr>
<td>Database Name:</td>
<td><input type="text" name="name" value="<?php echo $hesk_settings['db_name']; ?>" size="40" /></td>
</tr>
<tr>
<td>Database User (login):</td>
<td><input type="text" name="user" value="<?php echo $hesk_settings['db_user']; ?>" size="40" /></td>
</tr>
<tr>
<td>User Password:</td>
<td><input type="text" name="pass" value="<?php echo $hesk_settings['db_pass']; ?>" size="40" /></td>
</tr>
<tr>
<td>Table prefix:</td>
<td><input type="text" name="pfix" value="<?php echo $hesk_settings['db_pfix']; ?>" size="40" /></td>
</tr>
</table>

<p align="center"><input type="hidden" name="dbtest" value="1" /><input type="submit" value="Continue to Step 4" class="orangebutton" onmouseover="hesk_btn(this,'orangebuttonover');" onmouseout="hesk_btn(this,'orangebutton');" /></p>
</form>

</td>
</tr>
</table>
</div>

			</td>
			<td class="roundcornersright">&nbsp;</td>
		</tr>
		<tr>
			<td><img src="../img/roundcornerslb.jpg" width="7" height="7" alt="" /></td>
			<td class="roundcornersbottom"></td>
			<td width="7" height="7"><img src="../img/roundcornersrb.jpg" width="7" height="7" alt="" /></td>
		</tr>
		</table>
	    </div>
<?php
    hesk_iFooter();
} // End hesk_iDatabase()




function hesk_iCheckSetup() {
    global $hesk_settings;
    hesk_iHeader();
    $_SESSION['all_passed']=1;
    $correct_this=array();
?>

<table border="0" width="100%">
<tr>
<td>INSTALLATION STEPS:<br />
<font color="#008000">1. License agreement</font> -&gt; <b>2. Check setup</b> -&gt; 3. Database settings -&gt; 4. Setup database tables</td>
</tr>
</table>

<br />

    <div align="center">
	<table border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="7" height="7"><img src="../img/roundcornerslt.jpg" width="7" height="7" alt="" /></td>
		<td class="roundcornerstop"></td>
		<td><img src="../img/roundcornersrt.jpg" width="7" height="7" alt="" /></td>
	</tr>
	<tr>
		<td class="roundcornersleft">&nbsp;</td>
		<td>

<h3>Check setup</h3>

<p>Checking wether your server meets all requirements and that files are setup correctly</p>

<div align="center">
<table border="0" width="750" cellspacing="1" cellpadding="3" class="white">
<tr>
<th class="admin_white"><b>Required</b></th>
<th class="admin_white"><b>Your setting</b></th>
<th class="admin_white"><b>Status</b></th>
</tr>

<tr>
<td class="admin_gray"><b>PHP version</b><br />Should be at least PHP 4 >= 4.3.2</td>
<td class="admin_gray" valign="middle" nowrap="nowrap"><b><?php echo PHP_VERSION; ?></b></td>
<td class="admin_gray" valign="middle">
<?php
if (function_exists('version_compare') && version_compare(PHP_VERSION,'4.3.2','>='))
{
    echo '<font color="#008000"><b>Passed</b></font>';
}
else
{
    $_SESSION['all_passed']=0;
    echo '<font color="#FF0000"><b>Failed</b></font>';
    $correct_this[]='You are using an old and non-secure version of PHP, ask your host to update your PHP version!';
}
?>
</td>
</tr>

<tr>
<td class="admin_white"><b>hesk_settings.inc.php file</b><br />Must be uploaded and writable by the script</td>
<td class="admin_white" valign="middle" nowrap="nowrap">
<?php
$mypassed=1;
if (file_exists('../hesk_settings.inc.php'))
{
    echo '<b><font color="#008000">Exists</font>, ';
    if (is__writable('../hesk_settings.inc.php'))
    {
        echo '<font color="#008000">Writable</font></b>';
    }
    else
    {
        echo '<font color="#FF0000">Not writable</font></b>';
        $mypassed=2;
    }
}
else
{
    $mypassed=0;
    echo '<b><font color="#FF0000">Not uploaded</font>, <font color="#FF0000">Not writable</font></b>';
}
?>
</td>
<td class="admin_white" valign="middle">
<?php
if ($mypassed==1)
{
    echo '<font color="#008000"><b>Passed</b></font>';
}
elseif ($mypassed==2)
{
    $_SESSION['all_passed']=0;
    echo '<font color="#FF0000"><b>Failed</b></font>';
    $correct_this[]='Make sure the <b>hesk_settings.inc.php</b> file is writable: on Linux chmod it to 666 or rw-rw-rw-, on Windows (IIS) make sure IUSR account has modify/read/write permissions';
}
else
{
    $_SESSION['all_passed']=0;
    echo '<font color="#FF0000"><b>Failed</b></font>';
    $correct_this[]='Upload the <b>hesk_settings.inc.php</b> file to the server and make sure it\'s writable!';
}
?>
</td>
</tr>

<tr>
<td class="admin_gray"><b>attachments directory</b><br />Must exist and be writable by the script</td>
<td class="admin_gray" valign="middle" nowrap="nowrap">
<?php
$mypassed=1;

if (!file_exists('../attachments'))
{
    @mkdir('../attachments', 0777);
}

if (is_dir('../attachments')) {
    echo '<b><font color="#008000">Exists</font>, ';
    if (is__writable('../attachments/'))
    {
        echo '<font color="#008000">Writable</font></b>';
    }
    else
    {
        echo '<font color="#FF0000">Not writable</font></b>';
        $mypassed=2;
    }
}
else
{
    $mypassed=0;
    echo '<b><font color="#FF0000">Not uploaded</font>, <font color="#FF0000">Not writable</font></b>';
}
?>
</td>
<td class="admin_gray" valign="middle">
<?php
if ($mypassed==1)
{
    echo '<font color="#008000"><b>Passed</b></font>';
} elseif ($mypassed==2)
{
    $_SESSION['all_passed']=0;
    echo '<font color="#FF0000"><b>Failed</b></font>';
    $correct_this[]='Make sure the <b>attachments</b> directory is writable: on Linux chmod it to 777 or rwxrwxrwx, on Windows (IIS) make sure IUSR account has modify/read/write permissions';
}
else
{
    $_SESSION['all_passed']=0;
    echo '<font color="#FF0000"><b>Failed</b></font>';
    $correct_this[]='Within hesk folder create a new one called <b>attachments</b> and make sure it is writable: on Linux chmod it to 777 or rwxrwxrwx, on Windows (IIS) make sure IUSR account has modify/read/write permissions';
}
?>
</td>
</tr>

<tr>
<td class="admin_white"><b>File uploads</b><br />To use file attachments <i>file_uploads</i> must be enabled in PHP</td>
<td class="admin_white" valign="middle">
<?php
$mypassed=1;
$can_use_attachments=1;
if (ini_get('file_uploads'))
{
    echo '<b><font color="#008000">Enabled</font></b>';
}
else
{
    $mypassed=0;
    $can_use_attachments=0;
    echo '<b><font color="#FFA500">Disabled</font></b>';
}
?>
</td>
<td class="admin_white" valign="middle">
<?php
if ($mypassed==1)
{
    echo '<font color="#008000"><b>Passed</b></font>';
}
else
{
    echo '<font color="#FFA500"><b>Unavailable*</b></font>';
}
?>
</td>
</tr>

<tr>
<td class="admin_gray"><b>ZLib Support</b><br />PHP must be compiled with ZLib support</td>
<td class="admin_gray" valign="middle" nowrap="nowrap">
<?php
$mypassed=1;
if (function_exists('gzdeflate'))
{
    echo '<b><font color="#008000">Enabled</font></b>';
}
else
{
    $mypassed=0;
    $_SESSION['all_passed']=0;
    echo '<font color="#FF0000"><b>Disabled</b></font>';
    $correct_this[]='PHP needs to be compiled with ZLib support enabled (--with-zlib[=DIR]) in order for Hesk to work correctly. Contact your host and ask them to enable ZLib support for PHP.';
}
?>
</td>
<td class="admin_gray" valign="middle">
<?php
if ($mypassed==1)
{
    echo '<font color="#008000"><b>Passed</b></font>';
}
else
{
    echo '<font color="#FF0000"><b>Failed</b></font>';
}
?>
</td>
</tr>

<tr>
<td class="admin_white"><b>GD Library</b><br />Check if GD library is enabled</td>
<td class="admin_white" valign="middle" nowrap="nowrap">
<?php
$mypassed=1;
if (extension_loaded('gd') && function_exists('gd_info'))
{
    echo '<b><font color="#008000">Enabled</font></b>';
    $can_use_gd=1;
}
else
{
    $mypassed=0;
    $can_use_gd=0;
    echo '<font color="#FF0000"><b>Disabled</b></font>';
}
?>
</td>
<td class="admin_white" valign="middle">
<?php
if ($mypassed==1)
{
    echo '<font color="#008000"><b>Passed</b></font>';
}
else
{
    echo '<font color="#ff9900"><b>Not available</b></font>';
}
?>
</td>
</tr>

</table>
</div>

<?php
if ($can_use_attachments==0)
{
    echo '<p><font color="#FFA500"><b>*</b></font> Hesk will still work if all other tests are successful, but File attachments won\'t work.</p>';
    $_SESSION['set_attachments']=0;
}
else
{
	$_SESSION['set_attachments']=1;
}

if ($can_use_gd==0)
{
    echo '<p><font color="#FFA500"><b>*</b></font> Hesk will work without GD library but you will not be able to use the anti-SPAM image (captcha)</p>';
    $_SESSION['set_captcha']=0;
    $_SESSION['use_spamq']=1;
}
else
{
	$_SESSION['set_captcha']=1;
    $_SESSION['use_spamq']=0;
}
?>

<p>&nbsp;</p>

<?php
if (!empty($correct_this))
{
	?>
	<div align="center">
	<table border="0" width="750" cellspacing="1" cellpadding="3">
	<tr>
	<td>
	<p><font color="#FF0000"><b>You will not be able to continue installation until the required tests are passed. Things you need to correct before continuing installation:</b></font></p>
	<ol>
	<?php
	foreach($correct_this as $mythis)
	{
	    echo "<li>$mythis<br />&nbsp;</li>";
	}
	?>
	</ol>
	<form method="post" action="install.php">
	<p align="center">&nbsp;<br /><input type="submit" value="Test again" class="orangebutton" onmouseover="hesk_btn(this,'orangebuttonover');" onmouseout="hesk_btn(this,'orangebutton');" /></p>
	</form>
	</td>
	</tr>
	</table>
	</div>
	<?php
}
else
{
	$_SESSION['step']=2;
	?>
	<form method="POST" action="install.php">
	<div align="center">
	<table border="0">
	<tr>
	<td>
	<p align="center"><font color="#008000"><b>All required tests passed, you may now continue to database setup</b></font></p>
	<p align="center"><input type="submit" value="Continue to Step 3" class="orangebutton" onmouseover="hesk_btn(this,'orangebuttonover');" onmouseout="hesk_btn(this,'orangebutton');" /></p>
	</td>
	</tr>
	</table>
	</div>
	</form>

	<?php
}
?>
			</td>
			<td class="roundcornersright">&nbsp;</td>
		</tr>
		<tr>
			<td><img src="../img/roundcornerslb.jpg" width="7" height="7" alt="" /></td>
			<td class="roundcornersbottom"></td>
			<td width="7" height="7"><img src="../img/roundcornersrb.jpg" width="7" height="7" alt="" /></td>
		</tr>
		</table>
	    </div>
<?php
    hesk_iFooter();
} // End hesk_iCheckSetup()



function hesk_iStart() {
    global $hesk_settings;
    hesk_iHeader();
?>

<table border="0" width="100%">
<tr>
<td>INSTALLATION STEPS:<br />
<b>1. License agreement</b> -&gt; 2. Check setup -&gt; 3. Database settings -&gt; 4. Setup database tables</td>
</tr>
</table>

<br />

    <div align="center">
	<table border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td width="7" height="7"><img src="../img/roundcornerslt.jpg" width="7" height="7" alt="" /></td>
		<td class="roundcornerstop"></td>
		<td><img src="../img/roundcornersrt.jpg" width="7" height="7" alt="" /></td>
	</tr>
	<tr>
		<td class="roundcornersleft">&nbsp;</td>
		<td>

<h3>License agreement</h3>

<p><b>Summary:</b></p>

<ul>
<li>The script is provided &quot;as is&quot;, without any warranty. Use at your own risk.<br />&nbsp;</li>
<li>You are not allowed to redistribute this script or any software based on this script over the Internet or in any other medium without express written permission<br />&nbsp;</li>
<li>Using this code, in part or full, to create new scripts or products is expressly forbidden.<br />&nbsp;</li>
<li>You mustn't edit or remove &quot;Powered by&quot; links without purchasing a <a href="https://www.hesk.com/buy.php" target="_blank">License</a> to do so</li>
</ul>

<p><b>The entire License agreement:</b></p>

<p align="center"><textarea rows="15" cols="70">
LICENSE AGREEMENT

The &quot;script&quot; is all files included with the HESK distribution archive as well as all files produced as a result of the installation scripts. Klemen Stirn (&quot;Author&quot;,&quot;HESK&quot;) is the author and sole copyrgihts owner of the script. The &quot;Licensee&quot; (&quot;you&quot;) is the person downloading or using the Licensed version of script. &quot;User&quot; is any person using or viewing the script with their HTML browser.

&quot;Powered by&quot; link is herein defined as an anchor link pointing to HESK website and/or script webpage, usually located at the bottom of the script and visible to users of the script without looking into source code.

&quot;Copyright headers&quot; is a written copyright notice located in script source code and normally not visible to users.

This License may be modified by the Author at any time. The new version of the License becomes valid when published on HESK website. You are encouraged to regularly check back for License updates.

THIS SCRIPT IS PROVIDED &quot;AS IS&quot; AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL KLEMEN STIRN BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SCRIPT, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Using this code, in part or full, to create derivate work, new scripts or products is expressly forbidden. Obtain permission before redistributing this software over the Internet or in any other medium.

REMOVING POWERED BY LINKS
You are not allowed to remove or in any way edit the &quot;Powered by&quot; links in this script without purchasing a License. You can purchase a License at
https://www.hesk.com/buy.php

If you remove the Powered by links without purchasing a License and paying the licensee fee, you are in a direct violation of European Union and International copyright laws. Your Licence to use the scripts is immediately terminated and you must delete all copies of the entire program from your web server. Klemen Stirn may, at any time, terminate this License agreement if Klemen Stirn determines, that this License agreement has been breached.

Under no circumstance is the removal of copyright headers from the script source code permitted.

This License Agreement is governed by the laws of Slovenia, European Union. Both the Licensee and Klemen Stirn submit to the jurisdiction of the courts of Slovenia, European Union. Both the Licensee and Klemen Stirn agree to commence any litigation that may arise hereunder in the courts located in Slovenia.

If any provision hereof shall be held illegal, invalid or unenforceable, in whole or in part, such provision shall be modified to the minimum extent necessary to make it legal, valid and enforceable, and the legality, validity and enforceability of all other provisions of this Agreement shall not be affected thereby. No delay or failure by either party to exercise or enforce at any time any right or provision hereof shall be considered a waiver thereof or of such party's right thereafter to exercise or enforce each and every right and provision of this Agreement.
</textarea></p>

<hr />

<script language="javascript" type="text/javascript"><!--
function hesk_checkAgree() {
    if (document.license.agree[0].checked) {
        return true;
    } else {
        alert('You must agree to the License agreement in order to use Hesk!');
        return false;
    }
}
//-->
</script>

<form method="get" action="install.php" name="license" onsubmit="return hesk_checkAgree()">
<div align="center">
<table border="0">
<tr>
<td>
<p><b>Do you agree to the License agreement and all the terms incorporated therein?</b> <font color="#FF0000"><i>(required)</i></font><br />
<label><input type="radio" name="agree" value="YES" /> YES</label><br />
<label><input type="radio" name="agree" value="NO" /> NO</label></p>
<p align="center"><input type="submit" value="Continue to Step 2" class="orangebutton" onmouseover="hesk_btn(this,'orangebuttonover');" onmouseout="hesk_btn(this,'orangebutton');" /></p>
</td>
</tr>
</table>
</div>
</form>

		</td>
		<td class="roundcornersright">&nbsp;</td>
	</tr>
	<tr>
		<td><img src="../img/roundcornerslb.jpg" width="7" height="7" alt="" /></td>
		<td class="roundcornersbottom"></td>
		<td width="7" height="7"><img src="../img/roundcornersrb.jpg" width="7" height="7" alt="" /></td>
	</tr>
	</table>
    </div>

<?php
    hesk_iFooter();
} // End hesk_iStart()


function hesk_iHeader() {
    global $hesk_settings;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<title>Install Hesk <?php echo HESK_NEW_VERSION; ?></title>
	<meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-1" />
	<link href="../hesk_style.css" type="text/css" rel="stylesheet" />
	<script language="Javascript" type="text/javascript" src="../hesk_javascript.js"></script>
    </head>
<body>


<div align="center">
<table border="0" cellspacing="0" cellpadding="5" class="enclosing">
<tr>
<td>
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
	<td width="3"><img src="../img/headerleftsm.jpg" width="3" height="25" alt="" /></td>
	<td class="headersm">HESK <?php echo HESK_NEW_VERSION; ?> installation script</td>
	<td width="3"><img src="../img/headerrightsm.jpg" width="3" height="25" alt="" /></td>
	</tr>
	</table>

	</td>
	</tr>
	<tr>
	<td>

<?php
} // End hesk_iHeader()


function hesk_iFooter() {
    global $hesk_settings;
?>
	<p style="text-align:center"><span class="smaller">Powered by <a href="http://www.hesk.com" class="smaller" target="_blank">Help Desk Software</a> HESK<sup>TM</sup></span></p></td></tr></table></div></body></html>
<?php
} // End hesk_iFooter()


/*
This function is from http://www.php.net/is_writable
and is a work-around for IIS bug which returns files as
writable by PHP when in fact they are not.
*/
function is__writable($path) {
//will work in despite of Windows ACLs bug
//NOTE: use a trailing slash for folders!!!
//see http://bugs.php.net/bug.php?id=27609
//see http://bugs.php.net/bug.php?id=30931

    if ($path{strlen($path)-1}=='/') // recursively return a temporary file path
        return is__writable($path.uniqid(mt_rand()).'.tmp');
    else if (is_dir($path))
        return is__writable($path.'/'.uniqid(mt_rand()).'.tmp');
    // check tmp file for read/write capabilities
    $rm = file_exists($path);
    $f = @fopen($path, 'a');
    if ($f===false)
        return false;
    fclose($f);
    if (!$rm)
        unlink($path);
    return true;
}
?>
