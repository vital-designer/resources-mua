<?php
include ("../common.php");
include ("../include/template_function.php");
$section = "templates";




if (isset($_GET['id']))
{
				if (!isset($_POST['action']) || $_POST['action'] != "change")
				{
								if ($_GET['id'] == 0)
								{
												$content = getblankcontent();
								}
								else
								{
												$right_name = "view_item";
												check_right($section, $right_name);
												$content = getcontent($_GET['id']);
								}
								if ($_GET['form'] == "wyswyg")
								{
												$smarty->assign("id", $content['id']);
												$smarty->assign("name", $content['name']);
												//require_once ("../tinymce/tinymce.php");
												$newsletter['body'] = token2br($content['body']);
												$smarty->assign("newsletter", $newsletter);
												//$smarty->assign("tinymce", $tinymce);
												$smarty->assign("test", $newsletter['body']);
												$smarty->assign("format", "html");
												$smarty->assign("razdel", "Templates");
												$smarty->assign("description", "Mailing HTML Template Editing");
												$smarty->assign("hint", "Please edit the values in the fields of this mailing template");
												$smarty->display("{$admin_nl_gentemplates}/template_change_html_template.tpl");
								}
								else
								{
												$smarty->assign("id", $content['id']);
												$smarty->assign("name", $content['name']);
												$smarty->assign("rel", $content);
												$smarty->assign("format", "text");
												$smarty->assign("razdel", "Templates");
												$smarty->assign("description", "Mailing Text Template Editing");
												$smarty->assign("hint", "Please edit the values in the fields of this mailing template");
												$smarty->display("{$admin_nl_gentemplates}/template_change_txt_template.tpl");
								}
								exit();
				}
				else
				{
								$body = "";
								$format = $_POST['format'];
								switch ($_POST['bodyfrom'])
								{
												case "text":
																$body = isset($_POST['body1']) && !empty($_POST['body1']) ? $_POST['body1']:
																trim($_POST['wysiwyg']);
																break;
												case "file":
																if (!isset($_HTTP_POST_FILES['bodyfile']['tmp_name']) || empty($_HTTP_POST_FILES['bodyfile']['tmp_name']))
																{
																				$message = "Error: Can't open file";
																}
																else
																{
																				$body = join("", file($_FILES['bodyfile']['tmp_name']));
																}
																break;
												case "link":
																if (!isset($_POST['bodyurl']) || empty($_POST['bodyurl']) || $_POST['bodyurl'] == "http://")
																{
																				$message = "Error: Empty URL";
																}
																else
																{
																				if (!preg_match("/http:\\/\\//i", $_POST['bodyurl']))
																				{
																								$bodyurl = "http://" . $_POST['bodyurl'];
																				}
																				else
																				{
																								$bodyurl = $_POST['bodyurl'];
																				}
																				include ("../include/Snoopy.class.inc");
																				$snoopy = new snoopy();
																				@$snoopy->fetch($bodyurl, "");
																				$body = $snoopy->results;
																				if (!empty($body))
																				{
																								break;
																				}
																				$message = "Error: Empty content from URL";
																				break;
																}
												default:
																$body = isset($_POST['body1']) && !empty($_POST['body1']) ? $_POST['body1']:
																trim($_POST['wysiwyg']);
																break;
								}
								if (isset($_POST['body1']) && trim($_POST['body1']) == "" || isset($_POST['wyswyg']) && trim($_POST['wyswyg']) || trim($_POST['name']) == "")
								{
												$message .= "Empty name or content of template";
								}
								if (!isset($message))
								{
												if ($_GET['id'] == 0)
												{
																$right_name = "create";
																check_right($section, $right_name);
																$releaseID = addrelease($_POST['name'], $body, $format);
												}
												else
												{
																$right_name = "edit";
																check_right($section, $right_name);
																updrelease($_GET['id'], $_POST['name'], $body);
																$releaseID = $_GET['id'];
												}
												$smarty->assign("rel", getcontent($releaseID, "1"));
												header("Location: index.php");
								}
								else
								{
												if ($_GET['id'] == 0)
												{
																$content = getblankcontent();
												}
												else
												{
																$content = getcontent($_GET['id']);
												}
												$smarty->assign("message", $message);
												if ($_GET['form'] == "wyswyg")
												{
																$content['body'] = token2br($content['body']);
																$smarty->assign("id", $content['id']);
																$smarty->assign("name", $content['name']);
																require_once ("../tinymce/tinymce.php");
																$newsletter['body'] = token2br($content['body']);
																$smarty->assign("newsletter", $newsletter);
																$smarty->assign("tinymce", $tinymce);
																$smarty->assign("format", "html");
																$smarty->display("{$admin_nl_gentemplates}/template_change_html_template.tpl");
												}
												else
												{
																$smarty->assign("id", $content['id']);
																$smarty->assign("name", $content['name']);
																$smarty->assign("rel", $content);
																$smarty->assign("format", "text");
																$smarty->assign("razdel", "Templates");
																$smarty->assign("description", "Mailing Text Template Editing");
																$smarty->assign("hint", "Edit the values in the fields of this mailing template");
																$smarty->display("{$admin_nl_gentemplates}/template_change_txt_template.tpl");
												}
												exit();
								}
				}
}
else
{
				header("Location: index.php");
}
?>