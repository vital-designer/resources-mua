<?php
include ("../common.php");
include ("../include/attaches_function.php");
if (isset($_GET['id']))
{
				if (!isset($_POST['action']) || $_POST['action'] != "change")
				{
								if ($_GET['id'] == 0)
								{
												$smarty->assign("razdel", "Attachments");
												$smarty->assign("description", "Upload An Attachment");
												$smarty->assign("hint", "Upload file to the server. Afterwards you will be able to add uploaded files to sent newsletters from the general depository.");
												$content = getblankcontent();
								}
								else
								{
												$smarty->assign("razdel", "Attachments");
												$smarty->assign("description", "Attach Editing");
												$smarty->assign("hint", "Edit the values in the fields of this attachment.");
												$content = getcontent((integer)$_GET['id']);
								}
								$smarty->assign("rel", $content);
								$smarty->display("{$admin_nl_gentemplates}/attaches_change_attach.tpl");
				}
				else
				{
								if ($_GET['id'] == 0 || $_GET['id'] == "0")
								{
												if (isset($_POST['action']) && $_POST['action'] == "change")
												{
																addattach();
												}
								}
								else
								{
												updattach();
								}
								header("Location: index.php");
								exit();
				}
}
else
{
				header("Location: index.php");
				exit();
}
?>