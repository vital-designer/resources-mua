<?php
$upload_services[]="uploadline.com_member";
$max_file_size["uploadline.com_member"]=1024;
$page_upload["uploadline.com_member"] = "uploadline.com_member.php";
?>