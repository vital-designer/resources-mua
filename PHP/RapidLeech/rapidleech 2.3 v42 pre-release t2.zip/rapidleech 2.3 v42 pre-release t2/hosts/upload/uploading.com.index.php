<?php
$upload_services[]="uploading.com";
$max_file_size["uploading.com"]=1000;
$page_upload["uploading.com"] = "uploading.com.php";
?>
