<?php
include_once ("crypt.inc.php");
if (!defined("_ADODB_LAYER"))
{
				include ("adodb.inc.php");
}
if (!defined("ADODB_SESSION"))
{
				define("ADODB_SESSION", 1);
				global $ADODB_SESSION_CONNECT;
				global $ADODB_SESSION_DRIVER;
				global $ADODB_SESSION_USER;
				global $ADODB_SESSION_PWD;
				global $ADODB_SESSION_DB;
				global $ADODB_SESS_CONN;
				global $ADODB_SESS_LIFE;
				global $ADODB_SESS_DEBUG;
				global $ADODB_SESS_INSERT;
				if (empty($ADODB_SESSION_DRIVER))
				{
								$ADODB_SESSION_DRIVER = "mssql";
								$ADODB_SESSION_CONNECT = "(local)";
								$ADODB_SESSION_USER = "sa";
								$ADODB_SESSION_PWD = "";
								$ADODB_SESSION_DB = "elearning";
				}
				if (empty($ADODB_SESSION_TBL))
				{
								$ADODB_SESSION_TBL = "sessions";
				}
				function adodb_session_key()
				{
								$ADODB_CRYPT_KEY = "CRYPTED ADODB SESSIONS ROCK!";
								return crypt($ADODB_CRYPT_KEY, session_id());
				}
				$ADODB_SESS_LIFE = get_cfg_var("session.gc_maxlifetime");
				if ($ADODB_SESS_LIFE <= 1)
				{
								$ADODB_SESS_LIFE = 1440;
				}
				function adodb_sess_open($save_path, $session_name)
				{
								global $ADODB_SESSION_CONNECT;
								global $ADODB_SESSION_DRIVER;
								global $ADODB_SESSION_USER;
								global $ADODB_SESSION_PWD;
								global $ADODB_SESSION_DB;
								global $ADODB_SESS_CONN;
								global $ADODB_SESS_DEBUG;
								$ADODB_SESS_INSERT = false;
								if (isset($ADODB_SESS_CONN))
								{
												return true;
								}
								$ADODB_SESS_CONN = adonewconnection($ADODB_SESSION_DRIVER);
								if (!empty($ADODB_SESS_DEBUG))
								{
												$ADODB_SESS_CONN->debug = true;
												print " conn={$ADODB_SESSION_CONNECT} user={$ADODB_SESSION_USER} pwd={$ADODB_SESSION_PWD} db={$ADODB_SESSION_DB} ";
								}
								return $ADODB_SESS_CONN->pconnect($ADODB_SESSION_CONNECT, $ADODB_SESSION_USER, $ADODB_SESSION_PWD, $ADODB_SESSION_DB);
				}
				function adodb_sess_close()
				{
								global $ADODB_SESS_CONN;
								if ($ADODB_SESS_CONN)
								{
												$ADODB_SESS_CONN->close();
								}
								return true;
				}
				function adodb_sess_read($key)
				{
								$Crypt = new md5crypt();
								global $ADODB_SESS_CONN;
								global $ADODB_SESS_INSERT;
								global $ADODB_SESSION_TBL;
								$rs = $ADODB_SESS_CONN->execute("SELECT data FROM {$ADODB_SESSION_TBL} WHERE sesskey = '{$key}' AND expiry >= " . time());
								if ($rs)
								{
												if ($rs->EOF)
												{
																$ADODB_SESS_INSERT = true;
																$v = "";
												} else
												{
																$v = rawurldecode($Crypt->decrypt(reset($rs->fields), adodb_session_key()));
												}
												$rs->close();
												return $v;
								} else
								{
												$ADODB_SESS_INSERT = true;
								}
								return false;
				}
				function adodb_sess_write($key, $val)
				{
								$Crypt = new md5crypt();
								global $ADODB_SESS_INSERT;
								global $ADODB_SESS_CONN;
								global $ADODB_SESS_LIFE;
								global $ADODB_SESSION_TBL;
								$expiry = time() + $ADODB_SESS_LIFE;
								$val = $Crypt->encrypt(rawurlencode($val), adodb_session_key());
								$qry = "UPDATE {$ADODB_SESSION_TBL} SET expiry={$expiry},data='{$val}' WHERE sesskey='{$key}'";
								$rs = $ADODB_SESS_CONN->execute($qry);
								if ($rs)
								{
												$rs->close();
								} else
								{
												print "<p>Session Update: " . $ADODB_SESS_CONN->errormsg() . "</p>";
								}
								if ($ADODB_SESS_INSERT || $rs === false)
								{
												$qry = "INSERT INTO {$ADODB_SESSION_TBL}(sesskey,expiry,data) VALUES ('{$key}',{$expiry},'{$val}')";
												$rs = $ADODB_SESS_CONN->execute($qry);
												if ($rs)
												{
																$rs->close();
												} else
												{
																print "<p>Session Insert: " . $ADODB_SESS_CONN->errormsg() . "</p>";
												}
								}
								if ($ADODB_SESS_CONN->databaseType == "access")
								{
												$rs = $ADODB_SESS_CONN->execute("select sesskey from {$ADODB_SESSION_TBL} WHERE sesskey='{$key}'");
								}
								return isset($rs);
				}
				function adodb_sess_destroy($key)
				{
								global $ADODB_SESS_CONN;
								global $ADODB_SESSION_TBL;
								$qry = "DELETE FROM {$ADODB_SESSION_TBL} WHERE sesskey = '{$key}'";
								$rs = $ADODB_SESS_CONN->execute($qry);
								if ($rs)
								{
												$rs->close();
								}
								return $rs;
				}
				function adodb_sess_gc($maxlifetime)
				{
								global $ADODB_SESS_CONN;
								global $ADODB_SESSION_TBL;
								$qry = "DELETE FROM {$ADODB_SESSION_TBL} WHERE expiry < " . time();
								$rs = $ADODB_SESS_CONN->execute($qry);
								if ($rs)
								{
												$rs->close();
								}
								if (defined("ADODB_SESSION_OPTIMIZE"))
								{
												switch ($ADODB_SESSION_DRIVER)
												{
																case "mysql":
																case "mysqlt":
																				$opt_qry = "OPTIMIZE TABLE " . $ADODB_SESSION_TBL;
																				break;
																case "postgresql":
																case "postgresql7":
																				$opt_qry = "VACUUM " . $ADODB_SESSION_TBL;
												}
								}
								return true;
				}
				session_module_name("user");
				session_set_save_handler("adodb_sess_open", "adodb_sess_close", "adodb_sess_read", "adodb_sess_write", "adodb_sess_destroy", "adodb_sess_gc");
}
?>