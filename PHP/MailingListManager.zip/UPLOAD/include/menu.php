<?php
function adminxmlmenu($root)
{
				global $config;
				global $item_uid;
				$menu = array();
				foreach ($root->children as $cnt => $node)
				{
								++$item_uid;
								switch ($node->tag)
								{
												case "section":
																$menu[$cnt] = array();
																$menu[$cnt][0] = $node->attrs['name'];
																$menu[$cnt][1] = "";
																$menu[$cnt][2] = array();
																if (!(0 < $node->childrenCount))
																{
																				break;
																}
																$menu[$cnt][2] = adminxmlmenu($node);
																break;
												case "item":
																$menu[$cnt] = array();
																$menu[$cnt][0] = array();
																$menu[$cnt][0][0] = $node->attrs['name'];
																$menu[$cnt][0][1] = $config['server'] . $config['theme_path'] . $node->attrs['img'];
																$menu[$cnt][0][2] = $config['server'] . $node->attrs['href'];
																$menu[$cnt][0][3] = "item" . $item_uid;
																$menu[$cnt][1] = array();
																if (!(0 < $node->childrenCount))
																{
																				break;
																}
																$menu[$cnt][1] = adminxmlmenu($node);
																break;
												case "subitem":
																$menu[$cnt] = array();
																$menu[$cnt][0] = $node->attrs['name'];
																$menu[$cnt][1] = $config['server'] . $config['theme_path'] . $node->attrs['img'];
																$menu[$cnt][2] = $config['server'] . $node->attrs['href'];
																if ($node->attrs['onclick'] != "")
																{
																				$node->attrs['onclick'] = str_replace("[href]", $menu[$cnt][2], $node->attrs['onclick']);
																}
																$menu[$cnt][3] = $node->attrs['onclick'];
								}
				}
				return $menu;
}
function adminjsmenu($menu_arr, $keys = "")
{
				$menu_str = "";
				foreach ($menu_arr as $key => $value)
				{
								if (is_array($menu_arr[$key]))
								{
												$menu_str .= "menuElements" . $keys . "[" . $key . "] = new Array();\n";
												$menu_str .= adminjsmenu($menu_arr[$key], $keys . "[" . $key . "]");
								} else
								{
												$menu_str .= "menuElements" . $keys . "[" . $key . "] = \"" . $value . "\";\n";
								}
				}
				return $menu_str;
}
include ("../common.php");
include ("xmlparser.php");
if (isset($_GET['js']))
{
				$xml_parser = new simplexmlparser("menu.xml");
				$xml_root = $xml_parser->getroot();
				$menu_arr = array();
				$menu_arr = adminxmlmenu($xml_root);
				$menu_str = adminjsmenu($menu_arr);
				unset($xml_parser);
				unset($xml_root);
				$smarty->assign("menuElements", $menu_str);
				$smarty->display($admin_nl_gentemplates . "/js/menu.js");
}
if (isset($_GET['css']))
{
				header("Content-type: text/css;");
				$smarty->display($admin_nl_gentemplates . "/css/menu.css");
}
?>
