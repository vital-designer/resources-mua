<?php
function rs2html(&$rs, $ztabhtml = "", $zheaderarray = "")
{
				$s = "";
				$rows = 0;
				$docnt = false;
				global $gSQLMaxRows;
				global $gSQLBlockRows;
				if (!$rs)
				{
								printf(ADODB_BAD_RS, "rs2html");
								return false;
				}
				if (!$ztabhtml)
				{
								$ztabhtml = "BORDER='1' WIDTH='98%'";
				}
				$typearr = array();
				$ncols = $rs->fieldcount();
				$hdr = "<TABLE COLS={$ncols} {$ztabhtml}>\n\n";
				$i = 0;
				for (; $i < $ncols; ++$i)
				{
								$field = $rs->fetchfield($i);
								if ($zheaderarray)
								{
												$fname = $zheaderarray[$i];
								} else
								{
												$fname = htmlspecialchars($field->name);
								}
								$typearr[$i] = $rs->metatype($field->type, $field->max_length);
								if (empty($fname))
								{
												$fname = "&nbsp;";
								}
								$hdr .= "<TH>{$fname}</TH>";
				}
				print $hdr . "\n\n";
				$numoffset = isset($rs->fields[0]);
				while (!$rs->EOF)
				{
								$s .= "<TR>\n";
								$i = 0;
								$v = $numoffset ? $rs->fields[0] : reset($rs->fields);
								for (; $i < $ncols; $v = $numoffset ? $rs->fields[++$i] : next($rs->fields))
								{
												$type = $typearr[$i];
												switch ($type)
												{
																case "T":
																				$s .= "\t<TD>" . $rs->usertimestamp($v, "D d, M Y, h:i:s") . "&nbsp;</TD>\n";
																				break;
																case "D":
																				$s .= "\t<TD>" . $rs->userdate($v, "D d, M Y") . "&nbsp;</TD>\n";
																				break;
																case "I":
																case "N":
																				$s .= "\t<TD align=right>" . htmlspecialchars(trim($v)) . "&nbsp;</TD>\n";
																				$s = stripslashes($s);
																				$s = urldecode($s);
																				break;
																default:
																				$s .= "\t<TD>" . htmlspecialchars(trim($v)) . "&nbsp;</TD>\n";
																				$s = stripslashes($s);
																				$s = urldecode($s);
												}
								}
								$s .= "</TR>\n\n";
								$rows += 1;
								if ($gSQLMaxRows <= $rows)
								{
												$rows = "<p>Truncated at {$gSQLMaxRows}</p>";
								} else
								{
												$rs->movenext();
												if (!$rs->EOF && $rows % $gSQLBlockRows == 0)
												{
																print $s . "</TABLE>\n\n";
																$s = $hdr;
												}
								}
				}
				print $s . "</TABLE>\n\n";
				if ($docnt)
				{
								print "<H2>" . $rows . " Rows</H2>";
				}
				return $rows;
}
function arr2html(&$arr, $ztabhtml = "", $zheaderarray = "")
{
				if (!$ztabhtml)
				{
								$ztabhtml = "BORDER=1";
				}
				$s = "<TABLE {$ztabhtml}>";
				if ($zheaderarray)
				{
								$s .= "<TR>";
								$i = 0;
								for (; $i < sizeof($zheaderarray); ++$i)
								{
												$s .= "    <TD>{$zheaderarray[$i]}</TD>\n";
								}
								$s .= "\n</TR>";
				}
				$i = 0;
				for (; $i < sizeof($arr); ++$i)
				{
								$s .= "<TR>";
								$a = &$arr[$i];
								if (is_array($a))
								{
												$j = 0;
												for (; $j < sizeof($a); ++$j)
												{
																$val = $a[$j];
																if (empty($val))
																{
																				$val = "&nbsp;";
																}
																$s .= "    <TD>{$val}</TD>\n";
												}
								} else
												if ($a)
												{
																$s .= "    <TD>" . $a . "</TD>\n";
												} else
												{
																$s .= "    <TD>&nbsp;</TD>\n";
												}
												$s .= "\n</TR>\n";
				}
				$s .= "</TABLE>";
				print $s;
}
global $gSQLMaxRows;
global $gSQLBlockRows;
$gSQLMaxRows = 1000;
$gSQLBlockRows = 20;
?>