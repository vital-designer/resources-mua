
</div><!--end panel-->

</div><!--end container-->

<img id="bottom" src="images/bottom.png" class="fix_png"/>
<div id="footer">
<div align="center">Powered by <strong>MachForm</strong<br />&copy; Copyright 2007-2008 Appnitro Software</div>
</div><!--footer-->
<?php if(!empty($footer_data)){ echo $footer_data; } ?>
</body>
</html>