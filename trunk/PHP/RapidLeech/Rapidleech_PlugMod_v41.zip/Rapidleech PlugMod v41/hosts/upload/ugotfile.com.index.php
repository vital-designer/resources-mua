<?php
$upload_services[]="ugotfile.com";
$max_file_size["ugotfile.com"]=200;
$page_upload["ugotfile.com"]="ugotfile.com.php";
?>