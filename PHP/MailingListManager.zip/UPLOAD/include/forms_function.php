<?php
function getforms($orderby = "", $form_page = 0)
{
				global $dbconn;
				global $smarty;
				global $config;
				if (isset($_GET['p']) && 0 < $_GET['p'])
				{
								$p = $_GET['p'];
				} else
				{
								$p = 0;
				}
				$end = $_SESSION['is_desc'] && !$_GET['is_nav'] || !$_SESSION['is_desc'] && $_GET['is_nav'] ? " desc " : "";
				if ($orderby)
				{
								$is_nav = isset($_GET['is_nav']) ? $_GET['is_nav'] : false;
								if (!$is_nav && $orderby == $_SESSION['order'])
								{
												if ($_SESSION['is_desc'])
												{
																$GLOBALS['_SESSION']['is_desc'] = false;
																$end = " desc ";
												} else
												{
																$GLOBALS['_SESSION']['is_desc'] = true;
																$end = "";
												}
								}
								$sql .= " order by " . $orderby . $end;
				} else
				{
								$sql .= " order by name";
				}
				$smarty->assign("end", trim($end));
				$res = $dbconn->execute("select count(id) from form");
				$amount = $res->fields[0];
				$smarty->assign("navigation", create_navigation($amount, $form_page, "form_page={$form_page}&order=" . $_GET['order'] . "&is_nav=true", "index.php", $p, "form_page"));
				get_smarty_array_list("form_page", $config['form_page']);
				$per_page = $config['form_page'][$form_page];
				$res = $dbconn->pageexecute("select * from form " . $sql, $per_page, $p + 1);
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$releases[$c]['id'] = $res->fields[0];
								$releases[$c]['name'] = stripslashes($res->fields[1]);
								$releases[$c]['date'] = $res->fields[11];
								$releases[$c]['type'] = $res->fields[3] == "sub" ? "Subscription" : "Unsubscription";
								$releases[$c]['date'] = $res->fields[11];
								++$c;
								$res->movenext();
				}
				$smarty->assign("amount", $amount);
				return $releases;
}
function getusers($a = "", $orderby = "")
{
				global $dbconn;
				if ($a)
				{
								$sql = " where id='" . $a . "' and uns_date IS NULL ";
				} else
				{
								$sql = " where uns_date IS NULL ";
				}
				if ($orderby)
				{
								$sql .= " order by " . $orderby;
				} else
				{
								$sql .= " order by id";
				}
				$res = $dbconn->execute("select id,date,firstname,secondname,company,email1,comment from snd_users " . $sql);
				$users = array();
				$c = 0;
				while (!$res->EOF)
				{
								$users[$c] = $res->getrowassoc();
								++$c;
								$res->movenext();
				}
				return $users;
}
function delform($id)
{
				global $dbconn;
				$res = $dbconn->execute("delete from form where id='" . $id . "'");
				$res = $dbconn->execute("delete from forms_lists where form_id='" . $id . "'");
}
function addform($name, $owner_name, $owner_email)
{
				global $dbconn;
				$res = $dbconn->execute("insert into list (name,owner_name,owner_email,date) values ('" . addslashes($name) . "','" . addslashes($owner_name) . "','" . addslashes($owner_email) . "',NOW())");
				$rid = $dbconn->_insertid();
				return $rid;
}
function sendrelease($rid, $usersArray)
{
				global $dbconn;
				$res = $dbconn->execute("select id,body,subject from creleases where id='" . $rid . "'");
				$userInfo = array();
				if ($res->rowcount())
				{
								$body = nl2br(stripslashes($res->fields[2]));
								$subject = stripslashes($res->fields[3]);
								$headers = "From: Manager <manager@domain.ltd>\r\n";
								$headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
								$headers .= "X-Priority: 1\r\n";
								$headers .= "MIME-Version: 1.0\r\n";
								$headers .= "Content-type: text/html; charset=windows-1251\r\n";
								foreach ($usersArray as $u)
								{
												$body = "";
												$email = "";
												$body = nl2br(stripslashes($res->fields[2]));
												$subject = stripslashes($res->fields[3]);
												$res2 = $dbconn->execute("select id,firstname,secondname,email1 from snd_users where id='" . $u . "'");
												$userInfo[] = $res2->fields[1] . " " . $res2->fields[2];
												$email = !empty($res2->fields[3]) ? $res2->fields[3] : $res2->fields[4];
												$body = preg_replace("/\\[name\\]/i", $res2->fields[1] . " " . $res2->fields[2], $body);
												$body = preg_replace("/\\[unsubscribe\\]/i", "http://www.domain.ltd/u.php?c=" . md5($res2->fields[3]), $body);
												$body = preg_replace("/\\[(http:.*?)\\]/i", "http://www.domain.ltd/r.php?c=" . $res2->fields[0] . "&r=" . $rid . "&l=\\1", $body);
												$body = "<table width=\"100%\"><tr><td><font size=2 face=\"Verdana\">" . $body . "</font>\n</td></tr>\n";
												$body = $body . "\n</table>";
												mail($email, $subject, $body, $headers);
												$res3 = $dbconn->execute("insert into clients_releases (client_id,release_id) values ('" . $res2->fields[0] . "','" . $rid . "')");
								}
				}
				return $userInfo;
}
function updlist($id, $name, $owner_name, $owner_email)
{
				global $dbconn;
				$res = $dbconn->execute("UPDATE list SET name='" . addslashes($name) . "', owner_name='" . addslashes($owner_name) . "', owner_email='" . addslashes($owner_email) . "',date=NOW() WHERE id='" . $id . "'");
}
function getcontent($id, $br = "")
{
				global $dbconn;
				$res = $dbconn->execute("SELECT id, name, owner_name, owner_email FROM list WHERE id='" . $id . "'");
				$releases = array();
				$releases['id'] = $res->fields[0];
				$releases['name'] = stripslashes($res->fields[1]);
				$releases['owner_name'] = stripslashes($res->fields[2]);
				$releases['owner_email'] = stripslashes($res->fields[3]);
				return $releases;
}
function getblankcontent()
{
				$releases = array();
				$releases['id'] = 0;
				$releases['name'] = "";
				$releases['owner_name'] = "";
				$releases['owner_email'] = "";
				return $releases;
}
function getlists()
{
				global $dbconn;
				$res = $dbconn->execute("SELECT id, name, date, owner_name, owner_email FROM list ORDER BY id");
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$releases[$c]['num'] = $c;
								$releases[$c]['id'] = $res->fields[0];
								$releases[$c]['name'] = stripslashes($res->fields[1]);
								$releases[$c]['date'] = $res->fields[2];
								$releases[$c]['owner_name'] = $res->fields[3];
								$releases[$c]['owner_email'] = $res->fields[4];
								$res2 = $dbconn->execute("SELECT count(*) FROM clients_lists WHERE list_id='" . $res->fields[0] . "'");
								$releases[$c]['count'] = $res2->fields[0];
								++$c;
								$res->movenext();
				}
				return $releases;
}
function generateform($form_data)
{
				global $config;
				global $dbconn;
				global $smarty;
				global $admin_nl_gentemplates;
				$smarty->assign("server_path", $config['server']);
				$smarty->assign("form_data", $form_data);
				include_once ("class.form.php");
				$form_class = new form($dbconn, $config);
				$fields = $form_class->getformattributes($form_data['id']);
				$regs = $form_class->getregexps();
				foreach ($fields as $index => $field)
				{
								if (isset($field['setup']['reg_exp']))
								{
												$id_reg = $fields[$index]['setup']['reg_exp'];
												$fields[$index]['setup']['reg_exp'] = $regs[$id_reg]['reg_exp'];
								}
				}
				$smarty->assign("fields", $fields);
				$smarty->assign("regs", $regs);
				$lists = array();
				$rs = $dbconn->execute("SELECT list_id FROM forms_lists WHERE form_id='{$form_data['id']}'");
				while (!$rs->EOF)
				{
								$lists[] = $rs->fields[0];
								$rs->movenext();
				}
				$smarty->assign("lists", $lists);
				return $smarty->fetch("{$admin_nl_gentemplates}/forms_subscribe_form.tpl");
}
function generateunsubscribeform($form_data)
{
				global $config;
				global $dbconn;
				global $smarty;
				global $admin_nl_gentemplates;
				$smarty->assign("server_path", $config['server']);
				$smarty->assign("form_data", $form_data);
				$lists = array();
				$rs = $dbconn->execute("SELECT list_id FROM forms_lists WHERE form_id='" . $form_data['id'] . "'");
				while (!$rs->EOF)
				{
								$lists[] = $rs->fields[0];
								$rs->movenext();
				}
				$smarty->assign("lists", $lists);
				return $smarty->fetch("{$admin_nl_gentemplates}/forms_unsubscribe_form.tpl");
}
function getformcontent($id)
{
				global $dbconn;
				global $config;
				$res = $dbconn->execute("SELECT * FROM form WHERE id='" . $id . "'");
				$row = $res->getrowassoc(false);
				$row['confirmation_text'] = stripslashes($row['confirmation_text']);
				$row['thankyou_text'] = stripslashes($row['thankyou_text']);
				$row['from_name'] = stripslashes($row['from_name']);
				$row['thankyou_subject'] = stripslashes($row['thankyou_subject']);
				$row['confirmation_subject'] = stripslashes($row['confirmation_subject']);
				$row['thankyou_email'] = stripslashes($row['thankyou_email']);
				$row['confirmation_email'] = stripslashes($row['confirmation_email']);
				$row['from_name'] = stripslashes($row['from_name']);
				$row['from_email'] = stripslashes($row['from_email']);
				return $row;
}
?>
