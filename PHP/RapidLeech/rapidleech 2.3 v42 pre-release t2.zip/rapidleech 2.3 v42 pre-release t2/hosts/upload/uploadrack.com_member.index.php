<?php
$upload_services[]="uploadrack.com_member";
$max_file_size["uploadrack.com_member"]=1024;
$page_upload["uploadrack.com_member"] = "uploadrack.com_member.php";  
?>