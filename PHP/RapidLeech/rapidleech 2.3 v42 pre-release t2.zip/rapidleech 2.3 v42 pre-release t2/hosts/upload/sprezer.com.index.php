<?php
$upload_services[]="sprezer.com";
$max_file_size["sprezer.com"]=200;
$page_upload["sprezer.com"] = "sprezer.com.php";  
?>