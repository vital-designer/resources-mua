<?php
include ("../common.php");
include ("../include/forms_function.php");
$section = "forms";
$right_name = "view_item";
check_right($section, $right_name);
$res = $dbconn->execute("SELECT * FROM form WHERE id='" . (integer)$_GET['id'] . "'");
$row = $res->getrowassoc(false);
print $row['type'] == "sub" ? generateform($row) : generateunsubscribeform($row);
?>
