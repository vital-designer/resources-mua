<?php
include ("../common.php");
$users = array();
$res = $dbconn->execute("SELECT DISTINCT client_id FROM clients_releases WHERE release_id='" . (integer)$_GET['id'] . "' AND date_format(date, '%Y-%m-%d')='" . addslashes($_GET['date']) . "' AND is_sent='2'");
while (!$res->EOF)
{
				$res2 = $dbconn->execute("SELECT * FROM snd_users WHERE id='" . $res->fields[0] . "'");
				$users[] = $res2->getrowassoc(false);
				$res->movenext();
}
$smarty->assign("list_id", (integer)$_GET['l']);
$smarty->assign("count", count($users));
$smarty->assign("rel_id", (integer)$_GET['id']);
$smarty->assign("date", addslashes($_GET['date']));
$smarty->assign("users", $users);
$smarty->display("{$admin_nl_gentemplates}/newsletters_undelivered.tpl");
?>