<?php 
$upload_services[] = "easy-share.com";
$max_file_size["easy-share.com"] = 100;
$page_upload["easy-share.com"] = "easy-share.com.php";
?>