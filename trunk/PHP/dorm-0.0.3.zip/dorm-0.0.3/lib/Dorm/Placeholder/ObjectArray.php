<?php
/**
 * This file is part of Dorm and is subject to the GNU Affero General
 * Public License Version 3 (AGPLv3). You should have received a copy
 * of the GNU Affero General Public License along with Dorm. If not,
 * see <http://www.gnu.org/licenses/>.
 *
 * @category Dorm
 * @package Dorm_Placeholder
 * @copyright Copyright (c) 2008-2009 Olivier Lalonde <olalonde@gmail.com>
 */

/**
 * Placeholders are used to lazyload from DB
 *
 * !!! This class is really sketchy !!!
 *
 * @todo implement isset overloading
 *       implement $property->set() and get()
 *
 */
class Dorm_Placeholder_ObjectArray extends ArrayIterator  {

    // This is used for lazy loading foreign objects

    /**
     * @var Dorm
     */
    public $dorm_Dorm;

    /**
     * @var Dorm_Object
     */
    public $dorm_Parent;

    /**
     * @var Dorm_Map_Property
     */
    public $dorm_Property;

    /**
     * @var array
     */
    public $array;

    public $arrayCount = 0;
    public $arrayPointer = 0;

    public function __construct($dorm, $parent, $property) {
        $this->dorm_Dorm = $dorm;
        $this->dorm_Parent = $parent;
        $this->dorm_Property = $property;
    }


    private $valid = true;

    /**
     * ARRAY ITERATOR
     */
    //public $iterator_position = 0;
    public function current() {
        $this->dorm_ReplacePlaceholderWithArray();
        return current($this->array);
    }

    // this is the first thing executed by foreach()
    public function rewind($flag = false) {
        $this->dorm_ReplacePlaceholderWithArray();

        $this->arrayPointer = 0;
        //rewind($this->array);
    }
    public function valid() {
        $this->dorm_ReplacePlaceholderWithArray();

        if ($this->arrayPointer >= $this->arrayCount) return false;

        return true;
    }
    public function key() {
        $this->dorm_ReplacePlaceholderWithArray();
        return key($this->array);
    }
    public function next() {
        $this->dorm_ReplacePlaceholderWithArray();
        $this->arrayPointer++;
        return next($this->array);
    }
    public function seek($position) {
        $this->dorm_ReplacePlaceholderWithArray();
        return $this->array[$position];
    }

    public function offsetExists($offset) {
        $this->dorm_ReplacePlaceholderWithArray();
        return isset($this->array[$offset]);
    }
    public function offsetSet($offset, $value) {
        $this->dorm_ReplacePlaceholderWithArray();
        $this->array[$offset] = $value;
    }
    public function offsetGet($offset) {
        $this->dorm_ReplacePlaceholderWithArray();
        return $this->array[$offset];
    }
    public function offsetUnset($offset) {
        $this->dorm_ReplacePlaceholderWithArray();
        unset($this->array[$offset]);
    }

    private function dorm_ReplacePlaceholderWithArray() {
        if (!isset($this->array)) {
            $property_name = $this->dorm_Property->getName();
            $this->array =& $this->dorm_Parent->_->$property_name;
            $this->dorm_Dorm->getDataMapper($this->dorm_Parent)->loadObjectArray(
                $this->dorm_Parent,
                $this->dorm_Property
            );
            $this->arrayCount = count($this->array);
        }
    }
}