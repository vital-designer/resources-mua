<?php
function TinyMCE_cleanInput($str)
{
				return preg_replace("/[^0-9a-z\\-_,]+/i", "", $str);
}
function TinyMCE_echo($str)
{
				global $cacheData;
				global $diskCache;
				if ($diskCache)
				{
								$cacheData .= $str;
				}
				else
				{
								echo $str;
				}
}
$suffix = "";
$expiresOffset = 864000;
$diskCache = false;
$cacheDir = realpath(".");
$debug = false;
header("Content-type: text/javascript; charset: UTF-8");
header("Vary: Accept-Encoding");
header("Expires: " . gmdate("D, d M Y H:i:s", time() + $expiresOffset) . " GMT");
$theme = isset($_GET['theme']) ? tinymce_cleaninput($_GET['theme']) : "";
$language = isset($_GET['language']) ? tinymce_cleaninput($_GET['language']) : "";
$plugins = isset($_GET['plugins']) ? tinymce_cleaninput($_GET['plugins']) : "";
$lang = isset($_GET['lang']) ? tinymce_cleaninput($_GET['lang']) : "en";
$index = isset($_GET['index']) ? tinymce_cleaninput($_GET['index']) : -1;
$cacheKey = md5($theme . $language . $plugins . $lang . $index . $debug);
$cacheFile = $cacheDir == "" ? "" : $cacheDir . "/" . "tinymce_" . $cacheKey . ".gz";
$cacheData = "";
if (!function_exists("file_get_contents"))
{
				function file_get_contents($filename)
				{
								$fd = fopen($filename, "rb");
								$content = fread($fd, filesize($filename));
								fclose($fd);
								return $content;
				}
}
$encodings = array();
if (isset($_SERVER['HTTP_ACCEPT_ENCODING']))
{
				$encodings = explode(",", strtolower(preg_replace("/\\s+/", "", $_SERVER['HTTP_ACCEPT_ENCODING'])));
}
if ((in_array("gzip", $encodings) || in_array("x-gzip", $encodings) || isset($_SERVER['---------------'])) && function_exists("ob_gzhandler") && !ini_get("zlib.output_compression"))
{
				$enc = in_array("x-gzip", $encodings) ? "x-gzip" : "gzip";
				if (file_exists($cacheFile) && !$debug)
				{
								header("Content-Encoding: " . $enc);
								echo file_get_contents($cacheFile);
								exit();
				}
				if (!$diskCache)
				{
								ob_start("ob_gzhandler");
				}
}
else
{
				$diskCache = false;
}
if (-1 < $index)
{
				if ($index == 0)
				{
								tinymce_echo(file_get_contents(realpath("tiny_mce" . $suffix . ".js")));
								tinymce_echo("TinyMCE.prototype.orgLoadScript = TinyMCE.prototype.loadScript;");
								tinymce_echo("TinyMCE.prototype.loadScript = function() {};var realTinyMCE = tinyMCE;");
				}
				else
				{
								tinymce_echo("tinyMCE = realTinyMCE;");
				}
				tinymce_echo("tinyMCE.init(tinyMCECompressed.configs[" . $index . "]);");
				if ($index == 0)
				{
								tinymce_echo("tinyMCECompressed.loadPlugins();");
				}
				if ($theme)
				{
								tinymce_echo(file_get_contents(realpath("themes/" . $theme . "/editor_template" . $suffix . ".js")));
								tinymce_echo(file_get_contents(realpath("themes/" . $theme . "/langs/" . $lang . ".js")));
				}
				if ($language)
				{
								tinymce_echo(file_get_contents(realpath("langs/" . $language . ".js")));
				}
				$plugins = explode(",", $plugins);
				foreach ($plugins as $plugin)
				{
								$pluginFile = realpath("plugins/" . $plugin . "/editor_plugin" . $suffix . ".js");
								$languageFile = realpath("plugins/" . $plugin . "/langs/" . $lang . ".js");
								if ($pluginFile)
								{
												tinymce_echo(file_get_contents($pluginFile));
								}
								if ($languageFile)
								{
												tinymce_echo(file_get_contents($languageFile));
								}
				}
				tinymce_echo("tinyMCE = tinyMCECompressed;");
				if ($diskCache)
				{
								if ($debug)
								{
												$ratio = round(100 - strlen(gzencode($cacheData, 9, FORCE_GZIP)) / strlen($cacheData) * 100);
												tinymce_echo("alert('TinyMCE was compressed by " . $ratio . "%.\\nOutput cache file: " . $cacheFile . "');");
								}
								$cacheData = gzencode($cacheData, 9, FORCE_GZIP);
								$fp = @fopen($cacheFile, "wb");
								if ($fp)
								{
												fwrite($fp, $cacheData);
												fclose($fp);
								}
								header("Content-Encoding: " . $enc);
								echo $cacheData;
				}
				exit();
}
?>
function TinyMCECompressed()
{
	this.configs = new Array();
	this.loadedFiles = new Array();
	this.externalPlugins = new Array();
	this.loadAdded = false;
	this.isLoaded = false;
}
TinyMCECompressed.prototype.init = function(settings)
{
	var elements = document.getElementsByTagName('script');
	var scriptURL = "";
	for (var i=0; i < elements.length; i++)
	{
		if (elements[i].src && elements[i].src.indexOf("tiny_mce_gzip.php") != -1)
		{
			scriptURL = elements[i].src;
			break;
		}
	}
	settings["theme"] = typeof(settings["theme"]) != "undefined" ? settings["theme"] : "default";
	settings["plugins"] = typeof(settings["plugins"]) != "undefined" ? settings["plugins"] : "";
	settings["language"] = typeof(settings["language"]) != "undefined" ? settings["language"] : "en";
	settings["button_tile_map"] = typeof(settings["button_tile_map"]) != "undefined" ? settings["button_tile_map"] : true;

	this.configs[this.configs.length] = settings;
	this.settings = settings;
	scriptURL += "?theme=" + escape(this.getOnce(settings["theme"])) + "&language=" + escape(this.getOnce(settings["language"])) + "&plugins=" + escape(this.getOnce(settings["plugins"])) + "&lang=" + settings["language"] + "&index=" + escape(this.configs.length-1);
	document.write('<sc'+'ript language="javascript" type="text/javascript" src="' + scriptURL + '"></script>');
	if (!this.loadAdded)
	{
		tinyMCE.addEvent(window, "DOMContentLoaded", TinyMCECompressed.prototype.onLoad);
		tinyMCE.addEvent(window, "load", TinyMCECompressed.prototype.onLoad);
		this.loadAdded = true;
	}
}
TinyMCECompressed.prototype.onLoad = function()
{
	if (tinyMCE.isLoaded)
		return true;
		tinyMCE = realTinyMCE;
		TinyMCE_Engine.prototype.onLoad();
		tinyMCE._addUnloadEvents();
		tinyMCE.isLoaded = true;
}
TinyMCECompressed.prototype.addEvent = function(o, n, h)
{
	if (o.attachEvent)
		o.attachEvent("on" + n, h);
	else
		o.addEventListener(n, h, false);
}
TinyMCECompressed.prototype.getOnce = function(str)
{
	var ar = str.replace(/\\s+/g, '').split(',');
	for (var i=0; i < ar.length; i++)
	{
		if (ar[i] == '' || ar[i].charAt(0) == '-')
		{
			ar[i] = null;
			continue;
		}
		for (var x=0; x < this.loadedFiles.length; x++)
		{
			if (this.loadedFiles[x] == ar[i])
			ar[i] = null;
		}
		this.loadedFiles[this.loadedFiles.length] = ar[i];
	}
	// Glue
	str = "";
	for (var i=0; i < ar.length; i++)
	{
		if (ar[i] == null)
			continue;
			str += ar[i];
			if (i != ar.length-1)
			str += ",";
	}
	return str;
};
TinyMCECompressed.prototype.loadPlugins = function() {
	var i, ar;
	TinyMCE.prototype.loadScript = TinyMCE.prototype.orgLoadScript;
	tinyMCE = realTinyMCE;
	ar = tinyMCECompressed.externalPlugins;
	for (i=0; i < ar.length; i++)
		tinyMCE.loadPlugin(ar[i].name, ar[i].url);
		TinyMCE.prototype.loadScript = function() {};
};
TinyMCECompressed.prototype.loadPlugin = function(n, u) {
	this.externalPlugins[this.externalPlugins.length] = {name : n, url : u};
};
TinyMCECompressed.prototype.importPluginLanguagePack = function(n, v) {
	tinyMCE = realTinyMCE;
	TinyMCE.prototype.loadScript = TinyMCE.prototype.orgLoadScript;
	tinyMCE.importPluginLanguagePack(n, v);
};
TinyMCECompressed.prototype.addPlugin = function(n, p) {
	tinyMCE = realTinyMCE;
	tinyMCE.addPlugin(n, p);
};
var tinyMCE = new TinyMCECompressed();
var tinyMCECompressed = tinyMCE;
<?php

?>