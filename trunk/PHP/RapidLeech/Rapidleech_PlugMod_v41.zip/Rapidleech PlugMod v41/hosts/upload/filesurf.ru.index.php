<?php
$upload_services[]="filesurf.ru";
$max_file_size["filesurf.ru"]=100;
$page_upload["filesurf.ru"] = "filesurf.ru.php";  
?>