<?php
include ("../common.php");
include ("../include/users_function.php");
include ("../include/class.form.php");
ini_set("display_errors", "0");
if (isset($_GET['id']))
{
				$smarty->assign("razdel", "Subscriber");
				$smarty->assign("description", "View subscriber details");
				$form_class = new form($dbconn, $config);
				$user_attrs = array();
				$count = 0;
				$attrs = $form_class->getallattributes($count);
				foreach ($attrs as $index => $attr)
				{
								$temp = $form_class->getuserattribute($_GET['id'], $attr['id'], true);
								if ($temp === false)
								{
								}
								else
								{
												$user_attrs[$attr['id']] = $temp;
								}
				}
				$smarty->assign("attrs", $attrs);
				$smarty->assign("user_attrs", $user_attrs);
				$smarty->display("{$admin_nl_gentemplates}/view_user_details.tpl");
}
?>