<?php
function showform($id_form, $id_block = 0, $id_section = 0, $err = "")
{
				global $smarty;
				global $dbconn;
				global $config;
				global $admin_nl_gentemplates;
				$file_name = isset($_SERVER['PHP_SELF']) ? basename($_SERVER['PHP_SELF']) : "form_fields.php";
				$form = new form($dbconn, $config);
				$sections = $form->getsections();
				if ($id_section == 0 && isset($sections[0]))
				{
								$id_section = $sections[0]['id'];
				}
				$smarty->assign("sections", $sections);
				$smarty->assign("blocks", $blocks);
				$smarty->assign("blocks_count", count($blocks));
				$smarty->assign("id_section", $id_section);
				$smarty->assign("id_form", $id_form);
				$smarty->assign("id_block", $id_block);
				$smarty->assign("button", $lang['button']);
				$smarty->assign("header", $lang['forms']);
				$smarty->display("{$admin_nl_gentemplates}/forms_fields_edit.tpl");
				exit();
}
include_once ("../common.php");
include ("../include/class.form.php");
include ("../include/forms_function.php");
$section = "forms";
$right_name = "edit";
check_right($section, $right_name);
$smarty->assign("razdel", "Forms");
$smarty->assign("description", "Manage Addtitional Form Fields");
$sel = $_GET['sel'] ? $_GET['sel'] : $_POST['sel'];
$id_form = intval($_REQUEST['id']);
do
{
				showform($id_form, 0, $id_section);
				break;
} while (!true);
?>
