<?php
function getreleasesinfo($orderby = "", $archive_page = 0)
{
				global $dbconn;
				global $smarty;
				global $config;
				if (isset($_GET['p']) && 0 < $_GET['p'])
				{
								$p = $_GET['p'];
				} else
				{
								$p = 0;
				}
				$end = $_SESSION['is_desc'] && !$_GET['is_nav'] || !$_SESSION['is_desc'] && $_GET['is_nav'] ? " desc " : "";
				if ($orderby)
				{
								$is_nav = isset($_GET['is_nav']) ? $_GET['is_nav'] : false;
								if (!$is_nav && $orderby == $_SESSION['order'])
								{
												if ($_SESSION['is_desc'])
												{
																$GLOBALS['_SESSION']['is_desc'] = false;
																$end = " desc ";
												} else
												{
																$GLOBALS['_SESSION']['is_desc'] = true;
																$end = "";
												}
								}
								$sql .= " order by " . $orderby . $end;
								if ($orderby == "date")
								{
												$sql_date = "order by " . $orderby . $end;
												$sql = "order by subject";
								}
				} else
				{
								$sql .= "order by subject";
				}
				$smarty->assign("end", trim($end));
				$res2 = $dbconn->execute("select distinct(date_format(date,'%Y-%m-%d')) from clients_releases ");
				$c = 0;
				while (!$res2->EOF)
				{
								$res3 = $dbconn->execute("select distinct a.subject,a.id from creleases a left join clients_releases b on (a.id=b.release_id) where date_format(b.date, '%Y-%m-%d')='" . $res2->fields[0] . "'");
								while (!$res3->EOF)
								{
												++$c;
												$res3->movenext();
								}
								$res2->movenext();
				}
				$amount = $c;
				$smarty->assign("navigation", create_navigation($amount, $archive_page, "archive_page={$archive_page}&order=" . $_GET['order'] . "&is_nav=true", "sent_newsletters.php", $p, "archive_page"));
				get_smarty_array_list("archive_page", $config['archive_page']);
				$per_page = $config['archive_page'][$archive_page];
				$rel = array();
				$c = -1;
				$count_on_page = 0;
				$res2 = $dbconn->execute("select distinct(date_format(date,'%Y-%m-%d'))  from clients_releases " . $sql_date);
				while (!$res2->EOF)
				{
								$res3 = $dbconn->execute("select distinct a.subject, a.id, a.is_sent, a.priority, a.is_attach, a.format from creleases a left join clients_releases b on (a.id=b.release_id) where date_format(b.date, '%Y-%m-%d')='" . $res2->fields[0] . "' " . $sql);
								while (!$res3->EOF)
								{
												++$c;
												if ($c < $per_page * $p)
												{
																$res3->movenext();
												} else
												{
																$rel[$count_on_page]['id'] = $res3->fields[1];
																$rel[$count_on_page]['date'] = $res2->fields[0];
																$rel[$count_on_page]['subject'] = stripslashes($res3->fields[0]);
																$rel[$count_on_page]['status'] = $res3->fields[2];
																$rel[$count_on_page]['priority'] = $res3->fields[3];
																$rel[$count_on_page]['is_attach'] = $res3->fields[4];
																$rel[$count_on_page]['format'] = $res3->fields[5];
																if ($res3->fields[2] == 2)
																{
																				$rel[$count_on_page]['subject'] .= " (In process)";
																}
																$res4 = $dbconn->execute("select count(distinct(client_id)) from clients_releases where release_id='" . $res3->fields[1] . "' and is_sent='1' and date_format(date, '%Y-%m-%d')='" . $res2->fields[0] . "'");
																$rel[$count_on_page]['get'] = $res4->fields[0];
																$res4 = $dbconn->execute("select count(distinct(id)) from click_counter where release_id='" . $res3->fields[1] . "'");
																$rel[$count_on_page]['link'] = $res4->fields[0];
																$res4 = $dbconn->execute("select count(distinct(id)) from click_counter where release_id='" . $res3->fields[1] . "' and url='uns'");
																$rel[$count_on_page]['uns'] = $res4->fields[0];
																$res4 = $dbconn->execute("select count(distinct(client_id)) from clients_releases where release_id='" . $res3->fields[1] . "' and is_sent='0' and date_format(date, '%Y-%m-%d')='" . $res2->fields[0] . "'");
																$rel[$count_on_page]['left'] = $res4->fields[0];
																$res4 = $dbconn->execute("select count(distinct(client_id)) from clients_releases where release_id='" . $res3->fields[1] . "' and is_sent='2' and date_format(date, '%Y-%m-%d')='" . $res2->fields[0] . "'");
																$rel[$count_on_page]['error'] = $res4->fields[0];
																++$count_on_page;
																if ($count_on_page == $per_page)
																{
																				break;
																} else
																{
																				$res3->movenext();
																}
												}
								}
								$res2->movenext();
				}
				$smarty->assign("amount", $amount);
				return $rel;
}
function getrelease($id)
{
				global $dbconn;
				global $config;
				//echo "select * from creleases where id='" . $id . "'";
				$res = $dbconn->execute("select * from creleases where id='" . $id . "'");
				$rel = array();
				$rel['id'] = $res->fields[0];
				$rel['subject'] = stripslashes($res->fields[1]);
				$rel['date'] = stripslashes($res->fields[3]);
				$rel['format'] = $res->fields[4];
				$rel['priority'] = $res->fields[5];
				$rel['date_send'] = stripslashes($res->fields[6]);
				$rel['status'] = $res->fields[10];
				$rel['subject'] .= " (" . $rel['format'] . "). Created on " . $rel['date'];
				$rel['priority'] = $config['priority'][$rel['priority']];
				if ($rel['status'] == 0)
				{
								$rel['status'] = "Not sent";
				} else
								if ($rel['status'] == 1)
								{
												$rel['status'] = "Sent";
								} else
												if ($rel['status'] == 2)
												{
																$rel['status'] = "In process";
												}
				$rs_attach = $dbconn->execute("select * from attach where id_crelease='" . $id . "'");
				$attach = "";
				$a = 0;
				$rs_attach = $dbconn->execute("select * from release_attach ra, attach a where ra.release_id='" . $rid . "' and ra.attach_id=a.id");
				while (!$rs_attach->EOF)
				{
								$row = $rs_attach->getrowassoc(false);
								$attach .= "<a title='View file' href='" . $config['files_path'] . "/" . $row['file_name'] . "' target='_blank'>" . $row['file_name'] . " (" . file_size($config['files_path'] . "/" . $row['file_name']) . ")</a> &nbsp;&nbsp;";
								++$a;
								$rs_attach->movenext();
				}
				if ($attach == "")
				{
								$rel['attach'] = "No";
				} else
				{
								$rel['attach'] = $attach;
				}
				return $rel;
}
function getclientsinfo($id, $a, $date, $status)
{
				global $dbconn;
				if (trim($status) == "")
				{
								$status = 1;
				}
				$res = $dbconn->execute("select distinct a.id,a.firstname,a.secondname,a.email1,a.company,a.comment, date_format(b.date, '%H:%i') from snd_users a,clients_releases b\r\n                         where b.client_id=a.id and b.release_id='" . $id . "' and b.is_sent='" . $status . "' and date_format(b.date,'%Y-%m-%d')='" . $date . "' order by " . $a);
				$clients = array();
				$c = 0;
				while (!$res->EOF)
				{
								$clients[$c]['num'] = $c + 1;
								$clients[$c]['id'] = $res->fields[0];
								$clients[$c]['name'] = stripslashes($res->fields[1]) . " " . stripslashes($res->fields[2]);
								$clients[$c]['email'] = stripslashes($res->fields[3]);
								$clients[$c]['company'] = stripslashes($res->fields[4]);
								$clients[$c]['comment'] = stripslashes($res->fields[5]);
								$clients[$c]['time'] = $res->fields[6];
								++$c;
								$res->movenext();
				}
				return $clients;
}
function getintclientsinfo($id, $a)
{
				global $dbconn;
				$res = $dbconn->execute("select a.id,a.name,a.email1,b.date,b.link from snd_users a,clients_links b\r\n                         where b.client_id=a.id and b.release_id='" . $id . "' and b.date order by " . $a);
				$clients = array();
				$c = 0;
				while (!$res->EOF)
				{
								$clients[$c]['num'] = $c + 1;
								$clients[$c]['id'] = $res->fields[0];
								$clients[$c]['name'] = stripslashes($res->fields[1]);
								$clients[$c]['email'] = stripslashes($res->fields[2]);
								$clients[$c]['date'] = $res->fields[3];
								$clients[$c]['link'] = stripslashes($res->fields[4]);
								++$c;
								$res->movenext();
				}
				return $clients;
}
function getmaxintclients()
{
				global $dbconn;
				$res = $dbconn->execute("select id,firstname,email1,secondname from snd_users");
				$clients = array();
				$c = 0;
				while (!$res->EOF)
				{
								$clients[$c]['num'] = $c + 1;
								$clients[$c]['id'] = $res->fields[0];
								$clients[$c]['name'] = stripslashes($res->fields[1]) . " " . stripslashes($res->fields[3]);
								$clients[$c]['email'] = stripslashes($res->fields[2]);
								$res2 = $dbconn->execute("select max(date),count(link) from clients_links where client_id='" . $res->fields[0] . "'");
								if (empty($res2->fields[0]))
								{
												$clients[$c]['date'] = "-";
								} else
								{
												$clients[$c]['date'] = $res2->fields[0];
								}
								$clients[$c]['links'] = $res2->fields[1];
								++$c;
								$res->movenext();
				}
				return $clients;
}
function getunsubscribed()
{
				global $dbconn;
				$res = $dbconn->execute("select id,email1,firstname,company,country,comment,uns_date,secondname from snd_users where uns_date IS NOT NULL");
				$clients = array();
				$c = 0;
				while (!$res->EOF)
				{
								$clients[$c]['num'] = $c + 1;
								$clients[$c]['id'] = $res->fields[0];
								$clients[$c]['email'] = stripslashes($res->fields[1]);
								$clients[$c]['name'] = stripslashes($res->fields[2]) . " " . stripslashes($res->fields[7]);
								$clients[$c]['company'] = stripslashes($res->fields[3]);
								$clients[$c]['country'] = stripslashes($res->fields[4]);
								switch ($res->fields[5])
								{
												case "p":
																$clients[$c]['comment'] = "�������";
																break;
												case "f":
																$clients[$c]['comment'] = "�������������� �������";
																break;
												case "c":
																$clients[$c]['comment'] = "������";
								}
								$clients[$c]['uns_date'] = stripslashes($res->fields[6]);
								$res2 = $dbconn->execute("select count(link) from clients_links where client_id='" . $res->fields[0] . "'");
								$clients[$c]['links'] = $res2->fields[0];
								$res3 = $dbconn->execute("select count(release_id) from clients_releases where client_id='" . $res->fields[0] . "'");
								$clients[$c]['releases'] = $res3->fields[0];
								++$c;
								$res->movenext();
				}
				return $clients;
}
function getlinks($id)
{
				global $dbconn;
				$res = $dbconn->execute("select a.id,a.firstname,a.email1,a.company,a.country,a.secondname from snd_users a\r\n                         where a.id='" . $id . "'");
				$clients = array();
				$clients['id'] = $res->fields[0];
				$clients['name'] = stripslashes($res->fields[1]) . " " . stripslashes($res->fields[5]);
				$clients['email'] = stripslashes($res->fields[2]);
				$clients['company'] = stripslashes($res->fields[3]);
				$clients['country'] = stripslashes($res->fields[4]);
				$res2 = $dbconn->execute("select link,date from clients_links where client_id='" . $id . "' order by date desc");
				$clients['l'] = array();
				$c = 0;
				while (!$res2->EOF)
				{
								$clients['l'][$c]['link'] = $res2->fields[0];
								$clients['l'][$c]['date'] = $res2->fields[1];
								++$c;
								$res2->movenext();
				}
				return $clients;
}
function getallreleases()
{
				global $dbconn;
				$rs = $dbconn->execute("select id,subject,date from creleases order by id");
				$rel = array();
				$c = 0;
				while (!$rs->EOF)
				{
								$rel[$c]['id'] = $rs->fields[0];
								$rel[$c]['subject'] = stripslashes($rs->fields[1]);
								$rel[$c]['date'] = $rs->fields[2];
								++$c;
								$rs->movenext();
				}
				return $rel;
}
function getallclients()
{
				global $dbconn;
				$rs = $dbconn->execute("select id,firstname,secondname,email1 from snd_users order by firstname");
				$rel = array();
				$c = 0;
				while (!$rs->EOF)
				{
								$rel[$c]['id'] = $rs->fields[0];
								$rel[$c]['firstname'] = stripslashes($rs->fields[1]);
								$rel[$c]['secondname'] = stripslashes($rs->fields[2]);
								$rel[$c]['email1'] = $rs->fields[3];
								++$c;
								$rs->movenext();
				}
				return $rel;
}
function getallurls()
{
				global $dbconn;
				$rs = $dbconn->execute("select distinct url from click_counter order by url");
				$rel = array();
				$c = 0;
				while (!$rs->EOF)
				{
								$rel[$c]['url'] = stripslashes($rs->fields[0]);
								++$c;
								$rs->movenext();
				}
				return $rel;
}
function getinterestedsubscribers($rid, $uid, $url)
{
				global $dbconn;
				$sql = " where 1 ";
				if ($rid != 0)
				{
								$sql .= "and a.release_id = '" . $rid . "' ";
				}
				if ($uid != 0)
				{
								$sql .= "and a.client_id = '" . $uid . "' ";
				}
				if (!empty($url))
				{
								$sql .= "and a.url = '" . $url . "' ";
				}
				$rs = $dbconn->execute("select a.id,a.client_id,a.release_id,a.url,a.time,b.firstname,b.secondname,b.email1,c.subject from click_counter a\r\n                            left join snd_users b on (a.client_id=b.id)\r\n                            left join creleases c on (a.release_id=c.id)" . $sql);
				$rel = array();
				$c = 0;
				while (!$rs->EOF)
				{
								$rel[$c]['num'] = $c + 1;
								$rel[$c]['client'] = stripslashes($rs->fields[5]) . " " . stripslashes($rs->fields[6]);
								$rel[$c]['email1'] = stripslashes($rs->fields[7]);
								$rel[$c]['subject'] = stripslashes($rs->fields[8]);
								$rel[$c]['url'] = stripslashes($rs->fields[3]);
								$rel[$c]['time'] = stripslashes($rs->fields[4]);
								++$c;
								$rs->movenext();
				}
				return $rel;
}
?>
