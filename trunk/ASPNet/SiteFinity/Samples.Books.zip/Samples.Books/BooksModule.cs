﻿using System.Collections.Generic;
using Telerik;
using Telerik.Web;
using Samples.Books.WebControls;

namespace Samples.Books
{
    public class BooksModule : WebModule
    {
        /// <summary>
        /// Name of the module
        /// </summary>
        public override string Name
        {
            get
            {
                return "Books";
            }
        }

        /// <summary>
        /// Title of the module
        /// </summary>
        public override string Title
        {
            get
            {
                return "Books";
            }
        }

        /// <summary>
        /// Module description
        /// </summary>
        public override string Description
        {
            get
            {
                return "Sample books module";
            }
        }

        /// <summary>
        ///             Gets information for the controls which would be showed in the toolbox when
        ///             editing a page.
        /// </summary>
        /// <value>
        ///             IList generic collection for the IToolBoxItem objects representing the public
        ///             controls.
        /// </value>
        /// <example>
        /// <code>
        ///             /// &lt;summary&gt;
        ///             /// Gets ToolboxItemCollection with all ToolboxItem objects which register the corresponding control for use in the public part of the CMS system.
        ///             /// &lt;/summary&gt;
        ///             public override IList&lt;IToolboxItem&gt; Controls
        ///             {
        ///                 get
        ///                 {
        ///                     return new List&lt;IToolboxItem&gt;(new ToolboxItem[] { new JobListToolboxItem(), new JobListSummaryToolboxItem() });
        ///                 }
        ///             }
        /// </code>
        /// </example>
        /// <remarks>
        ///                 Each module public control should be represented as a IToolboxItem object which
        ///                 contains information for the type of the control it reffers to as well as a title
        ///                 and description information. For more information take a look at the
        ///                 <see cref="T:Telerik.Web.IToolboxItem">IToolBoxItem</see> interface.
        /// </remarks>
        public override IList<IToolboxItem> Controls
        {
            get
            {
                // no public controls for the sample module
                return new List<IToolboxItem>();
            }
        }

        /// <summary>
        /// Creates ControlPanel control which is the main container for the module
        /// administration.
        /// </summary>
        /// <param name="parent">Specifies the container in which the ControlPanel control will be
        /// rendered.</param>
        /// <returns>
        /// Returns the ControlPanel control instance which is the main container for the
        /// module administration.
        /// </returns>
        /// <remarks>
        /// The ControPanel control is usually rendered in the right side of the administration
        /// part for a module. It should inherit the
        /// <see cref="T:Telerik.Web.IControlPanel">Telerik.Web.IControlPanel</see> interface.
        /// Usually the ControlPanel controls inherit the
        /// <see cref="T:Telerik.Web.ControlPanelBase">Telerik.Web.ControlPanelBase</see> class
        /// which in its turn inherits the
        /// <see cref="T:Telerik.Web.IControlPanel">Telerik.Web.IControlPanel</see> and provides
        /// basic implementation for the ControlPanel controls.
        /// </remarks>
        /// <example>
        /// 	<code lang="CS" title="CreateControlPanel implementation" description="The following example provides sample implementation of the CreateControlPanel method. It simply returns instance of a control which inherits from ControlPanelBase class and IControlPanel respectively">
        /// /// &lt;summary&gt;
        /// /// Creates the ControlPanel object which is rendered on the right side of the screen.
        /// /// &lt;/summary&gt;
        /// /// &lt;returns&gt;Instance of the ControlPanel object of the module.&lt;/returns&gt;
        /// public override System.Web.UI.Control CreateControlPanel(System.Web.UI.TemplateControl parent)
        /// {
        /// return new Telerik.Samples.Jobs.Pluggable.WebControls.ControlPanel();
        /// }
        /// </code>
        /// </example>
        public override System.Web.UI.Control CreateControlPanel(System.Web.UI.TemplateControl parent)
        {
            return new BooksControlPanel();
        }

    }
}
