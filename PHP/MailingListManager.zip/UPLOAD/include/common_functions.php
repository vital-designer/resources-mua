<?php
function get_smarty_list($control, $table)
{
				global $smarty;
				global $values_global;
				global $output_global;
				$values = array();
				$output = array();
				get_list($values, $output, $table);
				$smarty->assign(array($control . "_values" => $values, $control . "_output" => $output));
				$values_global = $values;
				$output_global = $output;
}
function get_smarty_condition_list($control, $table, $condition)
{
				global $smarty;
				$values = array();
				$output = array();
				get_condition_list($values, $output, $table, $condition);
				$smarty->assign(array($control . "_values" => $values, $control . "_output" => $output));
}
function get_smarty_array_list($control, $arr)
{
				global $smarty;
				$smarty->assign(array($control . "_values" => range(0, count($arr) - 1), $control . "_output" => $arr));
}
function get_smarty_numeric_list($control, $from, $to, $step = 1)
{
				global $smarty;
				if ($step == 1)
				{
								$arr = range($from, $to);
				} else
				{
								$arr = array();
								$i = $from;
								for (; $i <= $to; $i += $step)
								{
												$arr[] = $i;
								}
				}
				$smarty->assign(array($control . "_values" => $arr, $control . "_output" => $arr));
}
function get_list(&$values, &$output, $table, $ord = 1)
{
				global $dbconn;
				$rs = $dbconn->execute("SELECT id, name FROM {$table} ORDER BY {$ord}");
				while (!$rs->EOF)
				{
								$values[] = stripslashes($rs->fields[0]);
								$output[] = stripslashes($rs->fields[1]);
								$rs->movenext();
				}
}
function get_values_list($table)
{
				global $dbconn;
				$values = array();
				$i = 0;
				$rs = $dbconn->execute("SELECT id, name FROM {$table} ORDER BY name");
				while (!$rs->EOF)
				{
								$values['id'][$i] = $rs->fields[0];
								$values['name'][$i] = $rs->fields[1];
								++$i;
								$rs->movenext();
				}
				return $values;
}
function get_list_rev(&$values, &$output, $table)
{
				global $dbconn;
				$rs = $dbconn->execute("SELECT id, name FROM {$table} ORDER BY id DESC");
				while (!$rs->EOF)
				{
								$values[] = stripslashes($rs->fields[0]);
								$output[] = stripslashes($rs->fields[1]);
								$rs->movenext();
				}
}
function get_condition_list(&$values, &$output, $table, $condition)
{
				global $dbconn;
				$rs = $dbconn->execute("SELECT id, name FROM {$table} WHERE {$condition} ORDER BY id");
				while (!$rs->EOF)
				{
								$values[] = stripslashes($rs->fields[0]);
								$output[] = stripslashes($rs->fields[1]);
								$rs->movenext();
				}
}
function get_month_short($value)
{
				$month_eng = array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
				$month_fr = array("Janvier", "F&eacute;vrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Ao&ucirc;t", "Septembre", "Octobre", "Novembre", "D&eacute;cembre");
				return $month_eng[$value - 1];
}
function date_to_iso($fr_date)
{
				$res = "";
				$a = explode("/", $fr_date);
				if (count($a) == 3 && checkdate($a[1], $a[0], $a[2]))
				{
								$res = sprintf("%04d-%02d-%02d", $a[2], $a[1], $a[0]);
				}
				return $res;
}
function date_to_french($fr_date)
{
				$res = "";
				if (0 < strpos($fr_date, " "))
				{
								$a = explode(" ", $fr_date);
								$fr_date = $a[0];
				}
				$a = explode("-", $fr_date);
				if (count($a) == 3 && checkdate($a[1], $a[2], $a[0]))
				{
								$res = sprintf("%02d/%02d/%04d", $a[2], $a[1], $a[0]);
				}
				return $res;
}
function date_to_usa($fr_date)
{
				$res = "";
				$a = explode("-", $fr_date);
				if (count($a) == 3 && checkdate($a[1], $a[2], $a[0]))
				{
								$res = sprintf("%02d/%02d/%04d", $a[1], $a[2], $a[0]);
				}
				return $res;
}
function date_to_iso1($value)
{
				$b = preg_split("/\\s+/", $value);
				$fr_date = $b[0];
				$fr_time = explode(":", $b[1]);
				$hour = $fr_time[0];
				$minute = $fr_time[1];
				$second = $fr_time[2];
				$res = "";
				$a = explode("/", $fr_date);
				if (count($a) == 3 && checkdate($a[1], $a[0], $a[2]) && $hour < 24 && 0 <= $hour && $minute < 60 && 0 <= $minute && $second < 60 && 0 <= $second)
				{
								$res = sprintf("%04d-%02d-%02d", $a[2], $a[1], $a[0]) . " {$b['1']}";
				}
				return $res;
}
function date_to_french1($value)
{
				$res = "";
				$b = preg_split("/\\s+/", $value);
				$fr_date = $b[0];
				$fr_time = $b[1];
				$a = explode("-", $fr_date);
				if (count($a) == 3 && checkdate($a[1], $a[2], $a[0]))
				{
								$res = sprintf("%02d/%02d/%04d", $a[2], $a[1], $a[0]) . " {$fr_time}";
				}
				return $res;
}
function date_to_french_short($fr_date)
{
				$res = "";
				$a = explode("-", $fr_date);
				if (count($a) == 3 && checkdate($a[1], $a[2], $a[0]))
				{
								$res = sprintf("%02d/%02d", $a[2], $a[1]);
				}
				return $res;
}
function date_to_chat1($fr_date)
{
				$res = "";
				$b = explode(" ", $fr_date);
				$a = explode("-", $b[0]);
				if (count($a) == 3 && checkdate($a[1], $a[2], $a[0]))
				{
								$res = $b[1];
				}
				return $res;
}
function get_timestamp($date)
{
				$a = split(" ", $date);
				$dat = split("-", $a[0]);
				$tim = split(":", $a[1]);
				$dat_ret = mktime($tim[0], $tim[1], 0, $dat[1], $dat[2], $dat[0]);
				return 0 <= $dat_ret ? $dat_ret : 0;
}
function split_date($date)
{
				if (0 < strpos($date, " "))
				{
								$a = explode(" ", $date);
								$date = $a[0];
				}
				$a = split("-", $date);
				return array($a[2], $a[1], $a[0]);
}
function get_numeric_list(&$values, &$output, $from, $to)
{
				$i = $from;
				for (; $i <= $to; ++$i)
				{
								$values[] = $i;
								$output[] = $i;
				}
}
function get_numeric_list_rev(&$values, &$output, $from, $to)
{
				$i = $from;
				for (; $to <= $i; --$i)
				{
								$values[] = $i;
								$output[] = $i;
				}
}
function get_yesno_list(&$values, &$output)
{
				$values = array(1, 0);
				$output = array("Yes", "No");
}
function get_yesno_value($value)
{
				switch ($value)
				{
								case 1:
												return "Yes";
								case 0:
												return "No";
								default:
												return "";
				}
}
function get_value($table, $value, $s = 0)
{
				global $dbconn;
				$rs = $dbconn->execute("SELECT id, name FROM {$table} WHERE id='{$value}'");
				if ($s == 1 && ($rs->rowcount() == 0 || strlen($rs->fields[0]) == 0))
				{
								return "&nbsp;";
				}
				return stripslashes($rs->fields[0]);
}
function get_field($table, $field, $value)
{
				global $dbconn;
				$rs = $dbconn->execute("SELECT {$field} FROM {$table} WHERE id='{$value}'");
				return stripslashes($rs->fields[0]);
}
function createthumb($name, $filename, $new_w, $new_h)
{
				$size = getimagesize($name);
				if ($size[2] == 2)
				{
								$src_img = imagecreatefromjpeg($name);
				} else
								if ($size[2] == 3)
								{
												$src_img = imagecreatefrompng($name);
								}
				$old_x = imagesx($src_img);
				$old_y = imagesy($src_img);
				if ($old_y < $old_x)
				{
								$thumb_w = $new_w;
								$thumb_h = $old_y * ($new_h / $old_x);
				}
				if ($old_x < $old_y)
				{
								$thumb_w = $old_x * ($new_w / $old_y);
								$thumb_h = $new_h;
				}
				if ($old_x == $old_y)
				{
								$thumb_w = $new_w;
								$thumb_h = $new_h;
				}
				$dst_img = imagecreate($thumb_w, $thumb_h);
				imagecopyresized($dst_img, $src_img, 0, 0, 0, 0, $thumb_w, $thumb_h, $old_x, $old_y);
				if ($size[2] == 2)
				{
								imagejpeg($dst_img, $filename);
				} else
								if ($size[2] == 3)
								{
												imagepng($dst_img, $filename);
								}
				imagedestroy($dst_img);
				imagedestroy($src_img);
}
function check_available($value)
{
				if (0 < strlen(trim($value)))
				{
								return $value;
				} else
				{
								return "N/A";
				}
}
function is_image_acceptable($f)
{
				$size = getimagesize($f);
				if ($size[2] != 1 && $size[2] != 2 && $size[2] != 3)
				{
								return false;
				} else
				{
								return true;
				}
}
function is_image_size_acceptable($f)
{
				global $config;
				$size = getimagesize($f);
				if ($config['max_image_x'] < $size[0] || $config['max_image_y'] < $size[1])
				{
								return false;
				} else
				{
								return true;
				}
}
function get_image_type($f)
{
				if (preg_match("/^.+\\.mpeg\$/", $f) || preg_match("/^.+\\.mpg\$/", $f) || preg_match("/^.+\\.avi\$/", $f))
				{
								return 1;
				} else
				{
								return 0;
				}
}
function is_image_acceptable_admin($f)
{
				if (preg_match("/^.+\\.mpeg\$/", $f) || preg_match("/^.+\\.mpg\$/", $f) || preg_match("/^.+\\.avi\$/", $f) || preg_match("/^.+\\.jpg\$/", $f) || preg_match("/^.+\\.jpe\$/", $f) || preg_match("/^.+\\.jpeg\$/", $f) || preg_match("/^.+\\.png\$/", $f))
				{
								return true;
				} else
				{
								return false;
				}
}
function create_navigation($jobs_total, $user_page, $params, $script_name, $p, $who = "user_page")
{
				global $dbconn;
				global $config;
				$per_page = $config[$who][$user_page];
				$pages_total = ceil($jobs_total / $per_page);
				$page_start = $p < 9 ? 1 : $p - 4;
				$page_stop = $page_start + 9 < $pages_total ? $page_start + 9 : $pages_total;
				$job_start = $jobs_total == 0 ? 0 : $p * $per_page + 1;
				$job_stop = ($p + 1) * $per_page;
				if ($jobs_total < $job_stop)
				{
								$job_stop = $jobs_total;
				}
				$nav_arr = array();
				if (0 < $p)
				{
								$nav_arr[] = "<a href=\"{$script_name}?p=0&{$params}\">&lt;&lt;</a>";
								$nav_arr[] = "<a href=\"{$script_name}?p=" . ($p - 1) . "&{$params}\">&lt;</a>";
				}
				if (1 < $pages_total)
				{
								$i = $page_start;
								for (; $i <= $page_stop; ++$i)
								{
												if ($i == $p + 1)
												{
																$nav_arr[] = "<b>{$i}</b>";
												} else
												{
																$nav_arr[] = "<a href=\"{$script_name}?p=" . ($i - 1) . "&{$params}\">{$i}</a>";
												}
								}
				}
				if ($p < $pages_total - 1)
				{
								$nav_arr[] = "<a href=\"{$script_name}?p=" . ($p + 1) . "&{$params}\">&gt;</a>";
								$nav_arr[] = "<a href=\"{$script_name}?p=" . ($pages_total - 1) . "&{$params}\">&gt;&gt;</a>";
				}
				$navigation = join("&nbsp;|&nbsp;", $nav_arr);
				return $navigation;
}
function url_redirect($url)
{
				header("Location: " . $url);
				exit();
}
function count_days($start, $end)
{
				if ($start != "0000-00-00" && $end != "0000-00-00")
				{
								$timestamp_start = strtotime($start);
								$timestamp_end = strtotime($end);
								if ($timestamp_end <= $timestamp_start)
								{
												return 0;
								}
								$start_year = date("Y", $timestamp_start);
								$end_year = date("Y", $timestamp_end);
								$num_days_start = date("z", strtotime($start));
								$num_days_end = date("z", strtotime($end));
								$num_days = 0;
								$i = 0;
								while ($start_year < $end_year && $i < $end_year - $start_year)
								{
												$num_days = $num_days + date("z", strtotime($start_year + $i . "-12-31"));
												++$i;
								}
								return $num_days_end + $num_days - $num_days_start + 1;
				} else
				{
								return 0;
				}
}
function resizeimage($path, $width_to, $height_to)
{
				global $dbconn;
				if (file_exists($path) && extension_loaded("gd"))
				{
								$image_info = getimagesize($path);
								$image_width = $image_info[0];
								$image_height = $image_info[1];
								$image_type = $image_info[2];
								if ($width_to < $image_width || $height_to < $image_height)
								{
												if ($config_index['use_image_resize'])
												{
																$st = resizeaction($path, $image_type, $image_width, $image_height, $width_to, $height_to);
												} else
												{
																$st = true;
												}
												if ($st)
												{
																return true;
												} else
												{
																return false;
												}
								} else
								{
												return true;
								}
				} else
				{
								return true;
				}
}
function resizeaction($path, $type, $image_width, $image_height, $width_to, $height_to)
{
				switch ($type)
				{
								case "1":
												$srcImage = @imagecreatefromgif($path);
												break;
								case "2":
												$srcImage = @imagecreatefromjpeg($path);
												break;
								case "3":
												$srcImage = @imagecreatefrompng($path);
												break;
								case "6":
												$srcImage = @imagecreatefromwbmp($path);
				}
				$srcWidth = imagesx($srcImage);
				$srcHeight = imagesy($srcImage);
				if ($width_to < $image_width)
				{
								$image_height = round($image_height * $width_to / $image_width);
								$image_width = $width_to;
				}
				if ($height_to < $image_height)
				{
								$image_width = round($image_width * $height_to / $image_height);
								$image_height = $height_to;
				}
				$destImage = imagecreate($image_width, $image_height);
				imagecopyresized($destImage, $srcImage, 0, 0, 0, 0, $image_width, $image_height, $srcWidth, $srcHeight);
				switch ($type)
				{
								case "1":
												imagegif($destImage, $path);
												break;
								case "2":
												imagejpeg($destImage, $path);
												break;
								case "3":
												imagepng($destImage, $path);
												break;
								case "6":
												imagewbmp($destImage, $path);
				}
				imagedestroy($srcImage);
				imagedestroy($destImage);
				return true;
				return false;
}
function file_size($file)
{
				if (!is_file($file))
				{
								echo "File {$file} does not exist!";
				}
				$kb = 1024;
				$mb = 1024 * $kb;
				$gb = 1024 * $mb;
				$tb = 1024 * $gb;
				$size = filesize($file);
				if ($size < $kb)
				{
								return $size . " B";
				} else
								if ($size < $mb)
								{
												return round($size / $kb, 2) . " KB";
								} else
												if ($size < $gb)
												{
																return round($size / $mb, 2) . " MB";
												} else
																if ($size < $tb)
																{
																				return round($size / $gb, 2) . " GB";
																} else
																{
																				return round($size / $tb, 2) . " TB";
																}
}
function delete_dir($file)
{
				chmod($file, 511);
				if (is_dir($file))
				{
								$handle = opendir($file);
								while ($filename = readdir($handle))
								{
												if ($filename != "." && $filename != "..")
												{
																delete_dir($file . "/" . $filename);
												}
								}
								closedir($handle);
								rmdir($file);
				} else
				{
								unlink($file);
				}
}
function getlistsfilled()
{
				global $dbconn;
				global $config;
				$res = $dbconn->execute("select id, name, date,owner_name,owner_email from list order by id");
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$res2 = $dbconn->execute("select count(*) from clients_lists where list_id='" . $res->fields[0] . "' and status_subscribe<>'" . $config['status_subscribe_val']['unsubscribe'] . "'");
								if (0 < $res2->fields[0])
								{
												$releases[$c]['count'] = $res2->fields[0];
												$releases[$c]['id'] = $res->fields[0];
												$releases[$c]['name'] = stripslashes($res->fields[1]);
												$releases[$c]['date'] = $res->fields[2];
												$releases[$c]['owner_name'] = $res->fields[3];
												$releases[$c]['owner_email'] = $res->fields[4];
												++$c;
								}
								$res->movenext();
				}
				return $releases;
}
function str_prepare($s)
{
				return addslashes(trim($s));
}
function emailtext($email, $subj, $text, $from_name, $from_email)
{
				global $config;
				$headers = "From: " . $from_name . " <" . $from_email . ">\r\n";
				$headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
				$headers .= "X-Priority: 0\r\n";
				$headers .= "MIME-Version: 1.0\r\n";
				$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
				@mail($email, $subj, $text, $headers);
}
function check_right($section, $right_name)
{
				global $dbconn;
				global $config;
				global $group_right;
				global $right;
				if (0 < $_SESSION['admin_id'])
				{
								if (!isset($right[$section][$right_name]['code']) || !isset($group_right[$section]['code']))
								{
												header("Location: " . $config['server'] . "/not_right.php");
												exit();
								} else
								{
												$res = $dbconn->execute("SELECT count(*) FROM group_right WHERE group_id='" . $_SESSION['group_id'] . "' AND section_id='" . $group_right[$section]['code'] . "' AND right_id='" . $right[$section][$right_name]['code'] . "'");
												if (0 < $res->fields[0])
												{
																return true;
												} else
												{
																header("Location: " . $config['server'] . "/not_right.php");
																exit();
												}
								}
				} else
				{
								return true;
				}
}
?>
