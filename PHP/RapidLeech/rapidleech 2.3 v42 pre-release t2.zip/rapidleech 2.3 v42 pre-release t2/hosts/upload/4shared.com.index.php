<?php 
$upload_services[] = "4shared.com";
$max_file_size["4shared.com"] = 100;
$page_upload["4shared.com"] = "4shared.com.php";  
?>