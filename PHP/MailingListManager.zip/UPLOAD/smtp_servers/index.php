<?php
include ("../common.php");
include ("../include/smtp_servers_function.php");
$section = "settings";
$right_name = "view_smtp";
check_right($section, $right_name);
if (isset($_POST['del']))
{
				$right_name = "delete_server";
				check_right($section, $right_name);
				foreach ($GLOBALS['_POST']['del'] as $val)
				{
								delserver($val);
				}
}
if (isset($_POST['OrderNum']))
{
				$right_name = "edit_server";
				check_right($section, $right_name);
				foreach ($GLOBALS['_POST']['OrderNum'] as $key => $val)
				{
								if ($_POST['OrderNumOld'][$key] != $val)
								{
												$res = $dbconn->execute("update smtp_server set order_num='" . $val . "' where id_smtp_server='" . $key . "'");
								}
				}
}
if (isset($_GET['did']) && !empty($_GET['did']))
{
				$right_name = "delete_server";
				check_right($section, $right_name);
				delserver($_GET['did']);
}
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "date";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
}
else
{
				$order = "";
}
if (isset($_REQUEST['server_page']))
{
				$server_page = $_REQUEST['server_page'];
}
else
{
				$server_page = 0;
}
$smarty->assign("razdel", "Settings");
$smarty->assign("description", "Manage SMTP Servers");
$smarty->assign("hint", "List of SMTP servers used for newsletter delivery is presented here. \"Order Num\" shows sequence of its use from the very beginning. Principle is the following: localhost will be used if no server is indicated. System will connect automatically to server with greater \"Order Num\" from server list, in case of server connection failure while newsletter delivery.");
$GLOBALS['_SESSION']['return_url'] = "index.php";
$smarty->assign("order", $order);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("server_page", $server_page);
$smarty->assign("rel", getservers($order, $server_page));
$smarty->display("{$admin_nl_gentemplates}/smtp_servers_smtp_list.tpl");
?>