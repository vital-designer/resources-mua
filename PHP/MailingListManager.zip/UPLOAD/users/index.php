<?php
include ("../common.php");
include ("../include/users_function.php");
$section = "subscribers";
$right_name = "view";
check_right($section, $right_name);
if (isset($_GET['did']) && !empty($_GET['did']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				deluser((integer)$_GET['did']);
}
if (isset($_POST['sub_click']) && $_POST['sub_click'] == 1)
{
				$right_name = "subscribe";
				check_right($section, $right_name);
				if (isset($_POST['del']))
				{
								foreach ($GLOBALS['_POST']['del'] as $key => $val)
								{
												$res = $dbconn->execute("select * from clients_lists where client_id='" . $val . "' and list_id='" . $_REQUEST['list_id'] . "'");
												if (!$res->rowcount())
												{
																$rs = $dbconn->execute("insert into clients_lists values ('" . $val . "','" . $_REQUEST['list_id'] . "', '" . $config['status_subscribe_val']['subscribe'] . "', now())");
												}
												else
												{
																$rs = $dbconn->execute("update clients_lists set status_subscribe='" . $config['status_subscribe_val']['subscribe'] . "', date_status=now() where client_id='" . $val . "' and list_id='" . $_REQUEST['list_id'] . "'");
												}
								}
				}
				foreach ($GLOBALS['_POST']['unsub'] as $key => $val)
				{
								if ($_POST['unsub'][$key] == 0)
								{
												$rs = $dbconn->execute("update clients_lists set status_subscribe='" . $config['status_subscribe_val']['unsubscribe'] . "', date_status=now() where client_id='" . $_POST['item'][$key] . "' and list_id='" . $_REQUEST['list_id'] . "'");
								}
				}
}
else
				if (isset($_POST['del']) && $_POST['sub_click'] == "inactive")
				{
								$right_name = "edit";
								check_right($section, $right_name);
								foreach ($GLOBALS['_POST']['del'] as $key => $val)
								{
												activeuser($val, 0);
								}
				}
				else
								if (isset($_POST['del']) && $_POST['sub_click'] == "active")
								{
												$right_name = "edit";
												check_right($section, $right_name);
												foreach ($GLOBALS['_POST']['del'] as $key => $val)
												{
																activeuser($val, 1);
												}
								}
								else
												if (isset($_POST['del']) && $_POST['sub_click'] != "inactive" && $_POST['sub_click'] != "active" && $_POST['sub_click'] != "filter")
												{
																$right_name = "delete";
																check_right($section, $right_name);
																foreach ($GLOBALS['_POST']['del'] as $key => $val)
																{
																				deluser($val);
																}
												}
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "firstname";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
}
else
{
				$order = "";
}
if (isset($_REQUEST['user_page']))
{
				$user_page = $_REQUEST['user_page'];
}
else
{
				$user_page = 0;
}
$res = $dbconn->execute("select count(id) from snd_users");
$total_users = $res->fields[0];
$smarty->assign("razdel", "Subscribers");
$smarty->assign("description", "Manage Subscribers");
$smarty->assign("hint", "Here you can view all your subscribers, mailing lists they are subscribed to, create and import new subscribers, edit, export existing subscribers to file, subscribe selected users to certain mailing lists.");
$GLOBALS['_SESSION']['return_url'] = "index.php";
if (isset($_SESSION['message']) && $_SESSION['message'] != "")
{
				$msg = $_SESSION['message'];
				$GLOBALS['_SESSION']['message'] = "";
}
$smarty->assign("msg", $msg);
$smarty->assign("total_users", $total_users);
$smarty->assign("order", $order);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("config", $config);
$smarty->assign("user_page", $user_page);
$smarty->assign("lid", $_REQUEST['lid']);
$smarty->assign("list_id", $_REQUEST['list_id']);
$smarty->assign("users", getusers("", $order, $user_page, $filter));
$smarty->assign("list", get_values_list("list"));
$smarty->display("{$admin_nl_gentemplates}/users_all_users.tpl");
?>