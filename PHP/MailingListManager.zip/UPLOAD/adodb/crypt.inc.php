<?php
class md5crypt
{
				function keyed($txt, $encrypt_key)
				{
								$encrypt_key = md5($encrypt_key);
								$ctr = 0;
								$tmp = "";
								$i = 0;
								for (; $i < strlen($txt); ++$i)
								{
												if ($ctr == strlen($encrypt_key))
												{
																$ctr = 0;
												}
												$tmp .= substr($txt, $i, 1) ^ substr($encrypt_key, $ctr, 1);
												++$ctr;
								}
								return $tmp;
				}
				function encrypt($txt, $key)
				{
								srand((double)microtime() * 1000000);
								$encrypt_key = md5(rand(0, 32000));
								$ctr = 0;
								$tmp = "";
								$i = 0;
								for (; $i < strlen($txt); ++$i)
								{
												if ($ctr == strlen($encrypt_key))
												{
																$ctr = 0;
												}
												$tmp .= substr($encrypt_key, $ctr, 1) . (substr($txt, $i, 1) ^ substr($encrypt_key, $ctr, 1));
												++$ctr;
								}
								return base64_encode($this->keyed($tmp, $key));
				}
				function decrypt($txt, $key)
				{
								$txt = $this->keyed(base64_decode($txt), $key);
								$tmp = "";
								$i = 0;
								for (; $i < strlen($txt); ++$i)
								{
												$md5 = substr($txt, $i, 1);
												++$i;
												$tmp .= substr($txt, $i, 1) ^ $md5;
								}
								return $tmp;
				}
				function randpass()
				{
								$randomPassword = "";
								srand((double)microtime() * 1000000);
								$i = 0;
								for (; $i < 8; ++$i)
								{
												$randnumber = rand(48, 120);
												while (58 <= $randnumber && $randnumber <= 64 || 91 <= $randnumber && $randnumber <= 96)
												{
																$randnumber = rand(48, 120);
												}
												$randomPassword .= chr($randnumber);
								}
								return $randomPassword;
				}
}
?>
