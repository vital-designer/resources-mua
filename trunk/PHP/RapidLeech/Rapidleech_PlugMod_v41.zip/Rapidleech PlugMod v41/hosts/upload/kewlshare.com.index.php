<?php 
$upload_services[]="kewlshare.com";
$max_file_size["kewlshare.com"]=200;
$page_upload["kewlshare.com"] = "kewlshare.com.php";  
?>