<?php
$upload_services[]="uploadwing.com";
$max_file_size["uploadwing.com"]=300;
$page_upload["uploadwing.com"] = "uploadwing.com.php";  
?>