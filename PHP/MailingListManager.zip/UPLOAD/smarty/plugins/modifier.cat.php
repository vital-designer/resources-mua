<?php
function smarty_modifier_cat($string, $cat)
{
				return $string . $cat;
}
?>