<?php
$alphabet = "0123456789abcdefghijklmnopqrstuvwxyz";
$allowed_symbols = "23456789abcdefghkmnpqrstuvxyz";
$fontsdir = "fonts";
$length = 6;
$width = 190;
$height = 40;
$fluctuation_amplitude = 3;
$no_spaces = false;
$show_credits = false;
$credits = "";
$foreground_color = array(mt_rand(0, 100), mt_rand(0, 100), mt_rand(0, 100));
$background_color = array(mt_rand(200, 255), mt_rand(200, 255), mt_rand(200, 255));
$jpeg_quality = 80;
?>
