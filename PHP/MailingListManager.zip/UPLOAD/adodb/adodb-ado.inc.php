<?php
define("_ADODB_ADO_LAYER", 1);
class adodb_ado extends adoconnection
{
				var $databaseType = "ado";
				var $_bindInputArray = false;
				var $fmtDate = "'Y-m-d'";
				var $fmtTimeStamp = "'Y-m-d, h:i:sA'";
				var $replaceQuote = "''";
				var $dataProvider = "ado";
				var $hasAffectedRows = true;
				var $adoParameterType = 201;
				var $_affectedRows = false;
				function adodb_ado()
				{
				}
				function _affectedrows()
				{
								return $this->_affectedRows;
				}
				function _connect($argHostname, $argUsername, $argPassword, $argProvider = "MSDASQL")
				{
								$u = "UID";
								$p = "PWD";
								$dbc = new com("ADODB.Connection");
								if (!$dbc)
								{
												return false;
								}
								if ($argProvider)
								{
												$dbc->Provider = $argProvider;
								} else
								{
												$dbc->Provider = "MSDASQL";
								}
								if ($argUsername)
								{
												$argHostname .= ";{$u}={$argUsername}";
								}
								if ($argPassword)
								{
												$argHostname .= ";{$p}={$argPassword}";
								}
								if ($this->debug)
								{
												print "<p>Host=" . $argHostname . "<BR>version={$dbc->version}</p>";
								}
								@$dbc->open((boolean)$argHostname);
								$this->_connectionID = $dbc;
								return $dbc != false;
				}
				function _pconnect($argHostname, $argUsername, $argPassword, $argProvider = "MSDASQL")
				{
								$dbc = new com("ADODB.Connection");
								if (!$dbc)
								{
												return false;
								}
								if ($argProvider)
								{
												$dbc->Provider = $argProvider;
								} else
								{
												$dbc->Provider = "MSDASQL";
								}
								if ($argUsername)
								{
												$argHostname .= ";UID={$argUsername}";
								}
								if ($argPassword)
								{
												$argHostname .= ";PWD={$argPassword}";
								}
								if ($this->debug)
								{
												print "<p>Host=" . $argHostname . "<BR>version={$dbc->version}</p>";
								}
								$dbc->open((boolean)$argHostname);
								$this->_connectionID = $dbc;
								return $dbc != false;
				}
				function metatables()
				{
								$arr = array();
								$dbc = $this->_connectionID;
								$adors = @$dbc->openschema(20);
								if ($adors)
								{
												$f = $adors->fields(2);
												$t = $adors->fields(3);
												while (!$adors->EOF)
												{
																$tt = substr($t->value, 0, 6);
																if ($tt != "SYSTEM" && $tt != "ACCESS")
																{
																				$arr[] = $f->value;
																}
																$adors->movenext();
												}
												$adors->close();
								}
								return $arr;
				}
				function metacolumns($table)
				{
								$table = strtoupper($table);
								$arr = array();
								$dbc = $this->_connectionID;
								$adors = @$dbc->openschema(4);
								if ($adors)
								{
												$t = $adors->fields(2);
												while (!$adors->EOF)
												{
																if (strtoupper($t->Value) == $table)
																{
																				$fld = new adofieldobject();
																				$c = $adors->fields(3);
																				$fld->name = $c->Value;
																				$fld->type = "CHAR";
																				$fld->max_length = -1;
																				$arr[strtoupper($fld->name)] = $fld;
																}
																$adors->movenext();
												}
												$adors->close();
								}
								return $arr;
				}
				function &_query($sql, $inputarr = false)
				{
								$dbc = $this->_connectionID;
								if ($inputarr)
								{
												$oCmd = new com("ADODB.Command");
												$oCmd->ActiveConnection = $dbc;
												$oCmd->CommandText = $sql;
												$oCmd->CommandType = 1;
												foreach ($inputarr as $val)
												{
																$this->adoParameterType = 130;
																$p = $oCmd->createparameter("name", $this->adoParameterType, 1, strlen($val), $val);
																$oCmd->Parameters->append($p);
												}
												$p = false;
												$rs = $oCmd->execute();
												$e = $dbc->Errors;
												if (0 < $dbc->Errors->Count)
												{
																return false;
												}
												return $rs;
								}
								$rs = @$dbc->execute($sql, $this->_affectedRows);
								if (0 < $dbc->Errors->Count)
								{
												return false;
								}
								if ($rs->State == 0)
								{
												return true;
								}
								return $rs;
				}
				function begintrans()
				{
								$o = $this->_connectionID->properties("Transaction DDL");
								if (!$o)
								{
												return false;
								}
								@$this->_connectionID->begintrans();
								return true;
				}
				function committrans()
				{
								@$this->_connectionID->committrans();
								return true;
				}
				function rollbacktrans()
				{
								@$this->_connectionID->rollbacktrans();
								return true;
				}
				function errormsg()
				{
								$errc = $this->_connectionID->Errors;
								if ($errc->Count == 0)
								{
												return "";
								}
								$err = $errc->item($errc->Count - 1);
								return $err->Description;
				}
				function errorno()
				{
								$errc = $this->_connectionID->Errors;
								if ($errc->Count == 0)
								{
												return 0;
								}
								$err = $errc->item($errc->Count - 1);
								return $err->NativeError;
				}
				function _close()
				{
								if ($this->_connectionID)
								{
												$this->_connectionID->close();
								}
								$this->_connectionID = false;
								return true;
				}
}
class adorecordset_ado extends adorecordset
{
				var $bind = false;
				var $databaseType = "ado";
				var $dataProvider = "ado";
				var $_tarr = false;
				var $_flds;
				var $canSeek = true;
				var $hideErrors = true;
				function adorecordset_ado(&$id)
				{
								global $ADODB_FETCH_MODE;
								$this->fetchMode = $ADODB_FETCH_MODE;
								return $this->adorecordset($id);
				}
				function fetchfield($fieldOffset = -1)
				{
								$off = $fieldOffset + 1;
								$o = new adofieldobject();
								$rs = $this->_queryID;
								$f = $rs->fields($fieldOffset);
								$o->name = $f->Name;
								$o->type = $f->Type;
								$o->max_length = $f->DefinedSize;
								return $o;
				}
				function fields($colname)
				{
								if ($this->fetchMode & ADODB_FETCH_ASSOC)
								{
												return $this->fields[$colname];
								}
								if (!$this->bind)
								{
												$this->bind = array();
												$i = 0;
												for (; $i < $this->_numOfFields; ++$i)
												{
																$o = $this->fetchfield($i);
																$this->bind[strtoupper($o->name)] = $i;
												}
								}
								return $this->fields[$this->bind[strtoupper($colname)]];
				}
				function _initrs()
				{
								$rs = $this->_queryID;
								$this->_numOfRows = $rs->RecordCount;
								$f = $rs->Fields;
								$this->_numOfFields = $f->Count;
				}
				function _seek($row)
				{
								$rs = $this->_queryID;
								if ($row < $this->_currentRow)
								{
												return false;
								}
								@$rs->move((integer)$row - $this->_currentRow - 1);
								return true;
				}
				function MetaType($t, $len = -1, $fieldobj = false)
				{
								if (is_object($t))
								{
												$fieldobj = $t;
												$t = $fieldobj->type;
												$len = $fieldobj->max_length;
								}
								if (!is_numeric($t)) return $t;
								switch ($t)
								{
												case 0:
												case 12:
												case 8:
												case 129:
												case 130:
												case 200:
												case 202:
												case 128:
												case 204:
												case 72:
																if ($len <= $this->blobSize) return 'C';
												case 201:
												case 203:
																return 'X';
												case 128:
												case 204:
												case 205:
																return 'B';
												case 7:
												case 133:
																return 'D';
												case 134:
												case 135:
																return 'T';
												case 11:
																return 'L';
												case 16:
												case 2:
												case 3:
												case 4:
												case 17:
												case 18:
												case 19:
												case 20:
																return 'I';
												default:
																return 'N';
								}
				}
				/**
				function metatype($t, $len = -1)
				{
								switch ($t)
								{
												case 12:
												case 8:
												case 129:
												case 130:
												case 200:
												case 202:
												case 128:
												case 204:
												case 72:
																do {
																				if (!($len <= $this->blobSize))
																				{
																								break;
																				} else
																				{
																								return "C";
																				}
																case 201 : } while (0);
												case 203:
																return "X";
												case 128:
												case 204:
												case 205:
																return "B";
												case 7:
												case 133:
																return "D";
												case 134:
												case 135:
																return "T";
												case 11:
																return "L";
												case 16:
												case 2:
												case 3:
												case 4:
												case 17:
												case 18:
												case 19:
												case 20:
																return "I";
												default:
																return "N";
								}
				}
				**/
				function _fetch()
				{
								$rs = $this->_queryID;
								if ($rs->EOF)
								{
												return false;
								}
								$this->fields = array();
								if (!$this->_tarr)
								{
												$tarr = array();
												$flds = array();
												$i = 0;
												$max = $this->_numOfFields;
												for (; $i < $max; ++$i)
												{
																$f = $rs->fields($i);
																$flds[] = $f;
																$tarr[] = $f->Type;
												}
												$this->_tarr = $tarr;
												$this->_flds = $flds;
								}
								$t = reset($this->_tarr);
								$f = reset($this->_flds);
								if ($this->hideErrors)
								{
												$olde = error_reporting(E_ERROR | E_CORE_ERROR);
								}
								$i = 0;
								$max = $this->_numOfFields;
								for (; $i < $max; ++$i)
								{
												switch ($t)
												{
																case 133:
																				$val = $f->value;
																				$this->fields[] = substr($val, 0, 4) . "-" . substr($val, 4, 2) . "-" . substr($val, 6, 2);
																				break;
																case 7:
																				$this->fields[] = date("Y-m-d", (integer)$f->value);
																				break;
																case 1:
																				$this->fields[] = false;
																				break;
																case 6:
																				print "<br><b>" . $f->Name . ": currency type not supported by PHP</b><br>";
																				$this->fields[] = (double)$f->value;
																				break;
																default:
																				$this->fields[] = $f->value;
																				break;
												}
												$f = next($this->_flds);
												$t = next($this->_tarr);
								}
								if ($this->hideErrors)
								{
												error_reporting($olde);
								}
								@$rs->movenext();
								if ($this->fetchMode == ADODB_FETCH_ASSOC)
								{
												$this->fields = $this->getrowassoc(false);
								}
								return true;
				}
				function _close()
				{
								$this->_flds = false;
								@$this->_queryID->close();
								$this->_queryID = false;
				}
}
?>
