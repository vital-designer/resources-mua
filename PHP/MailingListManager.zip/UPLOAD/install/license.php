<?php
$license = "[iAG] Nulled 2008";
?>