<?
//phpFormBuilder Version 1.5 by Baris Kayar (barishkayar@yahoo.com)
//2002(cl)  The FormBuilder Group http://pfb.sourceforge.net

require("config.inc.php");
require("connectdb.inc.php");
require("style.inc.php");
?>
<body background="images/bkg.gif">
<?
if ($server && $database && $table)
{
echo "<h3 style=\"color:navy;\">$DbServer_Caption $server</h3>";
echo "<h3 style=\"color:navy;\">$DbList_Caption $database</h3>";
echo "<h4 style=\"color:navy;\">$Table_Caption $table</h4>";
$result = mysql_list_fields($database, $table);
$fields = mysql_num_fields($result);
$rows   = mysql_num_rows($result);
$chkinsert= "<input type=\"checkbox\" name=\"chkinsert\"".
			" onclick=\"javascript: ".
			" if ( chkupdate.checked) {chkinsert.checked=true;}".
			"\">$Insert_Caption&nbsp;&nbsp;";
$chkupdate= "<input type=\"checkbox\" name=\"chkupdate\"".
			" onclick=\"javascript:".
			" if (chkupdate.checked) {chkupdate.checked=false;}  ".
			" if (!chkdelete.checked && !chkupdate.checked) ".
			"{chkinsert.disabled=false;}".
			"if (chkupdate.checked) {chkinsert.checked=true;chklist.checked=true;".
			" chkinsert.disabled=true;chklist.disabled=true;} else chkinsert.disabled=false; ".
			"\" disabled>$Update_Caption&nbsp;&nbsp;";
$chkdelete= "<input type=\"checkbox\" name=\"chkdelete\"".
			" onclick=\"javascript:".
			" if (chkdelete.checked) {chkdelete.checked=false;}  ".
			" if (!chkdelete.checked && !chkupdate.checked) {chklist.disabled=false;}".
			" if (chkdelete.checked) {chklist.checked=true;chklist.disabled=true;}".
			"\"  disabled>$Delete_Caption&nbsp;&nbsp;";
$chklist= "<input type=\"checkbox\" name=\"chklist\"".
			" onclick=\"javascript: ".
			" if (chkdelete.checked || chkupdate.checked) {chklist.checked=true;}".
			"\">$List_Caption&nbsp;&nbsp;";
$unique="";
$i = 0;
$table = mysql_field_table($result, $i);
echo "<form name=\"PFB_former\" action=\"builder.php?act=olustur\" method=\"post\"><table>";
echo "<input type=\"hidden\" name=\"server\" value=\"$server\">";
echo "<input type=\"hidden\" name=\"hostindex\" value=\"$hostindex\">";
echo "<input type=\"hidden\" name=\"database\" value=\"$database\">";
echo "<input type=\"hidden\" name=\"table\" value=\"$table\">";
echo "<tr>
	  <td width=120><b>$FieldName_Caption</b></td>
	  <td width=120><b>$Type_Caption</b></td>
	  <td width=80><b>$Size_Caption</b></td>
	  <td width=120><b>$Property_Caption</b></td>
	  <td width=20><b>$ShowOnList_Caption</b></td>
	  <td width=20><b>$ShowOnForm_Caption</b></td>
	  <td><!-- Hidden --></td>
  	  <td width=190><b>$InputType_Caption</b></td></tr>";
while ($i < $fields) {
    $type  = mysql_field_type  ($result, $i);
    $name  = mysql_field_name  ($result, $i);
    $len   = mysql_field_len   ($result, $i);
    $flags = mysql_field_flags ($result, $i);
	echo "<tr><td>$name</td><td>$type</td><td>$len</td><td>$flags</td>";
	if (!strpos($flags,"auto_inc") < 1)  
		{
		$checked=" disabled ";
		echo "<td colspan=4>&nbsp;</td>";
		}
		else
		{
		$checked=" checked ";
		echo "<td><input type=\"Checkbox\" name=\"PFBl_$name\" $checked></td>";
		echo "<td><input type=\"Checkbox\" name=\"PFBf_$name\" $checked></td>";
		echo "<td><input type=\"Hidden\" name=\"PFBo_$name\"".
			 " value=\"edit;$name;$name;20;0;20;text;void;false;\"></td>";
		echo "<td><select name=\"PFBt_".$name."tip\">".
			 "<option value=\"textarea\">Textarea</option>".
			 "<option value=\"edit\" selected>Edit</option>".
			 "<option value=\"checkbox\">Checkbox</option>".	 
			 "<option value=\"radiobox\">Radiobox</option>".
			 "<option value=\"lov\">List of value</option>".
			 "</select>&nbsp;".
			 "<a href=\"javascript: void(0);\" ".
			 " onclick=\"javascript: window.open('options.php?PFBg_opt='+PFB_former.PFBo_".$name.".value+'&PFBg_obj='".
			 "+PFB_former.PFBt_".$name."tip.options[PFB_former.PFBt_".$name."tip.selectedIndex].value+'&form=PFB_former&alan=PFBo_$name','options',".
			 "'width=400,height=450,resizable=no');\"".
			 ">$Property_Caption</a>".
			 "</td></tr>";
		}
	if (strpos($flags,"unique") >-1 || strpos($flags,"auto_inc") >-1) 
		{
		$unique.="<option value=\"$name\">$name";
		$chkupdate="<input type=\"checkbox\" name=\"chkupdate\"".
		" onclick=\"javascript:".
		" if (!chkdelete.checked && !chkupdate.checked) {chklist.disabled=false;}".
		" if (chkupdate.checked) {chklist.checked=true;chklist.disabled=true;".
		" chkinsert.checked=true;chkinsert.disabled=true;} else chkinsert.disabled=false; ".
		"\">$Update_Caption&nbsp;&nbsp;";
		$chkdelete= "<input type=\"checkbox\" name=\"chkdelete\"".
		" onclick=\"javascript:".
		" if (!chkdelete.checked && !chkupdate.checked) {chklist.disabled=false;}".
		" if (chkdelete.checked) {chklist.checked=true;chklist.disabled=true;}".
		"\">$Delete_Caption&nbsp;&nbsp;";
		}
    $i++;
}//while
$unique="<SELECT name=\"unique\">".$unique."</SELECT>";
echo "</table><table>
	 <tr><td>$UniqueField_Caption</td><td>$unique</td></tr>".
	 "<tr><td>$FileName_Caption</td><td><input type=\"text\" name=\"dosya\" value=\"$table\">.php</td></tr>".
	"<tr><td>$PossibleActions_Caption</td><td>$chkinsert $chklist $chkupdate $chkdelete</td></tr>".
	"<td>$LimitofList_Caption</td><td><input type=\"text\" name=\"HavingCount\" size=4 value=\"10\"></td>".
	 "</table><br><td align=\"center\"><input type=\"submit\" name=\"submit\" value=\"$OkayButon_Caption\"></form>";
mysql_close();
}//if
else
{
echo "<h3 align=center>$Welcome_Caption</h3>";
}
//echo "$servers[$hostindex],$users[$hostindex],$passes[$hostindex]<br>"; //ne gelmi� bi g�relim
echo "<br><br><br>";
include("about.inc.php");
?>
<br>
<div align="center"><a href="logoff.php" target="_top"><b>logoff</b></a></div>
</body>
</html>
