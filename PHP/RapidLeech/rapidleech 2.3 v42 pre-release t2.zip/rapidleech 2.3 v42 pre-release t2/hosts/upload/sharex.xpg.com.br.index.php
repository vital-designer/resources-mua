<?php
$upload_services[]="sharex.xpg.com.br";
$max_file_size["sharex.xpg.com.br"]=300;
$page_upload["sharex.xpg.com.br"] = "sharex.xpg.com.br.php";
?>