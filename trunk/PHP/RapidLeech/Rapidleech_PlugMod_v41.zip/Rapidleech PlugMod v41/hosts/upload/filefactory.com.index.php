<?php 
$upload_services[] = "filefactory.com";
$max_file_size["filefactory.com"] = 300;
$page_upload["filefactory.com"] = "filefactory.com.php";
?>