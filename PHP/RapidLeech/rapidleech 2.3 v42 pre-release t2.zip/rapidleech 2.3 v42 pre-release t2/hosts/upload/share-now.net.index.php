<?php
$upload_services[]="share-now.net";
$max_file_size["share-now.net"]=150;
$page_upload["share-now.net"] = "share-now.net.php";  
?>