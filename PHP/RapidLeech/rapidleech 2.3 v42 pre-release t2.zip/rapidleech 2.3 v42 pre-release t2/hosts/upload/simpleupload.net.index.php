<?php
$upload_services[]="simpleupload.net";
$max_file_size["simpleupload.net"]=300;
$page_upload["simpleupload.net"] = "simpleupload.net.php";  
?>
