<?php
define("_D_S_", "/");
if (substr(php_uname(), 0, 7) == "Windows")
{
				$install['system'] = "win";
}
else
{
				$install['system'] = "unix";
}
$install['existing_files'] = array(1 => "adodb" . _D_S_ . "adodb.inc.php", 2 => "smarty" . _D_S_ . "Smarty.class.php", 3 => "templates_c");
$install['permission_files'] = array(1 => "templates_c" . _D_S_, 2 => "files" . _D_S_, 3 => "pictures" . _D_S_, 4 => "tmp" . _D_S_, 5 => "include" . _D_S_ . "config.php", 6 => "install" . _D_S_ . "install_log.txt", 7 => "install" . _D_S_ . "bases" . _D_S_ . "newsletter_tmp.sql");
$def_path = "../";
$install['install_path'] = substr(__file__, 0, -20);
$install['install_path'] = str_replace("\\", "/", $install['install_path']);
if (strlen($install['install_path']) < 1)
{
				$install['install_path'] = $def_path;
}
?>