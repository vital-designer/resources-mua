<?php
function smarty_modifier_capitalize($string)
{
				return ucwords($string);
}
?>