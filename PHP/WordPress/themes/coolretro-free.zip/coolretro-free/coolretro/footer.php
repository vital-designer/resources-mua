<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
?>


<div id="footer">
	<p>
<!-- FOOTER CREDITS LINK -->	
<strong>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?></strong><br>
<font size="1"><strong><a href="http://www.freethemelayouts.com/" style="color: #9C3B15;text-decoration: none;" title="Free WordPress Themes">Wordpress Themes</a> by DT <a href="http://www.dreamtemplate.com" style="color: #9C3B15;text-decoration: none;" title="Website Templates">Website Templates</a><strong></font>

	</p>
</div>
</div>
</div>
</div>


		<?php wp_footer(); ?>
</body>
</html>
