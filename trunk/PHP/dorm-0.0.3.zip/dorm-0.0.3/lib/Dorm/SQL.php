<?php
/**
 * This file is part of Dorm and is subject to the GNU Affero General
 * Public License Version 3 (AGPLv3). You should have received a copy
 * of the GNU Affero General Public License along with Dorm. If not,
 * see <http://www.gnu.org/licenses/>.
 *
 * @category Dorm
 * @package Dorm_SQL
 * @copyright Copyright (c) 2008-2009 Olivier Lalonde <olalonde@gmail.com>
 */

/**
 * @see http://www.martinfowler.com/eaaCatalog/unitOfWork.html
 *
 */
class Dorm_SQL {

    public static function primaryKey($pk) {
        $str = $sep = '';
        $i = 0;
        foreach ($pk->getFields() as $field) {
            $str .= $sep . $field . '=:pK' . $i;
            $sep = ' AND ';
            $i++;
        }
        return $str;
    }

    public static function bindArray($stmt, $array) {
        foreach ($array as $key => $val) {
            $stmt->bindValue(':' . $key , $val);
        }
    }

    public static function bindPrimaryKey($stmt, $id) {
        $i = 0;
        foreach ($id as $val) {
            $stmt->bindValue(':pK' . $i , $val);
            $i++;
        }
    }

}