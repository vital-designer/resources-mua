<?php
function getreleases($orderby = "", $template_page = 0)
{
				global $dbconn;
				global $smarty;
				global $config;
				if (isset($_GET['p']) && 0 < $_GET['p'])
				{
								$p = $_GET['p'];
				} else
				{
								$p = 0;
				}
				$end = $_SESSION['is_desc'] && !$_GET['is_nav'] || !$_SESSION['is_desc'] && $_GET['is_nav'] ? " desc " : "";
				if ($orderby)
				{
								$is_nav = isset($_GET['is_nav']) ? $_GET['is_nav'] : false;
								if (!$is_nav && $orderby == $_SESSION['order'])
								{
												if ($_SESSION['is_desc'])
												{
																$GLOBALS['_SESSION']['is_desc'] = false;
																$end = " desc ";
												} else
												{
																$GLOBALS['_SESSION']['is_desc'] = true;
																$end = "";
												}
								}
								$sql .= " order by " . $orderby . $end;
				} else
				{
								$sql .= " order by name";
				}
				$smarty->assign("end", trim($end));
				$res = $dbconn->execute("select count(id) from templates");
				$amount = $res->fields[0];
				$smarty->assign("navigation", create_navigation($amount, $template_page, "template_page={$template_page}&order=" . $_GET['order'] . "&is_nav=true", "index.php", $p, "template_page"));
				get_smarty_array_list("template_page", $config['template_page']);
				$per_page = $config['template_page'][$template_page];
				$res = $dbconn->pageexecute("select id, name, body,date,format from templates " . $sql, $per_page, $p + 1);
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$releases[$c]['id'] = $res->fields[0];
								$releases[$c]['name'] = stripslashes($res->fields[1]);
								$releases[$c]['body'] = nl2br(stripslashes($res->fields[2]));
								$releases[$c]['date'] = $res->fields[3];
								$releases[$c]['format'] = $res->fields[4] == "html" ? "HTML" : "Text";
								++$c;
								$res->movenext();
				}
				$smarty->assign("amount", $amount);
				return $releases;
}
function getusers($a = "", $orderby = "")
{
				global $dbconn;
				if ($a)
				{
								$sql = " where id='" . $a . "' and uns_date IS NULL ";
				} else
				{
								$sql = " where uns_date IS NULL ";
				}
				if ($orderby)
				{
								$sql .= " order by " . $orderby;
				} else
				{
								$sql .= " order by id";
				}
				$res = $dbconn->execute("select id,date,firstname,secondname,company,email1,comment from snd_users " . $sql);
				$users = array();
				$c = 0;
				while (!$res->EOF)
				{
								$users[$c] = $res->getrowassoc();
								++$c;
								$res->movenext();
				}
				return $users;
}
function delrelease($id)
{
				global $dbconn;
				$res = $dbconn->execute("delete from templates where id='" . $id . "'");
}
function addrelease($name, $body, $format = "")
{
				global $dbconn;
				$body = htmlentities($body, ENT_QUOTES);
				$res = $dbconn->execute("insert into templates (name,body,date,format) values ('" . addslashes($name) . "','" . $body . "',NOW(),'" . $format . "')");
				$rid = $dbconn->_insertid();
				return $rid;
}
function updrelease($id, $name, $body)
{
				global $dbconn;
				$body = htmlentities($body, ENT_QUOTES);
				$res = $dbconn->execute("update templates set name='" . addslashes($name) . "', body='" . $body . "',date=NOW(),format='" . $_POST['format'] . "' where id='" . $id . "'");
}
function getcontent($id, $br = "")
{
				global $dbconn;
				$res = $dbconn->execute("select id,name,body,format from templates where id='" . $id . "'");
				$releases = array();
				$releases['id'] = $res->fields[0];
				$releases['name'] = stripslashes($res->fields[1]);
				$releases['format'] = stripslashes($res->fields[3]);
				$releases['body'] = html_entity_decode($res->fields[2]);
				return $releases;
}
function getblankcontent()
{
				$releases = array();
				$releases['id'] = 0;
				$releases['name'] = "";
				$releases['body'] = "";
				return $releases;
}
function getlists()
{
				global $dbconn;
				$res = $dbconn->execute("select id, name, date,owner_name,owner_email from list order by id");
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$releases[$c]['id'] = $res->fields[0];
								$releases[$c]['name'] = stripslashes($res->fields[1]);
								$releases[$c]['date'] = $res->fields[2];
								$releases[$c]['owner_name'] = $res->fields[3];
								$releases[$c]['owner_email'] = $res->fields[4];
								$res2 = $dbconn->execute("select count(*) from clients_lists where list_id='" . $res->fields[0] . "'");
								$releases[$c]['count'] = $res2->fields[0];
								++$c;
								$res->movenext();
				}
				return $releases;
}
function parsebody($body, $res2, $list_id)
{
				global $config;
				$body = preg_replace("/%BASIC:FIRSTNAME%/i", $res2->fields[1], $body);
				$body = preg_replace("/%BASIC:SECONDNAME%/i", $res2->fields[2], $body);
				$body = preg_replace("/%BASIC:EMAIL%/i", $res2->fields[3], $body);
				$body = preg_replace("/%BASIC:UNSUBLINK%/i", $config['server'] . "/uns.php?l=" . $list_id . "&c=" . md5($res2->fields[3]), $body);
				$images = getallimages();
				foreach ($images as $image)
				{
								$body = preg_replace("/%IMAGE:" . $image['id'] . "%/i", "<img src=\"" . $config['server'] . "/newsletters/images/" . $image['filename'] . "\" border=0>", $body);
				}
				return $body;
}
function token2br($text)
{
				$text = preg_replace("/\n/i", "", $text);
				$text = preg_replace("/\r/i", "", $text);
				return $text;
}
?>
