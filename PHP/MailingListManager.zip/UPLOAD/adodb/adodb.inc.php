<?php
if (!defined("_ADODB_LAYER"))
{
				define("_ADODB_LAYER", 1);
				define("ADODB_BAD_RS", "<p>Bad \$rs in %s. Connection or SQL invalid. Try using \$connection->debug=true;</p>");
				define("ADODB_FETCH_DEFAULT", 0);
				define("ADODB_FETCH_NUM", 1);
				define("ADODB_FETCH_ASSOC", 2);
				define("ADODB_FETCH_BOTH", 3);
				define("ADODB_TABLE_REGEX", "([]0-9a-z_\\.\\@\\[-]*)");
				if (!defined("MAX_BLOB_SIZE"))
				{
								define("MAX_BLOB_SIZE", 999999);
				}
				if (!defined("ADODB_PREFETCH_ROWS"))
				{
								define("ADODB_PREFETCH_ROWS", 10);
				}
				if (!defined("ADODB_DIR"))
				{
								define("ADODB_DIR", dirname(__file__));
				}
				global $ADODB_vers;
				global $ADODB_Database;
				global $ADODB_COUNTRECS;
				global $ADODB_CACHE_DIR;
				global $ADODB_FETCH_MODE;
				$ADODB_FETCH_MODE = ADODB_FETCH_DEFAULT;
				if (!isset($ADODB_CACHE_DIR))
				{
								$ADODB_CACHE_DIR = "/tmp";
				} else
								if (strpos($ADODB_CACHE_DIR, ":/") !== false)
								{
												exit("Illegal \$ADODB_CACHE_DIR - switch to using back-slash, C:\\path\\to\\dir if on Windows");
								}
				srand((double)microtime() * 1000000);
				$ADODB_Database = "";
				$ADODB_vers = "V1.90 5 April 2002 (c) 2000-2002 John Lim (jlim@natsoft.com.my). All rights reserved. Released BSD & LGPL.";
				$ADODB_COUNTRECS = true;
				class adofieldobject
				{
								var $name = "";
								var $max_length = 0;
								var $type = "";
								var $not_null = false;
								var $has_default = false;
								var $default_value;
				}
				class adoconnection
				{
								var $dataProvider = "native";
								var $databaseType = "";
								var $database = "";
								var $host = "";
								var $user = "";
								var $password = "";
								var $debug = false;
								var $maxblobsize = 8000;
								var $concat_operator = "+";
								var $fmtDate = "'Y-m-d'";
								var $fmtTimeStamp = "'Y-m-d, h:i:s A'";
								var $true = "1";
								var $false = "0";
								var $replaceQuote = "\\'";
								var $hasInsertID = false;
								var $hasAffectedRows = false;
								var $charSet = false;
								var $metaTablesSQL = "";
								var $hasTop = false;
								var $hasLimit = false;
								var $readOnly = false;
								var $hasMoveFirst = false;
								var $hasGenID = false;
								var $genID = 0;
								var $raiseErrorFn = false;
								var $upperCase = false;
								var $isoDates = false;
								var $cacheSecs = 3600;
								var $sysDate = false;
								var $noNullStrings = false;
								var $_connectionID = false;
								var $_errorMsg = "";
								var $_queryID = false;
								var $_isPersistentConnection = false;
								var $_bindInputArray = false;
								var $autoCommit = true;
								function adoconnection()
								{
												exit("Virtual Class -- cannot instantiate");
								}
								function connect($argHostname = "", $argUsername = "", $argPassword = "", $argDatabaseName = "")
								{
												if ($argHostname != "")
												{
																$this->host = $argHostname;
												}
												if ($argUsername != "")
												{
																$this->user = $argUsername;
												}
												if ($argPassword != "")
												{
																$this->password = $argPassword;
												}
												if ($argDatabaseName != "")
												{
																$this->database = $argDatabaseName;
												}
												$this->_isPersistentConnection = false;
												if ($fn = $this->raiseErrorFn)
												{
																if ($this->_connect($this->host, $this->user, $this->password, $this->database))
																{
																				return true;
																}
																$err = $this->errormsg();
																if (empty($err))
																{
																				$err = "Connection error to server '{$argHostname}' with user '{$argUsername}'";
																}
																$fn($this->databaseType, "CONNECT", $this->errorno(), $err, $this->host, $this->database);
												} else
												{
																if ($this->_connect($this->host, $this->user, $this->password, $this->database))
																{
																				return true;
																}
												}
												if ($this->debug)
												{
																print $this->host . ": " . $this->errormsg() . "<br>";
												}
												return false;
								}
								function pconnect($argHostname = "", $argUsername = "", $argPassword = "", $argDatabaseName = "")
								{
												if ($argHostname != "")
												{
																$this->host = $argHostname;
												}
												if ($argUsername != "")
												{
																$this->user = $argUsername;
												}
												if ($argPassword != "")
												{
																$this->password = $argPassword;
												}
												if ($argDatabaseName != "")
												{
																$this->database = $argDatabaseName;
												}
												$this->_isPersistentConnection = true;
												if ($fn = $this->raiseErrorFn)
												{
																if ($this->_pconnect($this->host, $this->user, $this->password, $this->database))
																{
																				return true;
																}
																$err = $this->errormsg();
																if (empty($err))
																{
																				$err = "Connection error to server '{$argHostname}' with user '{$argUsername}'";
																}
																$fn($this->databaseType, "PCONNECT", $this->errorno(), $err, $this->host, $this->database);
												} else
												{
																if ($this->_pconnect($this->host, $this->user, $this->password, $this->database))
																{
																				return true;
																}
												}
												if ($this->debug)
												{
																print $this->host . ": " . $this->errormsg() . "<br>";
												}
												return false;
								}
								function unixdate($d)
								{
												return adorecordset::unixdate($d);
								}
								function prepare($sql)
								{
												return $sql;
								}
								function quote($s)
								{
												return $this->qstr($s);
								}
								function errornative()
								{
												return $this->errorno();
								}
								function nextid($seq_name)
								{
												return $this->genid($seq_name);
								}
								function rowlock($table, $where)
								{
												return false;
								}
								function commitlock($table)
								{
												return $this->committrans();
								}
								function rollbacklock($table)
								{
												return $this->rollbacktrans();
								}
								function setfetchmode($mode)
								{
												global $ADODB_FETCH_MODE;
												$ADODB_FETCH_MODE = $mode;
								}
								function &query($sql, $inputarr = false)
								{
												$rs = &$this->execute($sql, $inputarr);
												if (!$rs && defined("ADODB_PEAR"))
												{
																return adodb_pear_error();
												}
												return $rs;
								}
								function &limitquery($sql, $offset, $count)
								{
												$rs = &$this->selectlimit($sql, $count, $offset);
												if (!$rs && defined("ADODB_PEAR"))
												{
																return adodb_pear_error();
												}
												return $rs;
								}
								function disconnect()
								{
												return $this->close();
								}
								function &execute($sql, $inputarr = false, $arg3 = false)
								{
												if (!$this->_bindInputArray && $inputarr)
												{
																$sqlarr = explode("?", $sql);
																$sql = "";
																$i = 0;
																foreach ($inputarr as $v)
																{
																				$sql .= $sqlarr[$i];
																				if (gettype($v) == "string")
																				{
																								$sql .= $this->qstr($v);
																				} else
																								if ($v === null)
																								{
																												$sql .= "NULL";
																								} else
																								{
																												$sql .= $v;
																								}
																								$i += 1;
																}
																$sql .= $sqlarr[$i];
																if ($i + 1 != sizeof($sqlarr))
																{
																				print "Input Array does not match ?: " . htmlspecialchars($sql);
																}
																$inputarr = false;
												}
												if ($this->debug)
												{
																global $HTTP_SERVER_VARS;
																$ss = "";
																if ($inputarr)
																{
																				foreach ($inputarr as $kk => $vv)
																				{
																								if (is_string($vv) && 64 < strlen($vv))
																								{
																												$vv = substr($vv, 0, 64) . "...";
																								}
																								$ss .= "({$kk}=>'{$vv}') ";
																				}
																				$ss = "[ {$ss} ]";
																}
																if (is_array($sql))
																{
																				$sqlTxt = $sql[0];
																} else
																{
																				$sqlTxt = $sql;
																}
																$inBrowser = isset($HTTP_SERVER_VARS['HTTP_USER_AGENT']);
																if ($inBrowser)
																{
																				print "<hr>\n({$this->databaseType}): " . htmlspecialchars($sqlTxt) . " &nbsp; <code>{$ss}</code>\n<hr>\n";
																} else
																{
																				print "=----\n({$this->databaseType}): " . $sqlTxt . " \n-----\n";
																}
																flush();
																$this->_queryID = $this->_query($sql, $inputarr, $arg3);
																if ($this->databaseType == "mssql")
																{
																				if ($this->errormsg())
																				{
																								$err = $this->errorno();
																								if ($err)
																								{
																												print $err . ": " . $this->errormsg() . ($inBrowser ? "<br>\n" : "\n");
																								}
																				}
																} else
																				if (!$this->_queryID)
																				{
																								print $this->errorno() . ": " . $this->errormsg() . ($inBrowser ? "<br>\n" : "\n");
																				}
												} else
												{
																$this->_queryID = @$this->_query($sql, $inputarr, $arg3);
												}
												if ($this->_queryID === false)
												{
																if ($fn = $this->raiseErrorFn)
																{
																				$fn($this->databaseType, "EXECUTE", $this->errorno(), $this->errormsg(), $sql, $inputarr);
																}
																return false;
												} else
												{
																if ($this->_queryID === true)
																{
																				$rs = new adorecordset_empty();
																				return $rs;
																}
												}
												$rsclass = "ADORecordSet_" . $this->databaseType;
												$rs = new $rsclass($this->_queryID);
												$rs->connection = &$this;
												$rs->init();
												if (is_string($sql))
												{
																$rs->sql = $sql;
												}
												return $rs;
								}
								function genid($seqname = "adodbseq", $startID = 1)
								{
												if (!$this->hasGenID)
												{
																return 0;
												}
												$getnext = sprintf($this->_genIDSQL, $seqname);
												$rs = @$this->execute($getnext);
												if (!$rs)
												{
																$u = strtoupper($seqname);
																$createseq = $this->execute(sprintf($this->_genSeqSQL, $seqname, $startID));
																$rs = $this->execute($getnext);
												}
												if ($rs && !$rs->EOF)
												{
																$this->genID = (integer)reset($rs->fields);
												} else
												{
																$this->genID = 0;
												}
												if ($rs)
												{
																$rs->close();
												}
												return $this->genID;
								}
								function insert_id()
								{
												if ($this->hasInsertID)
												{
																return $this->_insertid();
												}
												if ($this->debug)
												{
																print "<p>Insert_ID error</p>";
												}
												return false;
								}
								function po_insert_id($table = "", $id = "")
								{
												if ($this->hasInsertID)
												{
																return $this->insert_id();
												} else
												{
																return $this->getone("SELECT MAX({$id}) FROM {$table}");
												}
								}
								function affected_rows()
								{
												if ($this->hasAffectedRows)
												{
																$val = $this->_affectedrows();
																return $val < 0 ? false : $val;
												}
												if ($this->debug)
												{
																print "<p>Affected_Rows error</p>";
												}
												return false;
								}
								function errormsg()
								{
												return "!! " . strtoupper($this->dataProvider . " " . $this->databaseType) . ": " . $this->_errorMsg;
								}
								function errorno()
								{
												return $this->_errorMsg ? -1 : 0;
								}
								function metaprimarykeys($table)
								{
												return false;
								}
								function selectdb($dbName)
								{
												return false;
								}
								function &selectlimit($sql, $nrows = -1, $offset = -1, $inputarr = false, $arg3 = false, $secs2cache = 0)
								{
												if ($this->hasTop && 0 < $nrows)
												{
																if ($offset <= 0)
																{
																				$sql = preg_replace("/(^select[\\t\\n ]*(distinctrow|distinct)?)/i", "\\1 top " . $nrows . " ", $sql);
																				if (0 < $secs2cache)
																				{
																								return $this->cacheexecute($secs2cache, $sql, $inputarr, $arg3);
																				} else
																				{
																								return $this->execute($sql, $inputarr, $arg3);
																				}
																} else
																{
																				$nrows += $offset;
																				$sql = preg_replace("/(^select[\\t\\n ]*(distinctrow|distinct)?)/i", "\\1 top " . $nrows . " ", $sql);
																				$nrows = -1;
																}
												}
												if (0 < $secs2cache)
												{
																$rs = &$this->cacheexecute($secs2cache, $sql, $inputarr, $arg3);
												} else
												{
																$rs = &$this->execute($sql, $inputarr, $arg3);
												}
												if ($rs && !$rs->EOF)
												{
																return $this->_rs2rs($rs, $nrows, $offset);
												}
												return $rs;
								}
								function &_rs2rs(&$rs, $nrows = -1, $offset = -1)
								{
												$arr = &$rs->getarraylimit($nrows, $offset);
												$flds = array();
												$i = 0;
												$max = $rs->fieldcount();
												for (; $i < $max; ++$i)
												{
																$flds[] = &$rs->fetchfield($i);
												}
												$rs->close();
												$rs2 = new adorecordset_array();
												$rs2->connection = &$this;
												$rs2->initarrayfields($arr, $flds);
												return $rs2;
								}
								function getone($sql, $inputarr = false)
								{
												$ret = false;
												$rs = &$this->execute($sql, $inputarr);
												if ($rs)
												{
																if (!$rs->EOF)
																{
																				$ret = reset($rs->fields);
																}
																$rs->close();
												}
												return $ret;
								}
								function &getall($sql, $inputarr = false)
								{
												$rs = $this->execute($sql, $inputarr);
												if (!$rs)
												{
																if (defined("ADODB_PEAR"))
																{
																				return adodb_pear_error();
																} else
																{
																				return false;
																}
												}
												return $rs->getarray();
								}
								function getrow($sql, $inputarr = false)
								{
												$rs = $this->execute($sql, $inputarr);
												if ($rs)
												{
																$arr = false;
																if (!$rs->EOF)
																{
																				$arr = $rs->fields;
																}
																$rs->close();
																return $arr;
												}
												return false;
								}
								function &cacheselectlimit($secs2cache, $sql, $nrows = -1, $offset = -1, $inputarr = false, $arg3 = false)
								{
												if (!is_numeric($secs2cache))
												{
																if ($sql === false)
																{
																				$sql = -1;
																}
																if ($offset == -1)
																{
																				$offset = false;
																}
																return $this->selectlimit($secs2cache, $sql, $nrows, $offset, $inputarr, $this->cacheSecs);
												}
												if ($sql === false)
												{
																echo "Warning: \$sql missing from CacheSelectLimit()<br />";
												}
												return $this->selectlimit($sql, $nrows, $offset, $inputarr, $arg3, $secs2cache);
								}
								function cacheflush($sql)
								{
												$f = $this->_gencachename($sql, false);
												adodb_write_file($f, "");
												@unlink($f);
								}
								function _gencachename($sql, $createdir)
								{
												global $ADODB_CACHE_DIR;
												$m = md5($sql . $this->databaseType . $this->database . $this->user);
												$dir = $ADODB_CACHE_DIR . "/" . substr($m, 0, 2);
												if ($createdir && !file_exists($dir) && !mkdir($dir, 505) && $this->debug)
												{
																print "Unable to mkdir {$dir} for {$sql}<br>";
												}
												return $dir . "/adodb_" . $m . ".cache";
								}
								function &cacheexecute($secs2cache, $sql = false, $inputarr = false, $arg3 = false)
								{
												if (!is_numeric($secs2cache))
												{
																$arg3 = $inputarr;
																$inputarr = $sql;
																$sql = $secs2cache;
																$secs2cache = $this->cacheSecs;
												}
												include_once (ADODB_DIR . "/adodb-csvlib.inc.php");
												if ($inputarr)
												{
																return $this->execute($sql, $inputarr, $arg3);
												}
												$md5file = $this->_gencachename($sql, true);
												$err = "";
												if (0 < $secs2cache)
												{
																$rs = &csv2rs($md5file, $err, $secs2cache);
												} else
												{
																$err = "Timeout 1";
																$rs = false;
												}
												if (!$rs)
												{
																if ($this->debug)
																{
																				print " {$md5file} cache failure: {$err}<br>";
																}
																$rs = &$this->execute($sql, $inputarr, $arg3);
																if ($rs)
																{
																				$eof = $rs->EOF;
																				$rs = &$this->_rs2rs($rs);
																				$txt = &rs2csv($rs, false, $sql);
																				if (!adodb_write_file($md5file, $txt, $this->debug))
																				{
																								if ($fn = $this->raiseErrorFn)
																								{
																												$fn($this->databaseType, "CacheExecute", -32000, "Cache write error", $md5file, $sql);
																								}
																								if ($this->debug)
																								{
																												print " Cache write error<br>";
																								}
																				}
																				if ($rs->EOF && !$eof)
																				{
																								$rs = &csv2rs($md5file, $err);
																								$rs->connection = &$this;
																				}
																} else
																{
																				@unlink($md5file);
																}
												} else
												{
																$rs->connection = &$this;
																if ($this->debug)
																{
																				$ttl = $rs->timeCreated + $secs2cache - time();
																				print " {$md5file} reloaded, ttl={$ttl}<br>";
																}
												}
												return $rs;
								}
								function getupdatesql(&$rs, $arrFields, $forceUpdate = false, $magicq = false)
								{
												include_once (ADODB_DIR . "/adodb-lib.inc.php");
												return _adodb_getupdatesql($this, $rs, $arrFields, $forceUpdate, $magicq);
								}
								function getinsertsql(&$rs, $arrFields, $magicq = false)
								{
												include_once (ADODB_DIR . "/adodb-lib.inc.php");
												return _adodb_getinsertsql($this, $rs, $arrFields, $magicq);
								}
								function updateblob($table, $column, $val, $where, $blobtype = "BLOB")
								{
												$sql = "UPDATE {$table} SET {$column}=" . $this->qstr($val) . " WHERE {$where}";
												$rs = $this->execute($sql);
												$rez = !empty($rs);
												return $rez;
								}
								function updateblobfile($table, $column, $path, $where, $blobtype = "BLOB")
								{
												$fd = fopen($path, "rb");
												if ($fd === false)
												{
																return false;
												}
												$val = fread($fd, filesize($path));
												fclose($fd);
												$sql = "UPDATE {$table} SET {$column}=" . $this->qstr($val) . " WHERE {$where}";
												$rs = $this->execute($sql);
												$rez = !empty($rs);
												return $rez;
								}
								function updateclob($table, $column, $val, $where)
								{
												return $this->updateblob($table, $column, $val, $where, "CLOB");
								}
								function blankrecordset($id = false)
								{
												$rsclass = "ADORecordSet_" . $this->databaseType;
												return new $rsclass($id);
								}
								function actualtype($meta)
								{
												switch ($meta)
												{
																case "C":
																case "X":
																				return "VARCHAR";
																case "B":
																case "D":
																case "T":
																case "L":
																case "R":
																case "I":
																case "N":
																				return false;
												}
								}
								function charmax()
								{
												return 255;
								}
								function textmax()
								{
												return 4000;
								}
								function close()
								{
												return $this->_close();
								}
								function begintrans()
								{
												return false;
								}
								function committrans()
								{
												return true;
								}
								function rollbacktrans()
								{
												return false;
								}
								function metadatabases()
								{
												return false;
								}
								function metatables()
								{
												if ($this->metaTablesSQL)
												{
																$rs = $this->execute($this->metaTablesSQL);
																if ($rs === false)
																{
																				return false;
																}
																$arr = $rs->getarray();
																$arr2 = array();
																$i = 0;
																for (; $i < sizeof($arr); ++$i)
																{
																				$arr2[] = $arr[$i][0];
																}
																$rs->close();
																return $arr2;
												}
												return false;
								}
								function metacolumns($table)
								{
												global $ADODB_FETCH_MODE;
												if (!empty($this->metaColumnsSQL))
												{
																$save = $ADODB_FETCH_MODE;
																$ADODB_FETCH_MODE = ADODB_FETCH_NUM;
																$rs = $this->execute(sprintf($this->metaColumnsSQL, strtoupper($table)));
																$ADODB_FETCH_MODE = $save;
																if ($rs === false)
																{
																				return false;
																}
																$retarr = array();
																while (!$rs->EOF)
																{
																				$fld = new adofieldobject();
																				$fld->name = $rs->fields[0];
																				$fld->type = $rs->fields[1];
																				$fld->max_length = $rs->fields[2];
																				$retarr[strtoupper($fld->name)] = $fld;
																				$rs->movenext();
																}
																$rs->close();
																return $retarr;
												}
												return false;
								}
								function metacolumnnames($table)
								{
												$objarr = $this->metacolumns($table);
												if (!is_array($objarr))
												{
																return false;
												}
												$arr = array();
												foreach ($objarr as $v)
												{
																$arr[] = $v->name;
												}
												return $arr;
								}
								function concat()
								{
												$arr = func_get_args();
												return implode($this->concat_operator, $arr);
								}
								function dbdate($d)
								{
												if (empty($d) && $d !== 0)
												{
																return "null";
												}
												if (is_string($d) && !is_numeric($d))
												{
																if ($this->isoDates)
																{
																				return "'{$d}'";
																} else
																{
																				$d = adorecordset::unixdate($d);
																}
												}
												return date($this->fmtDate, $d);
								}
								function dbtimestamp($ts)
								{
												if (empty($ts) && $ts !== 0)
												{
																return "null";
												}
												if (is_string($ts) && !is_numeric($ts))
												{
																if ($this->isoDates)
																{
																				return "'{$ts}'";
																} else
																{
																				$ts = adorecordset::unixtimestamp($ts);
																}
												}
												return date($this->fmtTimeStamp, $ts);
								}
								function qstr($s, $magic_quotes = false)
								{
												$nofixquotes = false;
												if (!$magic_quotes)
												{
																if ($this->replaceQuote[0] == "\\")
																{
																				$s = str_replace("\\", "\\\\", $s);
																}
																return "'" . str_replace("'", $this->replaceQuote, $s) . "'";
												}
												$s = str_replace("\\\"", "\"", $s);
												if ($this->replaceQuote == "\\'")
												{
																return "'{$s}'";
												} else
												{
																$s = str_replace("\\\\", "\\", $s);
																return "'" . str_replace("\\'", $this->replaceQuote, $s) . "'";
												}
								}
								function &pageexecute($sql, $nrows, $page, $inputarr = false, $arg3 = false, $secs2cache = 0)
								{
												include_once (ADODB_DIR . "/adodb-lib.inc.php");
												return _adodb_pageexecute($this, $sql, $nrows, $page, $inputarr, $arg3, $secs2cache);
								}
								function &cachepageexecute($secs2cache, $sql, $nrows, $page, $inputarr = false, $arg3 = false)
								{
												include_once (ADODB_DIR . "/adodb-lib.inc.php");
												return _adodb_pageexecute($this, $sql, $nrows, $page, $inputarr, $arg3, $secs2cache);
								}
				}
				class adofetchobj
				{
				}
				class adorecordset_empty
				{
								var $dataProvider = "empty";
								var $EOF = true;
								var $_numOfRows = 0;
								var $fields = false;
								var $connection = false;
								function rowcount()
								{
												return 0;
								}
								function recordcount()
								{
												return 0;
								}
								function close()
								{
												return true;
								}
								function fetchrow()
								{
												return false;
								}
				}
				class adorecordset
				{
								var $dataProvider = "native";
								var $fields = false;
								var $blobSize = 64;
								var $canSeek = false;
								var $sql;
								var $EOF = false;
								var $emptyTimeStamp = "&nbsp;";
								var $emptyDate = "&nbsp;";
								var $debug = false;
								var $timeCreated = 0;
								var $bind = false;
								var $fetchMode;
								var $connection = false;
								var $_numOfRows = -1;
								var $_numOfFields = -1;
								var $_queryID = -1;
								var $_currentRow = -1;
								var $_closed = false;
								var $_inited = false;
								var $_obj;
								var $_names;
								var $_currentPage = -1;
								var $_atFirstPage = false;
								var $_atLastPage = false;
								function adorecordset(&$queryID)
								{
												$this->_queryID = $queryID;
								}
								function init()
								{
												if ($this->_inited)
												{
																return;
												}
												$this->_inited = true;
												if ($this->_queryID)
												{
																@$this->_initrs();
												} else
												{
																$this->_numOfRows = 0;
																$this->_numOfFields = 0;
												}
												if ($this->_numOfRows != 0 && $this->_numOfFields && $this->_currentRow == -1)
												{
																$this->_currentRow = 0;
																$this->EOF = $this->_fetch() === false;
												} else
												{
																$this->EOF = true;
												}
								}
								function getmenu($name, $defstr = "", $blank1stItem = true, $multiple = false, $size = 0, $selectAttr = "", $compareFields0 = true)
								{
												include_once (ADODB_DIR . "/adodb-lib.inc.php");
												return _adodb_getmenu($this, $name, $defstr, $blank1stItem, $multiple, $size, $selectAttr, $compareFields0);
								}
								function getmenu2($name, $defstr = "", $blank1stItem = true, $multiple = false, $size = 0, $selectAttr = "")
								{
												include_once (ADODB_DIR . "/adodb-lib.inc.php");
												return _adodb_getmenu($this, $name, $defstr, $blank1stItem, $multiple, $size, $selectAttr, false);
								}
								function getarray($nRows = -1)
								{
												$results = array();
												$cnt = 0;
												while (!$this->EOF && $nRows != $cnt)
												{
																$results[$cnt++] = $this->fields;
																$this->movenext();
												}
												return $results;
								}
								function nextrecordset()
								{
												return false;
								}
								function getarraylimit($nrows, $offset = -1)
								{
												if ($offset <= 0)
												{
																return $this->getarray($nrows);
												}
												$this->move($offset);
												$results = array();
												$cnt = 0;
												while (!$this->EOF && $nrows != $cnt)
												{
																$results[$cnt++] = $this->fields;
																$this->movenext();
												}
												return $results;
								}
								function getrows($nRows = -1)
								{
												return $this->getarray($nRows);
								}
								function getassoc($force_array = false)
								{
												$cols = $this->_numOfFields;
												if ($cols < 2)
												{
																return false;
												}
												$numIndex = isset($this->fields[0]);
												$results = array();
												if (2 < $cols || $force_array)
												{
																if ($numIndex)
																{
																				while (!$this->EOF)
																				{
																								$results[trim($this->fields[0])] = array_slice($this->fields, 1);
																								$this->movenext();
																				}
																} else
																				if (!$this->EOF)
																				{
																								while (!$this->EOF)
																								{
																												$results[trim(reset($this->fields))] = array_slice($this->fields, 1);
																												$this->movenext();
																								}
																				}
												} else
												{
																if ($numIndex)
																{
																				while (!$this->EOF)
																				{
																								$results[trim($this->fields[0])] = $this->fields[1];
																								$this->movenext();
																				}
																} else
																{
																				while (!$this->EOF)
																				{
																								$v1 = trim(reset($this->fields));
																								$v2 = "" . next($this->fields);
																								$results[$v1] = $v2;
																								$this->movenext();
																				}
																}
												}
												return $results;
								}
								function usertimestamp($v, $fmt = "Y-m-d H:i:s")
								{
												$tt = $this->unixtimestamp($v);
												if (($tt === false || $tt == -1) && $v != false)
												{
																return $v;
												}
												if ($tt == 0)
												{
																return $this->emptyTimeStamp;
												}
												return date($fmt, $tt);
								}
								function userdate($v, $fmt = "Y-m-d")
								{
												$tt = $this->unixdate($v);
												if (($tt === false || $tt == -1) && $v != false)
												{
																return $v;
												} else
																if ($tt == 0)
																{
																				return $this->emptyDate;
																} else
																				if ($tt == -1)
																				{
																				}
												return date($fmt, $tt);
								}
								function unixdate($v)
								{
												if (!preg_match("|([0-9]{4})[-/\\.]?([0-9]{1,2})[-/\\.]?([0-9]{1,2})|", $v, $rr))
												{
																return false;
												}
												if ($rr[1] <= 1970)
												{
																return 0;
												}
												return mktime(0, 0, 0, $rr[2], $rr[3], $rr[1]);
								}
								function unixtimestamp($v)
								{
												if (!preg_match("|([0-9]{4})[-/\\.]?([0-9]{1,2})[-/\\.]?([0-9]{1,2})[ -]?(([0-9]{1,2}):?([0-9]{1,2}):?([0-9]{1,2}))?|", $v, $rr))
												{
																return false;
												}
												if ($rr[1] <= 1970 && $rr[2] <= 1)
												{
																return 0;
												}
												return mktime($rr[5], $rr[6], $rr[7], $rr[2], $rr[3], $rr[1]);
								}
								function free()
								{
												return $this->close();
								}
								function numrows()
								{
												return $this->_numOfRows;
								}
								function numcols()
								{
												return $this->_numOfCols;
								}
								function fetchrow()
								{
												if ($this->EOF)
												{
																return false;
												}
												$arr = $this->fields;
												$this->movenext();
												return $arr;
								}
								function fetchinto(&$arr)
								{
												if ($this->EOF)
												{
																return defined("PEAR_ERROR_RETURN") ? new pear_error("EOF", -1) : false;
												}
												$arr = $this->fields;
												$this->movenext();
												return 1;
								}
								function movefirst()
								{
												if ($this->_currentRow == 0)
												{
																return true;
												}
												return $this->move(0);
								}
								function movelast()
								{
												if (0 <= $this->_numOfRows)
												{
																return $this->move($this->_numOfRows - 1);
												}
												while (!$this->EOF)
												{
																$this->movenext();
												}
												return true;
								}
								function movenext()
								{
												if (!$this->EOF)
												{
																++$this->_currentRow;
																if ($this->_fetch())
																{
																				return true;
																}
												}
												$this->EOF = true;
												return false;
								}
								function move($rowNumber = 0)
								{
												if ($rowNumber == $this->_currentRow)
												{
																return true;
												}
												if ($this->_numOfRows < $rowNumber && $this->_numOfRows != -1)
												{
																$rowNumber = $this->_numOfRows - 1;
												}
												if ($this->canSeek)
												{
																if ($this->_seek($rowNumber))
																{
																				$this->_currentRow = $rowNumber;
																				if ($this->_fetch())
																				{
																								$this->EOF = false;
																								return true;
																				}
																} else
																{
																				return false;
																}
												} else
												{
																if ($rowNumber < $this->_currentRow)
																{
																				return false;
																}
																while (!$this->EOF && $this->_currentRow < $rowNumber)
																{
																				++$this->_currentRow;
																				if (!$this->_fetch())
																				{
																								$this->EOF = true;
																				}
																}
																return !$this->EOF;
												}
												$this->fields = null;
												$this->EOF = true;
												return false;
								}
								function fields($colname)
								{
												return $this->fields[$colname];
								}
								function &getrowassoc($upper = true)
								{
												if (!$this->bind)
												{
																$this->bind = array();
																$i = 0;
																for (; $i < $this->_numOfFields; ++$i)
																{
																				$o = $this->fetchfield($i);
																				$this->bind[$upper ? strtoupper($o->name) : strtolower($o->name)] = $i;
																}
												}
												$record = array();
												foreach ($this->bind as $k => $v)
												{
																$record[$k] = $this->fields[$v];
												}
												return $record;
								}
								function close()
								{
												if (!$this->_closed)
												{
																$this->_closed = true;
																return $this->_close();
												} else
												{
																return true;
												}
								}
								function recordcount()
								{
												return $this->_numOfRows;
								}
								function rowcount()
								{
												return $this->_numOfRows;
								}
								function po_recordcount($table = "", $condition = "")
								{
												$lnumrows = $this->_numOfRows;
												if ($lnumrows == -1 && $this->connection && $table)
												{
																if ($condition)
																{
																				$condition = " WHERE " . $condition;
																}
																$resultrows = &$this->connection->execute("SELECT COUNT(*) FROM {$table} {$condition}");
																if ($resultrows)
																{
																				$lnumrows = reset($resultrows->fields);
																}
												}
												return $lnumrows;
								}
								function currentrow()
								{
												return $this->_currentRow;
								}
								function absoluteposition()
								{
												return $this->_currentRow;
								}
								function fieldcount()
								{
												return $this->_numOfFields;
								}
								function &fetchfield($fieldoffset)
								{
								}
								function &fetchobject($isupper = true)
								{
												if (empty($this->_obj))
												{
																$this->_obj = new adofetchobj();
																$this->_names = array();
																$i = 0;
																for (; $i < $this->_numOfFields; ++$i)
																{
																				$f = $this->fetchfield($i);
																				$this->_names[] = $f->name;
																}
												}
												$i = 0;
												$o = &$this->_obj;
												$i = 0;
												for (; $i < $this->_numOfFields; ++$i)
												{
																$name = $this->_names[$i];
																if ($isupper)
																{
																				$n = strtoupper($name);
																} else
																{
																				$n = $name;
																}
																$o->$n = $this->fields($name);
												}
												return $o;
								}
								function &fetchnextobject($isupper = true)
								{
												$o = false;
												if ($this->_numOfRows != 0 && !$this->EOF)
												{
																$o = $this->fetchobject($isupper);
																++$this->_currentRow;
																if ($this->_fetch())
																{
																				return $o;
																}
												}
												$this->EOF = true;
												return $o;
								}
								function MetaType($t, $len = -1, $fieldobj = false)
								{
												if (is_object($t))
												{
																$fieldobj = $t;
																$t = $fieldobj->type;
																$len = $fieldobj->max_length;
												}
												static $typeMap = array('VARCHAR' => 'C', 'VARCHAR2' => 'C', 'CHAR' => 'C', 'C' => 'C', 'STRING' => 'C', 'NCHAR' => 'C', 'NVARCHAR' => 'C', 'VARYING' => 'C', 'BPCHAR' => 'C', 'CHARACTER' => 'C', 'INTERVAL' => 'C', 'MACADDR' => 'C', 'LONGCHAR' => 'X', 'TEXT' => 'X', 'NTEXT' => 'X', 'M' => 'X', 'X' => 'X', 'CLOB' => 'X', 'NCLOB' => 'X', 'LVARCHAR' => 'X', 'BLOB' => 'B', 'IMAGE' => 'B', 'BINARY' => 'B', 'VARBINARY' => 'B', 'LONGBINARY' => 'B', 'B' => 'B', 'YEAR' => 'D', 'DATE' => 'D', 'D' => 'D', 'UNIQUEIDENTIFIER' => 'C', 'TIME' => 'T', 'TIMESTAMP' => 'T', 'DATETIME' => 'T', 'TIMESTAMPTZ' => 'T', 'T' => 'T', 'TIMESTAMP WITHOUT TIME ZONE' => 'T', 'BOOL' => 'L', 'BOOLEAN' => 'L', 'BIT' => 'L', 'L' => 'L', 'COUNTER' => 'R', 'R' => 'R', 'SERIAL' => 'R', 'INT IDENTITY' => 'R', 'INT' => 'I', 'INT2' => 'I', 'INT4' => 'I', 'INT8' => 'I', 'INTEGER' => 'I', 'INTEGER UNSIGNED' => 'I', 'SHORT' => 'I', 'TINYINT' => 'I', 'SMALLINT' => 'I', 'I' => 'I', 'LONG' => 'N', 'BIGINT' => 'N',
																'DECIMAL' => 'N', 'DEC' => 'N', 'REAL' => 'N', 'DOUBLE' => 'N', 'DOUBLE PRECISION' => 'N', 'SMALLFLOAT' => 'N', 'FLOAT' => 'N', 'NUMBER' => 'N', 'NUM' => 'N', 'NUMERIC' => 'N', 'MONEY' => 'N', 'SQLINT' => 'I', 'SQLSERIAL' => 'I', 'SQLSMINT' => 'I', 'SQLSMFLOAT' => 'N', 'SQLFLOAT' => 'N', 'SQLMONEY' => 'N', 'SQLDECIMAL' => 'N', 'SQLDATE' => 'D', 'SQLVCHAR' => 'C', 'SQLCHAR' => 'C', 'SQLDTIME' => 'T', 'SQLINTERVAL' => 'N', 'SQLBYTES' => 'B', 'SQLTEXT' => 'X', "SQLINT8" => 'I8', "SQLSERIAL8" => 'I8', "SQLNCHAR" => 'C', "SQLNVCHAR" => 'C', "SQLLVARCHAR" => 'X', "SQLBOOL" => 'L');
												$tmap = false;
												$t = strtoupper($t);
												$tmap = (isset($typeMap[$t])) ? $typeMap[$t] : 'N';
												switch ($tmap)
												{
																case 'C':
																				if ($this->blobSize >= 0)
																				{
																								if ($len > $this->blobSize) return 'X';
																				} else
																								if ($len > 250)
																								{
																												return 'X';
																								}
																				return 'C';
																case 'I':
																				if (!empty($fieldobj->primary_key)) return 'R';
																				return 'I';
																case false:
																				return 'N';
																case 'B':
																				if (isset($fieldobj->binary)) return ($fieldobj->binary) ? 'B' : 'X';
																				return 'B';
																case 'D':
																				if (!empty($this->connection) && !empty($this->connection->datetime)) return 'T';
																				return 'D';
																default:
																				if ($t == 'LONG' && $this->dataProvider == 'oci8') return 'B';
																				return $tmap;
												}
								}
								/**
								function metatype($t, $len = -1, $fieldobj = false)
								{
												switch (strtoupper($t))
												{
																case "VARCHAR":
																case "VARCHAR2":
																case "CHAR":
																case "STRING":
																case "C":
																case "NCHAR":
																case "NVARCHAR":
																case "VARYING":
																case "BPCHAR":
																				do {
																								do
																								{
																												if (empty($this))
																												{
																																break;
																												} else
																												{
																																if ($len <= $this->blobSize)
																																{
																																				return "C";
																																}
																																if (!($len <= 250))
																																{
																																				break;
																																} else
																																{
																																				return "C";
																																}
																												}
																								case "LONGCHAR" : case "TEXT" : case "M" : case "X" : case "CLOB" : case "NCLOB" : } while (0);
																				} while (0);
																case "LONG":
																				return "X";
																case "BLOB":
																case "NTEXT":
																case "BINARY":
																case "VARBINARY":
																case "LONGBINARY":
																case "B":
																				return "B";
																case "DATE":
																case "D":
																				return "D";
																case "TIME":
																case "TIMESTAMP":
																case "DATETIME":
																case "T":
																				return "T";
																case "BOOLEAN":
																case "BIT":
																case "L":
																				return "L";
																case "COUNTER":
																case "R":
																case "SERIAL":
																				return "R";
																case "INT":
																case "INTEGER":
																case "SHORT":
																case "TINYINT":
																case "SMALLINT":
																case "I":
																				if (!empty($fieldobj->primary_key))
																				{
																								return "R";
																				}
																				return "I";
																default:
																				return "N";
												}
								}
								**/
								function _close()
								{
								}
								function absolutepage($page = -1)
								{
												if ($page != -1)
												{
																$this->_currentPage = $page;
												}
												return $this->_currentPage;
								}
								function atfirstpage($status = false)
								{
												if ($status != false)
												{
																$this->_atFirstPage = $status;
												}
												return $this->_atFirstPage;
								}
								function atlastpage($status = false)
								{
												if ($status != false)
												{
																$this->_atLastPage = $status;
												}
												return $this->_atLastPage;
								}
				}
				class adorecordset_array extends adorecordset
				{
								var $databaseType = "array";
								var $_array;
								var $_types;
								var $_colnames;
								var $_skiprow1;
								var $_fieldarr;
								var $canSeek = true;
								var $affectedrows = false;
								var $insertid = false;
								var $sql = "";
								function adorecordset_array($fakeid = 1)
								{
												$this->adorecordset($fakeid);
								}
								function initarray(&$array, $typearr, $colnames = false)
								{
												$this->_array = $array;
												$this->_types = &$typearr;
												if ($colnames)
												{
																$this->_skiprow1 = false;
																$this->_colnames = $colnames;
												} else
												{
																$this->_colnames = $array[0];
												}
												$this->init();
								}
								function initarrayfields(&$array, &$fieldarr)
								{
												$this->_array = &$array;
												$this->_skiprow1 = false;
												if ($fieldarr)
												{
																$this->_fieldobjects = &$fieldarr;
												}
												$this->init();
								}
								function _initrs()
								{
												$this->_numOfRows = sizeof($this->_array);
												if ($this->_skiprow1)
												{
																$this->_numOfRows -= 1;
												}
												$this->_numOfFields = isset($this->_fieldobjects) ? sizeof($this->_fieldobjects) : sizeof($this->_types);
								}
								function fields($colname)
								{
												if (!$this->bind)
												{
																$this->bind = array();
																$i = 0;
																for (; $i < $this->_numOfFields; ++$i)
																{
																				$o = $this->fetchfield($i);
																				$this->bind[strtoupper($o->name)] = $i;
																}
												}
												return $this->fields[$this->bind[strtoupper($colname)]];
								}
								function &fetchfield($fieldOffset = -1)
								{
												if (isset($this->_fieldobjects))
												{
																return $this->_fieldobjects[$fieldOffset];
												}
												$o = new adofieldobject();
												$o->name = $this->_colnames[$fieldOffset];
												$o->type = $this->_types[$fieldOffset];
												$o->max_length = -1;
												return $o;
								}
								function _seek($row)
								{
												return true;
								}
								function _fetch()
								{
												$pos = $this->_currentRow;
												if ($this->_skiprow1)
												{
																if ($this->_numOfRows <= $pos - 1)
																{
																				return false;
																}
																$pos += 1;
												} else
												{
																if ($this->_numOfRows <= $pos)
																{
																				return false;
																}
												}
												$this->fields = $this->_array[$pos];
												return true;
								}
								function _close()
								{
												return true;
								}
				}
				function adoloaddb($dbType)
				{
								return adoloadcode($dbType);
				}
				function adoloadcode($dbType)
				{
								global $ADODB_Database;
								if (!$dbType)
								{
												return false;
								}
								$ADODB_Database = strtolower($dbType);
								switch ($ADODB_Database)
								{
												case "maxsql":
																$ADODB_Database = "mysqlt";
																break;
												case "pgsql":
																$ADODB_Database = "postgres7";
								}
								include_once (ADODB_DIR . "/drivers/adodb-{$ADODB_Database}.inc.php");
								return true;
				}
				function &newadoconnection($db = "")
				{
								return adonewconnection($db);
				}
				function &adonewconnection($db = "")
				{
								global $ADODB_Database;
								if ($db)
								{
												if ($ADODB_Database != $db)
												{
																adoloadcode($db);
												}
								} else
												if (!empty($ADODB_Database))
												{
																adoloadcode($ADODB_Database);
												} else
												{
																print "<p>ADONewConnection: No database driver defined</p>";
												}
												$cls = "ADODB_" . $ADODB_Database;
								$obj = new $cls();
								if (defined("ADODB_ERROR_HANDLER"))
								{
												$obj->raiseErrorFn = ADODB_ERROR_HANDLER;
								}
								return $obj;
				}
				function adodb_write_file($filename, $contents, $debug = false)
				{
								if (strpos(strtoupper(PHP_OS), "WIN") !== false)
								{
												$mtime = substr(str_replace(" ", "_", microtime()), 2);
												@unlink($filename);
												$tmpname = $filename . uniqid($mtime) . getmypid();
												if (!($fd = fopen($tmpname, "a")))
												{
																return false;
												}
												$ok = ftruncate($fd, 0);
												if (!fwrite($fd, $contents))
												{
																$ok = false;
												}
												fclose($fd);
												chmod($tmpname, 420);
												if (!rename($tmpname, $filename))
												{
																unlink($tmpname);
																$ok = false;
												}
												if (!$ok && $debug)
												{
																print " Rename {$tmpname} " . ($ok ? "ok" : "failed") . " <br>";
												}
												return $ok;
								}
								if (!($fd = fopen($filename, "a")))
								{
												return false;
								}
								if (flock($fd, LOCK_EX) && ftruncate($fd, 0))
								{
												$ok = fwrite($fd, $contents);
												fclose($fd);
												chmod($filename, 420);
								} else
								{
												fclose($fd);
												if ($debug)
												{
																print " Failed acquiring lock for {$filename}<br>";
												}
												$ok = false;
								}
								return $ok;
				}
}
?>
