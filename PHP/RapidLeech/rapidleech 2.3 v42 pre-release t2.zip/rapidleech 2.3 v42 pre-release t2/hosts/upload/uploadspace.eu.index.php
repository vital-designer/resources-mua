<?php
$upload_services[]="uploadspace.eu";
$max_file_size["uploadspace.eu"]=400;
$page_upload["uploadspace.eu"] = "uploadspace.eu.php";  
?>