<?php 
$upload_services[] = "megaupload.com";
$max_file_size["megaupload.com"] = 1024;
$page_upload["megaupload.com"] = "megaupload.com.php";
?>