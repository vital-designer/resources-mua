<?php
include ("../common.php");
include ("../include/archive_function.php");
$section = "statistic";
$right_name = "view_interest";
check_right($section, $right_name);
if (isset($_GET['rid']))
{
				$rid = $_GET['rid'];
} else
{
				$rid = "-1";
}
if (isset($_GET['uid']))
{
				$uid = $_GET['uid'];
} else
{
				$uid = "-1";
}
if (isset($_GET['url']))
{
				$url = $_GET['url'];
} else
{
				$url = "-1";
}
$smarty->assign("releases", getallreleases());
$smarty->assign("users", getallclients());
$smarty->assign("urls", getallurls());
$smarty->assign("rid", $rid);
$smarty->assign("uid", $uid);
$smarty->assign("url", $url);
$rel = getinterestedsubscribers($rid, $uid, $url);
$smarty->assign("rel", $rel);
$smarty->assign("razdel", "Statistics");
$smarty->assign("description", "Interested Subscribers");
$smarty->assign("hint", "View interested subscribers� statistics. Here you can view who, when, and by what links followed your newsletters. This is how you can watch your subscribers' activity related to visiting Internet web-pages, hyperlinks indicated in your newsletters.");
$smarty->assign("count", count($rel));
$smarty->display("{$admin_nl_gentemplates}/archive_interest.tpl");
?>