<?
//phpFormBuilder Version 1.5 by Baris Kayar (barishkayar@yahoo.com)
//2002(cl)  The FormBuilder Group http://pfb.sourceforge.net

require("config.inc.php");
$PFBg_Title="PHPFB $alan $Property_Caption";
require("style.inc.php");
//echo $PFBg_opt; //ne gelmi� g�relim.
$suAnkiDurum=explode(";",$PFBg_opt);
?>
<script>
//Javascript Functions :)) 2000(cl) [barish@bnet.net.tr]
function strcount(aranan,barindiran)
{
var havingcount=0;
for (var i = 0; i < barindiran.length; i++) 
	{
	if (barindiran.substr(i,1)==aranan) {havingcount++;}
	}
return havingcount;
}
function strpos(aranan,barindiran,neredensonra)
{
if (isNaN(neredensonra)) return false;
if (barindiran.length<neredensonra) return 0;
var pos=0;
for (var i = neredensonra; i < barindiran.length; i++) 
	{
	if (barindiran.substr(i,1)==aranan) 
		{
		pos=i;
		break;
		}
	}
return pos;
}
function numerik_mi(n){
        if ( isNaN(n) || n.indexOf(".") != -1)
            return true;	//not a number
        else
	        return false;	// number
    }

function gonder(option)
	{
	<?
	switch ($PFBg_obj)
	{
	case "textarea":
	echo "
		with (document.optta)
		{
		if (title.value==\"\") 
							{
							alert (\"$Caption_Caption $ErrorMsg_1\");
							title.focus();
							return false;
							}
		if (cols.value==\"\" || numerik_mi(cols.value)) 
							{
							alert (\"$Cols_Caption $ErrorMsg_2\");
							cols.focus();
							return false;
							}
		if (rows.value==\"\" || numerik_mi(rows.value))
							{
							alert (\"$Rows_Caption $ErrorMsg_2\");
							rows.focus();
							return false;
							}
		}
		";
	break;
	case "edit":
	echo "
		with (document.opted)
		{
		if (title.value==\"\") 
							{
							alert (\"$Caption_Caption $ErrorMsg_1\");
							title.focus();
							return false;
							}
		if (elength.value==\"\" || numerik_mi(elength.value))
							{
							alert (\"$Length_Caption $ErrorMsg_2\");
							elength.focus();
							return false;
							}
		if (emxsize.value==\"\" || numerik_mi(emxsize.value))
							{
							alert (\"$Max_Caption $Length_Caption $ErrorMsg_2\");
							emxsize.focus();
							return false;
							}
		if (emnsize.value==\"\" || numerik_mi(emnsize.value))
							{
							alert (\"$Min_Caption $Length_Caption $ErrorMsg_2\");
							emnsize.focus();
							return false;
							}
		}
		";
	break;
	case "checkbox":
	echo "
		with (document.optcb)
		{
		if (cbtitle.value==\"\") 
							{
							alert (\"$Caption_Caption $ErrorMsg_1\");
							cbtitle.focus();
							return false;
							}
		if (cbvalue.value==\"\") 
							{
							alert (\"$Caption_Caption $ErrorMsg_1\");
							cbvalue.focus();
							return false;
							}
		}
		";
	break;
	case "radiobox":
	echo "
		with (document.optrb)
		{
		if (rbmaintitle.value==\"\") 
							{
							alert (\"$Main_Caption $Caption_Caption $ErrorMsg_1\");
							rbmaintitle.focus();
							return false;
							}
		if (rbtitle.value==\"\" || strcount(\",\",rbtitle.value)<2) 
							{
							alert (\"$ErrorMsg_3\");
							rbtitle.focus();
							return false;
							}
		if (rbvalue.value==\"\" || strcount(\",\",rbvalue.value)<2) 
							{
							alert (\"$ErrorMsg_4\");
							rbvalue.focus();
							return false;
							}
		if (strcount(\",\",rbtitle.value)!=strcount(\",\",rbvalue.value))
							{
							alert (\"$ErrorMsg_5\");
							if (strcount(\",\",rbtitle.value)>strcount(\",\",rbvalue.value))
								{
								rbvalue.focus();
								}
								else
								{
								rbtitle.focus();
								}
							return false;
							}
		}
		";
	break;
	case "lov":
	echo "
		with (document.optlov)
		{
		if (lovtitle.value==\"\") 
			{
			alert (\"$Main_Caption $Caption_Caption $ErrorMsg_1\");
			lovtitle.focus();
			return false;
			}
		if (lovtcheck.value==\"dinamik\")
			{
			if (lovsql.value==\"\") 
				{
				alert (\"SQL $Statement_Caption $ErrorMsg_1\");
				lovsql.focus();
				return false;
				}
			}
		else
		{
		if (lovstitle.value==\"\" || strcount(\",\",lovstitle.value)<2) 
							{
							alert (\"$ErrorMsg_3\");
							lovstitle.focus();
							return false;
							}
		if (lovsvalue.value==\"\" || strcount(\",\",lovsvalue.value)<2) 
							{
							alert (\"$ErrorMsg_4\");
							lovsvalue.focus();
							return false;
							}
		if (strcount(\",\",lovstitle.value)!=strcount(\",\",lovsvalue.value))
							{
							alert (\"$ErrorMsg_5\");
							if (strcount(\",\",lovstitle.value)>strcount(\",\",lovsvalue.value))
								{
								lovsvalue.focus();
								}
								else
								{
								lovstitle.focus();
								}
							return false;
							}
		}
		}//else
		";
	break;
	}
	echo ("window.opener.document.$form.$alan.value =\"$PFBg_obj;\"+option;");
	?>
	window.close();
	}
</script>
<body>
<?
if ($PFBg_obj=="textarea")
{
echo "<h4>Textarea $Property_Caption</h4>";
?>
<form name="optta" onsubmit="return false;">
<table>
<tr><td><? echo $Caption_Caption;?></td><td>:<input type="text" name="title" value="<? echo $suAnkiDurum[2];?>"></td></tr>
<tr><td><? echo $Cols_Caption;?></td><td>:<input type="text" name="cols"
 value="<? if ($suAnkiDurum[0]=="textarea" && is_numeric($suAnkiDurum[3])) echo $suAnkiDurum[3]; else echo "40";?>"></td></tr>
<tr><td><? echo $Rows_Caption;?></td><td>:<input type="text" name="rows" 
 value="<? if ($suAnkiDurum[0]=="textarea" && is_numeric($suAnkiDurum[4])) echo $suAnkiDurum[4]; else echo "5";?>"></td></tr>
<tr><td><input type="Checkbox" name="readonly" <? if ($suAnkiDurum[0]=="textarea" && $suAnkiDurum[5]=="true") echo "checked";?>></td><td>Readonly</td></tr>
<tr><td><input type="Checkbox" name="notnull" <? if ($suAnkiDurum[0]=="textarea" && $suAnkiDurum[6]=="true") echo "checked";?>></td><td>Not Null</td></tr>
<tr><td colspan="2" align="center"><input type="Button" value="<? echo $OkayButon_Caption;?>" onclick="javascript: gonder('<? echo  $suAnkiDurum[1];?>;'+optta.title.value+';'+optta.cols.value+';'+optta.rows.value+';'+optta.readonly.checked+';'+optta.notnull.checked+';');"></td></tr>
</table>
</form>
<?
}
if ($PFBg_obj=="edit")
{
echo "<h4>Edit $Property_Caption</h4>";
?>
<form name="opted" onsubmit="return false;">
<table>
<tr><td><? echo $Caption_Caption;?></td><td>:<input type="text" name="title" value="<? echo $suAnkiDurum[2];?>"></td></tr>
<tr><td><? echo $Length_Caption;?></td><td>:<input type="text" name="elength" value="<? if ($suAnkiDurum[0]=="edit" && is_numeric($suAnkiDurum[3])) echo $suAnkiDurum[3];?>"></td></tr>
<tr><td><? echo $Min_Caption." ".$Length_Caption;?></td><td>:<input type="text" name="emnsize" value="<? if ($suAnkiDurum[0]=="edit" && is_numeric($suAnkiDurum[4])) echo $suAnkiDurum[4];?>"></td></tr>
<tr><td><? echo $Max_Caption." ".$Length_Caption;?></td><td>:<input type="text" name="emxsize" value="<? if ($suAnkiDurum[0]=="edit" && is_numeric($suAnkiDurum[5])) echo $suAnkiDurum[5];?>"></td></tr>
<tr><td><? echo $FieldType_Caption;?></td><td>:<select name="type">
	 <option value="text" <? if ($suAnkiDurum[6]=="text") echo "selected";?>>Text</option>
	 <option value="password" <? if ($suAnkiDurum[6]=="password") echo "selected";?>>Password</option>
	 </select></td></tr>
<tr><td><? echo $Value_Caption." ".$Type_Caption;?></td><td>:<select name="vtype">
	 <option value="alfanum" <? if ($suAnkiDurum[7]=="alfanum") echo "selected";?>><? echo $Alphanum_Caption;?></option>
	 <option value="alfa" <? if ($suAnkiDurum[7]=="alfa") echo "selected";?>><? echo $Alphabetic_Caption;?></option>
	 <option value="num" <? if ($suAnkiDurum[7]=="num") echo "selected";?>><? echo $Numeric_Caption;?></option>
	 <option value="void" <? if ($suAnkiDurum[7]=="void") echo "selected";?>><? echo $Void_Caption;?></option>
	 </select></td></tr>
<tr><td><input type="Checkbox" name="notnull" <? if ($suAnkiDurum[0]=="edit" && $suAnkiDurum[8]=="true") echo "checked";?>></td><td>Not Null</td></tr>
<tr><td colspan="2" align="center"><input type="Button" value="<? echo $OkayButon_Caption;?>" onclick="javascript: gonder('<? echo  $suAnkiDurum[1];?>;'+opted.title.value+';'+opted.elength.value+';'+opted.emnsize.value+';'+opted.emxsize.value+';'+opted.type.value+';'+opted.vtype.value+';'+opted.notnull.checked+';');"></td></tr>
</table>
</form>
<?
}
if ($PFBg_obj=="checkbox")
{
echo "<h4>Checkbox $Property_Caption</h4>";
?>
<form name="optcb" onsubmit="return false;">
<table>
<tr><td><? echo $Caption_Caption;?></td><td>:<input type="text" name="cbtitle" value="<? echo $suAnkiDurum[2];?>"></td></tr>
<tr><td><? echo $Value_Caption;?></td><td>:<input type="text" name="cbvalue"  value="<? if ($suAnkiDurum[0]=="checkbox") echo $suAnkiDurum[3];?>"></td></tr>
<tr><td><? echo $Caption_Caption." ".$Align_Caption;?></td><td>:<select name="cbalign">
	 <option value="top" <? if ($suAnkiDurum[4]=="top") echo "selected";?>><? echo $Up_Caption;?></option>
	 <option value="right" <? if ($suAnkiDurum[4]=="right") echo "selected";?>><? echo $Right_Caption;?></option>
	 <option value="left" <? if ($suAnkiDurum[4]=="left") echo "selected";?>><? echo $Left_Caption;?></option>
	 <option value="bottom" <? if ($suAnkiDurum[4]=="bottom") echo "selected";?>><? echo $Down_Caption;?></option>
	 </select></td></tr>
<tr><td><input type="checkbox" name="cbchecked" <? if ($suAnkiDurum[0]=="checkbox" && $suAnkiDurum[5]=="true") echo "checked";?>></td><td>Default Checked</td></tr>
<tr><td colspan="2" align="center"><input type="Button" value="<? echo $OkayButon_Caption;?>" onclick="javascript: gonder('<? echo  $suAnkiDurum[1];?>;'+optcb.cbtitle.value+';'+optcb.cbvalue.value+';'+optcb.cbalign.value+';'+optcb.cbchecked.checked+';');"></td></tr>
</table>
</form>
<?
}
if ($PFBg_obj=="radiobox")
{
echo "<h4>Radiobox $Property_Caption</h4>";
?>
<form name="optrb" onsubmit="return false;">
<table>
<tr><td><? echo $Main_Caption." ".$Caption_Caption;?></td><td>:<input type="text" name="rbmaintitle" value="<? echo $suAnkiDurum[2];?>"></td><td></td>
<tr><td><? echo $Captions_Caption;?></td><td>:<textarea name="rbtitle" cols="20" rows="4" readonly><? if ($suAnkiDurum[0]=="radiobox" && $suAnkiDurum[3]) echo $suAnkiDurum[3];?></textarea></td><td valign="middle"><a href="javascript: void(0);" onclick="javascript: newrbc();">Add</a></td></tr>
<tr><td><? echo $Values_Caption;?></td><td>:<textarea name="rbvalue" cols="20" rows="4" readonly><? if ($suAnkiDurum[0]=="radiobox" && $suAnkiDurum[4]) echo $suAnkiDurum[4];?></textarea></td><td valign="middle"><a href="javascript: void(0);" onclick="javascript: newrbv();">Add</a></td></tr>
<tr><td colspan="3" align="center"><input type="Button" value="<? echo $OkayButon_Caption;?>" onclick="javascript: gonder('<? echo  $suAnkiDurum[1];?>;'+optrb.rbmaintitle.value+';'+optrb.rbtitle.value+';'+optrb.rbvalue.value+';');"></td></tr>
</table>
</form>
<script>
function block(e) {
return false;
}
document.optrb.rbtitle.onkeypress = block;
document.optrb.rbvalue.onkeypress = block;
function newrbc()
{
  var str=prompt("<? echo $Caption_Caption;?> :","<? echo $Caption_Caption;?>");
  if ((str!=null) && (str!=""))
  	{
	 str=str.replace(",", "");
	 document.optrb.rbtitle.value+=str+",";
	}
  return true;
}
function newrbv()
{
  var str=prompt("<? echo $Value_Caption;?> :","<? echo $Value_Caption;?>");
  if ((str!=null) && (str!=""))
  		{
	  	str=str.replace(",", "");
		document.optrb.rbvalue.value+=str+",";
		}
  return true;
}
</script>
<?
}
if ($PFBg_obj=="lov")
{
echo "<h4>List of Value $Property_Caption</h4>";
?>
<form name="optlov" onsubmit="return false;">
<table>
<tr><td><? echo $Main_Caption." ".$Caption_Caption;?></td><td colspan="2">:<input type="text" name="lovtitle" value="<? echo $suAnkiDurum[2];?>"></td></tr>
<!--<tr><td><? //echo $Type_Caption;?></td><td colspan="2">:<select name="lovocheck">
<option value="multi" selected>Multi Select</option>
<option value="select">Select</option>
</select>
</td></tr> iptal ettim--><input type="Hidden" name="lovocheck" value="iptal">
<tr><td><? echo $Value_Caption." ".$Type_Caption;?></td><td colspan="2">:<select name="lovtcheck">
<option value="statik" <? if ($suAnkiDurum[4]=="statik") echo "selected";?>><? echo $Static_Caption;?></option>
<option value="dinamik" <? if ($suAnkiDurum[4]=="dinamik") echo "selected";?>><? echo $Dynamic_Caption;?></option>
</select>
</td></tr>
<tr><td><? echo $Static_Caption;?> LOV <? echo $Captions_Caption;?></td><td>:<textarea name="lovstitle" cols="20" rows="4" readonly><? if ($suAnkiDurum[0]=="lov" && $suAnkiDurum[5]) echo $suAnkiDurum[5];?></textarea></td><td valign="middle"><a href="javascript: void(0);" onclick="javascript: newlovtitle();"><? echo $AddButton_Caption;?></a></td></tr>
<tr><td><? echo $Static_Caption;?> LOV <? echo $Values_Caption;?></td><td>:<textarea name="lovsvalue" cols="20" rows="4" readonly><? if ($suAnkiDurum[0]=="lov" && $suAnkiDurum[6]) echo $suAnkiDurum[6];?></textarea></td><td valign="middle"><a href="javascript: void(0);" onclick="javascript: newlovvalue();"><? echo $AddButton_Caption;?></a></td></tr>
<tr><td><? echo $Dynamic_Caption;?> LOV <? echo $Statement_Caption;?></td><td>:<textarea name="lovsql" cols="20" rows="4"><? if ($suAnkiDurum[0]=="lov" && $suAnkiDurum[7]) echo $suAnkiDurum[7];?></textarea></td><td valign="middle"><a href="javascript: void(0);" onclick="javascript: newlovselect();"><? echo $Wizard_Caption;?></a></td></tr>
<tr><td colspan="3" align="center"><input type="Button" value="<? echo $OkayButon_Caption;?>" onclick="javascript: gonder('<? echo  $suAnkiDurum[1];?>;'+optlov.lovtitle.value+';'+optlov.lovocheck.value+';'+optlov.lovtcheck.options.value+';'+optlov.lovstitle.value+';'+optlov.lovsvalue.value+';'+optlov.lovsql.value+';');"></td></tr>
</table>
</form>
<script>
function block(e) {
return false;
}
document.optlov.lovstitle.onkeypress = block;
document.optlov.lovsvalue.onkeypress = block;
function newlovtitle()
{
  var str=prompt("<? echo $Caption_Caption;?> :","<? echo $Caption_Caption;?>");
  if ((str!=null) && (str!="")) 
  		{
		str=str.replace(",", "");
		document.optlov.lovstitle.value+=str+",";
		}
  return true;
}
function newlovvalue()
{
  var str=prompt("<? echo $Value_Caption;?> :","<? echo $Value_Caption;?>");
  if ((str!=null) && (str!=""))
  		{
		str=str.replace(",", "");
	  	document.optlov.lovsvalue.value+=str+",";
		}
  return true;
}
function newlovselect()
{
  document.optlov.lovsql.value="";
  var str1=prompt("<? echo "$Value_Caption $FieldName_Caption [$ErrorMsg_1]";?> :","");
  if ((str1!=null) && (str1!="")) document.optlov.lovsql.value+="select "+str1;
  	  else {
	  		document.optlov.lovsql.value="";
			return false;
	  		}
  var str2=prompt("<? echo "$Caption_Caption $FieldName_Caption [$ErrorMsg_1]";?> :","");
  if ((str2!=null) && (str2!="")) document.optlov.lovsql.value+=", "+str2;
  	  else {
	  		document.optlov.lovsql.value="";
			return false;
	  		}
  var str3=prompt("<? echo "$Table_Caption [$ErrorMsg_1]";?> :","");
  if ((str3!=null) && (str3!="")) document.optlov.lovsql.value+=" from "+str3;
  	  else {
	  		document.optlov.lovsql.value="";
			return false;
	  		}
  var str4=prompt("<? echo $Condition_Caption;?> :","");
  if ((str4!=null) && (str4!="")) document.optlov.lovsql.value+=" where "+str4;

  return true;
}
</script>
<?
}
?>
</body>
</html>
