<?
//phpFormBuilder Version 1.5 by Baris Kayar (barishkayar@yahoo.com)
//2002(cl)  The FormBuilder Group http://pfb.sourceforge.net

$PFB_js="<script language=\"JavaScript\">\n";
$PFB_js.="function uleynsubmitedilirmi() {\n";
$PFB_js.="with (document.$table)\n{\n";
$fmformsetedits="";
for ($i=0;$i<sizeof($postoptvalues);$i++) 
{
$actifDegerler=array();
$actifBasliklar=array();
$actifNesne=explode(";",$postoptvalues[$i]);
switch ($actifNesne[0])
{
	case "textarea":
	if ($actifNesne[5]=="true") //readonly
		$PFB_ro=" readonly"; 
	else {
			$PFB_ro="";
			if ($actifNesne[6]=="true") //notnull
			$PFB_js.="if ($actifNesne[1].value==\"\") 
						{
							alert (\"$actifNesne[2] $ErrorMsg_1\");
							$actifNesne[1].focus();
							return false;
						}\n";
			}
	$fmformsetedits.="<tr><td>".
					 $actifNesne[2].
					 "</td><td>".
					 "<textarea name=\"$actifNesne[1]\" cols=$actifNesne[3] rows=$actifNesne[4] $PFB_ro>".
					 "<? echo \$".$actifNesne[1]."; ?></textarea>".
					 "</td></tr>\n";
	break;
	case "edit":
	if ($actifNesne[8]=="true") //notnull
	$PFB_js.="if ($actifNesne[1].value==\"\") 
				{
				alert (\"$actifNesne[2] $ErrorMsg_1\");
				$actifNesne[1].focus();
				return false;
				}\n";
	if ($actifNesne[4]>0) //min size
	$PFB_js.="if ($actifNesne[1].value.length<$actifNesne[4]) 
				{
				alert (\"$Min_Caption $actifNesne[4] $Letter_Caption\");
				$actifNesne[1].focus();
				return false;
				}\n";

	$fmformsetedits.="<tr><td>".
					 $actifNesne[2].
					 "</td><td>".
					 "<input type=\"$actifNesne[6]\" size=\"$actifNesne[3]\" ".
					 "maxlength=\"$actifNesne[5]\" name=\"".$actifNesne[1]."\" ".
					 "value=\"<? echo \$".$actifNesne[1]."; ?>\">".
					 "</td></tr>\n";
	break;
	case "checkbox":
	if ($actifNesne[5]=="true") $PFB_chk=" checked"; else $PFB_chk="";
	$fmformsetedits.="<tr><td colspan=2>";
	if ($actifNesne[4]=="top") $fmformsetedits.=$actifNesne[2]."<br>".
					 "<input type=\"checkbox\" ".
					 "name=\"$actifNesne[1]\" ".
					 "value=\"$actifNesne[3]\" $PFB_chk>".
					 "</td></tr>\n";
	elseif ($actifNesne[4]=="right") 
					$fmformsetedits.="<input type=\"checkbox\" ".
					 "name=\"$actifNesne[1]\" ".
					 "value=\"$actifNesne[3]\" $PFB_chk>".
					 $actifNesne[2]."</td></tr>\n";
	elseif ($actifNesne[4]=="bottom") 
					$fmformsetedits.="<input type=\"checkbox\" ".
					 "name=\"$actifNesne[1]\" ".
					 "value=\"$actifNesne[3]\" $PFB_chk><br>".
					 $actifNesne[2]."</td></tr>\n";
	else $fmformsetedits.=$actifNesne[2].
					 "<input type=\"checkbox\" ".
					 "name=\"$actifNesne[1]\" ".
					 "value=\"$actifNesne[3]\" $PFB_chk>".
					 "</td></tr>\n";
	break;
	case "radiobox":
	$actifBasliklar=explode(",",$actifNesne[3]);
	$actifDegerler=explode(",",$actifNesne[4]);
	$fmformsetedits.="<tr><td>".
					 $actifNesne[2].
					 "</td><td>\n";
			for ($rbj=0;$rbj<sizeof($actifDegerler)-1;$rbj++)
					$fmformsetedits.=
					 "<? if (\$$actifNesne[1]==\"$actifDegerler[$rbj]\") \$PFB_chk=\" checked\"; else \$PFB_chk=\"\";?>\n".
					 "<input type=\"radio\" ".
					 "name=\"".$actifNesne[1]."\" ".
					 "value=\"$actifDegerler[$rbj]\" ".
					 "<? echo \$PFB_chk;?>>".
					 "$actifBasliklar[$rbj]<br>\n";
	$fmformsetedits.="</td></tr>\n";
	break;
	case "lov":
	$actifBasliklar=explode(",",$actifNesne[5]);
	$actifDegerler=explode(",",$actifNesne[6]);
	//if ($actifNesne[3]=="multi") $PFB_slctt="multiple"; else $PFB_slctt="";  // iptal ettim :))
	$fmformsetedits.="<tr><td>".
					 $actifNesne[2].
					 "</td><td>\n<select name=\"$actifNesne[1]\" $PFB_slctt>\n";
	if ($actifNesne[4]=="statik")
			{
			for ($rbj=0;$rbj<sizeof($actifDegerler)-1;$rbj++)
					$fmformsetedits.=
					 "<? if (\$$actifNesne[1]==\"$actifDegerler[$rbj]\") \$PFB_slct=\" selected\"; else \$PFB_slct=\"\";?>\n".
					 "<option value=\"$actifDegerler[$rbj]\" ".
					 "<? echo \$PFB_slct;?>>".
					 "$actifBasliklar[$rbj]</option>\n";
			}
			else
			{
			$fmformsetedits.=
			"<?
			\$result_$actifNesne[1]=mysql_query(\"$actifNesne[7]\");
			for (\$i=0;\$i<mysql_numrows(\$result_$actifNesne[1]);\$i++)
			{
 			if (\$$actifNesne[1]==mysql_result(\$result_$actifNesne[1],\$i,0)) \$PFB_slct=\" selected\"; else \$PFB_slct=\"\";
			echo \"<option value=\\\"\".mysql_result(\$result_$actifNesne[1],\$i,0).\"\\\" \".
			 \" \$PFB_slct>\".mysql_result(\$result_$actifNesne[1],\$i,1).\"</option>\";
			}
			?>";
			}
	$fmformsetedits.="</select>\n</td></tr>\n";
	break;

}
}
$PFB_js.="}\n}\n</script>\n";
?>