<?php
function getreleases($orderby = "", $newsletter_page = 0)
{
				global $dbconn;
				global $smarty;
				global $config;
				if (isset($_GET['p']) && 0 < $_GET['p'])
				{
								$p = $_GET['p'];
				} else
				{
								$p = 0;
				}
				$end = $_SESSION['is_desc'] && !$_GET['is_nav'] || !$_SESSION['is_desc'] && $_GET['is_nav'] ? " desc " : "";
				if ($orderby)
				{
								$is_nav = isset($_GET['is_nav']) ? $_GET['is_nav'] : false;
								if (!$is_nav && $orderby == $_SESSION['order'])
								{
												if ($_SESSION['is_desc'])
												{
																$GLOBALS['_SESSION']['is_desc'] = false;
																$end = " desc ";
												} else
												{
																$GLOBALS['_SESSION']['is_desc'] = true;
																$end = "";
												}
								}
								$sql .= " order by " . $orderby . $end;
				} else
				{
								$sql .= " order by subject";
				}
				$smarty->assign("end", trim($end));
				$res = $dbconn->execute("select count(id) from creleases");
				$amount = $res->fields[0];
				$smarty->assign("navigation", create_navigation($amount, $newsletter_page, "newsletter_page={$newsletter_page}&order=" . $_GET['order'] . "&is_nav=true", "index.php", $p, "newsletter_page"));
				get_smarty_array_list("newsletter_page", $config['newsletter_page']);
				$per_page = $config['newsletter_page'][$newsletter_page];
				$res = $dbconn->pageexecute("SELECT id, subject, body,date,format, priority, is_sent, is_attach, date_send FROM creleases " . $sql, $per_page, $p + 1);
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$releases[$c]['id'] = $res->fields[0];
								$releases[$c]['subject'] = stripslashes($res->fields[1]);
								$releases[$c]['body'] = html_entity_decode($res->fields[2]);
								$releases[$c]['date'] = $res->fields[3];
								$releases[$c]['format'] = $res->fields[4] == "html" ? "HTML" : "Text";
								$releases[$c]['priority'] = $res->fields[5];
								$releases[$c]['is_attach'] = $res->fields[7];
								$releases[$c]['date_sent'] = $res->fields[8];
								$res2 = $dbconn->execute("SELECT COUNT(DISTINCT(client_id)) FROM clients_releases WHERE release_id='" . $res->fields[0] . "' AND is_sent='1'");
								$releases[$c]['count'] = $res2->fields[0];
								$releases[$c]['is_sent'] = $res->fields[6];
								if ($releases[$c]['is_sent'] == 0)
								{
												$releases[$c]['sent'] = "Not Sent";
								} else
												if ($releases[$c]['is_sent'] == 1)
												{
																$releases[$c]['sent'] = "Sent (" . $releases[$c]['count'] . ")<br>" . $res->fields[8];
																$releases[$c]['addarchive'] = 1;
												} else
																if ($releases[$c]['is_sent'] == 2)
																{
																				$res3 = $dbconn->execute("SELECT COUNT(DISTINCT(client_id)) FROM clients_releases WHERE release_id='" . $res->fields[0] . "' AND is_sent='0'");
																				$left = $res3->fields[0];
																				$releases[$c]['sent'] = "In process (Left {$left})";
																} else
																				if ($releases[$c]['is_sent'] == 3)
																				{
																								$releases[$c]['sent'] = "Error (" . $releases[$c]['count'] . ")<br>" . $res->fields[8];
																				}
								$rl = $dbconn->execute("select * from creleases_lists where crelease_id='" . $releases[$c]['id'] . "'");
								$releases[$c]['count_suscribers'] = 0;
								while (!$rl->EOF)
								{
												$row = $rl->getrowassoc(false);
												$releases[$c]['list_id'] = $row['list_id'];
												$res2 = $dbconn->execute("select count(*) from clients_lists where list_id='" . $row['list_id'] . "'");
												$releases[$c]['count_suscribers'] += $res2->fields[0];
												$rl->movenext();
								}
								++$c;
								$res->movenext();
				}
				$smarty->assign("amount", $amount);
				return $releases;
}
function getreleasesarhive($newsletter_page = 0)
{
				global $dbconn;
				global $smarty;
				global $config;
				if (isset($_GET['p']) && 0 < $_GET['p'])
				{
								$p = $_GET['p'];
				} else
				{
								$p = 0;
				}
				$smarty->assign("end", trim($end));
				$res = $dbconn->execute("select count(id) from archive");
				$amount = $res->fields[0];
				$smarty->assign("navigation", create_navigation($amount, $newsletter_page, "newsletter_page={$newsletter_page}&order=" . $_GET['order'] . "&is_nav=true", "archive.php", $p, "newsletter_page"));
				get_smarty_array_list("newsletter_page", $config['newsletter_page']);
				$per_page = $config['newsletter_page'][$newsletter_page];
				$res = $dbconn->pageexecute("SELECT id, subject,date,name,link FROM archive", $per_page, $p + 1);
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$releases[$c]['id'] = $res->fields[0];
								$releases[$c]['subject'] = stripslashes($res->fields[1]);
								$releases[$c]['date'] = $res->fields[2];
								$releases[$c]['name'] = $res->fields[3];
								$releases[$c]['link'] = $res->fields[4];
								$res->movenext();
				}
				$smarty->assign("amount", $amount);
				return $releases;
}
function addarchive($id)
{
				global $dbconn;
				global $config;
				$res = $dbconn->execute("SELECT id, subject, body,date_send FROM creleases where id='" . intval($id) . "'");
				$header = "<html><head><title>" . $res->fields[1] . " " . $res->fields[3] . "</title></head><body>";
				$footer = "</body></html>";
				$file_name = $res->fields[1] . "_" . $res->fields[3] . ".html";
				$file = $config['files_path'] . $file_name;
				$fp = fopen($file, "w");
				$file_content = $header . html_entity_decode(html_entity_decode($res->fields[2])) . $footer;
				if ($fp)
				{
								fwrite($fp, $file_content);
								fclose($fp);
				}
				$res = $dbconn->execute("insert into archive (subject,date,name,link) values('" . $res->fields[1] . "', '" . $res->fields[3] . "','" . $file_name . "','" . $config['files_web'] . $file_name . "')");
}
function getreleasesschedule($orderby = "", $newsletter_page = 0)
{
				global $dbconn;
				global $smarty;
				global $config;
				if (isset($_GET['p']) && 0 < $_GET['p'])
				{
								$p = $_GET['p'];
				} else
				{
								$p = 0;
				}
				$end = $_SESSION['is_desc'] && !$_GET['is_nav'] || !$_SESSION['is_desc'] && $_GET['is_nav'] ? " desc " : "";
				if ($orderby)
				{
								$is_nav = isset($_GET['is_nav']) ? $_GET['is_nav'] : false;
								if (!$is_nav && $orderby == $_SESSION['order'])
								{
												if ($_SESSION['is_desc'])
												{
																$GLOBALS['_SESSION']['is_desc'] = false;
																$end = " desc ";
												} else
												{
																$GLOBALS['_SESSION']['is_desc'] = true;
																$end = "";
												}
								}
								$sql .= " order by " . $orderby . $end;
				} else
				{
								$sql .= " order by subject";
				}
				$smarty->assign("end", trim($end));
				$res = $dbconn->execute("select count(id) from creleases where date_send >= now()");
				$amount = $res->fields[0];
				$smarty->assign("navigation", create_navigation($amount, $newsletter_page, "newsletter_page={$newsletter_page}&order=" . $_GET['order'] . "&is_nav=true", "index.php", $p, "newsletter_page"));
				get_smarty_array_list("newsletter_page", $config['newsletter_page']);
				$per_page = $config['newsletter_page'][$newsletter_page];
				$res = $dbconn->pageexecute("select id, subject, body,date_send,format, priority, is_attach from creleases where date_send >= now() " . $sql, $per_page, $p + 1);
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$releases[$c]['id'] = $res->fields[0];
								$releases[$c]['subject'] = stripslashes($res->fields[1]);
								$releases[$c]['body'] = html_entity_decode($res->fields[2]);
								$releases[$c]['date'] = $res->fields[3];
								$releases[$c]['format'] = $res->fields[4] == "html" ? "HTML" : "Text";
								$releases[$c]['priority'] = $res->fields[5];
								$releases[$c]['is_attach'] = $res->fields[6];
								$res2 = $dbconn->execute("select count(distinct(client_id)) from clients_releases where release_id='" . $res->fields[0] . "'");
								$releases[$c]['count'] = $res2->fields[0];
								$releases[$c]['sent'] = $res2->fields[0] == 0 ? "Not Sent" : "Sent (" . $releases[$c]['count'] . ")";
								$releases[$c]['is_sent'] = $res2->fields[0] == 0 ? false : true;
								$rl = $dbconn->execute("select * from creleases_lists where crelease_id='" . $releases[$c]['id'] . "'");
								$releases[$c]['count_suscribers'] = 0;
								while (!$rl->EOF)
								{
												$row = $rl->getrowassoc(false);
												$res2 = $dbconn->execute("select count(*) from clients_lists where list_id='" . $row['list_id'] . "'");
												$releases[$c]['count_suscribers'] += $res2->fields[0];
												$rl->movenext();
								}
								++$c;
								$res->movenext();
				}
				$smarty->assign("amount", $amount);
				return $releases;
}
function getusers($a = "", $orderby = "")
{
				global $dbconn;
				if ($a)
				{
								$sql = " where id='" . $a . "'";
				} else
				{
								$sql = "";
				}
				if ($orderby)
				{
								$sql .= " order by " . $orderby;
				} else
				{
								$sql .= " order by id";
				}
				$res = $dbconn->execute("select id,date,firstname,secondname,company,email1,comment from snd_users " . $sql);
				$users = array();
				$c = 0;
				while (!$res->EOF)
				{
								$users[$c] = $res->getrowassoc();
								++$c;
								$res->movenext();
				}
				return $users;
}
function delrelease($id)
{
				global $dbconn;
				global $config;
				if (is_dir($config['files_path'] . $id))
				{
								delete_dir($config['files_path'] . $id);
				}
				$res = $dbconn->execute("delete from attach where id_crelease='" . $id . "'");
				$res = $dbconn->execute("delete from creleases where id='" . $id . "'");
				$res = $dbconn->execute("delete from clients_releases where release_id='" . $id . "'");
				$res = $dbconn->execute("delete from click_counter where release='" . $id . "'");
				$res = $dbconn->execute("delete from creleases_lists where crelease_id='" . $id . "'");
}
function delreleasearhive($id)
{
				global $dbconn;
				global $config;
				$res = $dbconn->execute("select name from archive where id='" . intval($id) . "'");
				if (file_exists($config['files_path'] . $res->fields[0]))
				{
								unlink($config['files_path'] . $res->fields[0]);
				}
				$res = $dbconn->execute("delete from archive where id='" . intval($id) . "'");
}
function addrelease($body, $date_send = null)
{
				global $dbconn;
				$lists_array = $_POST['list'];
				$subject = str_prepare($_POST['subject']);
				$priority = $_POST['priority'];
				$from_email = str_prepare($_POST['from_email']);
				$from_name = str_prepare($_POST['from_name']);
				$reply_to = str_prepare($_POST['reply_to']);
				$encode = $_POST['encode'];
				$format = $_POST['format'];
				$notify_email = str_prepare($_POST['notify_email']);
				$notify_start = isset($_POST['notify_start']) ? 1 : 0;
				$notify_end = isset($_POST['notify_end']) ? 1 : 0;
				$match_status = $_POST['match_status'];
				$match_confirm = $_POST['match_confirm'];
				$attaches_array = $_POST['attaches'];
				$date_send_sql = $date_send != null ? " '" . $date_send . "', " : " NULL, ";
				$res = $dbconn->execute("insert into creleases\r\n  (subject,body,date,format,priority,date_send, from_email, from_name, reply_to, encode,\r\n  notify_start, notify_end, notify_email, match_status, match_confirm)\r\n  values\r\n  ('" . addslashes($subject) . "',\r\n   '" . htmlentities($body, ENT_QUOTES) . "',\r\n   NOW(),\r\n   '" . $format . "',\r\n   '" . $priority . "',\r\n   {$date_send_sql}\r\n   '" . $from_email . "',\r\n   '" . $from_name . "',\r\n   '" . $reply_to . "',\r\n   '" . $encode . "',\r\n   '" . $notify_start . "',\r\n   '" . $notify_end . "',\r\n   '" . $notify_email . "',\r\n   '" . $match_status . "',\r\n   '" . $match_confirm . "'\r\n    )");
				$rid = $dbconn->_insertid();
				if (is_array($lists_array))
				{
								foreach ($lists_array as $list_id)
								{
												$res2 = $dbconn->execute("insert into creleases_lists set crelease_id='" . $rid . "', list_id='" . $list_id . "'");
								}
				}
				$is_attach = 0;
				if (is_array($attaches_array))
				{
								foreach ($attaches_array as $attach_id)
								{
												$res2 = $dbconn->execute("insert into release_attach set release_id='" . $rid . "', attach_id='" . $attach_id . "'");
												$is_attach = 1;
								}
				}
				$res = $dbconn->execute("update creleases set is_attach='" . $is_attach . "' where id='" . $rid . "'");
				return $rid;
}
function div($a, $b)
{
				return ($a - $a % $b) / $b;
}
function sendreleaseundelivered($rid, $date, $l)
{
				global $dbconn;
				global $config;
				include_once ("class.phpmailer.php");
				$one_error = true;
				$error_count = 0;
				$user_schedule = 0;
				$res = $dbconn->execute("SELECT id, body, subject, format, priority, from_email, from_name,reply_to, encode, notify_start, notify_end, notify_email FROM creleases WHERE id='" . $rid . "'");
				$notify_start = $res->fields[9];
				$notify_end = $res->fields[10];
				$notify_email = $res->fields[11];
				$rs_settings = $dbconn->execute("SELECT * FROM settings");
				$settings = $rs_settings->getrowassoc(false);
				$settings['send_period'] = intval($settings['send_period']);
				$settings['send_period'] = 0 < $settings['send_period'] ? $settings['send_period'] : 1;
				echo "<html><head><META http-equiv=Content-Type content='text/html; charset=windows-1251'>\r\n\t\t<style>\r\n\t\t\t.listTable{\r\n\t\t\t\tborder: solid 0px;\r\n\t\t\t\tbackground-color: #E6E6E6;\r\n\t\t\t\tcellspacing: 1;\r\n\t\t\t\tcellpadding: 3;\r\n\t\t\t\twidth: 100%;\r\n\t\t\t\tfont-family: verdana, arial, helvetica, sans-serif;\r\n\t\t\t\tfont-weight: normal;\r\n\t\t\t\tfont-size: 11px;\r\n\t\t\t}\r\n\r\n\t\t\t.listHeader{\r\n\t\t\t\tbackground-color: #E6E6E6;\r\n\t\t\t\tfont-family: verdana, arial, helvetica, sans-serif;\r\n\t\t\t\tfont-weight: normal;\r\n\t\t\t\tfont-size: 11px;\r\n\t\t\t\ttext-align: left;\r\n\t\t\t}\r\n\r\n\t\t\t.listItem{\r\n\t\t\t\tbackground-color: #FFFFFF;\r\n\t\t\t\tfont-family: verdana, arial, helvetica, sans-serif;\r\n\t\t\t\tfont-weight: normal;\r\n\t\t\t\tfont-size: 11px;\r\n\t\t\t}\r\n\r\n\t\t</style>\r\n\t\t<title>Pilot Group Newsletter Software</title>\r\n\t\t</head>\r\n\r\n\t\t<body topmargin=10 leftmargin=10 rightmargin=10 bottommargin=10 marginwidth=0 marginheight=0>\r\n\t\t<h4>Delivery Report</h4>";
				$listInfo = array();
				$quota = 0;
				if ($res->rowcount())
				{
								$mail = new phpmailer();
								$mail->issmtp();
								$res_server = $dbconn->execute("select * from smtp_server");
								while (!$res_server->EOF)
								{
												$row = $res_server->getrowassoc(false);
												$host .= $row['host'] . ";";
												$login .= $row['login'] . ";";
												$password .= $row['password'] . ";";
												if ($row['login'] != "" || $row['password'] != "")
												{
																$smtp_auth .= "1;";
												} else
												{
																$smtp_auth .= "0;";
												}
												$res_server->movenext();
								}
								$mail->Host = $host;
								$mail->SMTPAuth = $smtp_auth;
								$mail->Username = $login;
								$mail->Password = $password;
								$rs_attach = $dbconn->execute("SELECT * FROM release_attach ra, attach a WHERE ra.release_id='" . $rid . "' AND ra.attach_id=a.id");
								while (!$rs_attach->EOF)
								{
												$row = $rs_attach->getrowassoc(false);
												$attach[] = $row['file_name'];
												$mail->addattachment($config['files_path'] . $row['file_name']);
												$rs_attach->movenext();
								}
								$all = 0;
								$format = $res->fields[3];
								if ($format == "html")
								{
												$mail->ishtml(true);
								} else
								{
												$mail->ishtml(false);
								}
								$body = html_entity_decode(html_entity_decode($res->fields[1]));
								$subject = stripslashes($res->fields[2]);
								$priority = $res->fields[4];
								$mail->Priority = $priority;
								$mail->Subject = $subject;
								$mail->CharSet = $res->fields[8];
								if ($notify_start)
								{
												$message = "Start sending newsletter from " . $config['server'] . "<br>\r\n\t\t\t\t<strong>Subject: </strong>{$subject}<br>\r\n\t\t\t\t<strong>Priority: </strong>" . $config['priority'][$priority] . "<br>\r\n\t\t\t\t<strong>Attach file(s):</strong> ";
												if (is_array($attach))
												{
																foreach ($attach as $file_name)
																{
																				$message .= $file_name . " (" . file_size($config['files_path'] . $file_name) . ")&nbsp;&nbsp;";
																				++$t;
																}
												}
												if ($t == 0)
												{
																$message .= "No";
												}
								}
								$res4 = $dbconn->execute("SELECT owner_name, owner_email, name, id FROM list WHERE id='" . intval($rid) . "'");
								if ($res->fields[5] == "")
								{
												$mail->From = $res4->fields[1];
								} else
								{
												$mail->From = $res->fields[5];
								}
								if ($res->fields[6] == "")
								{
												$mail->FromName = $res4->fields[0];
								} else
								{
												$mail->FromName = $res->fields[6];
								}
								if ($res->fields[7] == "")
								{
												$mail->addreplyto($mail->From, $mail->FromName);
								} else
								{
												$mail->addreplyto($res->fields[7], $mail->FromName);
								}
								echo "<table width=100% border=0 cellspacing=1 cellpadding=3 class=listTable>\r\n\t\t\t\t<tr class='listHeader'>\r\n\t\t\t\t\t<td>\r\n\t\t\t\t\t\t<strong>List: </strong><a title='Edit list' target='_blank' href='../lists/change.php?id=" . $res4->fields[3] . "'>" . $res4->fields[2] . "</a><br>\r\n\t\t\t\t\t\t<strong>From: </strong><a title='Edit owner' target='_blank' href='../lists/change.php?id=" . $res4->fields[3] . "'>" . $mail->FromName . " (" . $mail->From . ")</a><br>\r\n\t\t\t\t\t\t<strong>Subject: </strong>{$subject}<br>\r\n\t\t\t\t\t\t<strong>Priority: </strong>" . $config['priority'][$priority] . "<br>\r\n\t\t\t\t\t\t<strong>Attach file(s):</strong> ";
								$t = 0;
								if (is_array($attach))
								{
												foreach ($attach as $file_name)
												{
																echo "<a title='View file' href='" . $config['files_path'] . $file_name . "' target='_blank'>" . $file_name . " (" . file_size($config['files_path'] . $file_name) . ")</a> &nbsp;&nbsp;";
																++$t;
												}
								}
								if ($t == 0)
								{
												echo "No";
								}
								echo "<br></td><td></td></tr><tr><td colspan=2></td></tr></table>";
								$res2 = $dbconn->execute("select a.id,a.firstname,a.secondname,a.email1, a.status from clients_releases b left join snd_users a on (a.id=b.client_id) where b.release_id='" . intval($rid) . "' and date_format(b.date, '%Y-%m-%d')='" . addslashes($date) . "' and b.is_sent='2'");
								$i = 0;
								while (!$res2->EOF)
								{
												if ($quota < $settings['smtp_quota'] && 0 < $settings['smtp_quota'] || $settings['smtp_quota'] == 0)
												{
																$userInfo[] = $res2->fields[1] . " " . $res2->fields[2] . " (" . $res2->fields[3] . ")";
																$email = $res2->fields[3];
																$status = $res2->fields[4] ? "Active" : "Inactive";
																$id_user = $res2->fields[0];
																$mail->Body = parsebody(html_entity_decode($body), $res2, $l, $format, $rid);
																$mail->addaddress($email);
																$num = $quota + 1;
																print "<table width=100% border=0 cellspacing=1 cellpadding=3 class=listTable>\r\n\t\t\t\t\t\t\t<tr class='listItem' onMouseOver=\"javascript: if (typeof(window.opera) == 'undefined') this.style.backgroundColor='#FEFED6'\" onMouseOut=\"this.style.backgroundColor=''\">\r\n\t\t\t\t\t\t\t\t<td>{$num}</td>\r\n\t\t\t\t\t\t\t\t<td>Send newsletter to <strong><a title='Edit user' target='_blank' href='../users/change.php?id=" . $id_user . "'>" . $res2->fields[1] . " " . $res2->fields[2] . " (" . $res2->fields[3] . ") </strong></a> - {$status}</td><td>";
																echo "Ok!";
																++$quota;
																$is_sent = true;
																$res3 = $dbconn->execute("update clients_releases set is_sent='1' where client_id='" . $res2->fields[0] . "' and release_id='" . intval($rid) . "' and date_format(date, '%Y-%m-%d')='" . addslashes($date) . "'");
																print str_repeat(" ", 4096);
																echo "</td></tr></table>";
																flush();
																sleep($settings['timeout']);
																++$i;
																$mail->clearaddresses();
																$status_sent = 1;
												} else
												{
																++$user_schedule;
																$group = div($user_schedule, $settings['smtp_quota'] + 1) + 1;
																$status_sent = 2;
																$date_send = date("Y-m-d H:i:s", mktime(date("H") + $group * $settings['send_period'], date("i"), date("s"), date("m"), date("d"), date("Y")));
																$res3 = $dbconn->execute("update clients_releases set is_sent='0' where client_id='" . $res2->fields[0] . "' and release_id='" . intval($rid) . "' and date_format(date, '%Y-%m-%d')='" . addslashes($date) . "'");
												}
												$res2->movenext();
								}
								$all += $i;
								print "<table width=100% border=0 cellspacing=1 cellpadding=3 class=listTable>\r\n\t\t\t\t\t<tr class='listItem'><td>Total: {$i}</td>\r\n\t\t\t\t\t<tr class='listItem'><td>With error: {$error_count}</td></tr></table>";
								if ($i == $error_count && 0 < $error_count)
								{
												$status_sent = 3;
								}
								$i = 0;
				}
				echo "<div class=listItem align=right>Amount: {$all}&nbsp;&nbsp;</div>";
				if ($all == $error_count && 0 < $error_count)
				{
								$status_sent = 3;
								echo "<div class=listItem align=right><font color=#FF0000;>All newsletters were sent with errors</font></div>";
				} else
								if ($all == 0)
								{
												$status_sent = 0;
												echo "<div class=listItem align=right><font color=#FF0000;>There are no subscribers matching your criteria</font></div>";
								}
				echo "</body></html>";
				$res = $dbconn->execute("update creleases set is_sent='" . $status_sent . "' where id='" . $rid . "'");
				if ($notify_end && ($status_sent == 1 || $status_sent == 3))
				{
								$message = "Complete sending newsletter from " . $config['server'] . "<br>\r\n\t\t\t\t<strong>Subject: </strong>{$subject}<br>\r\n\t\t\t\t<strong>Priority: </strong>" . $config['priority'][$priority] . "<br>\r\n\t\t\t\t<strong>Attach file(s):</strong> ";
								if (is_array($attach))
								{
												foreach ($attach as $file_name)
												{
																$message .= $file_name . " (" . file_size($config['files_path'] . $file_name) . ")&nbsp;&nbsp;";
																++$t;
												}
								}
								if ($t == 0)
								{
												$message .= "No";
								}
								$message .= "<br><strong>Sent:</strong> " . $all . "<br>";
								$message .= "<strong>Errors:</strong> " . $error_count . "<br>";
								emailtext($notify_email, "Notification: complete sending newsletter", $message, $settings['from_name'], $settings['from_email']);
				}
				return $userInfo;
}
function sendrelease($rid, $listsArray, $is_test = false, $cron_hour = false, $match_list, $match_status)
{
				global $dbconn;
				global $config;
				include_once ("class.phpmailer.php");
				$one_error = true;
				$error_count = 0;
				$user_schedule = 0;
				$res = $dbconn->execute("SELECT id, body, subject, format, priority, from_email, from_name,\r\n\t\treply_to, encode, notify_start, notify_end, notify_email\r\n\t\tFROM creleases WHERE id='" . $rid . "'");
				$notify_start = $res->fields[9];
				$notify_end = $res->fields[10];
				$notify_email = $res->fields[11];
				$rs_settings = $dbconn->execute("SELECT * FROM settings");
				$settings = $rs_settings->getrowassoc(false);
				$settings['send_period'] = intval($settings['send_period']);
				$settings['send_period'] = 0 < $settings['send_period'] ? $settings['send_period'] : 1;
				echo "\r\n<html>\r\n<head>\r\n<META http-equiv=Content-Type content='text/html; charset=windows-1251'>\r\n<style>\r\n\t.listTable\r\n\t{\r\n\t\tborder: solid 0px;\r\n\t\tbackground-color: #E6E6E6;\r\n\t\tcellspacing: 1;\r\n\t\tcellpadding: 3;\r\n\t\twidth: 100%;\r\n\t\tfont-family: verdana, arial, helvetica, sans-serif;\r\n\t\tfont-weight: normal;\r\n\t\tfont-size: 11px;\r\n\t}\r\n\r\n\t.listHeader\r\n\t{\r\n\t\tbackground-color: #E6E6E6;\r\n\t\tfont-family: verdana, arial, helvetica, sans-serif;\r\n\t\tfont-weight: normal;\r\n\t\tfont-size: 11px;\r\n\t\ttext-align: left;\r\n\t}\r\n\r\n\t.listItem\r\n\t{\r\n\t\tbackground-color: #FFFFFF;\r\n\t\tfont-family: verdana, arial, helvetica, sans-serif;\r\n\t\tfont-weight: normal;\r\n\t\tfont-size: 11px;\r\n\t}\r\n\r\n</style>\r\n<title>Pilot Group Newsletter Software</title>\r\n</head>\r\n\r\n<body topmargin=10 leftmargin=10 rightmargin=10 bottommargin=10 marginwidth=0 marginheight=0>\r\n<h4>Delivery Report</h4>\r\n\r\n\t";
				$listInfo = array();
				$quota = 0;
				if ($res->rowcount())
				{
								$mail = new phpmailer();
								$mail->issmtp();
								$res_server = $dbconn->execute("select * from smtp_server");
								while (!$res_server->EOF)
								{
												$row = $res_server->getrowassoc(false);
												$host .= $row['host'] . ";";
												$login .= $row['login'] . ";";
												$password .= $row['password'] . ";";
												if ($row['login'] != "" || $row['password'] != "")
												{
																$smtp_auth .= "1;";
												} else
												{
																$smtp_auth .= "0;";
												}
												$res_server->movenext();
								}
								$mail->Host = $host;
								$mail->SMTPAuth = $smtp_auth;
								$mail->Username = $login;
								$mail->Password = $password;
								$rs_attach = $dbconn->execute("SELECT * FROM release_attach ra, attach a WHERE ra.release_id='" . $rid . "' AND ra.attach_id=a.id");
								while (!$rs_attach->EOF)
								{
												$row = $rs_attach->getrowassoc(false);
												$attach[] = $row['file_name'];
												$mail->addattachment($config['files_path'] . $row['file_name']);
												$rs_attach->movenext();
								}
								$all = 0;
								$format = $res->fields[3];
								if ($format == "html")
								{
												$mail->ishtml(true);
								} else
								{
												$mail->ishtml(false);
								}
								$body = html_entity_decode(html_entity_decode($res->fields[1]));
								$subject = stripslashes($res->fields[2]);
								$priority = $res->fields[4];
								$mail->Priority = $priority;
								$mail->Subject = $subject;
								$mail->CharSet = $res->fields[8];
								if ($notify_start)
								{
												$message = "Start sending newsletter from " . $config['server'] . "<br>\r\n\t\t\t<strong>Subject: </strong>{$subject}<br>\r\n\t\t\t<strong>Priority: </strong>" . $config['priority'][$priority] . "<br>\r\n\t\t\t<strong>Attach file(s):</strong> ";
												if (is_array($attach))
												{
																foreach ($attach as $file_name)
																{
																				$message .= $file_name . " (" . file_size($config['files_path'] . $file_name) . ")&nbsp;&nbsp;";
																				++$t;
																}
												}
												if ($t == 0)
												{
																$message .= "No";
												}
								}
								if (is_array($listsArray))
								{
												foreach ($listsArray as $l)
												{
																$res4 = $dbconn->execute("SELECT owner_name, owner_email, name, id FROM list WHERE id='" . $l . "'");
																if ($res->fields[5] == "")
																{
																				$mail->From = $res4->fields[1];
																} else
																{
																				$mail->From = $res->fields[5];
																}
																if ($res->fields[6] == "")
																{
																				$mail->FromName = $res4->fields[0];
																} else
																{
																				$mail->FromName = $res->fields[6];
																}
																if ($res->fields[7] == "")
																{
																				$mail->addreplyto($mail->From, $mail->FromName);
																} else
																{
																				$mail->addreplyto($res->fields[7], $mail->FromName);
																}
																echo "\r\n\t\t\t\t<table width=100% border=0 cellspacing=1 cellpadding=3 class=listTable>\r\n\t\t\t\t<tr class='listHeader'><td>\r\n\t\t\t\t<strong>List: </strong><a title='Edit list' target='_blank' href='../lists/change.php?id=" . $res4->fields[3] . "'>" . $res4->fields[2] . "</a><br>\r\n\t\t\t\t<strong>From: </strong><a title='Edit owner' target='_blank' href='../lists/change.php?id=" . $res4->fields[3] . "'>" . $mail->FromName . " (" . $mail->From . ")</a><br>\r\n\t\t\t\t<strong>Subject: </strong>{$subject}<br>\r\n\t\t\t\t<strong>Priority: </strong>" . $config['priority'][$priority] . "<br>\r\n\t\t\t\t<strong>Attach file(s):</strong> ";
																$t = 0;
																if (is_array($attach))
																{
																				foreach ($attach as $file_name)
																				{
																								echo "<a title='View file' href='" . $config['files_path'] . $file_name . "' target='_blank'>" . $file_name . " (" . file_size($config['files_path'] . $file_name) . ")</a> &nbsp;&nbsp;";
																								++$t;
																				}
																}
																if ($t == 0)
																{
																				echo "No";
																}
																echo "<br>\r\n\t\t\t\t</td><td></td></tr>\r\n\t\t\t\t<tr><td colspan=2></td></tr>\r\n\t\t\t\t";
																echo "</table>";
																if (!$is_test)
																{
																				if ($match_list == 0)
																				{
																								$sql = "and b.status_subscribe <> '" . $config['status_subscribe_val']['unsubscribe'] . "'";
																				} else
																								if ($match_list == 1)
																								{
																												$sql = "and (b.status_subscribe = '" . $config['status_subscribe_val']['subscribe'] . "' OR b.status_subscribe = '" . $config['status_subscribe_val']['unconf_unsub'] . "')";
																								} else
																												if ($match_list == 2)
																												{
																																$sql = "and b.status_subscribe = '" . $config['status_subscribe_val']['unconf_sub'] . "'";
																												}
																				if ($match_status == 1)
																				{
																								$sql .= " and a.status=1 ";
																				} else
																								if ($match_status == 2)
																								{
																												$sql .= " and a.status=0 ";
																								}
																				$res2 = $dbconn->execute("select a.id,a.firstname,a.secondname,a.email1, a.status from snd_users a left join clients_lists b on (a.id=b.client_id)\r\n\t\t\t\t\t\t\t\t\t\t\t   where b.list_id='" . $l . "' {$sql}");
																				$i = 0;
																				while (!$res2->EOF)
																				{
																								if ($quota < $settings['smtp_quota'] && 0 < $settings['smtp_quota'] || $settings['smtp_quota'] == 0)
																								{
																												$userInfo[] = $res2->fields[1] . " " . $res2->fields[2] . " (" . $res2->fields[3] . ")";
																												$email = $res2->fields[3];
																												$status = $res2->fields[4] ? "Active" : "Inactive";
																												$id_user = $res2->fields[0];
																												$mail->Body = parsebody(html_entity_decode($body), $res2, $l, $format, $rid);
																												$mail->addaddress($email);
																												$num = $quota + 1;
																												print "\r\n\t\t\t\t\t\t\t<table width=100% border=0 cellspacing=1 cellpadding=3 class=listTable>\r\n\t\t\t\t\t\t\t<tr class='listItem' onMouseOver=\"javascript: if (typeof(window.opera) == 'undefined') this.style.backgroundColor='#FEFED6'\"\r\n\t\t\tonMouseOut=\"this.style.backgroundColor=''\">\r\n\t\t\t<td>{$num}</td>\r\n\t\t\t<td>Send newsletter to <strong><a title='Edit user' target='_blank' href='../users/change.php?id=" . $id_user . "'>" . $res2->fields[1] . " " . $res2->fields[2] . " (" . $res2->fields[3] . ") </strong></a> - {$status}</td><td>";
																												echo "Ok!";
																												++$quota;
																												$is_sent = true;
																												if (!$cron_hour)
																												{
																																$res3 = $dbconn->execute("insert into clients_releases (client_id,release_id,date,is_sent) values ('" . $res2->fields[0] . "','" . $rid . "',NOW(),'1')");
																												} else
																												{
																																$res3 = $dbconn->execute("update clients_releases set date=now(), is_sent='1' where client_id='" . $res2->fields[0] . "'");
																												}
																												print str_repeat(" ", 4096);
																												echo "</td></tr></table>";
																												flush();
																												sleep($settings['timeout']);
																												++$i;
																												$mail->clearaddresses();
																												$status_sent = 1;
																								} else
																								{
																												++$user_schedule;
																												$group = div($user_schedule, $settings['smtp_quota'] + 1) + 1;
																												$status_sent = 2;
																												$date_send = date("Y-m-d H:i:s", mktime(date("H") + $group * $settings['send_period'], date("i"), date("s"), date("m"), date("d"), date("Y")));
																												$res3 = $dbconn->execute("insert into clients_releases (client_id,release_id,date,is_sent, list_id) values ('" . $res2->fields[0] . "','" . $rid . "','" . $date_send . "','0','" . $l . "')");
																								}
																								$res2->movenext();
																				}
																} else
																{
																				$email = $settings['test_email'];
																				$id_user = 0;
																				$res2->fields[1] = "Test Firstname";
																				$res2->fields[2] = "Test Lastname";
																				$res2->fields[3] = "Test SubscriberEmail";
																				$mail->Body = parsebody(html_entity_decode($body), $res2, $l, $format, $rid);
																				$mail->addaddress($email);
																				print "<tr class='listItem' onMouseOver=\"javascript: if (typeof(window.opera) == 'undefined') this.style.backgroundColor='#FEFED6'\"\r\n\t\tonMouseOut=\"this.style.backgroundColor=''\">\r\n\t\t<td>Send newsletter to <strong> Test email (" . $email . ")</strong></td><td>";
																				echo "Ok!";
																				$is_sent = false;
																				print str_repeat(" ", 4096);
																				echo "</td></tr>";
																				flush();
																				++$i;
																				$mail->clearaddresses();
																				$mail->clearreplytos();
																}
																$all += $i;
																print "\r\n\t\t\t\t<table width=100% border=0 cellspacing=1 cellpadding=3 class=listTable>\r\n\t\t\t\t<tr class='listItem'><td>Total: {$i}</td>";
																print "<tr class='listItem'><td>With error: {$error_count}</td>";
																echo "</table>";
																if ($i == $error_count && 0 < $error_count)
																{
																				$status_sent = 3;
																}
																$i = 0;
												}
								} else
								{
												echo "\r\n\t\t\t<br>\r\n\t\t\t<table width=100% border=0 cellspacing=1 cellpadding=3 class=listTable>\r\n\t\t\t<tr class='listHeader'><td>\r\n\t\t\t<strong>List: </strong>Undefined<br>\r\n\t\t\t<strong>From: </strong>Undefined (because mailing list is undefined)<br>\r\n\t\t\t<strong>Subject: </strong>{$subject}<br>\r\n\t\t\t<strong>Priority: </strong>" . $config['priority'][$priority] . "<br>\r\n\t\t\t<strong>Attach file(s):</strong> ";
												$t = 0;
												if (is_array($attach))
												{
																foreach ($attach as $file_name)
																{
																				echo "<a title='View file' href='" . $config['files_path'] . $file_name . "' target='_blank'>" . $file_name . " (" . file_size($config['files_path'] . $file_name) . ")</a> &nbsp;&nbsp;";
																				++$t;
																}
												}
												if ($t == 0)
												{
																echo "No";
												}
												echo "<br>\r\n\t\t\t</td><td></td></tr>\r\n\t\t\t<tr><td colspan=2></td></tr>\r\n\t\t\t";
												$email = $settings['test_email'];
												$id_user = 0;
												$res2->fields[1] = "Test Firstname";
												$res2->fields[2] = "Test Lastname";
												$res2->fields[3] = "Test SubscriberEmail";
												$mail->From = $email;
												$mail->FromName = $settings['test_email'];
												$mail->Body = parsebody(html_entity_decode($body), $res2, $l, $format, $rid);
												$mail->addaddress($email);
												print "<tr class='listItem' onMouseOver=\"javascript: if (typeof(window.opera) == 'undefined') this.style.backgroundColor='#FEFED6'\"\r\nonMouseOut=\"this.style.backgroundColor=''\">\r\n<td>Send newsletter to <strong> Test email (" . $email . ")</strong></td><td>";
												echo "Ok!";
												$res3 = $dbconn->execute("insert into clients_releases (client_id,release_id,date,is_sent) values ('" . $listsArray[0] . "','" . $rid . "',NOW(),'1')");
												$status_sent = 1;
												print str_repeat(" ", 4096);
												echo "</td></tr>";
												flush();
												++$i;
												$mail->clearaddresses();
												$all += $i;
												print "<tr class='listItem'><td></td><td>Total: {$i}</td>";
												$i = 0;
												echo "</table>";
								}
				}
				echo "\r\n\t<div class=listItem align=right>Amount: {$all}&nbsp;&nbsp;</div>";
				if ($all == $error_count && 0 < $error_count)
				{
								$status_sent = 3;
								echo "<div class=listItem align=right><font color=#FF0000;>All newsletters were sent with errors</font></div>";
				} else
								if ($all == 0)
								{
												$status_sent = 0;
												echo "<div class=listItem align=right><font color=#FF0000;>There are no subscribers matching your criteria</font></div>";
								}
				echo "</body></html>";
				$res = $dbconn->execute("update creleases set date_send=now(), is_sent='" . $status_sent . "' where id='" . $rid . "'");
				if ($notify_end && ($status_sent == 1 || $status_sent == 3))
				{
								$message = "Complete sending newsletter from " . $config['server'] . "<br>\r\n\t\t<strong>Subject: </strong>{$subject}<br>\r\n\t\t<strong>Priority: </strong>" . $config['priority'][$priority] . "<br>\r\n\t\t<strong>Attach file(s):</strong> ";
								if (is_array($attach))
								{
												foreach ($attach as $file_name)
												{
																$message .= $file_name . " (" . file_size($config['files_path'] . $file_name) . ")&nbsp;&nbsp;";
																++$t;
												}
								}
								if ($t == 0)
								{
												$message .= "No";
								}
								$message .= "<br><strong>Sent:</strong> " . $all . "<br>";
								$message .= "<strong>Errors:</strong> " . $error_count . "<br>";
								emailtext($notify_email, "Notification: complete sending newsletter", $message, $settings['from_name'], $settings['from_email']);
				}
				return $userInfo;
}
function sendreleasetouser($rid, $client_id, $list_id)
{
				global $dbconn;
				global $config;
				include_once ("class.phpmailer.php");
				$is_sent = false;
				$res = $dbconn->execute("select id,body,subject,format,priority from creleases where id='" . $rid . "'");
				$rs_settings = $dbconn->execute("select * from settings");
				$settings = $rs_settings->getrowassoc(false);
				$res2 = $dbconn->execute("select id, firstname, secondname, email1 from snd_users where id='" . $client_id . "'");
				if ($res->rowcount())
				{
								$mail = new phpmailer();
								$mail->issmtp();
								$res_server = $dbconn->execute("select * from smtp_server");
								while (!$res_server->EOF)
								{
												$row = $res_server->getrowassoc(false);
												$host .= $row['host'] . ";";
												$login .= $row['login'] . ";";
												$password .= $row['password'] . ";";
												if ($row['login'] != "" || $row['password'] != "")
												{
																$smtp_auth .= "1;";
												} else
												{
																$smtp_auth .= "0;";
												}
												$res_server->movenext();
								}
								$mail->Host = $host;
								$mail->SMTPAuth = $smtp_auth;
								$mail->Username = $login;
								$mail->Password = $password;
								$rs_attach = $dbconn->execute("select * from release_attach ra, attach a where ra.release_id='" . $rid . "' and ra.attach_id=a.id");
								while (!$rs_attach->EOF)
								{
												$row = $rs_attach->getrowassoc(false);
												$attach[] = $row['file_name'];
												$mail->addattachment($config['files_path'] . "/" . $row['file_name']);
												$rs_attach->movenext();
								}
								$all = 0;
								$format = $res->fields[3];
								if ($format == "html")
								{
												$mail->ishtml(true);
								} else
								{
												$mail->ishtml(false);
								}
								$body = html_entity_decode(html_entity_decode($res->fields[1]));
								$subject = stripslashes($res->fields[2]);
								$priority = $res->fields[4];
								$mail->Priority = $priority;
								$mail->Subject = $subject;
								$res4 = $dbconn->execute("select owner_name,owner_email, name, id from list where id='" . $list_id . "'");
								$mail->From = $res4->fields[1];
								$mail->FromName = $res4->fields[0];
								$userInfo[] = $res2->fields[1] . " " . $res2->fields[2] . " (" . $res2->fields[3] . ")";
								$email = $res2->fields[3];
								$id_user = $res2->fields[0];
								$mail->Body = parsebody(html_entity_decode($body), $res2, $l, $format, $id_user, $rid);
								$mail->addaddress($email);
								$res3 = $dbconn->execute("update clients_releases set date=now(), is_sent='1' where client_id='" . $res2->fields[0] . "'");
								$mail->clearaddresses();
				}
}
function updrelease($body, $date_send)
{
				global $dbconn;
				$id = $_GET['id'];
				$priority = $_POST['priority'];
				$format = $_POST['format'];
				$subject = str_prepare($_POST['subject']);
				$lists_array = $_POST['list'];
				$attaches_array = $_POST['attaches'];
				$from_email = str_prepare($_POST['from_email']);
				$from_name = str_prepare($_POST['from_name']);
				$reply_to = str_prepare($_POST['reply_to']);
				$encode = $_POST['encode'];
				$notify_email = str_prepare($_POST['notify_email']);
				$notify_start = isset($_POST['notify_start']) ? 1 : 0;
				$notify_end = isset($_POST['notify_end']) ? 1 : 0;
				$match_status = $_POST['match_status'];
				$match_confirm = $_POST['match_confirm'];
				$date_send_sql = $date_send != null ? "date_send='" . $date_send . "'" : "date_send=NULL";
				$res = $dbconn->execute("update creleases set priority='" . $priority . "',\r\n  \t\t\t\t\t\tsubject='" . $subject . "',\r\n\t\t\t\t\t\tbody='" . $body . "',\r\n\t\t\t\t\t\tformat='" . $format . "',\r\n\t\t\t\t\t\tdate=NOW(),\r\n\t\t\t\t\t\tfrom_email='" . $from_email . "',\r\n\t\t\t\t\t\tfrom_name='" . $from_name . "',\r\n\t\t\t\t\t\treply_to='" . $reply_to . "',\r\n\t\t\t\t\t\tencode='" . $encode . "',\r\n\t\t\t\t\t\t{$date_send_sql} ,\r\n\t\t\t\t\t\tnotify_start='" . $notify_start . "',\r\n\t\t\t\t\t\tnotify_end='" . $notify_end . "',\r\n\t\t\t\t\t\tnotify_email='" . $notify_email . "',\r\n\t\t\t\t\t\tmatch_status='" . $_POST['match_status'] . "',\r\n\t\t\t\t\t\tmatch_confirm='" . $_POST['match_confirm'] . "'\r\n\t\t\t\t\t\twhere id='" . $id . "'");
				$res2 = $dbconn->execute("delete from creleases_lists where crelease_id='" . $id . "'");
				if (is_array($lists_array))
				{
								foreach ($lists_array as $list_id)
								{
												$res2 = $dbconn->execute("insert into creleases_lists set crelease_id='" . $id . "', list_id='" . $list_id . "'");
								}
				}
				$res2 = $dbconn->execute("delete from release_attach where release_id='" . $id . "'");
				$is_attach = 0;
				if (is_array($attaches_array))
				{
								foreach ($attaches_array as $attach_id)
								{
												$res2 = $dbconn->execute("insert into release_attach set release_id='" . $id . "', attach_id='" . $attach_id . "'");
												$is_attach = 1;
								}
				}
				$res = $dbconn->execute("update creleases set is_attach='" . $is_attach . "' where id='" . $id . "'");
}
function getcontent($id)
{
				global $dbconn;
				$res = $dbconn->execute("select id,subject,body,format,priority,date_send, from_email, from_name,\r\n   reply_to, encode, notify_start, notify_end, notify_email, match_status, match_confirm\r\n   from creleases where id='" . $id . "'");
				$releases = array();
				$releases['id'] = $res->fields[0];
				$releases['subject'] = stripslashes($res->fields[1]);
				$releases['body'] = html_entity_decode($res->fields[2]);
				$releases['format'] = $res->fields[3];
				$releases['priority'] = $res->fields[4];
				$releases['date_send'] = $res->fields[5];
				$releases['from_email'] = $res->fields[6];
				$releases['from_name'] = $res->fields[7];
				$releases['reply_to'] = $res->fields[8];
				$releases['encode'] = $res->fields[9];
				$releases['notify_start'] = $res->fields[10];
				$releases['notify_end'] = $res->fields[11];
				$releases['notify_email'] = $res->fields[12];
				$releases['match_status'] = $res->fields[13];
				$releases['match_confirm'] = $res->fields[14];
				return $releases;
}
function getblankcontent()
{
				global $dbconn;
				$res = $dbconn->execute("select * from settings");
				$row = $res->getrowassoc(false);
				$releases = array();
				$releases['id'] = 0;
				$releases['subject'] = "";
				$releases['body'] = "";
				$releases['from_email'] = $row['from_email'];
				$releases['from_name'] = $row['from_name'];
				$releases['notify_email'] = $row['test_email'];
				$releases['match_status'] = 1;
				$releases['match_confirm'] = 1;
				return $releases;
}
function getlists()
{
				global $dbconn;
				global $config;
				$res = $dbconn->execute("select id, name, date,owner_name,owner_email from list order by id");
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$releases[$c]['id'] = $res->fields[0];
								$releases[$c]['name'] = stripslashes($res->fields[1]);
								$releases[$c]['date'] = $res->fields[2];
								$releases[$c]['owner_name'] = $res->fields[3];
								$releases[$c]['owner_email'] = $res->fields[4];
								$res2 = $dbconn->execute("select count(*) from clients_lists where list_id='" . $res->fields[0] . "' and status_subscribe<>'" . $config['status_subscribe_val']['unsubscribe'] . "'");
								$releases[$c]['count'] = $res2->fields[0];
								++$c;
								$res->movenext();
				}
				return $releases;
}
function getattaches()
{
				global $dbconn;
				global $config;
				$res = $dbconn->execute("SELECT * FROM attach ORDER BY file_name");
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$row = $res->getrowassoc();
								$releases[$c]['id'] = $row['ID'];
								$releases[$c]['name'] = $row['FILE_NAME'];
								$releases[$c]['description'] = $row['DESCRIPTION'];
								$releases[$c]['file_size'] = file_size($config['files_path'] . $row['FILE_NAME']);
								$res2 = $dbconn->execute("SELECT count(release_id) FROM release_attach WHERE attach_id='" . $row['attach'] . "'");
								$releases[$c]['count'] = $res2->fields[0];
								++$c;
								$res->movenext();
				}
				return $releases;
}
function parsebody($body, $res2, $list_id, $format = "text", $rid = 0)
{
				global $config;
				$body = preg_replace("/%BASIC:FIRSTNAME%/i", $res2->fields[1], $body);
				$body = preg_replace("/%BASIC:SECONDNAME%/i", $res2->fields[2], $body);
				$body = preg_replace("/%BASIC:EMAIL%/i", $res2->fields[3], $body);
				$body = preg_replace("/%BASIC:UNSUBLINK%/i", $config['server'] . "/uns.php?l=" . $list_id . "&cr=" . $rid . "&cu=" . $res2->fields[0] . "&c=" . md5($res2->fields[3]), $body);
				$link_counter_url = $config['server'] . "/cl.php";
				if ($format == "html")
				{
								$body = preg_replace("'href\\s*=\\s*\r\n                            ([\"\\'])?\r\n                            (?(1) (.*?)\\1 | ([^\\s\\>]+))'isxe", "'href=\"'.((preg_match('/mailto:/i','\\2\\3'))?'\\2\\3':'" . $link_counter_url . "?cu=" . $res2->fields[0] . "&cr=" . $rid . "&cl='.urlencode('\\2\\3')).'\"'", $body);
				} else
				{
								$body = preg_replace("/((http:\\/\\/|https:\\/\\/|ftp:\\/\\/|www)[^\\s\\>\\<\\'\"]+)/ie", "'" . $link_counter_url . "?cu=" . $res2->fields[0] . "&cr=" . $rid . "&cl='.urlencode('\\1')", $body);
				}
				return $body;
}
function token2br($text)
{
				$text = preg_replace("/\n/i", "", $text);
				$text = preg_replace("/\r/i", "", $text);
				return $text;
}
function gettemplates()
{
				global $dbconn;
				$res = $dbconn->execute("select id, name, body,date,format from templates order by id");
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$releases[$c]['id'] = $res->fields[0];
								$releases[$c]['name'] = stripslashes($res->fields[1]);
								$releases[$c]['body'] = html_entity_decode($res->fields[2]);
								$releases[$c]['date'] = $res->fields[3];
								$releases[$c]['format'] = $res->fields[4] == "html" ? "HTML" : "Text";
								++$c;
								$res->movenext();
				}
				return $releases;
}
function gettemplate($id)
{
				global $dbconn;
				$res = $dbconn->execute("select id,name,body,format from templates where id='" . $id . "'");
				$releases = array();
				$releases['id'] = $res->fields[0];
				$releases['name'] = stripslashes($res->fields[1]);
				$releases['format'] = stripslashes($res->fields[3]);
				$releases['body'] = html_entity_decode($res->fields[2]);
				return $releases;
}
?>
