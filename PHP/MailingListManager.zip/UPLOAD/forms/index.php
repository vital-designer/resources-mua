<?php
include ("../common.php");
include ("../include/forms_function.php");
$section = "forms";
$right_name = "view";
check_right($section, $right_name);
if (isset($_POST['del']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				foreach ($GLOBALS['_POST']['del'] as $val)
				{
								delform((integer)$val);
				}
}
if (isset($_GET['did']) && !empty($_GET['did']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				delform((integer)$_GET['did']);
}
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "date";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
} else
{
				$order = "";
}
$form_page = isset($_REQUEST['form_page']) ? $_REQUEST['form_page'] : 0;
$smarty->assign("razdel", "Forms");
$smarty->assign("description", "Manage Forms");
$smarty->assign("hint", "Here you can view a list of forms users subscribe to or unsubscribe from your newsletters. The form represents html-code you should insert into the page where your users will subscribe to your mailings. To have a look at a default form (because it�s design will suit the design of your site design) click \"View\" button.");
$GLOBALS['_SESSION']['return_url'] = "index.php";
$smarty->assign("order", $order);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("form_page", $form_page);
$smarty->assign("rel", getforms($order, $form_page));
$smarty->display("{$admin_nl_gentemplates}/forms_forms_list.tpl");
?>
