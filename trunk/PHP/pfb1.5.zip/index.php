<?
//phpFormBuilder Version 1.5 by Baris Kayar (barishkayar@yahoo.com)
//2002(cl)  The FormBuilder Group http://pfb.sourceforge.net

if ($username && $password)
{
setcookie("BaRTPFBuser",$username,time()+600000);
setcookie("BaRTPFBpass",$password,time()+600000);
setcookie("BaRTPFBserver",$dbserver,time()+600000);
header("location: index.php");
exit();
}
require("config.inc.php");
require("connectdb.inc.php");
require("style.inc.php");
?>
<frameset cols="150,*" rows="*" border="0" frameborder="0"> 
  <frame src="left.php" name="nav">
  <frame src="former.php" name="pfmmain">
</frameset>
<noframes>
<body bgcolor="#FFFFFF">
</body>
</noframes>
</html>
