<?php
error_reporting(E_ALL);
include ("../common.php");
include ("../include/forms_function.php");
if (isset($_POST['FormName']))
{
				$smarty->assign("name", $_POST['FormName']);
				$smarty->assign("list", getlists());
				$smarty->assign("listcount", count(getlists()));
				$smarty->assign("FormType", $_POST['FormType']);
				if (isset($_POST['lid']) && !empty($_POST['lid']))
				{
								$smarty->assign("lid", $_POST['lid']);
				}
				if (isset($_REQUEST['id']))
				{
								$id = $_REQUEST['id'];
								$form = getformcontent((integer)$_REQUEST['id']);
								$i = 0;
								$res = $dbconn->execute("select * from forms_lists where form_id='" . $id . "'");
								while (!$res->EOF)
								{
												$row = $res->getrowassoc(false);
												$list_form[$i]['id'] = $row['list_id'];
												++$i;
												$res->movenext();
								}
								$smarty->assign("list_form", $list_form);
								$smarty->assign("form", $form);
				}
				else
				{
								$smarty->assign("form", "");
				}
				$smarty->assign("razdel", "Forms");
				$smarty->assign("description", "New Form Creating: Step 2");
				$smarty->assign("hint", "Set form parameters, choose mailing lists the user will be subscribed or unsubscribed.");
				$smarty->display("{$admin_nl_gentemplates}/forms_create_form2.tpl");
}
else
{
				$smarty->assign("razdel", "Forms");
				$smarty->assign("description", "New Form Creating: Step 1");
				$smarty->assign("hint", "Indicate Form Name and choose its Type.");
				$smarty->display("{$admin_nl_gentemplates}/forms_create_form1.tpl");
}
?>
