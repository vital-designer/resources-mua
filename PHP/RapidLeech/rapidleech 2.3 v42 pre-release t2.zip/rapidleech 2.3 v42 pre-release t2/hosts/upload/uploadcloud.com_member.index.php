<?php
$upload_services[]="uploadcloud.com_member";
$max_file_size["uploadcloud.com_member"]=200;
$page_upload["uploadcloud.com_member"] = "uploadcloud.com_member.php";  
?>