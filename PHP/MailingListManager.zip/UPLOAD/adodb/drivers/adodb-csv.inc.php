<?php
if (!defined("_ADODB_CSV_LAYER"))
{
				define("_ADODB_CSV_LAYER", 1);
				include_once (ADODB_DIR . "/adodb-csvlib.inc.php");
				class adodb_csv extends adoconnection
				{
								var $databaseType = "csv";
								var $hasInsertID = true;
								var $hasAffectedRows = true;
								var $fmtTimeStamp = "'Y-m-d H:i:s'";
								var $_affectedrows = 0;
								var $_insertid = 0;
								var $_url;
								var $replaceQuote = "''";
								function adodb_csv()
								{
								}
								function _insertid()
								{
												return $this->_insertid;
								}
								function _affectedrows()
								{
												return $this->_affectedrows;
								}
								function &metadatabases()
								{
												return false;
								}
								function _connect($argHostname, $argUsername, $argPassword, $argDatabasename)
								{
												$this->_url = $argHostname;
												return true;
								}
								function _pconnect($argHostname, $argUsername, $argPassword, $argDatabasename)
								{
												$this->_url = $argHostname;
												return true;
								}
								function &metacolumns($table)
								{
												return false;
								}
								function &selectlimit($sql, $nrows = -1, $offset = -1, $arg3 = false)
								{
												global $ADODB_FETCH_MODE;
												$url = $this->_url . "?sql=" . urlencode($sql) . "&nrows={$nrows}&fetch={$ADODB_FETCH_MODE}&offset={$offset}&arg3=" . urlencode($arg3);
												$err = false;
												$rs = csv2rs($url, $err, false);
												if ($this->debug)
												{
																print "{$url}<br><i>{$err}</i><br>";
												}
												$at = strpos($err, "::::");
												if ($at === false)
												{
																$this->_errorMsg = $err;
																$this->_errorNo = (integer)$err;
												} else
												{
																$this->_errorMsg = substr($err, $at + 4, 1024);
																$this->_errorNo = -9999;
												}
												if (is_object($rs))
												{
																$rs->databaseType = "csv";
												}
												return $rs;
								}
								function execute($sql, $inputarr = false, $arg3 = false)
								{
												global $ADODB_FETCH_MODE;
												$url = $this->_url . "?sql=" . urlencode($sql) . "&fetch={$ADODB_FETCH_MODE}";
												if ($arg3)
												{
																$url .= "&arg3=" . urlencode($arg3);
												}
												$err = false;
												$rs = csv2rs($url, $err, false);
												if ($this->debug)
												{
																print urldecode($url) . "<br><i>{$err}</i><br>";
												}
												$at = strpos($err, "::::");
												if ($at === false)
												{
																$this->_errorMsg = $err;
																$this->_errorNo = (integer)$err;
												} else
												{
																$this->_errorMsg = substr($err, $at + 4, 1024);
																$this->_errorNo = -9999;
												}
												if (is_object($rs))
												{
																$this->_affectedrows = $rs->affectedrows;
																$this->_insertid = $rs->insertid;
																$rs->databaseType = "csv";
												}
												return $rs;
								}
								function errormsg()
								{
												return $this->_errorMsg;
								}
								function errorno()
								{
												return $this->_errorNo;
								}
								function _close()
								{
												return true;
								}
				}
				class adorecordset_csv extends adorecordset
				{
								function adorecordset_csv($id)
								{
												$this->adorecordset($id);
								}
								function _close()
								{
												return true;
								}
				}
}
?>