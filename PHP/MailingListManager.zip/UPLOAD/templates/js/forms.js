function InitXMLHttpRequest() {
	var req=null;
	// Make a new XMLHttp object
	if (window.XMLHttpRequest) {
		req = new XMLHttpRequest();
	} else if (window.ActiveXObject) {
		req = new ActiveXObject("Microsoft.XMLHTTP");
	}
	return req;
}
function AjaxQuery(query, dest, func, params){
	var req=InitXMLHttpRequest();
	
	if(dest!=null) field=document.getElementById(dest);
	req.onreadystatechange = function() {
		if(dest=='') return 0;
		if (req.readyState == 4) {
			if(dest!=null) RunJS(dest, req.responseText);
			if(func!=null) {
				exec_str="func(";
				var len=params.length;
				for(var i=0;i<len;i++){
					exec_str+="params["+i+"]";
					if(i!=(len-1)) exec_str+=', ';
				}
				exec_str+=");";
				eval(exec_str);
			}
		}
	}
	req.open("GET", query+'&rnd='+Math.random(), true);
	req.send(null);
	if(dest!=null) field.innerHTML = "Loading data...";
}

function GetSectionAttrs(id_sec, dest, dest1, dest2){
	last=document.getElementById('sec_'+id_section);
	cur=document.getElementById('sec_'+id_sec);
	last.className='inactive_section';
	cur.className='active_section';
	id_section=id_sec;
	var del_button=document.getElementById('del_button');

	if(s_const[id_section]!=null){
		del_button.disabled=true;
	}
	else{
		del_button.disabled=false;
	}
	var field1=null, field2=null;
	field1=document.getElementById(dest1);
	if(dest2) field2=document.getElementById(dest2);
	field1.innerHTML='';
	if(field2) field2.innerHTML='';
	
	AjaxQuery("ajax_sections.php?sel=get_section_attrs&id_section=" + id_sec, dest);
}

function DelSecAttibute(id_section, id_attr){
	var params=new Array(4);
	params[0]=id_section;
	params[1]='sec_attrs_div';
	params[2]='cur_section_div';
	params[3]='attr_props_div';
	
	AjaxQuery("ajax_sections.php?sel=del_section_attr&id_attr="+id_attr, null, GetSectionAttrs, params);
}

function LoadAtributeForm(id_sec, id_attr, dest, dest2){
	field2=document.getElementById(dest2);
	if(field2) field2.innerHTML="";
	var act=(id_attr!=null)?'edit':'new';
	AjaxQuery("ajax_sections.php?sel=get_attr_form&act="+act+"&id_sec="+id_sec+"&id_attr="+id_attr, dest);
}

function LoadAttrPropsForm(control_type, id_attr, dest){
	query="ajax_sections.php?sel=get_attr_props_form&control_type="+control_type;
	if(id_attr!=null) query+="&id_attr="+id_attr;
	AjaxQuery(query, dest);
}

function RunJS(div_name, response){
	var d2 = document.getElementById(div_name);

	//Check user browser
	var agent=(window.navigator.appName=='Netscape')?'Firefox':'IE';

	if(agent=='IE'){
		parseJS(div_name, response, true);
	}
	else{
		//Mozilla
		var d1=d2.parentNode;
		var d_new=document.createElement('div');
		
		//Set same attributes as original
		var attributes=d2.attributes;
		var len=attributes.length;

		d_new.innerHTML=response;
		for(var i=0; i<len; i++){
			d_new.setAttribute(attributes[i].name, attributes[i].value);
		}
		
		d1.replaceChild(d_new, d2);
	}
}

function parseJS(div_name, html, cut_flag){
   
	if ('undefined' == typeof(cut_flag)) {
		cut_flag = false;
	}
	
	if (cut_flag) {
		var breaker = 0;
		var cut_html= html;
		var pattern = /<script.*src=".*"/g;
		var result  = cut_html.match(pattern);
		
		var indx= 1;
		var pos = 1;
		while (-1 != pos && 11 >= breaker++) {
			pos = cut_html.indexOf('src="');
			if (-1 != pos) {
				x = cut_html.substring(pos+5);
				pos_e = x.indexOf('"');
				cut_html = x.substring(pos_e);
				
				var s = document.createElement('script');
				s.id  = 'dynamic' + (indx);
				s.type= 'text/javascript';
				s.language = 'javascript';
				s.src = x.substring(0, pos_e);
				var b = document.getElementById(div_name);
				b.appendChild(s);
			}
		}
		
		
		cut_html = html;
		pattern = /<script.*\/script>/g;
		result = cut_html.match(pattern);
		
		var js_code = '';
		
		pos = 1;
		breaker = 0;
		
		var _body = document.getElementById(div_name);
		_body.innerHTML=html;
		
		while (-1 != pos && 11 >= breaker++) {
			pos = cut_html.indexOf('<script');
			if (-1 != pos) {
				cut_html = cut_html.substring(pos+5);
				pos_next = cut_html.indexOf('>');
				cut_html = cut_html.substring(pos_next+1);
				pos_end  = cut_html.indexOf('/script>');
				js_code += cut_html.substring(0, pos_end-1);
				cut_html = cut_html.substring(pos_end+8);
			}
		}

		cut_html = null;
		if(js_code!=''){
			var s = document.createElement('script');
			s.id  = 'dynamic' + (indx);
			s.type= 'text/javascript';
			s.language = 'javascript';
			s.text= js_code;
			var b = document.getElementById(div_name);
			b.appendChild(s);			
		}
	}
	
	return;
}

function LoadSectionAttrs(id_sec, id_form, dest){
	last=document.getElementById('sec_'+id_section);
	cur=document.getElementById('sec_'+id_sec);
	last.className='inactive_section';
	cur.className='active_section';
	id_section=id_sec;

	var after_load=function(dest){
		Sortable.destroy(sections[0]);
		Sortable.destroy(sections[1]);
		Sortable.create(sections[0],{tag:'div', onUpdate: updateForm, dropOnEmpty: true, containment: sections, only:'lineitem', constraint:false});
		Sortable.create(dest,{tag:'div', dropOnEmpty: true, containment: sections, only:'lineitem', constraint:false});
	}
	var params=Array(1);
	params[0]=dest;
	AjaxQuery("ajax_forms.php?sel=get_section_attrs&id_section=" + id_sec+"&id_form="+id_form, dest, after_load, params);
}

function LoadFormAttrs(id_form, id_b, dest){
	last=document.getElementById('block_'+id_block);
	cur=document.getElementById('block_'+id_b);
	if(last!=null) last.className='inactive_section';
	if(cur!=null) cur.className='active_section';
	id_block=id_b;
	
	var after_load=function(dest){
		Sortable.destroy(sections[0]);
		Sortable.destroy(sections[1]);
		Sortable.create(sections[1],{tag:'div', onUpdate: updateForm, dropOnEmpty: true, containment: sections, only:'lineitem', constraint:false});
		Sortable.create(sections[0],{tag:'div', dropOnEmpty: true, containment: sections, only:'lineitem', constraint:false});
	}
	var params=Array(1);
	params[0]=dest;
	AjaxQuery("ajax_forms.php?sel=get_form_attrs&id_form="+id_form+"&id_block="+id_b, dest, after_load, params);
}

//Initiate place control
//path_prefix is global variable, uses if defined to call for location.php from other scripts placed not in root folder
function initPlaceControl(id_user, id_attr, target, section, value, load_user_data){
	var country_div='country_div_'+id_attr;
	var region_div='region_div_'+id_attr;
	var city_div='city_div_'+id_attr;
	switch(target){
		case 'country': 
						var query="location.php?sec=" + section + "&sel=country&id_user="+id_user+"&id_attr="+id_attr;
						if(path_prefix!=null && path_prefix!='') query=path_prefix+query;
						if(load_user_data) query+="&load";
						AjaxQuery(query, country_div);
						document.getElementById(region_div).innerHTML='';
						document.getElementById(city_div).innerHTML='';
						break;
		case 'region': 	
						if(value==0){
							document.getElementById(region_div).innerHTML='';
							document.getElementById(city_div).innerHTML='';
							return false;
						}
						var query="location.php?sec=" + section + "&sel=region&id_user="+id_user+"&id_attr="+id_attr+"&id_country="+value;
						if(path_prefix!=null && path_prefix!='') query=path_prefix+query;
						if(load_user_data) query+="&load";
						AjaxQuery(query, region_div);
						document.getElementById(city_div).innerHTML='';
						break;
		case 'city': 	
						if(value==0){
							document.getElementById(city_div).innerHTML='';
							return false;
						}
						var query="location.php?sec=" + section + "&sel=city&id_user="+id_user+"&id_attr="+id_attr+"&id_region="+value;
						if(path_prefix!=null && path_prefix!='') query=path_prefix+query;
						if(load_user_data) query+="&load";
						AjaxQuery(query, city_div);
						break;
	}
}