<?php
include ("kcaptcha.php");
if (!isset($_REQUEST[session_name()]))
{
				session_start();
}
$captcha = new kcaptcha();
if ($_REQUEST[session_name()])
{
				session_register("captcha_keystring");
				$GLOBALS['_SESSION']['captcha_keystring'] = $captcha->getkeystring();
}
?>
