UPDATE settings set admin_login='admin', admin_password='admin1', from_name='DummyCompany', from_email='admin@admin.com', test_email='admin@admin.com';

UPDATE smtp_server set host='localhost';
