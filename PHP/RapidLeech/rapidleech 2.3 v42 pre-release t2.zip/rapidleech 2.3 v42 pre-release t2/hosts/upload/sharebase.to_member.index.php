<?php
$upload_services[]="sharebase.to_member";
$max_file_size["sharebase.to_member"]=200;
$page_upload["sharebase.to_member"] = "sharebase.to_member.php";  
?>