﻿using Telerik.Cms.Web.UI;
using Telerik.Web.UI;
using System.Web.UI.WebControls;

namespace Samples.Books.WebControls
{
    /// <summary>
    /// View for displaying list of books
    /// </summary>
    public class BooksListView : ViewModeControl<BooksControlPanel>
    {
        /// <summary>
        /// Gets or sets the path to a custom layout template for the control.
        /// </summary>
        /// <remarks>
        /// We are overriding this property only to add attribute to it. The attribute will be used in future
        /// for the template mapping / exporting tool.
        /// </remarks>
        [WebSysTemplate(BooksListView.BooksListViewTemplateName,
            "BooksListViewTemplateName_Template_Desc", "/Books/", false, "2000-01-25")]
        public override string LayoutTemplatePath
        {
            get
            {
                return base.LayoutTemplatePath;
            }
            set
            {
                base.LayoutTemplatePath = value;
            }
        }

        /// <summary>
        /// Gets the name of the embedded layout template. If the control uses layout template this
        /// property must be overridden to provide the path (key) to an embedded resource file.
        /// </summary>
        /// <value>Name of the resource with embedded template</value>
        protected override string LayoutTemplateName
        {
            get
            {
                return BooksListView.BooksListViewTemplateName;
            }
        }

        // we are not using a separate class of container for each control, but rather the one implemented on the 
        // base ViewModeControl
        #region Control references

        protected virtual HyperLink CreateNewButton
        {
            get { return base.Container.GetControl<HyperLink>("createNewButton", true); }
        }

        #endregion

        /// <summary>
        /// Initializes all controls instantiated in the layout container. This method is called at appropriate time for setting initial values and subscribing for events of layout controls.
        /// </summary>
        /// <param name="viewContainer">The control that will host the current view.</param>
        protected override void InitializeControls(System.Web.UI.Control viewContainer)
        {
            base.InitializeControls(viewContainer);

            // notice how we are not initializing templates and containers anymore - all this is now responsility of the
            // base ViewModeControl class

            // when switching from one view to another, we will not use postbacks anymore, but rather
            // a hyperlink. To get the url, all we have to do is call CreateHosViewCommand function
            // of the base class and specify the generic type for the view for which we desire to
            // create the command
            this.CreateNewButton.NavigateUrl = CreateHostViewCommand<BookInsertView>();
        }

        private const string BooksListViewTemplateName = "Samples.Books.Resources.ControlTemplates.Backend.BooksListView.ascx";
    }
}
