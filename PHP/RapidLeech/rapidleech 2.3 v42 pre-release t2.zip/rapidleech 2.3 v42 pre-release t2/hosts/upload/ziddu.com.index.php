<?php 
$upload_services[] = "ziddu.com";
$max_file_size["ziddu.com"] = 200;
$page_upload["ziddu.com"] = "ziddu.com.php";  
?>