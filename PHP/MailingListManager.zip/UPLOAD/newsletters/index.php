<?php
include ("../common.php");
include ("../include/newsletters_function.php");
$section = "newsletters";
$right_name = "view";
check_right($section, $right_name);
if (isset($_POST['del']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				foreach ($GLOBALS['_POST']['del'] as $val)
				{
								delrelease($val);
				}
}
if (isset($_GET['did']) && !empty($_GET['did']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				delrelease($_GET['did']);
}
if ($_GET['sel'] == "addarchive")
{
				check_right($section, $right_name);
				addarchive($_GET['id']);
				header("Location:archive.php");
				exit();
}
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "subject";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
}
else
{
				$order = "";
}
if (isset($_REQUEST['newsletter_page']))
{
				$newsletter_page = $_REQUEST['newsletter_page'];
}
else
{
				$newsletter_page = 0;
}
$smarty->assign("razdel", "Newsletters");
$smarty->assign("description", "Manage Newsletters");
$smarty->assign("hint", "Use the form below to review, edit and send your newsletters. To create a new newsletter, click on \"Create Newsletter\" button below. You can attach files to newsletter.");
$GLOBALS['_SESSION']['return_url'] = "index.php";
$res = $dbconn->execute("SELECT * FROM settings");
$settings = $res->getrowassoc(false);
if ($settings['test_email'] != "")
{
				$is_test = 1;
}
else
{
				$is_test = 0;
}
$smarty->assign("order", $order);
$smarty->assign("is_test", $is_test);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("rel", getreleases($order, $newsletter_page));
$smarty->assign("newsletter_page", $newsletter_page);
$smarty->display("{$admin_nl_gentemplates}/newsletters_newsletters_list.tpl");
?>