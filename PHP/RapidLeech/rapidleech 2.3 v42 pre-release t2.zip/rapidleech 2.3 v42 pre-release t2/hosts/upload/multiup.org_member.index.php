<?php
$upload_services[]="multiup.org_member";
$max_file_size["multiup.org_member"]=1024;
$page_upload["multiup.org_member"] = "multiup.org_member";  
?>