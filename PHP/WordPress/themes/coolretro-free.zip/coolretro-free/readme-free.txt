COPYRIGHT � DREAMTEMPLATE.COM & FREETHEMELAYOUTS.COM
ALL RIGHTS RESERVED


This work is under Creative Commons Attribution-Share Alike 3.0 License.
http://creativecommons.org/licenses/by-sa/3.0/

This means you may use it and make any changes you like. 
However, credit links must remain on footer for legal use.

 
For more information visit:
http://www.freethemelayouts.com/
http://www.themelayouts.com/
http://www.dreamtemplate.com/

##########################################

Installation Instructions:

Upload folder container themes to your Wordpress themes folder, usually:
/wp-content/themes/

If there are any plugins associated with this theme, upload plugins folder to:
/wp-content/plugins/

After uploading, goto your Wordpress Dashboard and click "Change Theme"

##########################################

