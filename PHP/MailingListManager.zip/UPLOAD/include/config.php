<?php
$config['site_root'] = "";
$config['host'] = "http://localhost:6455/";
$config['server'] = "http://localhost:6455/";
$config['site_path'] = $_SERVER['DOCUMENT_ROOT'] . "/";
$config['delimiter'] = "/";
$config['dbtype'] = "mysql";
$config['dbhost'] = "localhost:31013";
$config['dbuname'] = "root";
$config['dbpass'] = "";
$config['dbname'] = "newsletter";
$config['interval_between_click'] = 5;
$config['files_path'] = $config['site_path'] . "/files/";
$config['files_web'] = $config['server'] . "/files/";
include ("config.inc.php");
include ("constants.php");
?>
