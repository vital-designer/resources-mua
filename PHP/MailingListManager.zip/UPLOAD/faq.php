<?php
include ("common.php");
$smarty->assign("razdel", "Help");
$smarty->assign("description", "FAQ");
$smarty->display("{$admin_nl_gentemplates}/faq.tpl");
?>