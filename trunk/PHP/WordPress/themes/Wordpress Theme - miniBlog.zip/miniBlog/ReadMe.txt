Included is:
Theme Files

======
FAQ
======

If you have the PageNavi plugin activated in your plugins folder, disable it, it will conflict with the built-in PageNavi plugin in miniBlog.

You don't have to use images in posts, but if you want to, make sure they are 98px x 98px or they will be stretched.  To add an image to a post, from the "Write Post" page in the dashboard, scroll down to the "Custom Fields"area and input "image" as the key and the url to your image as the value and then save the post.  (Note, if you have been using a different key other than "image" and don't want all your past pictures to go to waste,
simply go to miniBlog's Theme Options page and change the post image keyword to the one you've
been using.  miniBlog will then retrieve all of your old pictures.

Everything else is pretty much self-explanitory.  Explore the Theme Options page to see other options that are available to you through miniBlog.  Enjoy the theme!