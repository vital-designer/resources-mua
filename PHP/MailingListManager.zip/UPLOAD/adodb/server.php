<?php
function err($s)
{
				exit("**** " . $s . " ");
}
function undomq(&$m)
{
				if (get_magic_quotes_gpc())
				{
								$m = str_replace("\\\\", "\\", $m);
								$m = str_replace("\\\"", "\"", $m);
								$m = str_replace("\\'", "'", $m);
				}
				return $m;
}
$ACCEPTIP = "";
$driver = "mysql";
$host = "localhost";
$uid = "root";
$pwd = "";
$database = "northwind";
$sep = " :::: ";
include ("./adodb.inc.php");
include_once (ADODB_DIR . "/adodb-csvlib.inc.php");
$remote = $HTTP_SERVER_VARS['REMOTE_ADDR'];
if (empty($_GET['sql']))
{
				err("No SQL");
}
if (!empty($ACCEPTIP) && $remote != "127.0.0.1" && $remote != $ACCEPTIP)
{
				err("Unauthorised client: '{$remote}'");
}
$conn = &adonewconnection($driver);
if (!$conn->connect($host, $uid, $pwd, $database))
{
				err($conn->errorno() . $sep . $conn->errormsg());
}
$sql = undomq(&$GLOBALS['_GET']['sql']);
if (isset($_GET['fetch']))
{
				$ADODB_FETCH_MODE = $_GET['fetch'];
}
if (isset($_GET['nrows']))
{
				$nrows = $_GET['nrows'];
				$offset = isset($_GET['offset']) ? $_GET['offset'] : -1;
				$rs = $conn->selectlimit($sql, $nrows, $offset);
} else
{
				$rs = $conn->execute($sql);
}
if ($rs)
{
				echo rs2csv($rs, $conn, $sql);
				$rs->close();
} else
{
				err($conn->errorno() . $sep . $conn->errormsg());
}
?>
