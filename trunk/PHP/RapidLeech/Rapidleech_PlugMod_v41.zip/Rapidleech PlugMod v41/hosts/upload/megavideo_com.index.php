<?php 
$upload_services[] = "megavideo_com";
$max_file_size["megavideo_com"] = 5000;
$page_upload["megavideo_com"] = "megavideo_com.php";  
?>