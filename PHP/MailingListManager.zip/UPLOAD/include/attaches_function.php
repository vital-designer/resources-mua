<?php
function getattach($orderby = "", $attach_page = 0)
{
				global $dbconn;
				global $smarty;
				global $config;
				if (isset($_GET['p']) && 0 < $_GET['p'])
				{
								$p = $_GET['p'];
				} else
				{
								$p = 0;
				}
				$end = $_SESSION['is_desc'] && !$_GET['is_nav'] || !$_SESSION['is_desc'] && $_GET['is_nav'] ? " desc " : "";
				if ($orderby)
				{
								$is_nav = isset($_GET['is_nav']) ? $_GET['is_nav'] : false;
								if (!$is_nav && $orderby == $_SESSION['order'])
								{
												if ($_SESSION['is_desc'])
												{
																$GLOBALS['_SESSION']['is_desc'] = false;
																$end = " desc ";
												} else
												{
																$GLOBALS['_SESSION']['is_desc'] = true;
																$end = "";
												}
								}
								$sql .= " order by " . $orderby . $end;
				} else
				{
								$sql .= " order by file_name";
				}
				$smarty->assign("end", trim($end));
				$res = $dbconn->execute("SELECT count(id) FROM attach");
				$amount = $res->fields[0];
				$smarty->assign("navigation", create_navigation($amount, $attach_page, "attach_page={$attach_page}&order=" . $_GET['order'] . "&is_nav=true", "index.php", $p, "attach_page"));
				get_smarty_array_list("attach_page", $config['attach_page']);
				$per_page = $config['attach_page'][$attach_page];
				$res = $dbconn->pageexecute("SELECT * FROM attach " . $sql, $per_page, $p + 1);
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$row = $res->getrowassoc(false);
								$releases[$c]['id'] = $row['id'];
								$releases[$c]['file_name'] = stripslashes($row['file_name']);
								$releases[$c]['description'] = stripslashes($row['description']);
								$releases[$c]['size'] = file_size($config['files_path'] . $row['file_name']);
								$releases[$c]['file_path'] = $config['files_web'] . $row['file_name'];
								++$c;
								$res->movenext();
				}
				$smarty->assign("amount", $amount);
				return $releases;
}
function delattach($id)
{
				global $dbconn;
				global $config;
				$res = $dbconn->execute("SELECT file_name FROM attach WHERE id='" . $id . "'");
				$row = $res->getrowassoc(false);
				unlink($config['files_path'] . $row['file_name']);
				$res = $dbconn->execute("DELETE FROM attach WHERE id='" . $id . "'");
}
function addattach()
{
				global $dbconn;
				global $config;
				if (is_uploaded_file($_FILES['attach']['tmp_name']))
				{
								move_uploaded_file($_FILES['attach']['tmp_name'], $config['files_path'] . $_FILES['attach']['name']);
								$res = $dbconn->execute("insert into attach set file_name='" . $_FILES['attach']['name'] . "', description='" . str_prepare($_POST['description']) . "'");
				}
				$rid = $dbconn->_insertid();
				return $rid;
}
function updattach()
{
				global $dbconn;
				$description = str_prepare($_POST['description']);
				$id = $_GET['id'];
				$res = $dbconn->execute("update attach set description='" . $description . "' where id='" . $id . "'");
}
function getcontent()
{
				global $dbconn;
				global $config;
				$id = $_GET['id'];
				$res = $dbconn->execute("select * from attach where id='" . $id . "'");
				$releases = array();
				$row = $res->getrowassoc();
				$releases['id'] = $row['ID'];
				$releases['file_name'] = stripslashes($row['FILE_NAME']);
				$releases['description'] = $row['DESCRIPTION'];
				$releases['size'] = file_size($config['files_path'] . $row['FILE_NAME']);
				$releases['file_path'] = $config['files_web'] . $row['FILE_NAME'];
				return $releases;
}
function getblankcontent()
{
				$releases = array();
				return $releases;
}
?>
