<?php
function &rs2csv(&$rs, $conn = false, $sql = "")
{
				$max = $rs->fieldcount();
				if ($sql)
				{
								$sql = urlencode($sql);
				}
				if ($max <= 0 || $rs->EOF)
				{
								if (is_object($conn))
								{
												$sql .= "," . $conn->affected_rows();
												$sql .= "," . $conn->insert_id();
								} else
								{
												$sql .= ",,";
								}
								$text = "====-1,0,{$sql}\n";
								return $text;
				} else
				{
								$tt = $rs->timeCreated ? $rs->timeCreated : time();
								$line = "====0,{$tt},{$sql}\n";
				}
				$i = 0;
				for (; $i < $max; ++$i)
				{
								$o = $rs->fetchfield($i);
								$line .= urlencode($o->name) . ":" . $rs->metatype($o->type, $o->max_length) . ":{$o->max_length},";
				}
				$text = substr($line, 0, strlen($line) - 1) . "\n";
				if ($rs->databaseType == "array")
				{
								$text .= serialize($rs->_array);
				} else
				{
								$rows = array();
								while (!$rs->EOF)
								{
												$rows[] = $rs->fields;
												$rs->movenext();
								}
								$text .= serialize($rows);
				}
				$rs->movefirst();
				return $text;
}
function &csv2rs($url, &$err, $timeout = 0)
{
				$fp = @fopen($url, "r");
				$err = false;
				if (!$fp)
				{
								$err = $url . "file/URL not found";
								return false;
				}
				flock($fp, LOCK_SH);
				$arr = array();
				$ttl = 0;
				if ($meta = fgetcsv($fp, 8192, ","))
				{
								if (substr($meta[0], 0, 4) === "****")
								{
												$err = trim(substr($meta[0], 4, 1024));
												fclose($fp);
												return false;
								}
								if (substr($meta[0], 0, 4) === "====")
								{
												if ($meta[0] == "====-1")
												{
																if (sizeof($meta) < 5)
																{
																				$err = "Corrupt first line for format -1";
																				fclose($fp);
																				return false;
																}
																fclose($fp);
																if (0 < $timeout)
																{
																				return false;
																}
																$val = 1;
																$rs = new adorecordset($val);
																$rs->EOF = true;
																$rs->_numOfFields = 0;
																$rs->sql = urldecode($meta[2]);
																$rs->affectedrows = (integer)$meta[3];
																$rs->insertid = $meta[4];
																$rs->aa = "100";
																return $rs;
												}
												if (1 < sizeof($meta))
												{
																if (0 < $timeout)
																{
																				$tdiff = $meta[1] + $timeout - time();
																				if ($tdiff <= 2)
																				{
																								switch ($tdiff)
																								{
																												case 2:
																																if (!((rand() & 15) == 0))
																																{
																																				break;
																																}
																																fclose($fp);
																																$err = "Timeout 2";
																																return false;
																																break;
																												case 1:
																																if (!((rand() & 3) == 0))
																																{
																																				break;
																																}
																																fclose($fp);
																																$err = "Timeout 1";
																																return false;
																																break;
																												default:
																																fclose($fp);
																																$err = "Timeout 0";
																																return false;
																								}
																				}
																}
																$ttl = $meta[1];
												}
												$meta = fgetcsv($fp, 8192, ",");
												if (!$meta)
												{
																fclose($fp);
																$err = "Unexpected EOF 1";
																return false;
												}
								}
								$flds = array();
								foreach ($meta as $o)
								{
												$o2 = explode(":", $o);
												if (sizeof($o2) != 3)
												{
																$arr[] = $meta;
																$flds = false;
												} else
												{
																$fld = new adofieldobject();
																$fld->name = urldecode($o2[0]);
																$fld->type = $o2[1];
																$fld->max_length = $o2[2];
																$flds[] = $fld;
												}
								}
				} else
				{
								fclose($fp);
								$err = "Recordset had unexpected EOF 2";
								return false;
				}
				$MAXSIZE = 128000;
				$text = fread($fp, $MAXSIZE);
				if (strlen($text) == $MAXSIZE)
				{
								$text .= fread($fp, filesize($url) - $MAXSIZE);
				}
				fclose($fp);
				$arr = @unserialize($text);
				if (!is_array($arr))
				{
								$err = "Recordset had unexpected EOF 3";
								return false;
				}
				$rs = new adorecordset_array();
				$rs->timeCreated = $ttl;
				$rs->initarrayfields($arr, $flds);
				return $rs;
}
?>