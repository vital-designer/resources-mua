<?php
$upload_services[] = "mega.1280.com";
$max_file_size["mega.1280.com"] = 200;
$page_upload["mega.1280.com"] = "mega.1280.com.php";  
?>