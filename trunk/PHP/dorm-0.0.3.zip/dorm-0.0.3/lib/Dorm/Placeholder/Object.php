<?php
/**
 * This file is part of Dorm and is subject to the GNU Affero General
 * Public License Version 3 (AGPLv3). You should have received a copy
 * of the GNU Affero General Public License along with Dorm. If not,
 * see <http://www.gnu.org/licenses/>.
 *
 * @category Dorm
 * @package Dorm_Placeholder
 * @copyright Copyright (c) 2008-2009 Olivier Lalonde <olalonde@gmail.com>
 */

/**
 * Placeholders are used to lazyload from DB
 *
 * Instead of loading all foreign objects, we put a place holder at the place of those objects and when a
 * call is made to them, we dynamically replace the place holder with the object load from the DB
 *
 * We prefixed everything with "dorm_" to avoid collisions with __get() __set() and __call()
 *
 * @todo implement isset overloading
 */
class Dorm_Placeholder_Object extends Dorm_Placeholder {

    // This is used for lazy loading foreign objects

    /**
     * @var Dorm
     */
    private $dorm_Dorm;

    /**
     * @var Dorm_Object
     */
    private $dorm_Parent;

    /**
     * @var Dorm_Map_Property
     */
    private $dorm_Property;

    /**
     * @var Dorm_Object Object to load...
     */
    private $dorm_Object;

    /**
     * @var object
     */
    private $dorm_DomainObject;

    public function __construct($dorm, $parent, $property, $object) {
        $this->dorm_Dorm = $dorm;
        $this->dorm_Parent = $parent;
        $this->dorm_Property = $property;
        $this->dorm_Object = $object;
        $this->dorm_DomainObject = $object->_;
    }

    public function __call($method, $arguments) {
        $this->dorm_ReplacePlaceholderWithObject();
        return call_user_func_array(array($this->dorm_Object->_, $method), $arguments);
    }

    public function __get($property_name) {
        $this->dorm_ReplacePlaceholderWithObject();
        return $this->dorm_DomainObject->$property_name;
    }

    public function __set($property_name, $value) {
        $this->dorm_ReplacePlaceholderWithObject();
        return $this->dorm_DomainObject->$property_name = $value;
    }

    private function dorm_ReplacePlaceholderWithObject() {
        $this->dorm_Dorm->load($this->dorm_Object);
        $this->dorm_Property->setValue($this->dorm_Parent, $this->dorm_Object->_);
    }
}