<?php
include ("../common.php");
include ("../include/newsletters_function.php");
$section = "newsletters";
foreach ($config['encodes'] as $k => $v)
{
				$encodes_value[] = $k;
				$encodes_output[] = $v;
}
$smarty->assign(array("encodes_value" => $encodes_value, "encodes_output" => $encodes_output));
$lists = getlists();
$attaches = getattaches();
$smarty->assign("lists", $lists);
$smarty->assign("attaches", $attaches);
if (empty($lists))
{
				$smarty->assign("list_count", 0);
}
else
{
				$smarty->assign("list_count", 1);
}
if (empty($attaches))
{
				$smarty->assign("attach_count", 0);
}
else
{
				$smarty->assign("attach_count", 1);
}
$smarty->assign("razdel", "Newsletters");
$smarty->assign("description", "Newsletter editing");
$smarty->assign("hint", "Edit newsletter and press \"Save Newsletter\" to apply changes");
foreach ($config['priority'] as $val => $out)
{
				$priority_values[] = $val;
				$priority_output[] = $out;
}
$smarty->assign("priority_values", $priority_values);
$smarty->assign("priority_output", $priority_output);
$smarty->assign("priority", 3);
if (isset($_GET['id']))
{
				if (!isset($_POST['action']) || $_POST['action'] != "change")
				{
								if ($_GET['id'] == 0)
								{
												$content = getblankcontent();
								}
								else
								{
												$right_name = "view_item";
												check_right($section, $right_name);
												$content = getcontent($_GET['id']);
												$res = $dbconn->execute("select * from release_attach where release_id='" . $_GET['id'] . "'");
												$c = 0;
												while (!$res->EOF)
												{
																$row = $res->getrowassoc(false);
																$attach_array[$c] = $row['attach_id'];
																++$c;
																$res->movenext();
												}
												$res = $dbconn->execute("select * from creleases_lists where crelease_id='" . $_GET['id'] . "'");
												$c = 0;
												while (!$res->EOF)
												{
																$row = $res->getrowassoc(false);
																$list_array[$c] = $row['list_id'];
																++$c;
																$res->movenext();
												}
												$smarty->assign("id", $content['id']);
												$smarty->assign("list_array", $list_array);
												$smarty->assign("attach_array", $attach_array);
								}
								$smarty->assign("rel", $content);
								$smarty->assign("message", $message);
								$smarty->assign("id", $content['id']);
								$smarty->assign("priority", $content['priority']);
								$smarty->assign("date_send", $content['date_send']);
								if ($_GET['form'] == "wyswyg")
								{
												require_once ("../tinymce/tinymce.php");
												$newsletter['body'] = token2br($content['body']);
												$smarty->assign("newsletter", $newsletter);
												$smarty->assign("tinymce", $tinymce);
												$smarty->display("{$admin_nl_gentemplates}/newsletters_change_html.tpl");
								}
								else
								{
												$smarty->display("{$admin_nl_gentemplates}/newsletters_change_txt.tpl");
								}
								exit();
				}
				else
				{
								$format = $_POST['format'];
								if (!preg_match("|([0-9]{4})[-/\\.]?([0-9]{1,2})[-/\\.]?([0-9]{1,2})|", $_POST['date_send']))
								{
												$date_send = null;
								}
								else
								{
												$date_send = $_POST['date_send'];
								}
								switch ($_POST['bodyfrom'])
								{
												case "text":
																$body = isset($_POST['body1']) && !empty($_POST['body1']) ? $_POST['body1']:
																trim($_POST['wysiwyg']);
																break;
												case "file":
																if (!isset($_FILES['bodyfile']['tmp_name']) || empty($_FILES['bodyfile']['tmp_name']))
																{
																				$message = "Error: Can't open file";
																}
																else
																{
																				$body = join("", file($_FILES['bodyfile']['tmp_name']));
																}
																break;
												case "link":
																if (!isset($_POST['bodyurl']) || empty($_POST['bodyurl']) || $_POST['bodyurl'] == "http://")
																{
																				$message = "Error: Empty URL";
																}
																else
																{
																				if (!preg_match("/http:\\/\\//i", $_POST['bodyurl']))
																				{
																								$bodyurl = "http://" . $_POST['bodyurl'];
																				}
																				else
																				{
																								$bodyurl = $_POST['bodyurl'];
																				}
																				include ("../include/Snoopy.class.inc");
																				$snoopy = new snoopy();
																				$snoopy->fetch($bodyurl, "");
																				$body = $snoopy->results;
																				if (!empty($body))
																				{
																								break;
																				}
																				$message = "Error: Empty content from URL";
																				break;
																}
												default:
																$body = isset($_POST['body1']) && !empty($_POST['body1']) ? $_POST['body1']:
																trim($_POST['wysiwyg']);
																break;
								}
								if (!isset($message))
								{
												if ($_GET['id'] == 0)
												{
																$right_name = "create";
																check_right($section, $right_name);
																$body = htmlentities($body, ENT_QUOTES);
																$releaseID = addrelease($body, $date_send);
												}
												else
												{
																$right_name = "edit";
																check_right($section, $right_name);
																$body = htmlentities($body, ENT_QUOTES);
																updrelease($body, $date_send);
																$releaseID = $_GET['id'];
												}
												$smarty->assign("rel", getcontent($releaseID, "1"));
												$smarty->assign("users", getusers());
												header("Location: index.php");
								}
								else
								{
												if ($_GET['id'] == 0)
												{
																$content = getblankcontent();
												}
												else
												{
																$content = getcontent($_GET['id']);
												}
												$smarty->assign("message", $message);
												$smarty->assign("id", $content['id']);
												$smarty->assign("priority", $content['priority']);
												$smarty->assign("date_send", $content['date_send']);
												if ($_GET['form'] == "wyswyg")
												{
																$content['body'] = token2br($content['body']);
																require_once ("../tinymce/tinymce.php");
																$newsletter['body'] = token2br($content['body']);
																$smarty->assign("newsletter", $newsletter);
																$smarty->assign("tinymce", $tinymce);
																$smarty->assign("subject", $content['subject']);
																$smarty->assign("rel", $content);
																$smarty->display("{$admin_nl_gentemplates}/newsletters_change_html.tpl");
												}
												else
												{
																$smarty->assign("rel", $content);
																$smarty->display("{$admin_nl_gentemplates}/newsletters_change_txt.tpl");
												}
												exit();
								}
				}
}
else
{
				header("Location: index.php");
}
?>