<?php
if (!defined('RAPIDLEECH'))
{
	require_once("index.html");
	exit;
}
include_once('uploaded_to.php');
?>