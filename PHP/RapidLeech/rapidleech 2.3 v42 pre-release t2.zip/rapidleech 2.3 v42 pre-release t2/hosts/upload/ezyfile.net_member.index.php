<?php
$upload_services[]="ezyfile.net_member";
$max_file_size["ezyfile.net_member"]=1024;
$page_upload["ezyfile.net_member"] = "ezyfile.net_member.php";  
?>