<?php
$upload_services[]="storeandserve.com";
$max_file_size["storeandserve.com"]=100;
$page_upload["storeandserve.com"] = "storeandserve.com.php";  
?>