<?php
include ("../common.php");
include ("../include/template_function.php");
$section = "templates";
$right_name = "create";
check_right($section, $right_name);
if (isset($_POST['format']) && !empty($_POST['format']))
{
				$content = getblankcontent();
				if ($_POST['format'] == "html")
				{
								require_once ("../tinymce/tinymce.php");
								$newsletter['body'] = token2br($content['body']);
								$smarty->assign("newsletter", $newsletter);
								$smarty->assign("tinymce", $tinymce);
								$smarty->assign("id", 0);
								$smarty->assign("format", "html");
								$smarty->assign("subject", $content['subject']);
								$smarty->assign("razdel", "Templates");
								$smarty->assign("description", "New HTML Template Creating: Step 2");
								$smarty->assign("hint", "Use WISIWIG-editor  to create a template. Pay attention to the fact that the more elements you use the larger newsletter size based on the template will be while sending.");
								$smarty->display("{$admin_nl_gentemplates}/template_change_html_template.tpl");
				}
				else
				{
								$smarty->assign("id", 0);
								$smarty->assign("format", "text");
								$smarty->assign("rel", $content);
								$smarty->assign("razdel", "Templates");
								$smarty->assign("description", "New Text Template Creating: Step 2");
								$smarty->assign("hint", "You may use text often repeated in newsletters as a template.");
								$smarty->display("{$admin_nl_gentemplates}/template_change_txt_template.tpl");
				}
				exit();
}
$smarty->assign("razdel", "Templates");
$smarty->assign("description", "New Template Creating: Step 1");
$smarty->assign("hint", "Choose template type. You don't need to know HTML (Hyper Text Market Language) as WISIWIG-editor is used for html template creating.");
$smarty->display("{$admin_nl_gentemplates}/template_create_format_template.tpl");
?>