<?php
if (!defined("_ADODB_PROXY_LAYER"))
{
				define("_ADODB_PROXY_LAYER", 1);
				include (ADODB_DIR . "/drivers/adodb-csv.inc.php");
				class adodb_proxy extends adodb_csv
				{
								var $databaseType = "proxy";
				}
				class adorecordset_proxy extends adorecordset_csv
				{
								var $databaseType = "proxy";
								function adorecordset_proxy($id)
								{
												$this->adorecordset($id);
								}
				}
}
?>