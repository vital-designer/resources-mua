<?php 
$upload_services[] = "turboupload.com";
$max_file_size["turboupload.com"] = 500;
$page_upload["turboupload.com"] = "turboupload.com.php";
?>