<html>
<head>
<title>UserCake - Database Setup</title>
</head>
<body>
<?php
/*
	Copyright UserCake
	http://usercake.com
	
	Developed by: Adam Davis
*/

//  Primitive installer
	
	include("../models/settings.php");
	
	//Dbal Support - Thanks phpBB ; )
	include('../models/classes/db/'.$dbtype.'.php');
	
	//Construct a db instance
	$db = new $sql_db();
	if(!$db->sql_connect($db_host, $db_user, $db_pass, $db_name, $db_port, false, false)) die("Unable to connect to database");

	$groups_sql = "
		CREATE TABLE IF NOT EXISTS `Groups` (
  		`Group_ID` int(11) NOT NULL auto_increment,
  		`Group_Name` varchar(225) NOT NULL,
         PRIMARY KEY  (`Group_ID`)
		) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;
	";
	
	$group_entry = "
		INSERT INTO `Groups` (`Group_ID`, `Group_Name`) VALUES
		(1, 'Standard User');
	";
	
	$users_sql = "
		 CREATE TABLE IF NOT EXISTS `Users` (
  		`User_ID` int(11) NOT NULL auto_increment,
  		`Username` varchar(150) NOT NULL,
  		`Username_Clean` varchar(150) NOT NULL,
    	`Password` varchar(225) NOT NULL,
  		`Email` varchar(150) NOT NULL,
  		`ActivationToken` varchar(225) NOT NULL,
        `LostPasswordRequest` int(1) NOT NULL default '0',
        `Active` int(1) NOT NULL,
        `Group_ID` int(11) NOT NULL,
        `SignUpDate` int(11) NOT NULL,
         `LastSignIn` int(11) NOT NULL,
         PRIMARY KEY  (`User_ID`)
		) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
	";
	
	
	if($db->sql_query($groups_sql))
	{
		echo "<p>Groups table created.....</p>";
	}
	else
	{
		echo "<p>Error constructing group table.</p><br /><br /> DBMS said: ";
		
		echo print_r($db->_sql_error());
		die;
	}
	
	if($db->sql_query($group_entry))
	{
		echo "<p>Inserted Standard User group into groups table.....</p>";
	}
	else
	{
		echo "<p>Error constructing group table.</p><br /><br /> DBMS said: ";
		
		echo print_r($db->_sql_error());
		die;
	}
	
	if($db->sql_query($users_sql))
	{
		echo "<p>User table created.....</p>";
	}
	else
	{
		echo "<p>Error constructing user table.</p><br /><br /> DBMS said: ";
		
		echo print_r($db->_sql_error());
		die;
	}
	
	echo "<p><strong>Database setup complete, please delete the install folder.</strong></p>";

	include("../models/clean_up.php");
?>
</body>
</html>