<?php
include ("../common.php");
include ("../include/forms_function.php");
$section = "forms";
if (isset($_REQUEST['id']))
{
				$right_name = "view_item";
				check_right($section, $right_name);
				$form = getformcontent((integer)$_REQUEST['id']);
				$smarty->assign("form", $form);
} else
{
				$smarty->assign("form", "");
}
$right_name = "create";
check_right($section, $right_name);
$smarty->assign("razdel", "Forms");
$smarty->assign("description", "New Form Creating: Step 1");
$smarty->assign("hint", "Indicate Form Name and choose its Type.");
$smarty->display("{$admin_nl_gentemplates}/forms_create_form1.tpl");
?>
