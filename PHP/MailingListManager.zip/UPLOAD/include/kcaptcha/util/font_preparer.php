<?php
exit();
if ($handle = opendir("../fonts0"))
{
				while (false !== ($file = readdir($handle)))
				{
								if ($file == "." || $file == "..")
								{
								} else
								{
												$img = imagecreatefrompng("../fonts0/" . $file);
												imagealphablending($img, false);
												imagesavealpha($img, true);
												$transparent = imagecolorallocatealpha($img, 255, 255, 255, 127);
												$white = imagecolorallocate($img, 255, 255, 255);
												$black = imagecolorallocate($img, 0, 0, 0);
												$gray = imagecolorallocate($img, 100, 100, 100);
												$x = 0;
												for (; $x < imagesx($img); ++$x)
												{
																$space = true;
																$column_opacity = 0;
																$y = 1;
																for (; $y < imagesy($img); ++$y)
																{
																				$rgb = imagecolorat($img, $x, $y);
																				$opacity = $rgb >> 24;
																				if ($opacity != 127)
																				{
																								$space = false;
																				}
																				$column_opacity += 127 - $opacity;
																}
																if (!$space)
																{
																				imageline($img, $x, 0, $x, 0, $column_opacity < 200 ? $gray : $black);
																}
												}
												imagepng($img, "../fonts/" . $file);
								}
				}
				closedir($handle);
}
echo " \r\n";
?>
