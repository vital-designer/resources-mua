<?php
$upload_services[]="storage.to_member";
$max_file_size["storage.to_member"]=1024;
$page_upload["storage.to_member"] = "storage.to_member.php";  
?>