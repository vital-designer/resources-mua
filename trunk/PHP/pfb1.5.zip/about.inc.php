<br>
<div class="about">
<CENTER><a href="http://pfb.sourceforge.net" target="_blank" class="linkler">phpFormBuilder</a> Version 1.5 by Baris Kayar 
(<a href="mailto:barishkayar@yahoo.com" target="_top" class="linkler">barishkayar@yahoo.com</a>)<BR> 2002 (cl) 
<a href="http://pfb.sourceforge.net" target="_blank" class="linkler">The FormBuilder Group</a>
</CENTER>
</div>
<BR>
