machform.js source-code is unavailable in original archive.

thx friends for helping