<?php
$upload_services[]="letitbit.net";
$max_file_size["letitbit.net"]=1200;
$page_upload["letitbit.net"] = "letitbit.net.php";  
?>