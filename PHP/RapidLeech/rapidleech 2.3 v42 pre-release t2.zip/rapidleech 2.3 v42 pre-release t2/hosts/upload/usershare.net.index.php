<?php 
$upload_services[]="usershare.net";
$max_file_size["usershare.net"]=1024;
$page_upload["usershare.net"] = "usershare.net.php";  
?>