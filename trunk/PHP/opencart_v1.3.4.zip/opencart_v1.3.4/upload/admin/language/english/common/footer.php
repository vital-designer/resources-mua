<?php
// Heading
$_['heading_title']       = 'Footer';
$_['heading_description'] = 'Administration Footer';
?>