﻿using Telerik.Cms.Web.UI;
using System.Web.UI.WebControls;

namespace Samples.Books.WebControls
{
    /// <summary>
    /// View for inserting books
    /// </summary>
    public class BookInsertView : ViewModeControl<BooksControlPanel>
    {
        /// <summary>
        /// Gets or sets the path to a custom layout template for the control.
        /// </summary>
        /// <remarks>
        /// We are overriding this property only to add attribute to it. The attribute will be used in future
        /// for the template mapping / exporting tool.
        /// </remarks>
        [WebSysTemplate(BookInsertView.BookInsertViewTemplateName,
            "BookInsertViewTemplateName_Template_Desc", "/Books/", false, "2000-01-25")]
        public override string LayoutTemplatePath
        {
            get
            {
                return base.LayoutTemplatePath;
            }
            set
            {
                base.LayoutTemplatePath = value;
            }
        }

        /// <summary>
        /// Gets the name of the embedded layout template. If the control uses layout template this
        /// property must be overridden to provide the path (key) to an embedded resource file.
        /// </summary>
        /// <value>Name of the resource with embedded template</value>
        protected override string LayoutTemplateName
        {
            get
            {
                return BookInsertView.BookInsertViewTemplateName;
            }
        }

        #region Control references

        /// <summary>
        /// Gets the back button.
        /// </summary>
        /// <value>The back button.</value>
        protected virtual HyperLink BackButton
        {
            get { return base.Container.GetControl<HyperLink>("backButton", true); }
        }

        /// <summary>
        /// Gets the save button.
        /// </summary>
        /// <value>The save button.</value>
        protected virtual IButtonControl SaveButton
        {
            get { return base.Container.GetControl<IButtonControl>("saveButton1", true); }
        }

        /// <summary>
        /// Gets the cancel button.
        /// </summary>
        /// <value>The cancel button.</value>
        protected virtual IButtonControl CancelButton
        {
            get { return base.Container.GetControl<IButtonControl>("cancelButton1", true); }
        }

        #endregion

        /// <summary>
        /// Initializes all controls instantiated in the layout container. This method is called at appropriate time for setting initial values and subscribing for events of layout controls.
        /// </summary>
        /// <param name="viewContainer">The control that will host the current view.</param>
        protected override void InitializeControls(System.Web.UI.Control viewContainer)
        {
            base.InitializeControls(viewContainer);

            this.BackButton.NavigateUrl = CreateHostViewCommand<BooksListView>();
            
            this.CancelButton.Command += this.Button_Command;
            this.CancelButton.CommandName = "Cancel";

            this.SaveButton.Command += this.Button_Command;
            this.SaveButton.CommandName = "Save";

        }

        /// <summary>
        /// Handles the Command event of the Button control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Web.UI.WebControls.CommandEventArgs"/> instance containing the event data.</param>
        protected void Button_Command(object sender, CommandEventArgs e)
        {
            switch (e.CommandName)
            {
                case "Save":
                    // do saving here
                    NavigateHostCommand<BooksListView>();
                    break;
                case "Cancel":
                    NavigateHostCommand<BooksListView>();
                    break;
            }
        }

        private const string BookInsertViewTemplateName =
            "Samples.Books.Resources.ControlTemplates.Backend.BookInsertView.ascx";
    }
}
