<?php
include ("../common.php");
include ("../include/archive_function.php");
$section = "statistic";
$right_name = "view_sent";
check_right($section, $right_name);
$archive_page = isset($_REQUEST['archive_page']) ? $_REQUEST['archive_page'] : 0;
$smarty->assign("razdel", "Statistics");
$smarty->assign("description", "Sent Newslettres");
$smarty->assign("rel", getreleasesinfo($order, $archive_page));
$table = $smarty->fetch("{$admin_nl_gentemplates}/archive_sent_newsletter_statistics_print.tpl");
print $table;
print "<script language=\"Javascript\">\n           window.print()\n           </script>";
print "\n<script language=\"Javascript\">\n       window.close()\n       </script>";
?>