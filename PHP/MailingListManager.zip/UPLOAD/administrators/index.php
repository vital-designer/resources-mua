<?php
include ("../common.php");
include ("../include/administrators_function.php");
$section = "admin_groups";
$right_name = "view";
check_right($section, $right_name);
if (isset($_POST['del']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				foreach ($GLOBALS['_POST']['del'] as $val)
				{
								delgroup((integer)$val);
				}
}
if (isset($_GET['clear_id']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				$res = $dbconn->execute("DELETE FROM administrator WHERE group_id='" . (integer)$_GET['clear_id'] . "'");
}
if (isset($_GET['erase_id']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				$res = $dbconn->execute("DELETE FROM administrator WHERE group_id='" . (integer)$_GET['erase_id'] . "'");
				$res = $dbconn->execute("DELETE FROM groups WHERE group_id='" . (integer)$_GET['erase_id'] . "'");
}
if (isset($_GET['did']) && !empty($_GET['did']))
{
				$right_name = "delete";
				check_right($section, $right_name);
				delgroup((integer)$_GET['did']);
}
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "name";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
}
else
{
				$order = "";
}
$group_page = isset($_REQUEST['group_page']) ? $_REQUEST['group_page'] : 0;
$smarty->assign("razdel", "Administrators");
$smarty->assign("description", "Manage Administrator's Groups");
$smarty->assign("hint", "List of admin groups is presented here. Administrative principle is simple. You create a group, set access permissions for group system. Then you create admin and assign him to some certain group. Admin can perform actions permitted for this group only. You can create unlimited number of groups with different permissions to perform various tasks. You can create unlimited number of administrators for each group. \"Settings (General)\" is the section with allowed access for main admin only. The reason for this is that main admin login and password info of the system are changed there. ");
$GLOBALS['_SESSION']['return_url'] = "index.php";
$smarty->assign("order", $order);
$smarty->assign("rel", $rel);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("group_page", $group_page);
$smarty->assign("rel", getgroups($order, $group_page));
$smarty->display("{$admin_nl_gentemplates}/administrators_admin_groups.tpl");
?>