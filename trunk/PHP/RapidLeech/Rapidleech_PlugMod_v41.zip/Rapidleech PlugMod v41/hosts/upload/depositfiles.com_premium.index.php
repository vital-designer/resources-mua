<?php 
$upload_services[] = "depositfiles.com_premium";
$max_file_size["depositfiles.com_premium"] = 2000;
$page_upload["depositfiles.com_premium"] = "depositfiles.com_premium.php";  
?>