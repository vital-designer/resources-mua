<?
//phpFormBuilder Version 1.5 by Baris Kayar (barishkayar@yahoo.com)
//2002(cl)  The FormBuilder Group http://pfb.sourceforge.net

if (!$BaRTPFBuser || !$BaRTPFBpass || !$BaRTPFBserver) 
	{
	header("location: logon.php");
	exit();
	}
$servers		=	array();
$users			=	array();
$passes			=	array();
$servers[0]		=	$BaRTPFBserver;
$users[0]		=	$BaRTPFBuser;
$passes[0]		=	$BaRTPFBpass;
$PFBg_rowColors=Array("#99cccc","#cccccc");
//include("langtr.inc.php");
include("langen.inc.php");
if (!$PFBg_Title) $PFBg_Title="phpFormBuilder";
?>