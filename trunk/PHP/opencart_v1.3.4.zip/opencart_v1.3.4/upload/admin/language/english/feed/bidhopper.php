<?php
// Heading
$_['heading_title']    = 'BidHopper';

// Text 
$_['text_payment']     = 'Product Feeds';
$_['text_success']     = 'Success: You have modified BidHopper feed!';
$_['text_development'] = '<span style="color: red;">In Development</span>';
?>