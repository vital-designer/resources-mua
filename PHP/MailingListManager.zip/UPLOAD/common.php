<?php
function checkinstallfolder($smarty)
{
				global $config;
				$dh = opendir($config['site_path']);
				while (($entry = readdir($dh)) !== false)
				{
								if (is_dir($config['site_path'] . "/" . $entry) && (strstr($entry, "install") || strstr($entry, "instal") || strstr($entry, "inst") || strstr($entry, "distrib")))
								{
												$smarty->assign("folder", $entry);
												$smarty->assign("str", "install, instal, inst, distrib");
												$smarty->display("file:" . $config['site_path'] . $config['theme_path'] . "/install_folder_error.tpl");
												exit();
								}
				}
				closedir($dh);
				return;
}
ini_set("display_errors", "0");
error_reporting(E_ALL);
ini_set("max_execution_time", 10000);
include (dirname(__file__) . "/include/config.php");
if (substr(php_uname(), 0, 7) == "Windows")
{
				$config['system'] = "win";
}
else
{
				$config['system'] = "unix";
}
$dir = $config['site_path'];
if (strlen($dir) == 0)
{
				$dir = ".";
				$dir = dirname(__file__);
}
switch ($config['system'])
{
				case "unix":
								ini_set("include_path", ".:" . $dir . ":" . $dir . "/adodb:" . $dir . "/smarty");
								break;
				case "win":
								ini_set("include_path", ".;" . $dir . ";" . $dir . "/adodb;" . $dir . "/smarty");
}
include ("include/common_functions.php");
include ("smarty/Smarty.class.php");
include ("adodb/adodb.inc.php");
session_start();
if (!$config['host'] && !$config['dbname'] && !$config['dbhost'] && !$config['dbuname'])
{
				echo "<script>location.href='./install/index.php'</script>";
				exit();
}
$smarty = new smarty();
$smarty->force_compile = true;
$smarty->cache_lifetime = 60;
$smarty->template_dir = $config['site_path'] . "/templates";
$smarty->compile_dir = $config['site_path'] . "/templates_c";
$smarty->plugins_dir = $config['site_path'] . "/smarty/plugins";
$config['theme_path'] = "/templates";
$smarty->assign("theme_path", $config['theme_path']);
$config['default_css'] = "/css";
$smarty->assign("default_css", $config['default_css']);
$config['default_image'] = "/images";
$smarty->assign("default_image", $config['default_image']);
$smarty->assign("server", $config['server']);
$smarty->assign("site_root", $config['site_root']);
$smarty->assign("site_path", $config['site_path']);
$smarty->assign("admin_nl_gentemplates", "file:" . $config['site_path'] . $config['theme_path']);
$admin_nl_gentemplates = $config['site_path'] . $config['theme_path'];
$smarty->assign("gentemplates", "file:" . $config['site_path'] . $config['theme_path']);
$config['admin_theme_path'] = $config['site_path'] . $config['theme_path'];
if (!$smarty)
{
				exit("Smarty error");
}
if (isset($_SESSION['is_tips']))
{
				$smarty->assign("is_tips", $_SESSION['is_tips']);
}
$dbconn = &adonewconnection($config['dbtype']);
global $ADODB_FETCH_MODE;
$dbh = $dbconn->pconnect($config['dbhost'], $config['dbuname'], $config['dbpass'], $config['dbname']);
$ADODB_FETCH_MODE = ADODB_FETCH_NUM;
if ($dbh === false)
{
				error_log("error: " . $dbconn->errormsg());
}
if ((!isset($_SESSION['admin_id']) || empty($_SESSION['admin_id'])) && !isset($_GET['email1']) && !preg_match("/login\\.php/i", $_SERVER['PHP_SELF']) && !preg_match("/conf\\.php/i", $_SERVER['PHP_SELF']) && !preg_match("/form\\.php/i", $_SERVER['PHP_SELF']) && !preg_match("/uns\\.php/i", $_SERVER['PHP_SELF']) && !preg_match("/cl\\.php/i", $_SERVER['PHP_SELF']))
{
				header("Location: " . $config['server'] . "/login.php");
				exit();
}
?>
