<?php
/**
 * This file is part of Dorm and is subject to the GNU Affero General
 * Public License Version 3 (AGPLv3). You should have received a copy
 * of the GNU General Public License along with Dorm. If not, see
 * <http://www.gnu.org/licenses/>.
 *
 * @category Dorm
 * @package Dorm_DataMapper
 * @copyright Copyright (c) 2008-2009 Olivier Lalonde <olalonde@gmail.com>
 */


/**
 * Implemented for MySQL
 *
 * @see http://martinfowler.com/eaaCatalog/dataMapper.html
 * @todo Make data mappers for other RDBMS
 */
class Dorm_DataMapper_Abstract {

    /**
     * @var Dorm
     */
    private $dorm;

    /**
     * Each class has its own Data Mapper and each Data Mapper is assigned a Map
     *
     * @var Dorm_Map
     */
    private $map;

    /**
     * @param Dorm $dorm
     */
    public function __construct($dorm) {
        $this->dorm = $dorm;
    }

    /**
     * @param Dorm_Map $map
     */
    public function setMap($map) {$this->map = $map;}

    /**
     * @return Dorm_Map
     */
    public function getMap() {return $this->map;}

    /**
     * @return Dorm
     */
    public function getDorm() {return $this->dorm;}

    /**
     * @return PDO
     */
    public function getConnection() {return $this->getMap()->getConnection();}

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // LOAD
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * @param Dorm_Object $object
     * @return boolean
     */
    public function load($object) {
        $map = $this->map;
        $sql = "SELECT * FROM "
                . $map->getTable()->getName() . " WHERE "
                . Dorm_SQL::primaryKey($map->getTable()->getPrimaryKey());
        $stmt = $map->getConnection()->prepare($sql);
        Dorm_SQL::bindPrimaryKey($stmt, $object->id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        // No row with this id !
        if($row === false) return false;

        $this->populate($object, $row);
    }

    /**
     * @todo REFACTOR!!! make sure it works although fields are not named the same across tables :/.
     *       this method is really shitty at the moment
     *
     * @param Dorm_Object $object
     * @param Dorm_Map_Property $property
     */
    public function loadObjectArray($object, $property) {
        $foreign_map = $this->getDorm()->getMap($property->getForeignClass());

        $parent_table = $this->map->getTable();
        $child_table = $foreign_map->getTable();
        $pivot_table = $property->getBind(); /* @var $bind Dorm_Database_Schema_Table */

        // BUILD ORDER BY STATEMENT
        $index_string = $index_order_by_string = '';
        $index_field = $property->getKey();
        if ($index_field !== null) {
            $index_string = ",pivot.{$index_field} AS dorm_pointer";
            $index_order_by_string = " ORDER BY pivot.{$index_field}  ";
        }

        // BUILD ON STATEMENT
        // TODO : in case pivot table's field names arent the same as foreign table field names...
        $fkeys = $this->guessParentAndChildFkeys($object, $property);
        $parent_fkey = $fkeys['parent'];
        $child_fkey = $fkeys['child'];

        $foreign_fields = $child_fkey->getForeignFields();
        $on_string_child = $sep = '';
        foreach ($child_fkey->getLocalFields() as $index => $local_field) {
            $foreign_field = $foreign_fields[$index];
            $on_string_child .= $sep . 'child.' . $foreign_field->getName()
                . ' = pivot.' . $local_field->getName();
            $sep = ' AND ';
        }

        $where_array = array();

        // BUILD WHERE
        $foreign_fields = $parent_fkey->getForeignFields();
        $where_string = $sep = '';
        foreach ($parent_fkey->getLocalFields() as $index => $local_field) {
            $foreign_field = $foreign_fields[$index];
            $where_string .= $sep . 'pivot.' . $local_field->getName()
                . '=:' . $foreign_field->getName();

            $where_array[$foreign_field->getName()] = $object->id[$foreign_field->getName()];
            $sep = ' AND ';
        }

        $sql = "SELECT child.* {$index_string}
            FROM {$child_table->getName()} child
            RIGHT JOIN {$pivot_table->getName()} pivot ON {$on_string_child}
            WHERE {$where_string}
            {$index_order_by_string}";

        $stmt = $this->getConnection()->prepare($sql);
        Dorm_SQL::bindArray($stmt, $where_array);
        $stmt->execute();
        $foreign_class = $property->getForeignClass();
        $property_name = $property->getName();
        $array = array();

        // to do.. better way to find ID and data mapper
        $data_mapper = $this->getDorm()->getDataMapper($foreign_class);
        $map = $data_mapper->getMap();
        $pk_fields = $map->getTable()->getPrimaryKey()->getFields();

        $index = null;
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC, PDO::FETCH_ORI_NEXT)) {
            if (isset($row['dorm_pointer'])) {
                $index = $row['dorm_pointer'];
                //if (is_numeric($index)) $index = (int)$index;
            }

            // Extract ID from row
            $id = $child_table->getPrimaryKey()->getIdFromRow($row);

            $foreign_object = $this->getDorm()->getDormObject($foreign_class, $id);

            // Object is not cached
            if ($foreign_object->isNotLoaded()) {
                $data_mapper->populate($foreign_object, $row);
            }

            if (isset($index)) $array[$index] = $foreign_object->_;
            else $array[] = $foreign_object->_;
        }
        $property->setValue($object, $array);
    }

    /**
     * @param Dorm_Object $object
     * @param array $array
     */
    public function populate($object, $array) {
        $properties = $this->map->getProperties();

        // Loop for all object properties and for each property see if the value is in the array
        foreach ($properties as $property) {
            $bind = $property->getBind();

            // SCALARs (fields)
            if ($property->isScalar()) { /* @var $bind Dorm_Database_Schema_Field */
                $property->setValue($object, $array[$bind->getName()]);
            }
            // OBJECTs (fkeys)
            elseif ($property->isObject()) { /* @var $bind Dorm_Database_Schema_ForeignKey */
                $foreign_id = array(); // foreign id
                $local_fields = $bind->getLocalFields();
                foreach ($local_fields as $index => $local_field) {
                    $value = $array[$local_field->getName()];
                    if ($value !== null) $foreign_id[] = $value;
                }

                // Foreign key is null... no foreign object
                if (!isset($foreign_id[0])) continue;

                $foreign_class = $property->getForeignClass();

                $foreign_object = $this->getDorm()->getDormObject($foreign_class, $foreign_id);
                if($foreign_object->isLoaded()) {
                    // If object is already loaded
                    $property->setValue($object, $foreign_object->_);
                }
                else {
                    // Object is not loaded.
                    // Put placeholder so we can lazyload !
                    $place_holder = new Dorm_Placeholder_Object(
                        $this->getDorm(),
                        $object,
                        $property,
                        $foreign_object
                    );
                    $property->setValue($object, $place_holder);
                }
            }
            // OBJECT ARRAYs (many to many relationships / pivot tables)
            elseif ($property->isObjectArray()) {
                // Put placeholder so we can lazyload !
                $place_holder = new Dorm_Placeholder_ObjectArray(
                    $this->getDorm(),
                    $object,
                    $property
                );
                $property->setValue($object, $place_holder);
            }
        }
    }

    /**
     * @param string $where
     * @param string $where_values
     * @param string $order
     * @param string $limit
     * @return array
     */
    public function loadCollection($where, $where_values, $order, $limit) {
        $map = $this->getMap();
        $sql = 'SELECT * FROM ' . $map->getTable()->getName();

        if (isset($where) && isset($where_values)) $sql .= ' WHERE ' . $where;

        if (isset($order)) $sql .= ' ORDER BY ' . $order;
        if (isset($limit)) $sql .= ' LIMIT ' . $limit;

        $stmt = $map->getConnection()->prepare($sql);

        if (isset($where) && isset($where_values)) {
            foreach ($where_values as $key => $value) {
                $stmt->bindValue(':' . $key, $value);
            }
        }

        if ($stmt->execute() === false)
            throw new Exception('SQL statement is invalid.');

        $stmt->setFetchMode(PDO::FETCH_ASSOC);

        $collection = array();

        $class = $this->getMap()->getClassName();
        while($row = $stmt->fetch()){
            $id = $this->getMap()->getTable()->getPrimaryKey()->getIdFromRow($row);

            $object = $this->getDorm()->getDormObject($class, $id);
            $this->populate($object, $row);
            $collection[] = $object->_;
        }

        if (count($collection) == 0) $collection = null;
        return $collection;
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // INSERT
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * @param Dorm_Object $object
     */
    public function insert($object) {
        // foreign objects first so we know the foreign key to insert in local table
        $this->insertObjects($object);

        $this->insertScalars($object);

        $this->insertObjectArrays($object);
    }

    /**
     * @param Dorm_Object $object
     * @todo better way to retrieve ID
     */
    public function insertScalars($object) {
        $map = $this->getMap(); /* @var $map Dorm_Map */
        $pdo = $map->getConnection();
        $table_name = $map->getTable()->getName();

        $id = array();

        $sql = "INSERT INTO {$table_name} SET ";
        $sep = "";
        $insert_fields = array();
        $insert_fkeys = array();

        // SCALARS
        foreach ($map->getProperties() as $property) {
            if (!$property->isScalar()) continue;

            $field = $property->getBind();
            /* @var $field Dorm_Database_Schema_Field */

            $field_name = $field->getName();
            $property_name = $property->getName();

            $insert_fields[$field_name] = $property;

            $sql .= $sep . "{$field_name}=:{$field_name}";
            $sep = ", ";
        }

        // OBJECTS
        foreach ($map->getProperties() as $property) {
            if (!$property->isObject()) continue;

            $fkey = $property->getBind();
            /* @var $fkey Dorm_Database_Schema_ForeignKey */

            $foreign_domain_object = null;
            $foreign_domain_object = $property->getValue($object);

            if (!isset($foreign_domain_object)) continue;

            $foreign_object = $this->getDorm()->getDormObject($foreign_domain_object);

            $foreign_id = $foreign_object->id;

            $local_fields = $fkey->getLocalFields();
            $foreign_fields = $fkey->getForeignFields();

            foreach ($local_fields as $key => $local_field) {
                $local_field_name = $local_field->getName();
                $sql .= ",{$local_field_name}=:{$local_field_name}";

                $insert_fkeys[$local_field_name] = $foreign_id[$foreign_fields[$key]->getName()];
            }
        }
        $stmt = $pdo->prepare($sql);

        $pkey = $map->getTable()->getPrimaryKey()->getFields();

        foreach ($insert_fields as $field_name => $property) {

            $value = $property->getValue($object);

            if (in_array($field_name, $pkey)) {
                $id[$field_name] = $value;
            }

            $stmt->bindValue(":{$field_name}", $value);
        }
        foreach ($insert_fkeys as $field_name => $value) {
            $stmt->bindValue(":{$field_name}", $value);
        }

        $stmt->execute();

        // GET AUTOINCREMENT IF WE DONT KNOW ID YET... @todo better
        if (count($id) == 0) {
            $id = $pdo->lastInsertId();
            $id = array($pkey[0] => $id);
        }

        $object->setId($id);
    }

    /**
     * @param Dorm_Object $object
     */
    private function insertObjects($object) {
        $map = $this->getMap(); /* @var $map Dorm_Map */
        $pdo = $map->getConnection();

        foreach ($map->getProperties() as $property) {
            if (!$property->isObject()) continue;

            $foreign_object = $property->getValue($object);

            if (!is_object($foreign_object)) continue;

            $this->getDorm()->save($foreign_object);
        }
    }

    /**
     * @param Dorm_Object $object
     * @param Dorm_Map_Property $property
     * @return array array('child' => $child_fkey, 'parent' => $parent_fkey)
     */
    private function guessParentAndChildFkeys($object, $property) {
        /* @var $property Dorm_Map_Property */

        $pivot_table = $property->getBind();
        /* @var $pivot_table Dorm_Database_Schema_Table */
        $parent_table = $this->getMap()->getTable();
        /* @var $parent_table Dorm_Database_Schema_Table */
        $child_table = $this->getDorm()->getMap($property->getForeignClass())->getTable();
        /* @var $child_table Dorm_Database_Schema_Table */

        // Find parent fkey
        $fkeys = $pivot_table->getForeignKeys();
        if ($parent_fkey_name = $property->getParentFkeyName()) {
            $parent_fkey = $pivot_table->getForeignKey($parent_fkey_name);
        }

        // FIND WHICH PIVOT TABLE'S FKEYs ARE ASSOCIATED WITH PARENT AND CHILD
        if (isset($parent_fkey)) {
            foreach ($fkeys as $key => $fkey)
                if ($fkey !== $parent_fkey)
                    $child_fkey = $fkey;
        }
        else {
            foreach ($fkeys as $key => $fkey) {
                $foreign_field = $fkey->getForeignFields();
                $foreign_field = $foreign_field[0];
                if (in_array($foreign_field, $parent_table->getFields())
                    && !isset($parent_fkey))
                    $parent_fkey = $fkey;
                if (in_array($foreign_field, $child_table->getFields())
                    && !isset($child_fkey))
                    $child_fkey = $fkey;
            }
        }

        /* @var $parent_fkey Dorm_Database_Schema_ForeignKey */
        /* @var $child_fkey Dorm_Database_Schema_ForeignKey */

        return array('parent' => $parent_fkey, 'child' => $child_fkey);
    }

    /**
     * @param Dorm_Object $object
     * @todo performance could be greatly improved if we make associations in one statement
     */
    private function insertObjectArrays($object) {
        foreach ($this->getMap()->getProperties() as $property) {
            /* @var $property Dorm_Map_Property */
            if (!$property->isObjectArray()) continue;
            $this->insertObjectArray($object, $property);
        }
    }

    private function insertObjectArray($object, $property) {
        $array = $property->getValue($object);

        if (!is_array($array)) return;

        $arr = $this->guessParentAndChildFkeys($object, $property);
        $parent_fkey = $arr['parent'];
        $child_fkey = $arr['child'];

        $pivot_table = $property->getBind();
        /* @var $pivot_table Dorm_Database_Schema_Table */
        $parent_table = $this->getMap()->getTable();
        /* @var $parent_table Dorm_Database_Schema_Table */
        $child_table = $this->getDorm()->getMap($property->getForeignClass())->getTable();
        /* @var $child_table Dorm_Database_Schema_Table */

        /* @var $parent_fkey Dorm_Database_Schema_ForeignKey */
        /* @var $child_fkey Dorm_Database_Schema_ForeignKey */

        // FOR EACH ARRAY ELEMENT, SAVE IT AND CREATE ASSOCIATION
        foreach ($array as $key => $foreign_domain_object) {
            // Save foreign object
            $this->getDorm()->save($foreign_domain_object);
            $foreign_object = $this->getDorm()->getDormObject($foreign_domain_object);

            $insert = array();

            // LINK OBJECTS TOGETHER IN PIVOT TABLE

            $sql = 'INSERT INTO ' . $pivot_table->getName() . ' SET ';

            // parent
            $foreign_fields = $parent_fkey->getForeignFields();
            $local_fields = $parent_fkey->getLocalFields();
            foreach ($foreign_fields as $index => $foreign_field) {
                $local_field = $local_fields[$index];
                $insert[$local_field->getName()] = $object->id[$foreign_field->getName()];
                $sql .= '' . $local_field->getName() . '=:' . $local_field->getName() . ',';
            }

            // child
            $foreign_fields = $child_fkey->getForeignFields();
            $local_fields = $child_fkey->getLocalFields();
            foreach ($foreign_fields as $index => $foreign_field) {
                $local_field = $local_fields[$index];
                $insert[$local_field->getName()] = $foreign_object->id[$foreign_field->getName()];
                $sql .= '' . $local_field->getName() . '=:' . $local_field->getName() . ',';
            }

            $sql = substr($sql, 0, -1); // strip trailing ,

            if ($key_field = $property->getKey()) {
                $insert[$key_field] = $key;
                $sql .= ',' . $key_field . '=:' . $key_field;
            }

            $pdo = $this->getMap($object)->getConnection();

            $stmt = $pdo->prepare($sql);

            Dorm_SQL::bindArray($stmt, $insert);

            $stmt->execute();
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    // UPDATE
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * @param Dorm_Object $object
     */
    public function update($object) {
        $this->updateObjects($object);
        $this->updateScalars($object);
        $this->updateObjectArrays($object);
    }

    /**
     * @param Dorm_Object $object
     */
    private function updateObjects($object) {
        $map = $this->getMap();
        foreach ($map->getProperties() as $property) {
            if (!$property->isObject()) continue;

            $foreign_domain_object = $property->getValue($object);

            if (!is_object($foreign_domain_object)) continue;

            $this->getDorm()->save($foreign_domain_object);
        }
    }

    /**
     * @param Dorm_Object $object
     */
    private function updateScalars($object) {
        $map = $this->getMap(); /* @var $map Dorm_Map */
        $pdo = $map->getConnection();
        $table_name = $map->getTable()->getName();
        $id = $object->id;

        $sql = "UPDATE {$table_name} SET ";
        $sep = "";
        $fields = array();

        foreach ($map->getProperties() as $property) {
            if($property->isScalar()) {
                $field = $property->getBind();
                /* @var $field Dorm_Database_Schema_Field */

                $field_name = $field->getName();
                $property_name = $property->getName();

                $fields[$field_name] = $property->getValue($object);

                $sql .= $sep . "{$field_name}=:{$field_name}";
                $sep = ", ";
            }
            elseif($property->isObject()) {
                $fkey = $property->getBind();
                /* @var $fkey Dorm_Database_Schema_ForeignKey */
                unset($foreign_domain_object);
                $foreign_domain_object = $property->getValue($object);
                if (!is_object($foreign_domain_object)) continue;

                $foreign_object = $this->getDorm()->getDormObject($foreign_domain_object);
                $foreign_id = $foreign_object->id;

                $local_fields = $fkey->getLocalFields();
                $foreign_fields = $fkey->getForeignFields();

                foreach ($local_fields as $key => $local_field) {
                    $local_field_name = $local_field->getName();
                    $sql .= ",{$local_field_name}=:{$local_field_name}";

                    $foreign_field_name = $foreign_fields[$key]->getName();

                    $fields[$local_field_name] = $foreign_id[$foreign_field_name];
                }
                $sql .= $sep . "{$field_name}=:{$field_name}";
                $sep = ", ";
            }
        }

        $sql .= " WHERE " . Dorm_SQL::primaryKey($map->getTable()->getPrimaryKey());

        $stmt = $pdo->prepare($sql);

        Dorm_SQL::bindPrimaryKey($stmt, $id);

        foreach ($fields as $field_name => $value) {
            $stmt->bindValue(":{$field_name}", $value);
        }

        $stmt->execute();
    }


    /**
     * @param Dorm_Object $object
     */
    private function updateObjectArrays($object) {
        $id = $object->id;

        foreach ($this->getMap()->getProperties() as $property) {
            if (!$property->isObjectArray()) continue;

            $pivot_table = $property->getBind();
            /* @var $pivot_table Dorm_Database_Schema_Table */

            $array = $property->getValue($object);
            if (!is_array($array)) continue;

            $fkeys = $this->guessParentAndChildFkeys($object, $property);
            $parent_fkey = $fkeys['parent'];
            $child_fkey = $fkeys['child'];

            ///// DELETE OLD ASSOCIATIONS FROM PIVOT TABLE /////
            $sql = "DELETE FROM " . $pivot_table->getName() . " WHERE ";

            $sep = "";
            $fields = array();
            $foreign_fields = $parent_fkey->getForeignFields();
            foreach ($parent_fkey->getLocalFields() as $key => $local_field) {
                $foreign_field = $foreign_fields[$key];
                $sql .= $sep . $local_field->getName() . '=:' . $local_field->getName();
                $fields[$local_field->getName()] = $object->id[$foreign_field->getName()];
                $sep = " AND ";
            }

            $stmt = $this->getMap()->getConnection()->prepare($sql);

            Dorm_SQL::bindArray($stmt, $fields);

            $stmt->execute();

            $this->insertObjectArray($object, $property);
        }
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////
    // DELETE
    ///////////////////////////////////////////////////////////////////////////////////////////////
    /**
     * @todo Delete pivot table associations
     *
     * @param Dorm_Object $object
     */
    public function delete($object) {
        $map = $this->getMap();
        $id = $object->id;
        $sql = "DELETE FROM " . $map->getTable()->getName()
            . " WHERE " . Dorm_SQL::primaryKey($map->getTable()->getPrimaryKey());
        $stmt = $map->getConnection()->prepare($sql);
        Dorm_SQL::bindPrimaryKey($stmt, $id);
        $stmt->execute();
    }

}