<?php
include ("common.php");
if (isset($_SESSION['is_del']) && $_SESSION['is_del'] == 1)
{
				unlink($config['site_path'] . $_REQUEST['file']);
				$smarty->assign("path", $config['site_path']);
				$smarty->assign("file_name", $_REQUEST['file']);
				$smarty->assign("description", "Report");
				$smarty->assign("hint", "Please, read it.");
				$smarty->display("{$admin_nl_gentemplates}/del_file.tpl");
}
else
{
				header("Location: login.php");
}
?>