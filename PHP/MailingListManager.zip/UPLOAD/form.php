<?php
function parseconfirmation($uid, $text, $formid)
{
				global $dbconn;
				global $config;
				$rs = $dbconn->execute("SELECT email1 FROM snd_users WHERE id='" . $uid . "'");
				$row = $rs->getrowassoc(false);
				$text = preg_replace("/\\%CONFIRMLINK\\%/i", $config['server'] . "/conf.php?e=" . md5($row['email1']) . "&f=" . $formid, $text);
				return $text;
}
include ("common.php");
include ("./include/newsletters_function.php");
include ("./include/class.form.php");
ini_set("display_errors", "0");
$errors = array();
if (!isset($_GET['id']))
{
				exit("Form ID not set!");
}
$form_id = (integer)$_GET['id'];
$res = $dbconn->execute("SELECT * FROM form WHERE id='{$form_id}'");
$form_data = $res->getrowassoc(false);
$name = isset($_POST['name']) ? strip_tags($_POST['name']) : "";
$surname = isset($_POST['surname']) ? strip_tags($_POST['surname']) : "";
$email = isset($_POST['email']) ? strip_tags($_POST['email']) : "";
$res = $dbconn->execute("SELECT * FROM settings");
$settings = $res->getrowassoc(false);
if ($form_data['type'] == "sub")
{
				$form_class = new form($dbconn, $config);
				$attrs = array();
				$data = $_POST;
				foreach ($data as $key => $value)
				{
								$arr = array();
								if (preg_match("/^attr_(\\d*)/", $key, $arr) == 0)
								{
								}
								else
								{
												$id_attr = $arr[1];
												$sec_attrs[$id_attr] = $form_class->getsectionattribute($id_attr);
												unset($data[$key]);
												if (is_array($value) && $sec_attrs[$id_attr]['control_type'] == "select")
												{
																$temp = array();
																foreach ($value as $i => $v)
																{
																				$temp[$v] = $v;
																}
																$data[$id_attr] = $temp;
												}
												else
												{
																$data[$id_attr] = $value;
												}
												$attrs[$id_attr] = $value;
								}
				}
				$form_fields = $form_class->getformattributes($form_id);
				foreach ($form_fields as $form_field)
				{
								if ($form_field['control_type'] == "checkbox")
								{
												$keys = array_keys($attrs);
												if (!in_array($form_field['id'], $keys))
												{
																$attrs[$form_field['id']] = 0;
												}
												$sec_attrs[$form_field['id']] = $form_class->getsectionattribute($form_field['id']);
								}
				}
				$regs = $form_class->getregexps();
				foreach ($sec_attrs as $index => $field)
				{
								if (isset($field['setup']['reg_exp']))
								{
												$id_reg = $sec_attrs[$index]['setup']['reg_exp'];
												$sec_attrs[$index]['setup']['reg_exp'] = $regs[$id_reg]['reg_exp'];
								}
				}
				$err = "";
				$valid = true;
				foreach ($attrs as $id_attr => $value)
				{
								if ($sec_attrs[$id_attr]['mandatory'] == "Y" && ($value == "" || !isset($value)))
								{
												$valid = false;
												$err .= "<br>" . $sec_attrs[$id_attr]['field_name'];
								}
								if (isset($sec_attrs[$id_attr]['setup']['reg_exp']))
								{
												$pattern = $sec_attrs[$id_attr]['setup']['reg_exp'];
												if (preg_match($pattern, $value) == 0)
												{
																$valid = false;
																$err .= "<br>" . $sec_attrs[$id_attr]['field_name'];
												}
								}
				}
				if (isset($attrs[FIELD_MAILLIST]))
				{
								foreach ($attrs[FIELD_MAILLIST] as $id_list)
								{
												if (!isset($_POST['SelectLists'][$id_list]))
												{
																$GLOBALS['_POST']['SelectLists'][$id_list] = "YES";
												}
								}
				}
				if (empty($name))
				{
								$errors[1] = "Name is empty";
				}
				if (empty($surname))
				{
								$errors[2] = "Last name is empty";
				}
				if (empty($email))
				{
								$errors[4] = "Email is empty";
				}
				else
								if (!preg_match("/^([a-zA-Z0-9])+([\\.a-zA-Z0-9_-])*@([a-zA-Z0-9_-])+(\\.[a-zA-Z0-9_-]+)+/", $email))
								{
												$errors[4] = "Incorrect email";
								}
								else
								{
												$rs = $dbconn->execute("SELECT id FROM snd_users WHERE email1='{$email}'");
												$arr_list = array();
												$action_user = "insert";
												if ($rs->rowcount())
												{
																foreach ($GLOBALS['_POST']['SelectLists'] as $key => $value)
																{
																				$rs = $dbconn->execute("SELECT * FROM clients_lists WHERE client_id='{$rs->fields[0]}' AND list_id='{$key}'");
																				if ($rs->rowcount())
																				{
																								unset($rs->rowcount[$key]);
																				}
																}
																$action_user = "update";
												}
												else
												{
																$action_user = "insert";
												}
								}
								if ($form_data['captcha'] == 1 && $_SESSION['captcha_keystring'] != $_POST['captcha'])
								{
												$errors[5] = "The value you inputed and the image code don`t match";
								}
				if (!$valid)
				{
								$errors[6] = $err;
				}
				if (!empty($errors))
				{
								$smarty->assign("name", $name);
								$smarty->assign("surname", $surname);
								$smarty->assign("company", $company);
								$smarty->assign("email", $email);
								$smarty->assign("errors", $errors);
								$smarty->assign("form_data", $form_data);
								$lists = array();
								$rs = $dbconn->execute("SELECT list_id FROM forms_lists WHERE form_id='" . $form_id . "'");
								while (!$rs->EOF)
								{
												$lists[] = $rs->fields[0];
												$rs->movenext();
								}
								$smarty->assign("lists", $lists);
								$res = $dbconn->execute("SELECT * FROM form WHERE id='" . $form_id . "'");
								$row = $res->getrowassoc(false);
								$fields = $form_class->getformattributes($_GET['id']);
								$regs = $form_class->getregexps();
								foreach ($fields as $index => $field)
								{
												if (isset($field['setup']['reg_exp']))
												{
																$id_reg = $fields[$index]['setup']['reg_exp'];
																$fields[$index]['setup']['reg_exp'] = $regs[$id_reg]['reg_exp'];
												}
								}
								$smarty->assign("fields", $fields);
								$smarty->assign("regs", $regs);
								$smarty->assign("user_data", $attrs);
								$smarty->display("{$admin_nl_gentemplates}/forms_subscribe_form.tpl");
								exit();
				}
				$company = isset($attrs[FIELD_COMPANY]) ? strip_tags($attrs[FIELD_COMPANY]) : "";
				unset($attrs[FIELD_COMPANY]);
				if ($action_user == "insert")
				{
								$rs = $dbconn->execute("INSERT INTO snd_users (date, email1, firstname, secondname, company) " . "VALUES (NOW(), '{$email}', '{$name}', '{$surname}', '{$company}')");
								$uid = $dbconn->insert_id();
				}
				else
								if ($action_user == "update")
								{
												$rs = $dbconn->execute("SELECT id FROM snd_users WHERE email1='{$email}'");
												$uid = $rs->fields[0];
								}
				$form_class->saveuserattributes($uid, $attrs);
				$status_subscribe = $config['status_subscribe_val']['subscribe'];
				if ($form_data['confirmation'] == "1")
				{
								$status_subscribe = $config['status_subscribe_val']['unconf_sub'];
								emailtext($email, $form_data['confirmation_subject'], parseconfirmation($uid, stripslashes($form_data['confirmation_email']), $form_id), $form_data['from_name'], $form_data['from_email']);
				}
				foreach ($GLOBALS['_POST']['SelectLists'] as $key => $value)
				{
								$rs = $dbconn->execute("SELECT * FROM clients_lists WHERE client_id='{$uid}' AND list_id='{$key}'");
								if (!$rs->rowcount())
								{
												$rs = $dbconn->execute("INSERT INTO clients_lists VALUES ('" . $uid . "','" . $key . "', '" . $status_subscribe . "',NOW())");
								}
								$rs = $dbconn->execute("SELECT * FROM list WHERE id='" . $key . "'");
								$row_list = $rs->getrowassoc();
								if (0 < $row_list['RELEASE_SUB_ID'])
								{
												sendreleasetouser($row_list['RELEASE_SUB_ID'], $uid, $key);
								}
								if ($row_list['NOTIFY_ADD'])
								{
												$message = "First Name: " . $name . "<br>\r\n\t\t\tLast Name: " . $surname . "<br>\r\n\t\t\tEmail: " . $email . "<br>\r\n\t\t\tCompany: " . $company;
												emailtext($row_list['OWNER_EMAIL'], "List " . $row_list['NAME'] . ": user subscribe", $message, $settings['from_name'], $settings['from_email']);
								}
				}
				if ($form_data['confirmation'] == "1")
				{
								if (!empty($form_data['confirmation_url']) && $form_data['confirmation_url'] !== "http://")
								{
												header("Location: " . $form_data['confirmation_url']);
												exit();
								}
								else
								{
												exit(parseconfirmation($uid, stripslashes($form_data['confirmation_text']), $form_id));
								}
				}
				if ($form_data['thankyou'] == "1")
				{
								emailtext($email, $form_data['thankyou_subject'], parseconfirmation($uid, stripslashes($form_data['thankyou_email']), $form_id), $form_data['from_name'], $form_data['from_email']);
				}
				if (!empty($form_data['thankyou_url']) && $form_data['thankyou_url'] !== "http://")
				{
								header("Location: " . $form_data['thankyou_url']);
								exit();
				}
				else
				{
								exit(parseconfirmation($uid, stripslashes($form_data['thankyou_text']), $form_id));
				}
				$smarty->display("{$admin_nl_gentemplates}/subscription.tpl");
}
else
{
				$rs = $dbconn->execute("SELECT id FROM snd_users WHERE email1='" . addslashes($email) . "'");
				if (!$rs->rowcount())
				{
								exit("Error: Unknown email");
				}
				$uid = $rs->fields[0];
				if ($form_data['confirmation'] == "1")
				{
								$rs = $dbconn->execute("UPDATE clients_lists SET status_subscribe='" . $config['status_subscribe_val']['unconf_unsub'] . "', date_status=NOW() " . "WHERE client_id='" . $uid . "'");
								emailtext($email, $form_data['confirmation_subject'], parseconfirmation($uid, stripslashes($form_data['confirmation_email']), $form_id), $form_data['from_name'], $form_data['from_email']);
								if (!empty($form_data['confirmation_url']) && $form_data['confirmation_url'] !== "http://")
								{
												header("Location: " . $form_data['confirmation_url']);
												exit();
								}
								else
								{
												exit(parseconfirmation($uid, stripslashes($form_data['confirmation_text']), $form_id));
								}
				}
				else
				{
								foreach ($GLOBALS['_POST']['SelectLists'] as $key => $value)
								{
												$rs = $dbconn->execute("SELECT * FROM list WHERE id='" . $key . "'");
												$row_list = $rs->getrowassoc();
												if (0 < $row_list['RELEASE_UNSUB_ID'])
												{
																sendreleasetouser($row_list['RELEASE_UNSUB_ID'], $uid, $key);
												}
												if ($row_list['NOTIFY_UNSUB'])
												{
																$rs = $dbconn->execute("SELECT * FROM snd_users WHERE id='" . $uid . "'");
																$row_user = $rs->getrowassoc();
																$message = "First Name: " . $row_user['FIRSTNAME'] . "<br>\r\n\t\t\t\tLast Name: " . $row_user['SECONDNAME'] . "<br>\r\n\t\t\t\tEmail: " . $row_user['EMAIL1'] . "<br>\r\n\t\t\t\tCompany: " . $row_user['COMPANY'];
																emailtext($row_list['OWNER_EMAIL'], "List " . $row_list['NAME'] . ": user unsubscribe", $message, $settings['from_name'], $settings['from_email']);
												}
												$rs = $dbconn->execute("DELETE FROM clients_lists WHERE client_id='" . $uid . "' AND list_id='" . $key . "'");
								}
				}
				if ($form_data['thankyou'] == "1")
				{
								emailtext($email, $form_data['thankyou_subject'], parseconfirmation($uid, stripslashes($form_data['thankyou_email']), $form_id), $form_data['from_name'], $form_data['from_email']);
				}
				if (!empty($form_data['thankyou_url']) && $form_data['thankyou_url'] !== "http://")
				{
								header("Location: " . $form_data['thankyou_url']);
								exit();
				}
				else
				{
								exit(parseconfirmation($uid, stripslashes($form_data['thankyou_text']), $form_id));
				}
				$smarty->display("{$admin_nl_gentemplates}/unsubscription.tpl");
}
?>
