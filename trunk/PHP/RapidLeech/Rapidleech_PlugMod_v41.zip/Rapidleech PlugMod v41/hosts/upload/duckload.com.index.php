<?php 
$upload_services[]="duckload.com";
$max_file_size["duckload.com"]=800;
$page_upload["duckload.com"] = "duckload.com.php";
?>