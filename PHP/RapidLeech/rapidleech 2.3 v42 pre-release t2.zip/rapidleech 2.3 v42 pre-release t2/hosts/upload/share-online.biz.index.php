<?
$upload_services[]="share-online.biz";
$max_file_size["share-online.biz"]=300;
$page_upload["share-online.biz"] = "share-online.biz.php";
?>