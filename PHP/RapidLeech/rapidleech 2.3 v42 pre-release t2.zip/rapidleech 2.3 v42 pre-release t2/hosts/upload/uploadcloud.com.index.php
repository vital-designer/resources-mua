<?php
$upload_services[]="uploadcloud.com";
$max_file_size["uploadcloud.com"]=100;
$page_upload["uploadcloud.com"] = "uploadcloud.com.php";  
?>