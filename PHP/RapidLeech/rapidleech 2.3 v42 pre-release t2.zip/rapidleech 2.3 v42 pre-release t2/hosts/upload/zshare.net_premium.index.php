<?php
$upload_services[]="zshare.net_premium";
$max_file_size["zshare.net_premium"]=1024;
$page_upload["zshare.net_premium"] = "zshare.net_premium.php";
?>