<?php
$config['server'] = "http://" . $_SERVER['HTTP_HOST'];
$config['site_root'] = "/affiliates/admin";
$config['site_path'] = "/home/wsbrasil/public_html";
$dir = $_SERVER['DOCUMENT_ROOT'] . "/affiliates";
$dir2 = "/home/wsbrasil/public_html/affiliates/admin";
$config['dbtype'] = "mysql";
$config['useoledb'] = 0;
$config['dbhost'] = "localhost";
$config['dbuname'] = "wsbrasil_user";
$config['dbpass'] = "banana";
$config['dbname'] = "wsbrasil_t";
?>
