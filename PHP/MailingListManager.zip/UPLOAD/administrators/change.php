<?php
include ("../common.php");
include ("../include/administrators_function.php");
$section = "admin_groups";
$g = 0;
$r = 0;
foreach ($group_right as $key => $val)
{
				$groups[$g]['section'] = $key;
				foreach ($val as $k => $v)
				{
								$groups[$g][$k] = $v;
				}
				++$g;
}
foreach ($right as $key1 => $val1)
{
				$r = 0;
				foreach ($val1 as $k2 => $v2)
				{
								foreach ($v2 as $k3 => $v3)
								{
												$rights[$r][$key1][$k3] = $v3;
												$rights[0][$key1]['amount'] = $r;
								}
								++$r;
				}
}
$k = 0;
$i = 0;
for (; $i < $g; ++$i)
{
				$res[$i]['name'] = $groups[$i]['name'];
				$res[$i]['code'] = $groups[$i]['code'];
				$j = 0;
				for (; $j <= $rights[0][$groups[$i]['section']]['amount']; ++$j)
				{
								$right_res[$k]['right'] = $rights[$j][$groups[$i]['section']]['name'];
								$right_res[$k]['key'] = $groups[$i]['code'];
								$right_res[$k]['id'] = $rights[$j][$groups[$i]['section']]['code'];
								++$k;
				}
}
$smarty->assign("res", $res);
$smarty->assign("right_res", $right_res);
if (isset($_GET['id']))
{
				if (!isset($_POST['action']) || $_POST['action'] != "change")
				{
								if ($_GET['id'] == 0)
								{
												$right_name = "create";
												check_right($section, $right_name);
												$smarty->assign("razdel", "Administrators");
												$smarty->assign("description", "New Administrator's Group");
												$smarty->assign("hint", "Complete the form and click \"Save\" button to create a new adminstrator's group.");
												$content = getblankcontent();
								}
								else
								{
												$right_name = "view_item";
												check_right($section, $right_name);
												$smarty->assign("razdel", "Administrators");
												$smarty->assign("description", "Administrator's Group Editing");
												$smarty->assign("hint", "Enter group name, group creating purpose summary and tick actions that group members will be able to perform.");
												$content = getcontent((integer)$_GET['id']);
								}
								$smarty->assign("rel", $content);
								$smarty->display("{$admin_nl_gentemplates}/administrators_change_admin_group.tpl");
				}
				else
				{
								if ($_GET['id'] == 0 || $_GET['id'] == "0")
								{
												if (isset($_POST['action']) && $_POST['action'] == "change")
												{
																$right_name = "create";
																check_right($section, $right_name);
																addgroup();
												}
								}
								else
								{
												$right_name = "edit";
												check_right($section, $right_name);
												updgroup();
								}
								header("Location: index.php");
				}
}
else
{
				header("Location: index.php");
}
?>