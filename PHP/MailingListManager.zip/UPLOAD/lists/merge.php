<?php
include ("../common.php");
include ("../include/lists_function.php");
$section = "lists";
$right_name = "create";
check_right($section, $right_name);
if (isset($_POST['action']) && $_POST['action'] == "change")
{
				mergelist($_POST);
				header("Location: index.php");
}
$res = $dbconn->execute("SELECT id, subject, date, format FROM creleases WHERE is_sent='0'");
while (!$res->EOF)
{
				$values[] = stripslashes($res->fields[0]);
				$output[] = stripslashes($res->fields[1]) . " (" . $res->fields[3] . " - " . $res->fields[2] . ")";
				$res->movenext();
}
$smarty->assign(array("newsletters_values" => $values, "newsletters_output" => $output));
$values = array();
$output = array();
$res = $dbconn->execute("SELECT id, subject, date, format FROM creleases WHERE is_sent<>'0'");
while (!$res->EOF)
{
				$values[] = stripslashes($res->fields[0]);
				$output[] = stripslashes($res->fields[1]) . " (" . $res->fields[3] . " - " . $res->fields[2] . ")";
				$res->movenext();
}
$smarty->assign(array("newsletters_sent_values" => $values, "newsletters_sent_output" => $output));
$smarty->assign("razdel", "Mailing Lists");
$smarty->assign("description", "Merge Mailing List");
$smarty->assign("hint", "Complete the form  and click \"Merge\" button to merge a mailing lists.");
$content = getblankcontent();
if (!isset($_SESSION['desc']))
{
				$GLOBALS['_SESSION']['desc'] = false;
				$GLOBALS['_SESSION']['order'] = "date";
}
if (isset($_GET['order']))
{
				$order = $_GET['order'];
				$GLOBALS['_SESSION']['order'] = $order;
} else
{
				$order = "";
}
$list_page = isset($_REQUEST['list_page']) ? $_REQUEST['list_page'] : 0;
$GLOBALS['_SESSION']['return_url'] = "index.php";
$smarty->assign("order", $order);
$smarty->assign("is_desc", $_SESSION['is_desc']);
$smarty->assign("list_page", $list_page);
$smarty->assign("rel", getlists($order, $list_page));
$smarty->assign("rel_1", $content);
$smarty->display("{$admin_nl_gentemplates}/lists_merge_list.tpl");
?>
