<?php
include ("../common.php");
include ("../include/lists_function.php");
$section = "lists";
$res = $dbconn->execute("SELECT id, subject, date, format FROM creleases WHERE is_sent='0'");
while (!$res->EOF)
{
				$values[] = stripslashes($res->fields[0]);
				$output[] = stripslashes($res->fields[1]) . " (" . $res->fields[3] . " - " . $res->fields[2] . ")";
				$res->movenext();
}
$smarty->assign(array("newsletters_values" => $values, "newsletters_output" => $output));
$values = array();
$output = array();
$res = $dbconn->execute("SELECT id, subject, date, format FROM creleases WHERE is_sent<>'0'");
while (!$res->EOF)
{
				$values[] = stripslashes($res->fields[0]);
				$output[] = stripslashes($res->fields[1]) . " (" . $res->fields[3] . " - " . $res->fields[2] . ")";
				$res->movenext();
}
$smarty->assign(array("newsletters_sent_values" => $values, "newsletters_sent_output" => $output));
if (isset($_GET['id']))
{
				if (!isset($_POST['action']) || $_POST['action'] != "change")
				{
								if ($_GET['id'] == 0)
								{
												$right_name = "create";
												check_right($section, $right_name);
												$smarty->assign("razdel", "Mailing Lists");
												$smarty->assign("description", "New Mailing List Creating");
												$smarty->assign("hint", "Complete the form  and click \"Save\" button to create a new mailing list.");
												$content = getblankcontent();
								} else
								{
												$right_name = "view_item";
												check_right($section, $right_name);
												$smarty->assign("razdel", "Mailing Lists");
												$smarty->assign("description", "Mailing List Editing");
												$smarty->assign("hint", "Please edit the values in the fields of this mailing list");
												$content = getcontent((integer)$_GET['id']);
								}
								$smarty->assign("rel", $content);
								$smarty->display("{$admin_nl_gentemplates}/lists_change_list.tpl");
				} else
				{
								if ($_GET['id'] == 0 || $_GET['id'] == "0")
								{
												if (isset($_POST['action']) && $_POST['action'] == "change")
												{
																addlist();
												}
								} else
								{
												$right_name = "edit";
												check_right($section, $right_name);
												updlist();
								}
								header("Location: index.php");
				}
} else
{
				header("Location: index.php");
}
?>
