<?php
class phpmailer
{
				var $Priority = 3;
				var $CharSet = "iso-8859-1";
				var $ContentType = "text/plain";
				var $Encoding = "8bit";
				var $ErrorInfo = "";
				var $From = "root@localhost";
				var $FromName = "Root User";
				var $Sender = "";
				var $Subject = "";
				var $Body = "";
				var $AltBody = "";
				var $WordWrap = 0;
				var $Mailer = "mail";
				var $Sendmail = "/usr/sbin/sendmail";
				var $PluginDir = "";
				var $Version = "1.73";
				var $ConfirmReadingTo = "";
				var $Hostname = "";
				var $Host = "localhost";
				var $Port = 25;
				var $Helo = "";
				var $SMTPAuth = false;
				var $Username = "";
				var $Password = "";
				var $Timeout = 10;
				var $SMTPDebug = 0;
				var $SMTPKeepAlive = false;
				var $smtp = null;
				var $to = array();
				var $cc = array();
				var $bcc = array();
				var $ReplyTo = array();
				var $attachment = array();
				var $CustomHeader = array();
				var $message_type = "";
				var $boundary = array();
				var $language = array();
				var $error_count = 0;
				var $LE = "\n";
				function ishtml($bool)
				{
								if ($bool == true)
								{
												$this->ContentType = "text/html";
								} else
								{
												$this->ContentType = "text/plain";
								}
				}
				function issmtp()
				{
								$this->Mailer = "smtp";
				}
				function ismail()
				{
								$this->Mailer = "mail";
				}
				function issendmail()
				{
								$this->Mailer = "sendmail";
				}
				function isqmail()
				{
								$this->Sendmail = "/var/qmail/bin/sendmail";
								$this->Mailer = "sendmail";
				}
				function addaddress($address, $name = "")
				{
								$cur = count($this->to);
								$this->to[$cur][0] = trim($address);
								$this->to[$cur][1] = $name;
				}
				function addcc($address, $name = "")
				{
								$cur = count($this->cc);
								$this->cc[$cur][0] = trim($address);
								$this->cc[$cur][1] = $name;
				}
				function addbcc($address, $name = "")
				{
								$cur = count($this->bcc);
								$this->bcc[$cur][0] = trim($address);
								$this->bcc[$cur][1] = $name;
				}
				function addreplyto($address, $name = "")
				{
								$cur = count($this->ReplyTo);
								$this->ReplyTo[$cur][0] = trim($address);
								$this->ReplyTo[$cur][1] = $name;
				}
				function send()
				{
								$header = "";
								$body = "";
								$result = true;
								if (count($this->to) + count($this->cc) + count($this->bcc) < 1)
								{
												$this->seterror($this->lang("provide_address"));
												return false;
								}
								if (!empty($this->AltBody))
								{
												$this->ContentType = "multipart/alternative";
								}
								$this->error_count = 0;
								$this->setmessagetype();
								$header .= $this->createheader();
								$body = $this->createbody();
								if ($body == "")
								{
												return false;
								}
								switch ($this->Mailer)
								{
												case "sendmail":
																$result = $this->sendmailsend($header, $body);
																break;
												case "mail":
																$result = $this->mailsend($header, $body);
																break;
												case "smtp":
																$result = $this->smtpsend($header, $body);
																break;
												default:
																$this->seterror($this->Mailer . $this->lang("mailer_not_supported"));
																$result = false;
																break;
								}
								return $result;
				}
				function sendmailsend($header, $body)
				{
								if ($this->Sender != "")
								{
												$sendmail = sprintf("%s -oi -f %s -t", $this->Sendmail, $this->Sender);
								} else
								{
												$sendmail = sprintf("%s -oi -t", $this->Sendmail);
								}
								if (!($mail = @popen($sendmail, "w")))
								{
												$this->seterror($this->lang("execute") . $this->Sendmail);
												return false;
								}
								fputs($mail, $header);
								fputs($mail, $body);
								$result = pclose($mail) >> 8 & 255;
								if ($result != 0)
								{
												$this->seterror($this->lang("execute") . $this->Sendmail);
												return false;
								}
								return true;
				}
				function mailsend($header, $body)
				{
								$to = "";
								$i = 0;
								for (; $i < count($this->to); ++$i)
								{
												if ($i != 0)
												{
																$to .= ", ";
												}
												$to .= $this->to[$i][0];
								}
								if ($this->Sender != "" && strlen(ini_get("safe_mode")) < 1)
								{
												$old_from = ini_get("sendmail_from");
												ini_set("sendmail_from", $this->Sender);
												$params = sprintf("-oi -f %s", $this->Sender);
												$rt = @mail($to, @$this->encodeheader($this->Subject), $body, $header, $params);
								} else
								{
												$rt = @mail($to, @$this->encodeheader($this->Subject), $body, $header);
								}
								if (isset($old_from))
								{
												ini_set("sendmail_from", $old_from);
								}
								if (!$rt)
								{
												$this->seterror($this->lang("instantiate"));
												return false;
								}
								return true;
				}
				function smtpsend($header, $body)
				{
								include_once ($this->PluginDir . "class.smtp.php");
								$error = "";
								$bad_rcpt = array();
								if (!$this->smtpconnect())
								{
												return false;
								}
								$smtp_from = $this->Sender == "" ? $this->From : $this->Sender;
								if (!$this->smtp->mail($smtp_from))
								{
												$error = $this->lang("from_failed") . $smtp_from;
												$this->seterror($error);
												$this->smtp->reset();
												return false;
								}
								$i = 0;
								for (; $i < count($this->to); ++$i)
								{
												if (!$this->smtp->recipient($this->to[$i][0]))
												{
																$bad_rcpt[] = $this->to[$i][0];
												}
								}
								$i = 0;
								for (; $i < count($this->cc); ++$i)
								{
												if (!$this->smtp->recipient($this->cc[$i][0]))
												{
																$bad_rcpt[] = $this->cc[$i][0];
												}
								}
								$i = 0;
								for (; $i < count($this->bcc); ++$i)
								{
												if (!$this->smtp->recipient($this->bcc[$i][0]))
												{
																$bad_rcpt[] = $this->bcc[$i][0];
												}
								}
								if (0 < count($bad_rcpt))
								{
												$i = 0;
												for (; $i < count($bad_rcpt); ++$i)
												{
																if ($i != 0)
																{
																				$error .= ", ";
																}
																$error .= $bad_rcpt[$i];
												}
												$error = $this->lang("recipients_failed") . $error;
												$this->seterror($error);
												$this->smtp->reset();
												return false;
								}
								if (!$this->smtp->data($header . $body))
								{
												$this->seterror($this->lang("data_not_accepted"));
												$this->smtp->reset();
												return false;
								}
								if ($this->SMTPKeepAlive == true)
								{
												$this->smtp->reset();
								} else
								{
												$this->smtpclose();
								}
								return true;
				}
				function smtpconnect()
				{
								if ($this->smtp == null)
								{
												$this->smtp = new smtp();
								}
								$this->smtp->do_debug = $this->SMTPDebug;
								$hosts = explode(";", $this->Host);
								$usernames = explode(";", $this->Username);
								$passwords = explode(";", $this->Password);
								$smtpauths = explode(";", $this->SMTPAuth);
								$index = 0;
								$connection = $this->smtp->connected();
								while ($index < count($hosts) && $connection == false)
								{
												if (strstr($hosts[$index], ":"))
												{
																list($host, $port) = explode(":", $hosts[$index]);
												} else
												{
																$host = $hosts[$index];
																$port = $this->Port;
												}
												if ($this->smtp->connect($host, $port, $this->Timeout))
												{
																if ($this->Helo != "")
																{
																				$this->smtp->hello($this->Helo);
																} else
																{
																				$this->smtp->hello($this->serverhostname());
																}
																if (intval($smtpauths[$index]) && !$this->smtp->authenticate($usernames[$index], $passwords[$index]))
																{
																				$this->seterror($this->lang("authenticate"));
																				$this->smtp->reset();
																				$connection = false;
																}
																$connection = true;
												}
												++$index;
								}
								if (!$connection)
								{
												$this->seterror($this->lang("connect_host"));
								}
								return $connection;
				}
				function smtpclose()
				{
								if ($this->smtp != null && $this->smtp->connected())
								{
												$this->smtp->quit();
												$this->smtp->close();
								}
				}
				function setlanguage($lang_type, $lang_path = "./")
				{
								if (file_exists("../include/phpmailer.lang-en.php"))
								{
												include ("../include/phpmailer.lang-en.php");
								} else
								{
												$this->seterror("Could not load language file");
												return false;
								}
								$this->language = $PHPMAILER_LANG;
								return true;
				}
				function addrappend($type, $addr)
				{
								$addr_str = $type . ": ";
								$addr_str .= $this->addrformat($addr[0]);
								if (1 < count($addr))
								{
												$i = 1;
												for (; $i < count($addr); ++$i)
												{
																$addr_str .= ", " . $this->addrformat($addr[$i]);
												}
								}
								$addr_str .= $this->LE;
								return $addr_str;
				}
				function addrformat($addr)
				{
								if (empty($addr[1]))
								{
												$formatted = $addr[0];
								} else
								{
												$formatted = $this->encodeheader($addr[1], "phrase") . " <" . $addr[0] . ">";
								}
								return $formatted;
				}
				function wraptext($message, $length, $qp_mode = false)
				{
								$soft_break = $qp_mode ? sprintf(" =%s", $this->LE) : $this->LE;
								$message = $this->fixeol($message);
								if (substr($message, -1) == $this->LE)
								{
												$message = substr($message, 0, -1);
								}
								$line = explode($this->LE, $message);
								$message = "";
								$i = 0;
								for (; $i < count($line); ++$i)
								{
												$line_part = explode(" ", $line[$i]);
												$buf = "";
												$e = 0;
												for (; $e < count($line_part); ++$e)
												{
																$word = $line_part[$e];
																if ($qp_mode && $length < strlen($word))
																{
																				$space_left = $length - strlen($buf) - 1;
																				if ($e != 0)
																				{
																								if (20 < $space_left)
																								{
																												$len = $space_left;
																												if (substr($word, $len - 1, 1) == "=")
																												{
																																--$len;
																												} else
																																if (substr($word, $len - 2, 1) == "=")
																																{
																																				$len -= 2;
																																}
																												$part = substr($word, 0, $len);
																												$word = substr($word, $len);
																												$buf .= " " . $part;
																												$message .= $buf . sprintf("=%s", $this->LE);
																								} else
																								{
																												$message .= $buf . $soft_break;
																								}
																								$buf = "";
																				}
																				do
																				{
																								if (0 < strlen($word))
																								{
																												$len = $length;
																												if (substr($word, $len - 1, 1) == "=")
																												{
																																--$len;
																												} else
																																if (substr($word, $len - 2, 1) == "=")
																																{
																																				$len -= 2;
																																}
																												$part = substr($word, 0, $len);
																												$word = substr($word, $len);
																												if (0 < strlen($word))
																												{
																																$message .= $part . sprintf("=%s", $this->LE);
																												} else
																												{
																																$buf = $part;
																												}
																								}
																				} while (1);
																} else
																{
																				$buf_o = $buf;
																				$buf .= $e == 0 ? $word : " " . $word;
																				if ($length < strlen($buf) && $buf_o != "")
																				{
																								$message .= $buf_o . $soft_break;
																								$buf = $word;
																				}
																}
												}
												$message .= $buf . $this->LE;
								}
								return $message;
				}
				function setwordwrap()
				{
								if ($this->WordWrap < 1)
								{
												return;
								}
								switch ($this->message_type)
								{
												case "alt":
												case "alt_attachments":
																$this->AltBody = $this->wraptext($this->AltBody, $this->WordWrap);
																break;
												default:
																$this->Body = $this->wraptext($this->Body, $this->WordWrap);
																break;
								}
				}
				function createheader()
				{
								$result = "";
								$uniq_id = md5(uniqid(time()));
								$this->boundary[1] = "b1_" . $uniq_id;
								$this->boundary[2] = "b2_" . $uniq_id;
								$result .= $this->headerline("Date", $this->rfcdate());
								if ($this->Sender == "")
								{
												$result .= $this->headerline("Return-Path", trim($this->From));
								} else
								{
												$result .= $this->headerline("Return-Path", trim($this->Sender));
								}
								if ($this->Mailer != "mail")
								{
												if (0 < count($this->to))
												{
																$result .= $this->addrappend("To", $this->to);
												} else
																if (count($this->cc) == 0)
																{
																				$result .= $this->headerline("To", "undisclosed-recipients:;");
																}
												if (0 < count($this->cc))
												{
																$result .= $this->addrappend("Cc", $this->cc);
												}
								}
								$from = array();
								$from[0][0] = trim($this->From);
								$from[0][1] = $this->FromName;
								$result .= $this->addrappend("From", $from);
								if (($this->Mailer == "sendmail" || $this->Mailer == "mail") && 0 < count($this->bcc))
								{
												$result .= $this->addrappend("Bcc", $this->bcc);
								}
								if (0 < count($this->ReplyTo))
								{
												$result .= $this->addrappend("Reply-to", $this->ReplyTo);
								}
								if ($this->Mailer != "mail")
								{
												$result .= $this->headerline("Subject", $this->encodeheader(trim($this->Subject)));
								}
								$result .= sprintf("Message-ID: <%s@%s>%s", $uniq_id, $this->serverhostname(), $this->LE);
								$result .= $this->headerline("X-Priority", $this->Priority);
								$result .= $this->headerline("X-Mailer", "PHPMailer [version " . $this->Version . "]");
								if ($this->ConfirmReadingTo != "")
								{
												$result .= $this->headerline("Disposition-Notification-To", "<" . trim($this->ConfirmReadingTo) . ">");
								}
								$index = 0;
								for (; $index < count($this->CustomHeader); ++$index)
								{
												$result .= $this->headerline(trim($this->CustomHeader[$index][0]), $this->encodeheader(trim($this->CustomHeader[$index][1])));
								}
								$result .= $this->headerline("MIME-Version", "1.0");
								switch ($this->message_type)
								{
												case "plain":
																$result .= $this->headerline("Content-Transfer-Encoding", $this->Encoding);
																$result .= sprintf("Content-Type: %s; charset=\"%s\"", $this->ContentType, $this->CharSet);
																break;
												case "attachments":
												case "alt_attachments":
																if ($this->inlineimageexists())
																{
																				$result .= sprintf("Content-Type: %s;%s\ttype=\"text/html\";%s\tboundary=\"%s\"%s", "multipart/related", $this->LE, $this->LE, $this->boundary[1], $this->LE);
																} else
																{
																				$result .= $this->headerline("Content-Type", "multipart/mixed;");
																				$result .= $this->textline("\tboundary=\"" . $this->boundary[1] . "\"");
																}
																break;
												case "alt":
																$result .= $this->headerline("Content-Type", "multipart/alternative;");
																$result .= $this->textline("\tboundary=\"" . $this->boundary[1] . "\"");
								}
								if ($this->Mailer != "mail")
								{
												$result .= $this->LE . $this->LE;
								}
								return $result;
				}
				function createbody()
				{
								$result = "";
								$this->setwordwrap();
								switch ($this->message_type)
								{
												case "alt":
																$result .= $this->getboundary($this->boundary[1], "", "text/plain", "");
																$result .= $this->encodestring($this->AltBody, $this->Encoding);
																$result .= $this->LE . $this->LE;
																$result .= $this->getboundary($this->boundary[1], "", "text/html", "");
																$result .= $this->encodestring($this->Body, $this->Encoding);
																$result .= $this->LE . $this->LE;
																$result .= $this->endboundary($this->boundary[1]);
																break;
												case "plain":
																$result .= $this->encodestring($this->Body, $this->Encoding);
																break;
												case "attachments":
																$result .= $this->getboundary($this->boundary[1], "", "", "");
																$result .= $this->encodestring($this->Body, $this->Encoding);
																$result .= $this->LE;
																$result .= $this->attachall();
																break;
												case "alt_attachments":
																$result .= sprintf("--%s%s", $this->boundary[1], $this->LE);
																$result .= sprintf("Content-Type: %s;%s\tboundary=\"%s\"%s", "multipart/alternative", $this->LE, $this->boundary[2], $this->LE . $this->LE);
																$result .= $this->getboundary($this->boundary[2], "", "text/plain", "") . $this->LE;
																$result .= $this->encodestring($this->AltBody, $this->Encoding);
																$result .= $this->LE . $this->LE;
																$result .= $this->getboundary($this->boundary[2], "", "text/html", "") . $this->LE;
																$result .= $this->encodestring($this->Body, $this->Encoding);
																$result .= $this->LE . $this->LE;
																$result .= $this->endboundary($this->boundary[2]);
																$result .= $this->attachall();
								}
								if ($this->iserror())
								{
												$result = "";
								}
								return $result;
				}
				function getboundary($boundary, $charSet, $contentType, $encoding)
				{
								$result = "";
								if ($charSet == "")
								{
												$charSet = $this->CharSet;
								}
								if ($contentType == "")
								{
												$contentType = $this->ContentType;
								}
								if ($encoding == "")
								{
												$encoding = $this->Encoding;
								}
								$result .= $this->textline("--" . $boundary);
								$result .= sprintf("Content-Type: %s; charset = \"%s\"", $contentType, $charSet);
								$result .= $this->LE;
								$result .= $this->headerline("Content-Transfer-Encoding", $encoding);
								$result .= $this->LE;
								return $result;
				}
				function endboundary($boundary)
				{
								return $this->LE . "--" . $boundary . "--" . $this->LE;
				}
				function setmessagetype()
				{
								if (count($this->attachment) < 1 && strlen($this->AltBody) < 1)
								{
												$this->message_type = "plain";
								} else
								{
												if (0 < count($this->attachment))
												{
																$this->message_type = "attachments";
												}
												if (0 < strlen($this->AltBody) && count($this->attachment) < 1)
												{
																$this->message_type = "alt";
												}
												if (0 < strlen($this->AltBody) && 0 < count($this->attachment))
												{
																$this->message_type = "alt_attachments";
												}
								}
				}
				function headerline($name, $value)
				{
								return $name . ": " . $value . $this->LE;
				}
				function textline($value)
				{
								return $value . $this->LE;
				}
				function addattachment($path, $name = "", $encoding = "base64", $type = "application/octet-stream")
				{
								if (!is_file($path))
								{
												$this->seterror($this->lang("file_access") . $path);
												return false;
								}
								$filename = basename($path);
								if ($name == "")
								{
												$name = $filename;
								}
								$cur = count($this->attachment);
								$this->attachment[$cur][0] = $path;
								$this->attachment[$cur][1] = $filename;
								$this->attachment[$cur][2] = $name;
								$this->attachment[$cur][3] = $encoding;
								$this->attachment[$cur][4] = $type;
								$this->attachment[$cur][5] = false;
								$this->attachment[$cur][6] = "attachment";
								$this->attachment[$cur][7] = 0;
								return true;
				}
				function attachall()
				{
								$mime = array();
								$i = 0;
								for (; $i < count($this->attachment); ++$i)
								{
												$bString = $this->attachment[$i][5];
												if ($bString)
												{
																$string = $this->attachment[$i][0];
												} else
												{
																$path = $this->attachment[$i][0];
												}
												$filename = $this->attachment[$i][1];
												$name = $this->attachment[$i][2];
												$encoding = $this->attachment[$i][3];
												$type = $this->attachment[$i][4];
												$disposition = $this->attachment[$i][6];
												$cid = $this->attachment[$i][7];
												$mime[] = sprintf("--%s%s", $this->boundary[1], $this->LE);
												$mime[] = sprintf("Content-Type: %s; name=\"%s\"%s", $type, $name, $this->LE);
												$mime[] = sprintf("Content-Transfer-Encoding: %s%s", $encoding, $this->LE);
												if ($disposition == "inline")
												{
																$mime[] = sprintf("Content-ID: <%s>%s", $cid, $this->LE);
												}
												$mime[] = sprintf("Content-Disposition: %s; filename=\"%s\"%s", $disposition, $name, $this->LE . $this->LE);
												if ($bString)
												{
																$mime[] = $this->encodestring($string, $encoding);
																if ($this->iserror())
																{
																				return "";
																}
																$mime[] = $this->LE . $this->LE;
												} else
												{
																$mime[] = $this->encodefile($path, $encoding);
																if ($this->iserror())
																{
																				return "";
																}
																$mime[] = $this->LE . $this->LE;
												}
								}
								$mime[] = sprintf("--%s--%s", $this->boundary[1], $this->LE);
								return join("", $mime);
				}
				function encodefile($path, $encoding = "base64")
				{
								if (!($fd = @fopen($path, "rb")))
								{
												$this->seterror($this->lang("file_open") . $path);
												return "";
								}
								$magic_quotes = get_magic_quotes_runtime();
								set_magic_quotes_runtime(0);
								$file_buffer = fread($fd, filesize($path));
								$file_buffer = $this->encodestring($file_buffer, $encoding);
								fclose($fd);
								set_magic_quotes_runtime($magic_quotes);
								return $file_buffer;
				}
				function encodestring($str, $encoding = "base64")
				{
								$encoded = "";
								switch (strtolower($encoding))
								{
												case "base64":
																$encoded = chunk_split(base64_encode($str), 76, $this->LE);
																break;
												case "7bit":
												case "8bit":
																$encoded = $this->fixeol($str);
																if (!(substr($encoded, 0 - strlen($this->LE)) != $this->LE))
																{
																				break;
																}
																$encoded .= $this->LE;
																break;
												case "binary":
																$encoded = $str;
																break;
												case "quoted-printable":
																$encoded = $this->encodeqp($str);
																break;
												default:
																$this->seterror($this->lang("encoding") . $encoding);
																break;
								}
								return $encoded;
				}
				function encodeheader($str, $position = "text")
				{
								$x = 0;
								switch (strtolower($position))
								{
												case "phrase":
																if (!preg_match("/[\\200-\\377]/", $str))
																{
																				$encoded = addcslashes($str, "\x00..\x1F\\\"");
																				if ($str == $encoded && !preg_match("/[^A-Za-z0-9!#\$%&'*+\\/=?^_`{|}~ -]/", $str))
																				{
																								return $encoded;
																				} else
																				{
																								return "\"{$encoded}\"";
																				}
																}
																$x = preg_match_all("/[^\\040\\041\\043-\\133\\135-\\176]/", $str, $matches);
																break;
												case "comment":
																$x = preg_match_all("/[()\"]/", $str, $matches);
												case "text":
												default:
																$x += preg_match_all("/[\\000-\\010\\013\\014\\016-\\037\\177-\\377]/", $str, $matches);
																break;
								}
								if ($x == 0)
								{
												return $str;
								}
								$maxlen = 68 - strlen($this->CharSet);
								if (strlen($str) / 3 < $x)
								{
												$encoding = "B";
												$encoded = base64_encode($str);
												$maxlen -= $maxlen % 4;
												$encoded = trim(chunk_split($encoded, $maxlen, "\n"));
								} else
								{
												$encoding = "Q";
												$encoded = $this->encodeq($str, $position);
												$encoded = $this->wraptext($encoded, $maxlen, true);
												$encoded = str_replace("=" . $this->LE, "\n", trim($encoded));
								}
								$encoded = preg_replace("/^(.*)\$/m", " =?" . $this->CharSet . "?{$encoding}?\\1?=", $encoded);
								$encoded = trim(str_replace("\n", $this->LE, $encoded));
								return $encoded;
				}
				function encodeqp($str)
				{
								$encoded = $this->fixeol($str);
								if (substr($encoded, 0 - strlen($this->LE)) != $this->LE)
								{
												$encoded .= $this->LE;
								}
								$encoded = preg_replace("/([\\000-\\010\\013\\014\\016-\\037\\075\\177-\\377])/e", "'='.sprintf('%02X', ord('\\1'))", $encoded);
								$encoded = preg_replace("/([\t ])" . $this->LE . "/e", "'='.sprintf('%02X', ord('\\1')).'" . $this->LE . "'", $encoded);
								$encoded = $this->wraptext($encoded, 74, true);
								return $encoded;
				}
				function encodeq($str, $position = "text")
				{
								$encoded = preg_replace("[\r\n]", "", $str);
								switch (strtolower($position))
								{
												case "phrase":
																$encoded = preg_replace("/([^A-Za-z0-9!*+\\/ -])/e", "'='.sprintf('%02X', ord('\\1'))", $encoded);
																break;
												case "comment":
																$encoded = preg_replace("/([\\(\\)\"])/e", "'='.sprintf('%02X', ord('\\1'))", $encoded);
												case "text":
												default:
																$encoded = preg_replace("/([\\000-\\011\\013\\014\\016-\\037\\075\\077\\137\\177-\\377])/e", "'='.sprintf('%02X', ord('\\1'))", $encoded);
																break;
								}
								$encoded = str_replace(" ", "_", $encoded);
								return $encoded;
				}
				function addstringattachment($string, $filename, $encoding = "base64", $type = "application/octet-stream")
				{
								$cur = count($this->attachment);
								$this->attachment[$cur][0] = $string;
								$this->attachment[$cur][1] = $filename;
								$this->attachment[$cur][2] = $filename;
								$this->attachment[$cur][3] = $encoding;
								$this->attachment[$cur][4] = $type;
								$this->attachment[$cur][5] = true;
								$this->attachment[$cur][6] = "attachment";
								$this->attachment[$cur][7] = 0;
				}
				function addembeddedimage($path, $cid, $name = "", $encoding = "base64", $type = "application/octet-stream")
				{
								if (!is_file($path))
								{
												$this->seterror($this->lang("file_access") . $path);
												return false;
								}
								$filename = basename($path);
								if ($name == "")
								{
												$name = $filename;
								}
								$cur = count($this->attachment);
								$this->attachment[$cur][0] = $path;
								$this->attachment[$cur][1] = $filename;
								$this->attachment[$cur][2] = $name;
								$this->attachment[$cur][3] = $encoding;
								$this->attachment[$cur][4] = $type;
								$this->attachment[$cur][5] = false;
								$this->attachment[$cur][6] = "inline";
								$this->attachment[$cur][7] = $cid;
								return true;
				}
				function inlineimageexists()
				{
								$result = false;
								$i = 0;
								for (; $i < count($this->attachment); ++$i)
								{
												if ($this->attachment[$i][6] == "inline")
												{
																$result = true;
																break;
												}
								}
								return $result;
				}
				function clearaddresses()
				{
								$this->to = array();
				}
				function clearccs()
				{
								$this->cc = array();
				}
				function clearbccs()
				{
								$this->bcc = array();
				}
				function clearreplytos()
				{
								$this->ReplyTo = array();
				}
				function clearallrecipients()
				{
								$this->to = array();
								$this->cc = array();
								$this->bcc = array();
				}
				function clearattachments()
				{
								$this->attachment = array();
				}
				function clearcustomheaders()
				{
								$this->CustomHeader = array();
				}
				function seterror($msg)
				{
								++$this->error_count;
								$this->ErrorInfo = $msg;
				}
				function rfcdate()
				{
								$tz = date("Z");
								$tzs = $tz < 0 ? "-" : "+";
								$tz = abs($tz);
								$tz = $tz / 3600 * 100 + $tz % 3600 / 60;
								$result = sprintf("%s %s%04d", date("D, j M Y H:i:s"), $tzs, $tz);
								return $result;
				}
				function servervar($varName)
				{
								global $HTTP_SERVER_VARS;
								global $HTTP_ENV_VARS;
								if (!isset($_SERVER))
								{
												$GLOBALS['_SERVER'] = $HTTP_SERVER_VARS;
												if (!isset($_SERVER['REMOTE_ADDR']))
												{
																$GLOBALS['_SERVER'] = $HTTP_ENV_VARS;
												}
								}
								if (isset($_SERVER[$varName]))
								{
												return $_SERVER[$varName];
								} else
								{
												return "";
								}
				}
				function serverhostname()
				{
								if ($this->Hostname != "")
								{
												$result = $this->Hostname;
								} else
												if ($this->servervar("SERVER_NAME") != "")
												{
																$result = $this->servervar("SERVER_NAME");
												} else
												{
																$result = "localhost.localdomain";
												}
												return $result;
				}
				function lang($key)
				{
								if (count($this->language) < 1)
								{
												$this->setlanguage("en");
								}
								if (isset($this->language[$key]))
								{
												return $this->language[$key];
								} else
								{
												return "Language string failed to load: " . $key;
								}
				}
				function iserror()
				{
								return 0 < $this->error_count;
				}
				function fixeol($str)
				{
								$str = str_replace("\r\n", "\n", $str);
								$str = str_replace("\r", "\n", $str);
								$str = str_replace("\n", $this->LE, $str);
								return $str;
				}
				function addcustomheader($custom_header)
				{
								$this->CustomHeader[] = explode(":", $custom_header, 2);
				}
}
?>
