<?php

class Location {
    public $address;
    public $city;
    public $country;
    public $parent;
}