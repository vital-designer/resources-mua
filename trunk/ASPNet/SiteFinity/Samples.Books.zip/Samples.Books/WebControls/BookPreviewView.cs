﻿using Telerik.Cms.Web.UI;

namespace Samples.Books.WebControls
{
    /// <summary>
    /// Represents a book preview view
    /// </summary>
    public class BookPreviewView : ViewModeControl<BooksControlPanel>
    {
        // not implemented
    }
}
