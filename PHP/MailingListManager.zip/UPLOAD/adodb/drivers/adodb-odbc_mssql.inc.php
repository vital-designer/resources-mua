<?php
if (!defined("_ADODB_ODBC_LAYER"))
{
				include (ADODB_DIR . "/drivers/adodb-odbc.inc.php");
}
class adodb_odbc_mssql extends adodb_odbc
{
				var $databaseType = "odbc_mssql";
				var $fmtDate = "'Y-m-d'";
				var $fmtTimeStamp = "'Y-m-d h:i:sA'";
				var $_bindInputArray = true;
				var $hasTop = true;
}
class adorecordset_odbc_mssql extends adorecordset_odbc
{
				var $databaseType = "odbc_mssql";
				function adorecordset_odbc_mssql($id)
				{
								return $this->adorecordset_odbc($id);
				}
}
?>