<?php
include ("../common.php");
include ("../include/newsletters_function.php");
$section = "newsletters";
$right_name = "send";
check_right($section, $right_name);
if (!isset($_GET['id']))
{
				header("Location: index.php");
}
if (isset($_GET['is_stop']) && $_GET['is_stop'] == 1)
{
				$rs = $dbconn->execute("delete from clients_releases where is_sent='0' and release_id='" . $_GET['id'] . "'");
				$rs = $dbconn->execute("update creleases set is_sent=1 where id='" . $_GET['id'] . "'");
				header("Location:" . $_SESSION['return_url']);
}
if (!isset($_POST['list']) && isset($_GET['is_test']) && $_GET['is_test'] == "false")
{
				$smarty->assign("id", $_GET['id']);
				$lists = getlistsfilled();
				$smarty->assign("lists", $lists);
				if (empty($lists))
				{
								$smarty->assign("list_count", 0);
				}
				else
				{
								$smarty->assign("list_count", 1);
				}
				$res = $dbconn->execute("select * from creleases_lists where crelease_id='" . $_GET['id'] . "'");
				$c = 0;
				while (!$res->EOF)
				{
								$row = $res->getrowassoc(false);
								$list_array[$c] = $row['list_id'];
								++$c;
								$res->movenext();
				}
				$smarty->assign("list_array", $list_array);
				$res = $dbconn->execute("select match_status, match_confirm from creleases where id='" . $_GET['id'] . "'");
				$row = $res->getrowassoc(false);
				$smarty->assign("rel", $row);
				$smarty->assign("razdel", "Newsletters");
				$smarty->assign("description", "Newsletter sending");
				$smarty->assign("hint", "Please choose mailing lists which you would like to send a letter. Empty lists are not reflected there.");
				$smarty->display("{$admin_nl_gentemplates}/newsletters_send_newsletter.tpl");
}
else
				if (isset($_POST['list']))
				{
								$id = $_GET['id'];
								$GLOBALS['_SESSION']['list'] = $_POST['list'];
								$match_list = $_POST['match_confirm'];
								$match_status = $_POST['match_status'];
								echo "
								<script>
								window.open('sending.php?id={$id}&match_list={$match_list}&match_status={$match_status}','Sending','width=600,height=400,menubar=no,status=no,location=no,toolbar=no,scrollbars=yes,resizable=yes');
								</script>";
								if (isset($_SESSION['return_url']))
								{
												echo "<script>";
												echo "document.location='" . $_SESSION['return_url'] . "'";
												echo "</script>";
								}
								else
								{
												echo "<script>";
												echo "document.location='index.php'";
												echo "</script>";
								}
				}
if (isset($_REQUEST['is_test']) && $_REQUEST['is_test'] == "true")
{
				$id = $_GET['id'];
				$res = $dbconn->execute("select * from creleases_lists where crelease_id='" . $_GET['id'] . "'");
				$c = 0;
				while (!$res->EOF)
				{
								$row = $res->getrowassoc(false);
								$list_array[$c] = $row['list_id'];
								++$c;
								$res->movenext();
				}
				$GLOBALS['_SESSION']['list'] = $list_array;
				echo "
				<script>
				window.open('sending.php?id={$id}&is_test=true','Sending','width=600,height=400,menubar=no,status=no,location=no,toolbar=no,scrollbars=yes,resizable=yes');
				</script>";
				if (isset($_SESSION['return_url']))
				{
								echo "<script>";
								echo "document.location='" . $_SESSION['return_url'] . "'";
								echo "</script>";
				}
				else
				{
								echo "<script>";
								echo "document.location='index.php'";
								echo "</script>";
				}
}
?>