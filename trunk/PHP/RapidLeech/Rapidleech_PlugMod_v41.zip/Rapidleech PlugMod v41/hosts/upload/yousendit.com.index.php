<?php
$upload_services[] = "yousendit.com";
$max_file_size["yousendit.com"] = 100;
$page_upload["yousendit.com"] = "yousendit.com.php";  
?>