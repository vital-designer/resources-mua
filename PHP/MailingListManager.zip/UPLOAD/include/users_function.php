<?php
function getusers($a = "", $orderby = "", $user_page = 0, $filter = "")
{
				global $dbconn;
				global $smarty;
				global $config;
				if (isset($_GET['p']) && 0 < $_GET['p'])
				{
								$p = $_GET['p'];
				} else
				{
								$p = 0;
				}
				if ($a)
				{
								$sql = " where id='" . $a . "' ";
				} else
				{
								$sql = "";
								if (isset($_POST['sub_click']) && $_POST['sub_click'] == "filter")
								{
												if (trim($_POST['FirstName']) != "")
												{
																$first_name .= " firstname LIKE '%" . $_POST['FirstName'] . "%' ";
												} else
												{
																$first_name = "";
												}
												if (trim($_POST['SecondName']) != "")
												{
																$second_name .= " secondname LIKE '%" . $_POST['SecondName'] . "%' ";
												} else
												{
																$second_name = "";
												}
												if (trim($_POST['Company']) != "")
												{
																$company .= " company LIKE '%" . $_POST['Company'] . "%' ";
												} else
												{
																$company = "";
												}
												if (trim($_POST['Email']) != "")
												{
																$email .= " email1 LIKE '%" . $_POST['Email'] . "%' ";
												} else
												{
																$email = "";
												}
												if ($first_name != "" && $second_name != "")
												{
																$filter = $first_name . $_POST['Logic1'] . $second_name;
												} else
																if ($first_name != "")
																{
																				$filter = $first_name;
																} else
																				if ($second_name != "")
																				{
																								$filter = $second_name;
																				} else
																				{
																								$filter = "";
																				}
																				if ($filter != "")
																				{
																								if ($company != "")
																								{
																												$filter .= $_POST['Logic2'] . $company;
																								}
																								if ($email != "")
																								{
																												$filter .= $_POST['Logic3'] . $email;
																								}
																				} else
																								if ($company != "" && $email != "")
																								{
																												$filter = $company . $_POST['Logic2'] . $email;
																								} else
																												if ($company != "")
																												{
																																$filter = $company;
																												} else
																																if ($email != "")
																																{
																																				$filter = $email;
																																}
												$filter_value['firstname'] = $_POST['FirstName'];
												$filter_value['secondname'] = $_POST['SecondName'];
												$filter_value['company'] = $_POST['Company'];
												$filter_value['email'] = $_POST['Email'];
												$filter_value['logic1'] = $_POST['Logic1'];
												$filter_value['logic2'] = $_POST['Logic2'];
												$filter_value['logic3'] = $_POST['Logic3'];
												$filter_url = "fname=" . $_POST['FirstName'] . "&sname=" . $_POST['SecondName'] . "&logic1=" . $_POST['Logic1'] . "&company=" . $_POST['Company'] . "&logic2=" . $_POST['Logic2'] . "&email=" . $_POST['Email'] . "&logic3=" . $_POST['Logic3'] . "&filter=yes";
												$smarty->assign("filter_value", $filter_value);
												$smarty->assign("filter_url", $filter_url);
								} else
												if (isset($_GET['filter']) && $_GET['filter'] != "")
												{
																if ($_GET['fname'] != "")
																{
																				$first_name .= " firstname LIKE '%" . $_GET['fname'] . "%' ";
																} else
																{
																				$first_name = "";
																}
																if ($_GET['sname'] != "")
																{
																				$second_name .= " secondname LIKE '%" . $_GET['sname'] . "%' ";
																} else
																{
																				$second_name = "";
																}
																if ($_GET['company'] != "")
																{
																				$second_name .= " company LIKE '%" . $_GET['company'] . "%' ";
																} else
																{
																				$company = "";
																}
																if ($_GET['email'] != "")
																{
																				$email .= " email1 LIKE '%" . $_GET['email'] . "%' ";
																} else
																{
																				$email = "";
																}
																if ($first_name != "" && $second_name != "")
																{
																				$filter = $first_name . $_GET['logic1'] . $second_name;
																} else
																				if ($first_name != "")
																				{
																								$filter = $first_name;
																				} else
																								if ($second_name != "")
																								{
																												$filter = $second_name;
																								} else
																								{
																												$filter = "";
																								}
																								if ($filter != "")
																								{
																												if ($company != "")
																												{
																																$filter .= $_GET['logic2'] . $company;
																												}
																												if ($email != "")
																												{
																																$filter .= $_GET['logic3'] . $email;
																												}
																								} else
																												if ($company != "" && $email != "")
																												{
																																$filter = $company . $_GET['logic3'] . $email;
																												} else
																																if ($company != "")
																																{
																																				$filter = $company;
																																} else
																																				if ($email != "")
																																				{
																																								$filter = $email;
																																				}
																$filter_value['firstname'] = $_GET['fname'];
																$filter_value['secondname'] = $_GET['sname'];
																$filter_value['company'] = $_GET['company'];
																$filter_value['email'] = $_GET['email'];
																$filter_value['logic1'] = $_GET['logic1'];
																$filter_value['logic2'] = $_GET['logic2'];
																$filter_value['logic3'] = $_GET['logic3'];
																$filter_url = "fname=" . $_GET['fname'] . "&sname=" . $_GET['sname'] . "&logic1=" . $_GET['logic1'] . "&company=" . $_GET['company'] . "&logic2=" . $_GET['logic2'] . "&email=" . $_GET['email'] . "&logic3=" . $_GET['logic3'] . "&filter=yes";
																$smarty->assign("filter_value", $filter_value);
																$smarty->assign("filter_url", $filter_url);
												}
								$end = $_SESSION['is_desc'] && !$_GET['is_nav'] || !$_SESSION['is_desc'] && $_GET['is_nav'] ? " desc " : "";
								if ($orderby)
								{
												$is_nav = isset($_GET['is_nav']) ? $_GET['is_nav'] : false;
												if (!$is_nav && $orderby == $_SESSION['order'])
												{
																if ($_SESSION['is_desc'])
																{
																				$GLOBALS['_SESSION']['is_desc'] = false;
																				$end = " desc ";
																} else
																{
																				$GLOBALS['_SESSION']['is_desc'] = true;
																				$end = "";
																}
												}
												$sql .= " order by " . $orderby . $end;
								} else
								{
												$sql .= " order by firstname,id";
								}
				}
				if (isset($_GET['lid']))
				{
								$id_list = $_GET['lid'];
				} else
				{
								$id_list = $_REQUEST['list_id'];
				}
				$smarty->assign("lid", $_GET['lid']);
				$smarty->assign("end", trim($end));
				if (0 < $id_list)
				{
								if ($filter != "")
								{
												$filter_sql = " and " . $filter;
								}
								$rs = $dbconn->execute("select count(distinct(cl.client_id)) from snd_users s, clients_lists cl where s.id=cl.client_id and cl.list_id='" . $id_list . "' and cl.status_subscribe<>'" . $config['status_subscribe_val']['unsubscribe'] . "' {$filter_sql}");
								$total = $rs->fields[0];
								$rl = $dbconn->execute("select name from list where id='" . $id_list . "'");
								$smarty->assign("list_name", "List: " . $rl->fields[0] . " &nbsp;&nbsp;&nbsp;");
				} else
								if ($id_list == 0)
								{
												if ($filter != "")
												{
																$filter_sql = " and " . $filter;
												}
												$rs = $dbconn->execute("select count(distinct(cl.client_id)) from snd_users s, clients_lists cl where s.id=cl.client_id and cl.status_subscribe<>'" . $config['status_subscribe_val']['unsubscribe'] . "' {$filter_sql}");
												$total = $rs->fields[0];
												$smarty->assign("list_name", "");
								}
				$smarty->assign("total", $total);
				if (isset($_GET['lid']) && 0 < $_GET['lid'])
				{
								$rs = $dbconn->execute("select count(s.id) from snd_users s, clients_lists cl where s.id=cl.client_id and cl.list_id='" . $_GET['lid'] . "' and status_subscribe<>'" . $config['status_subscribe_val']['unsubscribe'] . "' {$filter}");
								$total = $rs->fields[0];
								$smarty->assign("navigation", create_navigation($rs->fields[0], $user_page, "user_page={$user_page}&lid=" . $_GET['lid'] . "&order=" . $_GET['order'] . "&is_nav=true&" . $filter_url, "index.php", $p));
								get_smarty_array_list("user_page", $config['user_page']);
								$per_page = $config['user_page'][$user_page];
								$res = $dbconn->pageexecute("select id,date,firstname,secondname,company,email1,comment from snd_users s, clients_lists cl where s.id=cl.client_id and cl.list_id='" . $_GET['lid'] . "' and status_subscribe<>'" . $config['status_subscribe_val']['unsubscribe'] . "' {$filter} " . $sql, $per_page, $p + 1);
				} else
				{
								if ($filter != "")
								{
												$filter = "where " . $filter;
								}
								$rs = $dbconn->execute("select count(id) from snd_users {$filter}");
								$smarty->assign("navigation", create_navigation($rs->fields[0], $user_page, "user_page={$user_page}&list_id=" . $_REQUEST['list_id'] . "&order=" . $_GET['order'] . "&is_nav=true&" . $filter_url, "index.php", $p));
								get_smarty_array_list("user_page", $config['user_page']);
								$total = $rs->fields[0];
								$per_page = $config['user_page'][$user_page];
								$res = $dbconn->pageexecute("select id,date,firstname,secondname,company,email1,comment, status from snd_users {$filter} " . $sql, $per_page, $p + 1);
				}
				$users = array();
				$c = 0;
				while (!$res->EOF)
				{
								$users[$c] = $res->getrowassoc();
								$res2 = $dbconn->execute("select a.id,a.name, b.status_subscribe, b.date_status, s.status\r\n\t\t\t\t\t\t\tfrom list a left join clients_lists b on (a.id=b.list_id) left join snd_users s on (b.client_id=s.id)\r\n\t\t\t\t\t\t\twhere b.client_id='" . $res->fields[0] . "'");
								$j = 0;
								while (!$res2->EOF)
								{
												$users[$c]['LISTID'][$j] = $res2->fields[0];
												$users[$c]['LIST'][$j] = stripslashes($res2->fields[1]);
												$users[$c]['STATUS_SUBSCRIBE'][$j] = $res2->fields[2];
												$users[$c]['DATE_STATUS'][$j] = $res2->fields[3];
												++$j;
												$res2->movenext();
								}
								$users[$c]['i'] = $c;
								++$c;
								$res->movenext();
				}
				$smarty->assign("amount", $c);
				return $users;
}
function deluser($id)
{
				global $dbconn;
				$res = $dbconn->execute("delete from snd_users where id='" . $id . "'");
				$res = $dbconn->execute("delete from clients_lists where client_id='" . $id . "'");
				$res = $dbconn->execute("delete from clients_releases where client_id='" . $id . "'");
				$res = $dbconn->execute("delete from click_counter where client='" . $id . "'");
}
function activeuser($id, $status)
{
				global $dbconn;
				$res = $dbconn->execute("update snd_users set status='" . $status . "' where id='" . $id . "'");
}
function adduser($inf, &$user_id)
{
				global $dbconn;
				global $config;
				$rs = $dbconn->execute("select id from snd_users where email1='" . $inf['email1'] . "'");
				if ($rs->rowcount() == 0)
				{
								$strSQL = "insert into snd_users (date,firstname,secondname,company,email1,comment, status)\r\n\t                         values (NOW(),'" . addslashes($inf['firstname']) . "',\r\n\t\t\t\t\t\t\t '" . addslashes($inf['secondname']) . "','" . addslashes($inf['company']) . "',\r\n\t\t\t\t\t\t\t '" . addslashes($inf['email1']) . "','" . addslashes($inf['comment']) . "',\r\n\t\t\t\t\t\t\t '" . $inf['status'] . "')";
								$res = $dbconn->execute($strSQL);
								$uid = $dbconn->_insertid();
				} else
				{
								$uid = $rs->fields[0];
								$msg = "User with email: " . $inf['email1'] . " already exists.<br>";
				}
				foreach ($inf['list'] as $list)
				{
								if ($list != 0)
								{
												$rs = $dbconn->execute("select * from clients_lists where client_id='" . $uid . "' and list_id='" . $list . "'");
												if (0 < $rs->rowcount())
												{
																$strSQL = "update clients_lists set status_subscribe='" . $config['status_subscribe_val']['subscribe'] . "', date_status=now() where client_id='" . $uid . "' and list_id='" . $list . "'";
																$rs = $dbconn->execute($strSQL);
												} else
												{
																$strSQL = "insert into clients_lists values ('" . $uid . "','" . $list . "', '" . $config['status_subscribe_val']['subscribe'] . "', now() )";
																$res = $dbconn->execute($strSQL);
												}
								}
				}
				$user_id = $uid;
				return $msg;
}
function upduser($id, $inf)
{
				global $dbconn;
				global $config;
				$strSQL = "update snd_users set firstname='" . addslashes($inf['firstname']) . "',\r\n                         secondname='" . addslashes($inf['secondname']) . "',company='" . addslashes($inf['company']) . "',\r\n                         email1='" . addslashes($inf['email1']) . "',\r\n\t\t\t\t\t\t comment='" . addslashes($inf['comment']) . "',\r\n\t\t\t\t\t\t status='" . $inf['status'] . "'\r\n                         where id='" . $id . "'";
				$res = $dbconn->execute($strSQL);
				$strSQL = "update clients_lists set status_subscribe='" . $config['status_subscribe_val']['unsubscribe'] . "', date_status=now() where client_id='" . $id . "'";
				$res = $dbconn->execute($strSQL);
				if (isset($inf['list']) && 0 < count($inf['list']))
				{
								foreach ($inf['list'] as $list)
								{
												list($id_list, $id_status) = each($inf['status_subscribe']);
												if ($list != 0)
												{
																$res = $dbconn->execute("select * from clients_lists where client_id='" . $id . "' and list_id='" . $list . "'");
																if (!$res->rowcount())
																{
																				$strSQL = "insert into clients_lists values ('" . $id . "','" . $list . "', '" . $id_status . "', now())";
																				$res = $dbconn->execute($strSQL);
																} else
																{
																				$strSQL = "update clients_lists set status_subscribe='" . $id_status . "', date_status=now() where client_id='" . $id . "' and list_id='" . $list . "'";
																				$res = $dbconn->execute($strSQL);
																}
												}
								}
				}
}
function getblankcontent()
{
				global $config;
				$users = array();
				$users[0]['ID'] = 0;
				$users[0]['FIRSTNAME'] = "";
				$users[0]['SECONDNAME'] = "";
				$users[0]['COMPANY'] = "";
				$users[0]['EMAIL1'] = "";
				$users[0]['COMMENT'] = "";
				$users[0]['STATUS'] = 1;
				$users[0]['STATUS_SUBSCRIBE'] = $config['status_subscribe_val']['subscribe'];
				return $users;
}
function getlists()
{
				global $dbconn;
				global $config;
				$res = $dbconn->execute("select id, name, date,owner_name,owner_email from list order by id");
				$releases = array();
				$c = 0;
				while (!$res->EOF)
				{
								$releases[$c]['id'] = $res->fields[0];
								$releases[$c]['name'] = stripslashes($res->fields[1]);
								$releases[$c]['date'] = $res->fields[2];
								$releases[$c]['owner_name'] = $res->fields[3];
								$releases[$c]['owner_email'] = $res->fields[4];
								$res2 = $dbconn->execute("select count(*) from clients_lists where list_id='" . $res->fields[0] . "' and (status_subscribe='" . $config['status_subscribe_val']['subscribe'] . "' OR status_subscribe='" . $config['status_subscribe_val']['unconf_unsub'] . "')");
								$releases[$c]['count'] = $res2->fields[0];
								++$c;
								$res->movenext();
				}
				return $releases;
}
function check_email($p_email)
{
				if (eregi("^[_.0-9a-z-]+@([0-9a-z][-0-9a-z.]+).([a-z]{2,6}\$)", $p_email, $check))
				{
								return true;
				}
				return false;
}
?>
