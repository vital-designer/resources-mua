<?php
include ("../common.php");
include ("../include/template_function.php");
$section = "templates";
$right_name = "view_item";
check_right($section, $right_name);
$content = getcontent((integer)$_GET['id']);
$smarty->assign("content", $content['body']);
$smarty->display("{$admin_nl_gentemplates}/template_template_view.tpl");
?>