<?php
include ("common.php");
$smarty->assign("razdel", "Home");
$smarty->assign("description", "Welcome");
$smarty->assign("hint", "");
$smarty->display("{$admin_nl_gentemplates}/not_right.tpl");
?>