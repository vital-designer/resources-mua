<?php
clearstatcache();
if (file_exists("include/config.php") && filesize("include/config.php") < 100 || !file_exists("include/config.php"))
{
				header("Location:install/index.php");
}
include ("common.php");
include ("include/Snoopy.class.php");
checkinstallfolder($smarty);
$res = $dbconn->execute("select count(id) from snd_users");
$total['users'] = $res->fields[0];
$res = $dbconn->execute("select distinct client_id from clients_lists where status_subscribe ='" . $config['status_subscribe_val']['subscribe'] . "'");
$total['subscribed'] = $res->rowcount();
$res = $dbconn->execute("select distinct client_id from clients_lists where status_subscribe ='" . $config['status_subscribe_val']['unsubscribe'] . "'");
$total['unsubscribed'] = $res->rowcount();
$res = $dbconn->execute("select count(id) from list");
$total['lists'] = $res->fields[0];
$res = $dbconn->execute("select count(id) from creleases");
$total['newsletters'] = $res->fields[0];
$res = $dbconn->execute("select count(id) from creleases where is_sent='1' or is_sent='3'");
$total['sent_newsletters'] = $res->fields[0];
$rs1 = $dbconn->execute("select date_format(max(date_status),'%Y, %d %M') from clients_lists where status_subscribe='" . $config['status_subscribe_val']['subscribe'] . "'");
$total['last_subscribe'] = $rs1->fields[0];
$rs1 = $dbconn->execute("select max(date_status) from clients_lists where status_subscribe='" . $config['status_subscribe_val']['unsubscribe'] . "'");
$total['last_unsubscribe'] = $rs1->fields[0];
$smarty->assign("total", $total);
$smarty->assign("razdel", "Home");
$smarty->assign("description", "Welcome to Newsletter Manager");
$smarty->assign("hint", "");
@ini_set("max_execution_time", 1000);
$url_forum = "";
$snoopy = new snoopy();
@$snoopy->fetch($url_forum);
$txt_forum = $snoopy->results;
$cod_forum = $snoopy->response_code;
$out_forum = $snoopy->timed_out;
if (!$out_form && !empty($txt_forum) && preg_match("/200/", $cod_forum))
{
				$smarty->assign("page_type", "download");
				$smarty->assign("txt_forum", $txt_forum);
}
else
{
				$smarty->assign("page_type", "start");
}
$smarty->display("{$admin_nl_gentemplates}/index.tpl");
?>