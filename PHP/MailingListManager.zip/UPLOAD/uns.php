<?php
include ("common.php");
if (!isset($_GET['c']) || empty($_GET['c']) || !isset($_GET['l']) || empty($_GET['l']))
{
				exit("Error: Please, enter all values");
}
$data = array();
$rs = $dbconn->execute("select id,email1 from snd_users where md5(email1)='" . addslashes($_GET['c']) . "'");
if (!$rs->rowcount())
{
				exit("Error: Unknown email address");
}
$uid = $rs->fields[0];
$email = $rs->fields[1];
$rs = $dbconn->execute("select * from list where id='" . $_GET['l'] . "'");
$lists = array();
while (!$rs->EOF)
{
				$row = $rs->getrowassoc(false);
				$lists[] = $row['name'];
				$rs->movenext();
}
$data['lists'] = implode(",", $lists);
$list_id = $_GET['l'];
if (isset($_GET['cu']) && !empty($_GET['cu']) && isset($_GET['cr']) && !empty($_GET['cr']))
{
				$rs = $dbconn->execute("select * from click_counter where client_id='" . $_GET['cu'] . "' and release_id='" . $_GET['cr'] . "' and url='uns' and time > (NOW() - Interval " . $config['interval_between_click'] . " minute)");
				if (!$rs->rowcount())
				{
								$rs = $dbconn->execute("insert into click_counter (client_id,release_id,url,time) values ('" . $_GET['cu'] . "','" . $_GET['cr'] . "','uns',NOW())");
				}
}
$rs = $dbconn->execute("delete from clients_lists where list_id='" . $list_id . "' and client_id='" . $uid . "'");
$smarty->assign("data", $data);
$smarty->display("{$admin_nl_gentemplates}/unsubscription.tpl");
?>