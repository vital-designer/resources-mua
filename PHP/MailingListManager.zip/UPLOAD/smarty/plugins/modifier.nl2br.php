<?php
function smarty_modifier_nl2br($string)
{
				return nl2br($string);
}
?>