<?  
//** TEST EMAIL SCRIPT
//** =================
//** Copyright (c) William Fowler (wmfwlr AT cogeco DOT ca)
//** Released under GNU General Public License (GPL), Version 2
//** http://opensource.org/licenses/gpl-license.php
//**
//** A script that creates a test email message using the Email class and
//** sends it. Demonstrates the use of attachments and how
//** 'multipart/alternative' emails can be sent. Change the settings for
//** your own testing. environment. Please check the following list of
//** common mistakes before contacting me :
//**
//** (1) if the SMTP server listed in php.ini does not relay email for the
//**     message sender no email will be sent and the standard mail() warningl 
//**     will be output. 
//**
//** (2) all directories where attachments are referenced must be readable 
//**     by PHP.
//**
//** (3) if the underlying SMTP server is QMail change the EmailNewLine
//**     constant in class.Email.php to be "\n" instead of "\r\n". See the
//**     class file for details.
//**
//** -------------------------
//** September 27, 2004 (v2.0)

  include('class.Email.php');

//**EMAIL_SETTINGS************************************************************
//** determine who is sending the email and where it is going. All recipiant
//** address fields (CC,BCC,TO) can be multiple email addresses separated by
//** commas.

  $Sender = 'you@there.com'; 
  $Recipiant = 'me@here.com'; 
  $Cc = 'them@there.com'; 
  $Bcc = ''; 

  $Subject = 'A Test Email!';

//** you can still specify custom headers as long as you use the constant
//** 'EmailNewLine' to separate multiple headers.

  $CustomHeaders= '';

//** create the new email message. All constructor parameters are optional and
//** can be set later using the appropriate property.

  $message = new Email($Recipiant, $Sender, $Subject, $CustomHeaders);
  $message->Cc = $Cc; 
  $message->Bcc = $Bcc; 
  
//**SETTING_CONTENT***********************************************************
//** email messages can have different versions of the same content. This is
//** known as a 'multipart/alternative' message. You can set either the text
//** version, HTML version, or both.

//** set the text version of the email message.

  $text = 'Hello World!';
  $message->SetTextContent($text);

//** set the HTML version of the email message.

  $html = '<font color="red"><b>Hello World!</b></font>';
  $message->SetHtmlContent($html);

//** NOTE: the standard (RFC 1521) states that content versions should be 
//** added in order from simplest to most complex. This means it is always
//** best to set the text content for an email before any other version (i.e.
//** HTML or other).

//**ATTACHMENTS***************************************************************
//** get the full path to the file to be attached as well as the standard
//** MIME type for the file. This value can be left blank.

  $pathToServerFile = __FILE__;        //** attach this very PHP script.
  $serverFileMimeType = 'text/plain';  //** this PHP file is plain text.

//** attach the given file to be sent with this message. ANy number of
//** attachments can be associated with an email message. 

//** NOTE: If the file path does not exist or cannot be read by PHP the file
//** will not be sent with the email message.

  $message->Attach($pathToServerFile, $serverFileMimeType);

/* EXAMPLE ONLY
//**ADDITIONAL_CONTENT********************************************************
//** data other than text and HTML can be sent as a content version for an
//** email message. A common example is Richtext. The only limit on what can 
//** be sent as content is really the capabilities of the client email 
//** application. Most email clients won't support much more than text and
//** HTML, wheas Outlook will probably support other Microsoft formats (i.e
//** Word, Excel, etc).

//** get the full path to the file to be used as a version as well as the 
//** standard MIME type for the file.

  $pathToServerFile = 'HelloWorld.doc';      //** use Word doc as version.
  $serverFileMimeType = 'application/word';  //** standard word MIME type.

//** set the file version of the content.

  $message->SetFileContent($pathToServerFile, $serverFileMimeType);

//** NOTE: even when I tested the above Word attachment outlook displayed
//** the HTML version. Stick to text, HTML, and at best other text formats
//** when using content versions.

  EXAMPLE ONLY */

//**SEND_EMAIL****************************************************************
//** send the email message.

  $message->Send();
?>
