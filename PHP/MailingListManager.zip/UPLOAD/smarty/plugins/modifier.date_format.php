<?php
function smarty_modifier_date_format($string, $format = "%b %e, %Y", $default_date = null)
{
				if ($string != "")
				{
								return strftime($format, smarty_make_timestamp($string));
				} else
								if (isset($default_date) && $default_date != "")
								{
												return strftime($format, smarty_make_timestamp($default_date));
								} else
								{
												return;
								}
}
require_once ($smarty->_get_plugin_filepath("shared", "make_timestamp"));
?>