<?php
if (function_exists('xdebug_time_index'))
    echo "<p>Generated in " . xdebug_time_index() . " seconds</p>";