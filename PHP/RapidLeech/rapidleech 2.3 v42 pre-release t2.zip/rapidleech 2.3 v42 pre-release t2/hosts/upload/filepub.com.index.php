<?php
$upload_services[]="filepub.com";
$max_file_size["filepub.com"]=500;
$page_upload["filepub.com"] = "filepub.com.php";
?>