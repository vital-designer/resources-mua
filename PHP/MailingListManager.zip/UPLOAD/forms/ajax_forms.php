<?php
include ("../include/class.form.php");
include_once ("../common.php");
header("Content-type: text/html; charset=" . $charset);
$smarty->assign("template_root", $config['admin_theme_path']);
@$sel = $_REQUEST['sel'];
switch ($sel)
{
				case "get_section_attrs":
								$id_section = $_REQUEST['id_section'];
								$id_form = $_REQUEST['id_form'];
								$form = new form($dbconn, $config);
								$section = $form->getsection($id_section);
								$attrs = $form->getsectionattributes($id_section, $total_count, $id_form);
								$view_type = "section";
								$smarty->assign("view_type", $view_type);
								$smarty->assign("attrs", $attrs);
								$smarty->assign("total_count", $total_count);
								$smarty->assign("section", $section);
								$smarty->assign("id_section", $id_section);
								$smarty->display("{$admin_nl_gentemplates}/ajax_form_sec_attrs.tpl");
								break;
				case "get_form_attrs":
								$id_form = $_REQUEST['id_form'];
								$form = new form($dbconn, $config);
								$attrs = $form->getformattributes($id_form);
								$strSQL = "SELECT name FROM form WHERE id=" . $id_form;
								$rs = $dbconn->execute($strSQL);
								$form_name = $rs->fields[0];
								$view_type = "form";
								$smarty->assign("view_type", $view_type);
								$smarty->assign("form_name", $form_name);
								$smarty->assign("id_form", $id_form);
								$smarty->assign("attrs", $attrs);
								$smarty->display("{$admin_nl_gentemplates}/ajax_form_sec_attrs.tpl");
								break;
				case "update_form":
								$id_block = $_REQUEST['id_block'];
								$attrs_str = $_REQUEST['attrs_str'];
								$attrs = explode(",", $attrs_str);
								$form = new form($dbconn, $config);
								$form->updateform($id_block, $attrs);
}
?>
