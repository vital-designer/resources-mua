--
-- Table structure for table `wave_comments`
--

CREATE TABLE `wave_comments` (
  `id` int(11) NOT NULL auto_increment,
  `parent` int(11) NOT NULL default '0',
  `usr` varchar(16) collate utf8_unicode_ci NOT NULL default '',
  `comment` text collate utf8_unicode_ci NOT NULL,
  `dt` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `parent` (`parent`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `wave_comments`
--

INSERT INTO `wave_comments` VALUES(1, 0, 'Tutorialzine', 'This is a demo for a Tutorialzine tutorial about creating a Google Wave-like history slider.<br /><br />\r\nTo get started, just drag the slider above, and this thread will be reverted to a past state.', '2009-10-24 03:58:08');
INSERT INTO `wave_comments` VALUES(2, 0, 'Curious', 'Is HTML allowed in the comments?', '2009-10-24 03:59:44');
INSERT INTO `wave_comments` VALUES(3, 2, 'Tutorialzine', 'Nope. Also the messages in this demo are deleted every hour to prevent spamming.', '2009-10-24 04:00:15');
INSERT INTO `wave_comments` VALUES(4, 1, 'Tutorialzine', 'In this tutorial we are using <b>PHP</b>, <b>MySQL</b>, <b>jQuery</b> and <b>CSS</b>. The slider was created with <b>jQuery UI</b>. <a href="http://tutorialzine.com/2009/10/google-wave-history-slider-jquery/" target="_blank">View the tutorial</a>.', '2009-10-24 04:01:34');
INSERT INTO `wave_comments` VALUES(5, 2, 'Curious', 'Thanks! Also i noticed that you can click, rather than drag the slider.Great!', '2009-10-24 04:11:48');
