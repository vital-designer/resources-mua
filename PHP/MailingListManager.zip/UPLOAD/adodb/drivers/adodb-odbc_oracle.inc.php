<?php
if (!defined("_ADODB_ODBC_LAYER"))
{
				include (ADODB_DIR . "/drivers/adodb-odbc.inc.php");
}
class adodb_odbc_oracle extends adodb_odbc
{
				var $databaseType = "odbc_oracle";
				var $replaceQuote = "''";
				var $concat_operator = "||";
				var $fmtDate = "'Y-m-d 00:00:00'";
				var $fmtTimeStamp = "'Y-m-d h:i:sA'";
				var $metaTablesSQL = "select table_name from cat";
				var $metaColumnsSQL = "select cname,coltype,width from col where tname='%s' order by colno";
				function &metatables()
				{
								if ($this->metaTablesSQL)
								{
												$rs = $this->execute($this->metaTablesSQL);
												if ($rs === false)
												{
																return false;
												}
												$arr = $rs->getarray();
												$arr2 = array();
												$i = 0;
												for (; $i < sizeof($arr); ++$i)
												{
																$arr2[] = $arr[$i][0];
												}
												$rs->close();
												return $arr2;
								}
								return false;
				}
				function &metacolumns($table)
				{
								if (!empty($this->metaColumnsSQL))
								{
												$rs = $this->execute(sprintf($this->metaColumnsSQL, strtoupper($table)));
												if ($rs === false)
												{
																return false;
												}
												$retarr = array();
												while (!$rs->EOF)
												{
																$fld = new adofieldobject();
																$fld->name = $rs->fields[0];
																$fld->type = $rs->fields[1];
																$fld->max_length = $rs->fields[2];
																$retarr[strtoupper($fld->name)] = $fld;
																$rs->movenext();
												}
												$rs->close();
												return $retarr;
								}
								return false;
				}
				function _connect($argDSN, $argUsername, $argPassword, $argDatabasename)
				{
								global $php_errormsg;
								$php_errormsg = "";
								$this->_connectionID = odbc_connect($argDSN, $argUsername, $argPassword, SQL_CUR_USE_ODBC);
								$this->_errorMsg = $php_errormsg;
								$this->execute("ALTER SESSION SET NLS_DATE_FORMAT='YYYY-MM-DD HH24:MI:SS'");
								return $this->_connectionID != false;
				}
				function _pconnect($argDSN, $argUsername, $argPassword, $argDatabasename)
				{
								global $php_errormsg;
								$php_errormsg = "";
								$this->_connectionID = odbc_pconnect($argDSN, $argUsername, $argPassword, SQL_CUR_USE_ODBC);
								$this->_errorMsg = $php_errormsg;
								$this->execute("ALTER SESSION SET NLS_DATE_FORMAT='YYYY-MM-DD HH24:MI:SS'");
								return $this->_connectionID != false;
				}
}
class adorecordset_odbc_oracle extends adorecordset_odbc
{
				var $databaseType = "odbc_oracle";
				function adorecordset_odbc_oracle($id)
				{
								return $this->adorecordset_odbc($id);
				}
}
?>