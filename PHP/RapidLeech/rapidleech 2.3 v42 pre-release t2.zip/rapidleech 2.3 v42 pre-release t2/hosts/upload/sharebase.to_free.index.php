<?php
$upload_services[]="sharebase.to_free";
$max_file_size["sharebase.to_free"]=200;
$page_upload["sharebase.to_free"] = "sharebase.to_free.php";  
?>