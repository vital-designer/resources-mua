<?php
$upload_services[]="uploadmachine.com_member";
$max_file_size["uploadmachine.com_member"]=750;
$page_upload["uploadmachine.com_member"] = "uploadmachine.com_member.php";  
?>