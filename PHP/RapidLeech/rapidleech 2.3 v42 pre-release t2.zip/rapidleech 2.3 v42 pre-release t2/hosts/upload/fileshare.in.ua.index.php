<?php
$upload_services[]="fileshare.in.ua";
$max_file_size["fileshare.in.ua"]=2000;
$page_upload["fileshare.in.ua"] = "fileshare.in.ua.php"; 
?>
