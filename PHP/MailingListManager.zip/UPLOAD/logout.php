<?php
include ("common.php");
$GLOBALS['_SESSION'] = array();
header("Location: login.php");
?>