<?php
$data = implode("", file(dirname(__file__) . "/constants.xml"));
$xml_parser = xml_parser_create();
xml_parser_set_option($xml_parser, XML_OPTION_SKIP_WHITE, 1);
xml_parser_set_option($xml_parser, XML_OPTION_CASE_FOLDING, 0);
xml_parse_into_struct($xml_parser, $data, $vals, $index);
xml_parser_free($xml_parser);
foreach ($vals as $i => $node)
{
				if ($node['type'] == "complete")
				{
								define($node['tag'], $node['value']);
				}
}
unset($data);
unset($vals);
unset($index);
unset($node);
?>
