<?php

class Author {
    public $name;
}