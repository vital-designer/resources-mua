<?php 
$upload_services[] = "shareator.com";
$max_file_size["shareator.com"] = 250;
$page_upload["shareator.com"] = "shareator.com.php";
?>