<?php
include ("../common.php");
include ("../include/smtp_servers_function.php");
$section = "settings";
if (isset($_GET['id']))
{
				if (!isset($_POST['action']) || $_POST['action'] != "change")
				{
								if ($_GET['id'] == 0)
								{
												$right_name = "create_server";
												check_right($section, $right_name);
												$smarty->assign("razdel", "Settings");
												$smarty->assign("description", "Add SMTP Server");
												$smarty->assign("hint", "Complete the form and click \"Save\" button to add a new SMTP server.");
												$content = getblankcontent();
								}
								else
								{
												$right_name = "view_server";
												check_right($section, $right_name);
												$smarty->assign("razdel", "Settings");
												$smarty->assign("description", "SMTP Server Editing");
												$smarty->assign("hint", "Edit the values in the fields of this SMTP server");
												$content = getcontent($_GET['id']);
								}
								$smarty->assign("rel", $content);
								$smarty->display("{$admin_nl_gentemplates}/smtp_servers_change_smtp.tpl");
				}
				else
				{
								if ($_GET['id'] == 0 || $_GET['id'] == "0")
								{
												if (isset($_POST['action']) && $_POST['action'] == "change")
												{
																addserver();
												}
								}
								else
								{
												$right_name = "edit_server";
												check_right($section, $right_name);
												updserver();
								}
								header("Location: index.php");
				}
}
else
{
				header("Location: index.php");
}
?>
