<?php
$upload_services[]="upwap.ru";
$max_file_size["upwap.ru"]=30;
$page_upload["upwap.ru"] = "upwap.ru.php";  
?>