<?php
function listcensors()
{
				global $smarty;
				global $dbconn;
				global $config;
				global $admin_nl_gentemplates;
				$file_name = isset($_SERVER['PHP_SELF']) ? basename($_SERVER['PHP_SELF']) : "reg_exps.php";
				$form = new form($dbconn, $config);
				$regs = $form->getregexps();
				foreach ($regs as $index => $reg_exp)
				{
								$regs[$index]['del_link'] = $file_name . "?sel=del_censor&id=" . $reg_exp['id'];
				}
				$form_add['action'] = $file_name . "?sel=add_censor";
				$form_save['action'] = $file_name . "?sel=save_censors";
				$smarty->assign("regs", $regs);
				$smarty->assign("form_add", $form_add);
				$smarty->assign("form_save", $form_save);
				$smarty->display("{$admin_nl_gentemplates}/forms_reg_exps.tpl");
}
function addcensor()
{
				global $dbconn;
				global $config;
				$new_reg['name'] = $_POST['new_name'];
				$new_reg['reg_exp'] = $_POST['new_regexp'];
				$form = new form($dbconn, $config);
				$form->addnewregexp($new_reg);
				listcensors();
}
function delcensor($id)
{
				global $dbconn;
				global $config;
				$form = new form($dbconn, $config);
				$form->delregexp($id);
				listcensors();
}
function savecensors()
{
				global $dbconn;
				global $config;
				$regs = array();
				$i = 0;
				foreach ($GLOBALS['_POST']['regs'] as $key => $value)
				{
								$regs[$i]['reg_exp'] = $value;
								$regs[$i]['id'] = $key;
								++$i;
				}
				$form = new form($dbconn, $config);
				$form->updateregexps($regs);
				listcensors();
}
include ("../common.php");
include ("../include/forms_function.php");
include ("../include/class.form.php");
$section = "forms";
$right_name = "view";
check_right($section, $right_name);
$sel = $_GET['sel'] ? $_GET['sel'] : $_POST['sel'];
$smarty->assign("razdel", "Forms");
$smarty->assign("description", "Manage Patterns");
$smarty->assign("hint", "Here  you can and or edit the rules for filling this or that field in the subscription form. The system will check whether the field is filled in accord with these rules. If the field was filled incorrectly, the user will get a corresponding message.");
switch ($sel)
{
				case "censor":
								listcensors();
								break;
				case "add_censor":
								addcensor();
								break;
				case "del_censor":
								delcensor($_REQUEST['id']);
								break;
				case "save_censors":
								savecensors();
								break;
				default:
								listcensors();
								break;
}
?>
